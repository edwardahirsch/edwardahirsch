// Source code for hgen2 generator of satisfiable Boolean formulas in CNF
// in SAT Competition 2002 format. Written by Edward A. Hirsch,
// the original may be found at http://logic.pdmi.ras.ru/~hirsch/
// 
// DISCLAIMER: I assume no responsibility for: that this source code
//             corresponds to the ALGORITHM presented below,
//             produces the same benchmarks as were used in some particular 
//             code used in some particular competition or paper, or for
//             anything else. However, I did my best to satisfy the above
//             statements. --Edward A. Hirsch
//
// CHECKSUM: "grep -v grep unigen.c | md5sum" for this file should produce cab7bafdc52405abcca555efbbc1f5d8

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <math.h>

// ALGORITHM (n variables, assumes "define SATCOMP" below):
//   1. Generate satisfying assignment.
//   2. Generate 3.5n 3-clauses one by one:
//   2.1. Generate all but the last (i.e., two first) literals in a clause 
//        as follows:
//   2.1.1. Computer the number of "available" literals.
//          A literal is available is
//          a. There is no less frequent literal.
//          b. This variable did not appear in the current clause.
//          c. A variable dependent on it (=occurred together) did not appear here.
//          d. A variable dependent on a dependent variable did not appear here.
//          e. The opposite literal is satisfying or occurs more times.
//   2.1.2. Choose a literal from them uniformly at random.
//   2.2. If the clause is already satisfied, generate the last literal similarly.
//        Otherwise generate it in the same way except for replacing 2.1.1(e)
//        by "This literal satisfies the chosen assignment".
//   3. If at any step there are no available literals, restart the whole process 2.

#define SATCOMP // Respect SAT2002 Competition format: 
                // accept the number of variables and seed as the parameters 
                // and output a formula on stdout.
                // Otherwise would generate formulas for user-defined
                // clause length, number of variables, maximum seed,
                // and, eventually, number of occurrences and number of clauses.

//-- specific hgen2 settings, as opposed to other hgenX --
#define UNIFORM // Try to keep the number of occurrences the same for all literals.
#define ASYMM   // Given a pre-defined satisfied assignment,
                // always choose an unsatisfied literal from a, -a if in doubt.
                // Intended solely for fooling greedy algorithms.

#define MATRIX      // Do not allow two variables to occur together twice.
#define PREMATRIX   // Do not allow variable a occur with b if both occurred with c.
#define SATISFIABLE // Generate forced satisfiable formulas.
#define SPECclen 3  // Generate 3-CNF
#ifndef SATCOMP     // ...then don't know clause length in advance.
#define SPECncla (nvar*nocc/clen)
#else               // ...then it's 3-CNF, and 3.5n clauses are perfect.
#define SPECncla ((LLI)(nvar*3.5))
#endif
#define SPECnocc 0 // nocc/2 is the maximum number of occurrences of a literal.
                   // It is not used if UNIFORM is set.

//------ typedefs -------------

typedef long long int LLI;
typedef long double LD;

//----- naming conventions ----
char prefix[250]; // Prefix of generic names of such benchmarks, 
                  // created by makeprefix().
void makeprefix() 
{
  sprintf(prefix,"hgen");
#ifdef SATISFIABLE
  strcat(prefix,"-sat");
#endif
#ifdef UNIFORM
  strcat(prefix,"-uniform");
#endif
#ifdef ASYMM
  strcat(prefix,"-asymm");
#endif
#ifdef MATRIX
#ifdef PREMATRIX
  strcat(prefix,"-notriples");
#else
  strcat(prefix,"-nopairs");
#endif
#endif
}
//-----------------------------

LLI nvar, clen, nocc, ncla, seed; // number of variables, clause length,
                                  // nocc (unused), number of clauses, seed
char foname[500];   // output file name (temporary, if SATCOMP is defined)
char dirname[250];  // output directory name (temporary, if SATCOMP is defined)
FILE *fo;           // output file

LLI*iused=NULL; // temporary
LLI*used; //used[l]: how many literal occurrences of l have we used
LLI*cused=NULL; //cused[v]: did we use v or -v in this clause
LLI*prematrix=NULL; //...of dependency graph
LLI*matrix=NULL; //...of the square of dependency graph
LLI*clause=NULL; //current clause
LLI counter; //length of clause

#define MAXLEN 65000
char buffer[MAXLEN+1]; // for reading from temporary file

LLI getnocc(LLI clen) // crude heuristic to compute nocc for given clause length 
                      // (nocc is unused)
{
 return 2*(((LLI)(exp(clen)/1.5))/2);
}

int *GBLSAT=NULL; // global pointer to the chosen satisfying assignment 

void initavail() // initialize structures that inform us which literals 
                 // are currently allowed
{
 if (iused) free(iused);
 iused=(LLI*)calloc(2*nvar+1,sizeof(LLI));
 used=iused+nvar; //so that we could refer to used[-van]
 if (cused) free(cused);
 cused=(LLI*)calloc(nvar+1,sizeof(LLI));
#ifdef MATRIX
 if (matrix) free(matrix);
 matrix=(LLI*)calloc((nvar+1)*(nvar+1),sizeof(LLI));
#ifdef PREMATRIX
 if (prematrix) free(prematrix);
 prematrix=(LLI*)calloc((nvar+1)*(nvar+1),sizeof(LLI));
#endif
#endif
 if (clause) free(clause);
 clause=(LLI*)calloc(nvar+1,sizeof(LLI));
 counter=0;
}

inline int bval(LLI lit) // literal sign (truth value)
{
  if (lit>0) return 1; else return 0;
}

LLI MIN; // the smallest number of occurrences
int avail(LLI lit) // check if it is legal to put lit now into the formula
                   // (assuming no responsibility that this clause is satisfied)
{
#ifdef UNIFORM
#ifdef ASYMM
  if (used[lit]>MIN) return 0; // too frequent
  if (GBLSAT[abs(lit)]==bval(lit)) if (used[lit]>=used[-lit]) return 0; 
                               // put the False counterpart first
#else
  if (used[lit]>MIN) return 0; // too frequent
#endif
#else
#ifdef ASYMM
  if (used[lit]>nocc/2) return 0; // too frequent
  if (GBLSAT[abs(lit)]==bval(lit)) if (used[lit]>=used[-lit]) return 0; 
                               // put the False counterpart first
#else
  if (used[lit]>nocc/2) return 0; // too frequent
#endif
#endif
  if (cused[abs(lit)]) return 0; // already disabled for this clause (eg, occurred)
  return 1;
}

int normavail(LLI lit) // version of avail() for use by savail() below:
                       // does not care about putting False literals first
{
#ifdef UNIFORM
#ifdef ASYMM
  if (used[lit]>MIN) return 0; // too frequent
#else
  if (used[lit]>MIN) return 0; // too frequent
#endif
#else
#ifdef ASYMM
  if (used[lit]>nocc/2) return 0; // too frequent
#else
  if (used[lit]>nocc/2) return 0; // too frequent
#endif
#endif
  if (cused[abs(lit)]) return 0; // already disabled for this clause (eg, occurred)
  return 1;
}

int savail(LLI lit, int*satisfying)
                   // check if it is legal to put lit now into the formula
                   // including the check it satisfies the satisfying assignment
{
  if (normavail(lit)) // not too frequent or disabled for this clause
  {
    if (satisfying[abs(lit)]==bval(lit)) // must be True
    {
      return 1;
    }
  }
  return 0; 
}

LLI navail() // Compute the number of avail()'able literals we could choose from.
{ 
  LLI ret=0; // No good variable found yet.
#ifdef UNIFORM
  MIN=(nvar+1)*(nocc*2+1); // The least number of occurrences (initialized).
  for (LLI van=1; van<=nvar; van++) // Check all variables, compute MIN.
  {
#ifdef ASYMM
  if (avail(van))                                //Literal van is available and...
    if ((GBLSAT[van]==0)||(used[van]<used[-van]))//the opposite is unsat or 
                                                 //less frequent and...
      if (used[van]<MIN)                         //there is no less frequent literal
        MIN=used[van];                           //then OK -- update MIN.
  if (avail(-van))                               //The same with negative literal...
    if ((GBLSAT[van]==1)||(used[-van]<used[van]))
      if (used[-van]<MIN) //BUG
        MIN=used[-van]; //BUG
#else
    if (avail(van)) if ((used[van]<MIN)) MIN=used[van];    //Simplified version
    if (avail(-van)) if ((used[-van]<MIN)) MIN=used[-van]; //of the above.
#endif
  }
#endif
  for (LLI van=1; van<=nvar; van++) // Check all variables, now MIN is updated, 
                                    // count!
  {
#ifdef UNIFORM
#ifdef ASYMM
    if ((used[van]<=MIN)&&((GBLSAT[van]==0)||(used[van]<used[-van]))&&avail(van)) ret++;
    if ((used[-van]<=MIN)&&((GBLSAT[van]==1)||(used[-van]<used[van]))&&avail(-van)) ret++;
#else
    if ((used[van]<=MIN)&&avail(van)) ret++;
    if ((used[-van]<=MIN)&&avail(-van)) ret++;
#endif
#else
#ifdef ASYMM
    IE(200,"Not implemented.");
#endif
    if (avail(van)) ret++;
    if (avail(-van)) ret++;
#endif
  }
  return ret;
}

LLI nsavail(int*satisfying) // Computer the number of savail()'able literals
                            // we could choose from. Similar to navail()
                            // except for we choose from satisfying literals,
                            // hence we use savail() and not avail().
{
  LLI ret=0;
#ifdef UNIFORM
  MIN=(nvar+1)*(nocc*2+1);
  for (LLI van=1; van<=nvar; van++)
  {
    if (savail(van,satisfying)) if ((used[van]<MIN)) MIN=used[van];
    if (savail(-van,satisfying)) if ((used[-van]<MIN)) MIN=used[-van];
  }
#endif
  for (LLI van=1; van<=nvar; van++)
  {
#ifdef UNIFORM
    if ((used[van]<=MIN)&&savail(van,satisfying)) ret++;
    if ((used[-van]<=MIN)&&savail(-van,satisfying)) ret++;
#else
    if (savail(van,satisfying)) ret++;
    if (savail(-van,satisfying)) ret++;
#endif
  }
  return ret;
}

void updateavail(LLI lit) // Update all tables by the fact that lit 
                          // (or end of clause) came.
{
  if (!lit) // New clause: empty "temporarily disabled" list and the clause itself.
  {
    if (cused) free(cused);
    cused=(LLI*)calloc(nvar+1,sizeof(LLI));
    if (clause) free(clause);
    clause=(LLI*)calloc(nvar+1,sizeof(LLI));
    counter=0;
    return;
  }
  else // New literal in the same clause: put it to the clause and update tables.
  {
    cused[abs(lit)]=1; // Disable this variable for this clause.
    used[lit]++;       // One more occurrence of this literal.
#ifdef MATRIX
#ifdef PREMATRIX
    for (LLI vac=0; vac<counter; vac++) // Update the dependence matrix.
    {
      matrix[abs(lit)*(nvar+1)+abs(clause[vac])]=
      (matrix[abs(clause[vac])*(nvar+1)+abs(lit)]=
      (prematrix[abs(lit)*(nvar+1)+abs(clause[vac])]=
      (prematrix[abs(clause[vac])*(nvar+1)+abs(lit)]=1)));
      for (LLI vad=1; vad<=nvar; vad++) // Take square of the dependence matrix. 
      {
	if (prematrix[abs(lit)*(nvar+1)+vad])
	  matrix[abs(clause[vac])*(nvar+1)+vad]=
	  (matrix[vad*(nvar+1)+abs(clause[vac])]=1);
	if (prematrix[abs(clause[vac])*(nvar+1)+vad])
	  matrix[abs(lit)*(nvar+1)+vad]=
	  (matrix[vad*(nvar+1)+abs(lit)]=1);
      }
    }
#else
    for (LLI vac=0; vac<counter; vac++) // Update dependence matrix.
      matrix[abs(lit)*(nvar+1)+abs(clause[vac])]=
      matrix[abs(clause[vac])*(nvar+1)+abs(lit)]=1;
#endif
    for (LLI van=1; van<=nvar; van++)
      if (matrix[abs(lit)*(nvar+1)+van]) cused[van]=1;
#endif
    clause[counter++]=lit;
  }
  return;
}

void IE(int code, LLI a, LLI b) // INTERNAL ERROR: FOR DIAGNOSTICS
{
 fprintf(stderr, "INTERNAL ERROR %ld (lia=%lld, nava=%lld). DUMP FOLLOWS.\n",
		code,a,b);
 LLI lia=0;    //found the lia-th av. position in used[]
 LLI liu=0;    //literal to use
 for (LLI van=1; van<=nvar; van++)
 {
 	fprintf(stderr,"van=%5lld lia=%5lld used=%5lld:%5lld\n",
 			van, lia, used[van], used[-van]);
 	if (avail(van))
 		{ liu= van; break; }
 	if (avail(-van))
 		{ liu=-van; break; }
 }
 fprintf(stderr,"clause: ");
 for (LLI vac=0; vac<counter; vac++)
	 fprintf(stderr,"%lld ",clause[vac]);
 fprintf(stderr,"\n");
 exit(-code); 
}

void cat(char*foname) // Print temporary file to stdout.
{
  FILE *cf=fopen(foname,"rt");
  if (!cf) IE(21,0,0);

  while (!feof(cf))
    if (fgets(buffer,MAXLEN,cf)) printf("%s",buffer);

  fflush(stdout);
  fclose(cf);
}

//----------- main program ------------
int main(int argc,char *argv[])
{
  // Process the arguments...
#ifdef SATCOMP
  if (argc != 3)
  {     
    fprintf(stderr, "\nUsage: %s number-of-variables seed\n\n", argv[0]);
    exit(1);  
  }
  nvar = atol(argv[1]);
  if (nvar<250)
  {     
    fprintf(stderr, "\nThe number of variables should be at least 250.\n\n");
    exit(1);  
  }
  seed = atol(argv[2]);
  clen = SPECclen;
  nocc = SPECnocc;
  ncla = SPECncla;
  sprintf(dirname,"/tmp/unigen-%d-output",getpid());
#else
  if ((argc < 4)||(argc > 6))
  {     
    fprintf(stderr, "\nUsage: %s clen nvar seed [nocc [ncla]]\n\n", argv[0]);
    exit(1);  
  }
  clen = atol(argv[1]); 
  nvar = atol(argv[2]);
  nocc = (argc>=5)?atol(argv[4]):getnocc(clen);
  ncla = (argc>=6)?atol(argv[5]):SPECncla;
  seed = atol(argv[3]);
  sprintf(dirname,"OUTPUTS");
#endif
  if (mkdir(dirname,0xFFFF)) if (errno != EEXIST)
  {
    printf("Failed to mkdir %s\n",dirname);
    IE(1,0,0);
  }

  makeprefix();
#ifndef SATCOMP
  sprintf(dirname,"OUTPUTS/D%s_%02lld-CNF-%03lld_v%05lld_c%06lld",
		    prefix,clen,nocc,nvar,ncla);
  if (mkdir(dirname,0xFFFF)) if (errno != EEXIST)
  {
    printf("Failed to mkdir %s\n",dirname);
    IE(1,0,0);
  }
#endif
  

#ifdef SATCOMP
  LLI csee=seed; // The seed is supplied by the user.
#else
  for (LLI csee=1; csee<=seed; csee++) // Try all seeds 1..supplied by the user
                                       // generating the total of "seed" formulas.
  {
#endif
   int success=0; // Generated successfully?
   sprintf(foname,"%s/%s_%lld-CNF-%lld_v%lld_c%lld_s%05lld.cnf",
 		   dirname, prefix, clen,    nocc, nvar, ncla,  csee); // file name
   
#ifndef SATCOMP
   fprintf(stderr, 
 	"Parameters: elen=%lld, clen=%lld, nocc=%lld, nvar=%lld, ncla=%lld, seed=%lld, ",
 	ncla*clen, clen, nocc, nvar, ncla, csee); // DEBUG
#endif
   srandom(csee); // Initialize pseudorandom generator with the current seed.
#ifdef SATISFIABLE
   int satisfying[nvar+1];   // Satisfying assignment.
   GBLSAT=&(satisfying[0]);  // Export its address.
   for (LLI van=1; van<=nvar; van++) satisfying[van]=random()%2; // Generate it.
#endif
   while (!success) // Until formula is generated OK.
   {
    fo=fopen(foname,"wt"); // Will write to "fo".
    if (!fo)
    {     
      fprintf(stderr, "ERROR: Cannot open output file %s!\n", foname);
      exit(2);  
    }
  
    fprintf(fo,"c Command line:"); // Some initial fields...
    for (int clp=0; clp<argc; clp++) fprintf(fo," %s",argv[clp]);
    fprintf(fo,"\nc Original file name: %s\n",foname);  // cnf file comment
    fprintf(fo,"p cnf %lld %lld\n",nvar,ncla); // cnf file header
  
  
    initavail(); // Initialize tables.
  	  
    for (LLI cln=0; cln<ncla; cln++) // Will generate ncla clauses one by one...
    {
#ifdef SATISFIABLE
  	  for (LLI lin=0; lin<clen-1; lin++) // clen-1 literals each, one by one;
	                                     // the last (clen-th) literal will be 
	                                     // generated separately to ensure
	                                     // satisfiability.
#else
  	  for (LLI lin=0; lin<clen; lin++) // clen literals each, one by one.
#endif
	  {
  		LLI nava=navail(); // Compute the number of available literals.
    		if (!(nava=navail())) // No variables available -- failure!
  		{
#ifndef SATCOMP
  			fprintf(stderr,"FAIL(%lld:%lld) ",cln,lin);
			fflush(stderr);
#endif
  			fprintf(fo,"0\n");
  			fclose(fo); 
  			unlink(foname);
  			goto nextcsee; // Failure, try again.
  		}
		// Now generate a variable from avail()'able list.
  	  	LLI lis=random()%nava; //Will take the lis-th available literal.
  		LLI lia=0;	       //Found the lia-th available literal.
  		LLI liu=0;	       //Literal to use.
  		for (LLI van=1; van<=nvar; van++) // Search...
  		{
  			if (avail(van))  // Found next available literal!
  				if (lis==(lia++)) { liu= van; break; } // Our!
  			if (avail(-van)) // Found next available literal!
  				if (lis==(lia++)) { liu=-van; break; } // Our!
  		}
  		if (!liu) IE(10,lia,nava); // Should not happen.
  			
  		fprintf(fo,"%lld ",liu); // Generated literal "liu".
  		updateavail(liu);
  	  }
#ifdef SATISFIABLE
          { // Generate the last literal ensuring the clause is satisfied.
	    int satisfied=0;
	    for (LLI vic=0; vic<counter; vic++) // Is it already satisfied?
	      if (satisfying[abs(clause[vic])]==bval(clause[vic]))
	      { 
		satisfied=1; 
		break; 
	      }
	    if (satisfied) // Already satisfied, generate as usual.
	    {
  		LLI nava=navail(); // Computer the number of available literals.
    		if (!(nava=navail()))
  		{
#ifndef SATCOMP
  			fprintf(stderr,"N-FAIL(%lld:%lld) ",cln,clen-1); //DEBUG
			fflush(stderr);
#endif
  			fprintf(fo,"0\n");
  			fclose(fo); 
  			unlink(foname);
  			goto nextcsee; //Failure, try again.
  		}
  	  	LLI lis=random()%nava; //See similar lines above...
  		LLI lia=0;	       
  		LLI liu=0;	       
  		for (LLI van=1; van<=nvar; van++)
  		{
  			if (avail(van))
  				if (lis==(lia++)) { liu= van; break; }
  			if (avail(-van))
  				if (lis==(lia++)) { liu=-van; break; }
  		}
  		if (!liu) IE(10,lia,nava); 
  			
  		fprintf(fo,"%lld ",liu); // Generated literal "liu".
  		updateavail(liu);
  	  }
	      else // Not satisfied yet, must choose True literal now.
	      {
		  
  		LLI nava;
    		if (!(nava=nsavail(satisfying))) // Compute the number of 
		                                 // available satisfied literals.
  		{
#ifndef SATCOMP
  			fprintf(stderr,"S-FAIL(%lld:%lld) ",cln,clen-1); //DEBUG
			fflush(stderr);
#endif
  			fprintf(fo,"0\n");
  			fclose(fo); 
  			unlink(foname);
  			goto nextcsee; // Failure, try again.
  		}
  	  	LLI lis=random()%nava; // See similar lines above
  		LLI lia=0;	       // (but this time savail() instead of avail()
  		LLI liu=0;	   
  		for (LLI van=1; van<=nvar; van++)
  		{
  			if (savail(van,satisfying))
  				if (lis==(lia++)) { liu= van; break; }
  			if (savail(-van,satisfying))
  				if (lis==(lia++)) { liu=-van; break; }
  		}
  		if (!liu) IE(110,lia,nava); // Should not happen. 
  			
  		fprintf(fo,"%lld ",liu); // Generated literal "liu".
  		updateavail(liu);
	      }
          }
#endif
  	  fprintf(fo,"0\n"); // End of clause.
  	  updateavail(0);
    }
    fclose(fo);
    success=1; // The benchmark is successfully generated.
#ifdef SATCOMP
    cat(foname); // Output the formula to stdout.
    unlink(foname);
    rmdir(dirname);
    exit(0);
#else
    fprintf(stderr, "Done!%c\n            foname=%s\n", 7, foname);
#endif
nextcsee: ;
   }
#ifndef SATCOMP
  }
#endif
  exit(0);    
}

