// Source code for hgen8 generator of unsatisfiable Boolean formulas in CNF
// in SAT Competition 2003 format. Written by Edward A. Hirsch,
// the original may (or may not) be found at http://logic.pdmi.ras.ru/~hirsch/
// 
// DISCLAIMER: I assume no responsibility for: that this source code
//             corresponds to the ALGORITHM presented below,
//             produces the same benchmarks as were used in some particular 
//             code used in some particular competition or paper, or for
//             anything else. However, I did my best to satisfy the above
//             statements. --Edward A. Hirsch
//
// CHECKSUM: "grep -v grep hgen8.c | md5sum" for this file should produce 903664d938d681443381523f4f11d5f0
//
// ALGORITHM: generate 2-clauses expressing \sum_{i\in I} x_i \le 1
//            for disjoint I's {1..DDD}, {DDD+1..2*DDD}, ...;
//            then generate random clauses of length L (defined below)
//            expressing \sum{i\in J} \lnot x_i \ge 1.
//            Currenly, DDD is set to 5.
//            L is defined so that the latter clauses express 
//            \sum_{all} x_i\ge M+1 while the former give \sum... \le M.
//            Note that for certain DDD and L that would result in PHP.
//
//            The source code below can be used in a more general setting, 
//            where the first type of clauses is generated at random;
//            in particular, when some variables appear in several sums.

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <math.h>

#define SATCOMP // Respect SAT2003 Competition format: 
                // accept the number of variables and seed as the parameters 
                // and output a formula on stdout.

typedef long long int LLI;
typedef long double LD;

LLI nvar, seed, DDD; // DDD is the length of first-type clauses.

#define max(a,b) ((a>b)?(a):(b))
#define min(a,b) ((a<b)?(a):(b))

// Currently, LLImore is not used;
// it could be used in qsort(supset[sup],el,sizeof(LLI),&LLImore);
int LLImore (const void*a,const void*b)
{
  return (*((LLI*)a)>*((LLI*)b));
}

//----------- main program ------------
int main(int argc,char *argv[])
{
  FILE*fo;
  int success=0;
  // Process the arguments...
  if (argc != 3)
  {     
    fprintf(stderr, "\nUsage: %s number-of-variables seed\n\n", argv[0]);
    exit(1);  
  }
  nvar = atol(argv[1]);
  seed = atol(argv[2]);
  DDD = 5; // alternatively, could read it from the user as atol(argv[3]);
  nvar-=nvar%DDD; // make it divisible by DDD
  srandom(seed);

  while (!success) // Until formula is generated OK.
  {
// fo=fopen(foname,"wt"); // could write to "fo", will use stdout instead.
   fo=stdout;
   if (!fo)
   {     
     fprintf(stderr, "ERROR: Cannot open output file %s!\n","stdout"/* or foname*/);
     exit(2);  
   }
 
   fprintf(fo,"c Command line:"); // Comment the benchmark.
   for (int clp=0; clp<argc; clp++) fprintf(fo," %s",argv[clp]);
   fprintf(fo,"\n");
//--------------------------------------------------------------------------------
   //generate M size-K subsets of 1..nvar
#define M ((LLI)(nvar/DDD))
#define K ((LLI)(DDD))
   LLI subset[M][K];                          //the subsets
   LLI *occ=(LLI*)calloc(nvar+1,sizeof(LLI)); //#occurrences of vars in subset[][]
   LLI nextvar=0;
   for (LLI sub=0; sub<M; sub++)
   {
     int*taken=(int*)calloc(nvar+1,sizeof(int)); //so that we could use this code
                                                 //in a more general setting than
                                                 //just taking vars sequentially
     for (LLI el=0; el<K; el++)
     {
       subset[sub][el]=((nextvar++)%nvar)+1;     //el elements are already taken
//     for (LLI var=1; var<=subset[sub][el]; var++) //do not count smaller 
//	 if (taken[var]) subset[sub][el]++;         //taken elements
       occ[subset[sub][el]]++;
       taken[subset[sub][el]]=1;                 //take it
     }
   }
   
   //generate M+1 size-MK/(M+1)^- submultisets of the multiset \bigcup subset[sub]
   LLI L=((M*K)/(M+1));
   if (L<2) { fprintf(stderr,"This choice of parameters failed.\n"); exit(1); }
   LLI clauses[M+M*((K*(K-1))/2)+1][L+2]; // +1 just in case
   LLI NC=0;//current clause
   LLI NL=0;//current literal in clause
   LLI supset[M+1][L];                      //the submultisets
   LLI nAvar=nvar;                          //the number of vars still occurring in
   LLI done=0;
   for (LLI v=1; v<=nvar; v++) if (!occ[v]) nAvar--;
   for (LLI sup=0; (nAvar>0)&&(done<M+1); sup++)
   {
     LLI el;
     int*taken=(int*)calloc(nvar+1,sizeof(int));
     for (el=0; el<min(L,nAvar); el++)
     {
       supset[sup][el]=random()%(nAvar-el)+1; //el elements are already taken
       for (LLI var=1; var<=supset[sup][el]; var++) //do not count taken and
	                                            //non-occurring elements
	 if (taken[var]||!occ[var]) supset[sup][el]++; 
       taken[supset[sup][el]]=1; //take it
     }
     LLI win=M*K+1; //find the maximum number of occurrences we can take
     for (LLI elll=0; elll<el; elll++)
       if ((occ[supset[sup][elll]])<win) win=occ[supset[sup][elll]];
     done+=win;
     for (LLI ellll=0; ellll<el; ellll++) //...and take them
     {
       clauses[NC][NL++]=supset[sup][ellll];
       if (!(occ[supset[sup][ellll]]-=win)) 
       {
	 nAvar--;
       }
     }
     clauses[NC][NL++]=0; NC++; NL=0;
   }
   success=1;
   //prepare to print the formula
   for (LLI b=0; b<M; b++)
     for (LLI el1=0; el1<K; el1++)
      if (!occ[subset[b][el1]])//otherwise it's pure literal 
       for (LLI el2=el1+1; el2<K; el2++) 
	 if (!occ[subset[b][el2]]) //otherwise it's pure literal
	 {
	  if (subset[b][el1]==subset[b][el2]) 
	  {
	   fprintf(stderr,"ERROR. Please try different parameters\n.");
	   exit(2);
	  }
          else
	  {
           clauses[NC][0]=-subset[b][el1];
           clauses[NC][1]=-subset[b][el2];
	   clauses[NC][2]=0;
	   NC++;
	  }
	 }
   //print the formula
   fprintf(fo,"p cnf %lld %lld\n",nvar,NC); // cnf file header
   for (LLI cNC=0; cNC<NC; cNC++)
   {
     for (LLI cL=0; (clauses[cNC][cL]!=0); cL++)
       fprintf(fo,"%lld ",clauses[cNC][cL]);
     fprintf(fo,"0\n");
   }
   
//--------------------------------------------------------------------------------
   fflush(fo);
   fclose(fo);
 }
 exit(0);    
}

