#!/bin/bash 

mkdir -p ./build
[ -d ./build ] || { echo Failed to create ./build ; exit 1; }

mkdir -p ./bin
[ -d ./bin ] || { echo Failed to create ./bin ; exit 1; }

if [ ! -d build/$1 ]
then
  ./tools/re-create-build.sh $1
fi
