#!/bin/bash

mkdir -p ./build
[ -d ./build ] || { echo Failed to create ./build ; exit 1; }

mkdir -p ./bin
[ -d ./bin ] || { echo Failed to create ./bin ; exit 1; }


flavor=$1
echo $flavor
mkdir ./build/$flavor
./tools/symlinker.sh ./src ./build/$flavor $flavor

