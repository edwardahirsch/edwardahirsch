#!/bin/bash

if [ "$3" == "" ]
then
  echo "Usage: symlinker.sh from to flavor" 1>&2
  exit 1
fi

# Copy and paste from realpath bash script
CURPATH="$PATH"
PATH=/bin:/usr/bin
case "`uname -m`" in
  Power*)
    proc=powerPC
    ;;
  *)
    proc="`uname -m`"
    ;;
esac

mkdir -p `dirname $0`/$proc
gcc `dirname $0`/realpath.c -o `dirname $0`/$proc/`basename $0`

PATH="$CURPATH"
ln -sf "$proc/$(basename $0)" `dirname $0`/realpath-real
# End of copy and paste

exec `dirname $0`/symlinker-real.sh $*

