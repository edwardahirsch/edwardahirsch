#!/bin/bash

if [ "$3" == "" ]
then
  echo "Usage: symlinker-real.sh from to flavor" 1>&2
  exit 1
fi

FROM=$(tools/realpath-real $1)
TO=$(tools/realpath-real $2)
FLAVOR=$3

#echo $FROM
#echo $TO

if [ "$(ls $FROM/* 2>/dev/null)" != "" ] ; then for fulfrom in $FROM/*
do
file=$(basename $fulfrom)
#echo $file
#echo "$(basename $file _$FLAVOR)_$FLAVOR"
if [ "$(basename $file _$FLAVOR)_$FLAVOR" == "$file" ]
then
  file=$(basename $file _$FLAVOR)
  #echo $file
fi
fulto=$TO/$file
  if [ -d $fulfrom ]
  then
    if [ "$file" == "CVS" ]
    then
      continue
    fi

    if [ -e $fulto ]
    then 
      if [ ! -d $fulto  ] 
      then
        echo "Alert: $fulto is not a directory!"
        exit 2
      fi
    else
      mkdir $TO/$file
    fi
    ./tools/symlinker-real.sh $fulfrom $TO/$file $FLAVOR
  else
    if [ -e $fulto ]
    then
      if [ ! -f $fulto ]
      then
        echo "Alert: $fulto is not a regular file!"
	exit 3
      fi
    else
      ln -s $fulfrom $fulto
    fi
  fi
done ; fi
