#ifndef __CNFPARSER_H__
#define __CNFPARSER_H__

#include "../basicobject/dedobj.h"
#include "../basicobject/simpleobjectset.h"
#include "../general/solver.h"

/**
 * @file cnfparser.h
 * @brief Contains interface for
 * class CNFParser represented parser for simple cnf formulas
 * @author dmitrits
 */

// forward declaration
class BooleanAlgebraicSolver;

/**
 * An interface for an CNF parser. See README file 
 * to find CNF format specification.
 */
 
class CNFParser// : public  Parser
{
public: 

  /**
   *  Parses formula given in DIMACS CNF format from file and returns it's representation in deduction objects
   */
   
  virtual DeductionObjectSet* parseCNF(BooleanAlgebraicSolver *solver, const std::string fileName);


  /**
   *  Parses formula format given as array of clauses (a null-terminated 
   *  array of null-terminated arrays of literals) and returns it's representation in deduction objects
   *
   */
   
  virtual DeductionObjectSet* parseCNF(BooleanAlgebraicSolver *solver, const int* const * const array);
  
 /**
  * Constructor 
  */    
  CNFParser()
  { }
 
  /**
   * Destructor
   **/
  virtual ~CNFParser() {};
private:

    /**
     * Input file
     */
    FILE* myInputFile;
    
    /**
     * Number of variables in formula
     */  
    
    int myVarNumber;
    
    /**
     * Number of clauses in formula
     */  
    
    int myClauseNumber; 
    
    /**
      * Reads comments from input file: "c my comment"  
      */
    void readComment();
    /**
      * Reads string "p FORMAT VARIABLE CLAUSES " 
      */
    void readProblem(BooleanAlgebraicSolver *solver);
    /**
      * Reads declaration of one clause
      */
    void readClause(BooleanAlgebraicSolver *slv);
    
    /**
     * Resulting formula as set of deduction objects
     */
    
    DeductionObjectSet *myFormula; 
    
};
#endif
