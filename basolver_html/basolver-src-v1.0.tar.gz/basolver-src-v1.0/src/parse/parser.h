#ifndef __PARSER_H__
#define __PARSER_H__
/**
 * @file parser.h
 * @brief Contains interface for general Parser class.
 * @author arist
 * @date 01.12.04
 */
#include "cnfparser.h"
#include "rtlparser.h"

/** This file contains class Parser needed to parse the input problem.
 *  At the moment, we have two parsers, and Parser extends them: 
 *  1. CNFParser for DIMACS CNF formulae (used in SAT competitions);
 *  2. ISCASParser for formulae in ISCAS format.
 */
class Parser;
/**
 * smart pointer for \ref Parser
 */
 
typedef boost::shared_ptr<Parser> PParser;

/**
 * General parser interface.
 */
class Parser : public CNFParser, public RTLParser
{
public: 
  /**
   * Constructor 
   */    
  Parser()  
  { }

  
  /**
   * Destructor.
   */
  virtual 
  ~Parser()
  { }
};

#endif
