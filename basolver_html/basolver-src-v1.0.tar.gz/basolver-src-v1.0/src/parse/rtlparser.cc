#include "rtlparser.h"
#include "../logical/logical.h"
#include <iostream>
#include <boost/tokenizer.hpp>
#include "../basicobject/simpleobjectset.h"
#include "misc/assert.h"
#include "misc/i2s.h"

/**
 * @author kulikov 
 * @brief implementation for rtlparser.h
 **/

using namespace std;

  RTLParser::~RTLParser()
  {
    map<string, RTLVariable*>::iterator it = myVariableMap.begin();
    map<string, RTLVariable*>::iterator it_end = myVariableMap.end();
    for (; it != it_end; it++)
      delete (*it).second;
      
    myVariableMap.clear();
    
    if (myInputVariableList)
    {
      myInputVariableList->clear();
      delete myInputVariableList;
    }

    if (myOutputVariableList)
    {
      myOutputVariableList->clear();
      delete myOutputVariableList;
    }

  }
  
  RTLParser::RTLParser()
  {
    myFormula = 0;
    myInputVariableList = new list<long>;
    myOutputVariableList = new list<long>;
    myPrefix = string("");
    myClearStructures = true;
    myNumberOfCreatedVariables = 0;
  }


  DeductionObjectSet*
  RTLParser::parseRTL(BooleanAlgebraicSolver *slv, const std::string fileName) 
  {
    mySolver = slv;
 
    // When parisng two files we do not need to clear all internal structures.
    if (myClearStructures)
    {
      map<string, RTLVariable*>::iterator it = myVariableMap.begin();
      map<string, RTLVariable*>::iterator it_end = myVariableMap.end();
      for (; it != it_end; it++)
        delete (*it).second;
	
      myFormula = new AdjDedObjSet(0, slv->getLog(), slv);
    }
    
    if (myInputVariableList)
    {
      myInputVariableList->clear();
      delete myInputVariableList;
    }

    if (myOutputVariableList)
    {
      myOutputVariableList->clear();
      delete myOutputVariableList;
    }

    myInputVariableList = new list<long>;
    myOutputVariableList = new list<long>;
    
    // Parsing.
  
    myFileName=fileName;
    myInputFileStream= new std::ifstream(fileName.c_str());
    
    if (!(*myInputFileStream))
      this->reportFailure(fileName + " not found", false);

    boost::char_separator<char> sep("\t ", "=(,)");
    std::string str;
    
    if (myFormula == 0)
      myFormula = new AdjDedObjSet(0, slv->getLog(), slv);
      
    myStringNumber = 0;
    
    while (getline(*myInputFileStream, str))
    {
      myStringNumber++;
    
      if (str.size() == 0)
        this->reportFailure("empty string in input file");
      
      if (str[0] == '#')
        continue;
	
      boost::tokenizer<boost::char_separator<char> > tok(str,sep); // all tokens of the cuurent string
      boost::tokenizer<boost::char_separator<char> >::iterator cur_tok = tok.begin(); // current token
      if (*cur_tok == "INPUT" || *cur_tok == "input")
      {
        cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
	
        if (*cur_tok != "(")
          this->reportFailure("\'(\' is missed");
      
        cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
	RTLVariable* r = this->createNewVariable(*cur_tok, 0, true, true);
	myInputVariableList->push_back(r->myNumber);
	cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
        if (*cur_tok != ")")
          this->reportFailure("\')\' is missed");
	  
        cur_tok++;
        if (cur_tok != tok.end())
          this->reportFailure("end of line expected");
      }
      else 
      if (*cur_tok == "OUTPUT" || *cur_tok == "output")
      {
        cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
        if (*cur_tok != "(")
          this->reportFailure("\'(\' is missed");
      
        cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
	RTLVariable* r = this->findVariable(*cur_tok);
	if (!r)
	  r = this->createNewVariable(*cur_tok, 0, false, true);
	myOutputVariableList->push_back(r->myNumber);
	
	// check whether it is a bit
	if (!r->myIsBit)
	  this->reportFailure("output variable " + r->myName + " is not a bit");
	
	cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
        if (*cur_tok != ")")
          this->reportFailure("\')\' is missed");
	  
        cur_tok++;
        if (cur_tok != tok.end())
          this->reportFailure("end of line expected");
      }
      else
      if (*cur_tok == "CLAUSE" || *cur_tok == "clause")
      {
        cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
        if (*cur_tok != "(")
          this->reportFailure("\'(\' is missed");
	  
	PSAClause cl = LogicalGenerator::makeSAClause();
      
        while (cur_tok != tok.end())
	{
	  cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
   	  RTLVariable* r = this->findVariable(*cur_tok);
	  if (!r)
	  {
	    r = this->createNewVariable(*cur_tok, 0, false, true);
	  }
	  else
	  {
	    if (!r->myIsBit)
	      this->reportFailure("non-bit variable " + r->myName);
	  }
	  cl->add(LogicalGenerator::makeBoolLiteral(r->myNumber, 1));

     	  cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
          if (*cur_tok == ")")
	  {
            cur_tok++;
	    if (cur_tok != tok.end())
	      this->reportFailure("end of line expected");
	    break;
	  }
	  else
	  {
            if (*cur_tok != ",")
              this->reportFailure("\',\' is missed");
	  }
	}
	
	myFormula->add(cl);
      }
      else
      {
        readSimpleGate(str);
      }
    }
    
    return myFormula;  
  };
  
  void 
  RTLParser::readSimpleGate(std::string str)
  {
    boost::char_separator<char> sep("\t ", "=(,)");
    boost::tokenizer<boost::char_separator<char> > tok(str,sep); // all tokens of the cuurent string
    boost::tokenizer<boost::char_separator<char> >::iterator cur_tok = tok.begin(); // current token
    cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
    cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
        
    if (!(*cur_tok == "BUFF" || *cur_tok == "buf" || *cur_tok == "and" || *cur_tok == "AND"
    || *cur_tok == "OR" || *cur_tok == "or" || *cur_tok == "XOR" || *cur_tok == "xor"
    || *cur_tok == "NOR" || *cur_tok == "nor" || *cur_tok == "NAND" || *cur_tok == "nand"
    || *cur_tok == "NOT" || *cur_tok == "not" || *cur_tok == "XNOR" || *cur_tok == "xnor"))
    {
      return this->readComplexGate(str);
    }
  
    
    PEquality myEquality;
    
    RTLVariable* a; 
    RTLVariable* x; 
    RTLVariable* y; 
    string gate;
    
    this->extractGateAndVariableNames(str, gate, a, x, y);
    
    if (gate == "BUFF" || gate == "BUFF")
    {
      PPolynomial lhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(a->myNumber));
      PPolynomial rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(x->myNumber));
      myEquality = AlgebraicGenerator::createEquality(lhs, rhs);
    }
    else
    if (gate == "NOT" || gate == "not")
    {
      PPolynomial lhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(a->myNumber));
      lhs->addMonomial(AlgebraicGenerator::makeMonomial(x->myNumber));
      myEquality = AlgebraicGenerator::createEquality(lhs, AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial()));
    }
    else
    if (gate == "AND" || gate == "and")
    {
      myEquality = AlgebraicGenerator::createTypedEquality(eqtXeqAB, a->myNumber, true, x->myNumber, true, y->myNumber, true, 0, false);
    }
    else
    if (gate == "NAND" || gate == "nand")
    {
      myEquality = AlgebraicGenerator::createTypedEquality(eqtXeqAB, a->myNumber, false, x->myNumber, true, y->myNumber, true, 0, false);
    }
    else
    if (gate == "XOR" || gate == "xor")
    {
      myEquality = AlgebraicGenerator::createTypedEquality(eqt11m2, a->myNumber, true, x->myNumber, true, y->myNumber, true, 0, false);
    }
    else
    if (gate == "XNOR" || gate == "xnor")
    {
      myEquality = AlgebraicGenerator::createTypedEquality(eqt11m2, a->myNumber, false, x->myNumber, true, y->myNumber, true, 0, false);
    }
    else
    if (gate == "OR" || gate == "or")
    {
      myEquality = AlgebraicGenerator::createTypedEquality(eqtXeqAB, a->myNumber, false, x->myNumber, false, y->myNumber, false, 0, false);
    }
    else
    if (gate == "NOR" || gate == "nor")
    {
      myEquality = AlgebraicGenerator::createTypedEquality(eqtXeqAB, a->myNumber, true, x->myNumber, false, y->myNumber, false, 0, false);
    }
    else
    {
      this->reportFailure("wrong gate name: " + gate);
    }

    PSAClause clause = LogicalGenerator::makeSAClause();
    clause->add(myEquality);
    myFormula->add(PDeductionObject(clause));
  };



void
RTLParser::readComplexGate(string str)
{
  boost::char_separator<char> sep("\t ", "=(,)");
  boost::tokenizer<boost::char_separator<char> > tok(str,sep);
  boost::tokenizer<boost::char_separator<char> >::iterator cur_tok=tok.begin();
   
  string left_var_name = *cur_tok;
  
  // =
  cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
  if (*cur_tok != "=")
    this->reportFailure("\'=\' is missed");
    
  cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
  
  
  if (*cur_tok == "NUM" || *cur_tok == "num")
  {
    cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
    if (*cur_tok != "(")
      this->reportFailure("\'(\' is missed");
      
  
    RTLVariable* left_var = this->findVariable(left_var_name);
    
    if (left_var)
    {
      if (!left_var->myAssigned)
        this->reportFailure("the variable " + left_var->myName + " is present, but not assigned");
        
      cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
      vector<RTLVariable*>::iterator cur_bit = left_var->myBitList.begin();
      while (cur_tok != tok.end())
      {
	RTLVariable* x = this->createNewVariable(*cur_tok, 0, false, true);
	Variable y = mySolver->getVarNumber((*cur_bit)->myName);
	
	if (cur_bit == left_var->myBitList.end())
	  this->reportFailure("incompatible number of bits for variable " + left_var_name);
	
	PMonomial x_mon = AlgebraicGenerator::makeMonomial(x->myNumber);
	PMonomial y_mon = AlgebraicGenerator::makeMonomial(y);
	PPolynomial x_p = AlgebraicGenerator::makePolynomial(x_mon);
	PPolynomial y_p = AlgebraicGenerator::makePolynomial(y_mon);
	PEquality eq = AlgebraicGenerator::createEquality(x_p, y_p);
	PSAClause cl = LogicalGenerator::makeSAClause();
	cl->add(eq);
	myFormula->add(cl);
	cur_bit++;
	  
        
        cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
        if (*cur_tok == ")")
	{
          cur_tok++;
	  if (cur_tok != tok.end())
	    this->reportFailure("end of line expected");
	  break;
	}
	else
	{
          if (*cur_tok != ",")
            this->reportFailure("\',\' is missed");
	    
	  cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
	}
	
      }      
      
      if (cur_bit != left_var->myBitList.end())
        this->reportFailure("incompatible number of bits for variable " + left_var_name);
    }
    
    if (!left_var)
    {
      RTLVariable* new_var = this->createNewVariable(left_var_name, 0, false, false);
      
      cur_tok++;
      while (cur_tok != tok.end())
      {
        RTLVariable* bit = this->findVariable(*cur_tok);
	if (!bit)
	  bit = this->createNewVariable(*cur_tok, 0, false, true);
	new_var->addBit(bit);
	
	cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
        if (*cur_tok == ")")
	{
          cur_tok++;
	  if (cur_tok != tok.end())
	    this->reportFailure("end of line expected");
	  break;
	}
	else
	{
          if (*cur_tok != ",")
            this->reportFailure("\',\' is missed");
	    
	  cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
	}
      }      
      left_var = new_var;
    }
    
  } // NUM
  else
  {
    RTLVariable* a; 
    RTLVariable* x; 
    RTLVariable* y; 
    string gate;
    
    this->extractGateAndVariableNames(str, gate, a, x, y);
    if (gate == "SUM" || gate == "sum")
    {
      this->writeSum(a, x, y);
    }
    else
    if (gate == "MULT" || gate == "mult")
    {
      this->writeMultAsAddStep(a, x, y);
    }
    else
    {
      this->reportFailure("wrong gate name: " + gate);
    }
  }
  
  return;
}

RTLVariable::RTLVariable(long num, string name, long dim, bool assig, bool is_bit)
{
  myNumber = num;
  myName= name;
  myDimension = dim;
  myAssigned = assig;
  myIsBit = is_bit;
}

void
RTLVariable::addBit(RTLVariable* v)
{
  myBitList.push_back(v);
  myDimension++;
}

RTLVariable::~RTLVariable()
{
  myBitList.clear();
}

RTLVariable*
RTLParser::findVariable(string name) const
{
  map<string, RTLVariable*>::const_iterator it = myVariableMap.find(myPrefix + name);
  if (it != myVariableMap.end())
    return (*it).second;
    
  return 0;
}


// a=x+y
RTLVariable*
RTLParser::writeSum(RTLVariable* a, RTLVariable* x, RTLVariable* y)
{
/*  int dim = (x->myDimension >= y->myDimension ? x->myDimension : y->myDimension) + 1;

  if (a == 0)
    a = this->createNewVariable("_sum", dim, false, false);
  else
    Assert(a->myDimension == dim, "Bug");
  
  Assert(x, "Bug");
  Assert(y, "Bug");
  

  vector<RTLVariable*>::iterator xbitit = x->myBitList.begin();
  vector<RTLVariable*>::iterator ybitit = y->myBitList.begin();
  vector<RTLVariable*>::iterator abitit = a->myBitList.begin();
  
  RTLVariable* rtl_carry_bit= this->createNewVariable("_cbit", 0, false, true);
  PSAClause cl = LogicalGenerator::makeSAClause();
  cl->add(LogicalGenerator::makeBoolLiteral(rtl_carry_bit->myNumber, false));
  myFormula->add(cl);
  RTLVariable* next_rtl_carry_bit = 0;
  bool first_it=true;
  while (xbitit != x->myBitList.end() || ybitit != y->myBitList.end())
  {
    next_rtl_carry_bit = this->createNewVariable("_cbit", 0, false, true);
    Assert(*abitit != 0, "Bug");
    if (first_it)
      this->writeFullAdder(*abitit, next_rtl_carry_bit, (xbitit != x->myBitList.end() ? *xbitit : 0), (ybitit != y->myBitList.end() ? *ybitit : 0), 0); 
    else
      this->writeFullAdder(*abitit, next_rtl_carry_bit, rtl_carry_bit,(xbitit != x->myBitList.end() ? *xbitit : 0), (ybitit != y->myBitList.end() ? *ybitit : 0)); 
    first_it=false;
    rtl_carry_bit = next_rtl_carry_bit;
    if (xbitit != x->myBitList.end())
      xbitit++;
    if (ybitit != y->myBitList.end())
      ybitit++;
    Assert(abitit != a->myBitList.end(), "Bug.");
    abitit++;
  }
  (*abitit)=next_rtl_carry_bit;
  a->myAssigned = true;
  
  return a;
*/

  int dim = (x->myDimension >= y->myDimension ? x->myDimension : y->myDimension) + 1;

  if (a == 0)
    a = this->createNewVariable("_sum", dim, false, false);
  else
  {
    if (a->myDimension != dim)
      this->reportFailure("incomaptible number of bits for the variable " + a->myName);
  }
  
  if (!x)
    reportFailure("bug in RTLParser", false);
  if (!y)
    reportFailure("bug in RTLParser", false);

  

  vector<RTLVariable*>::iterator xbitit = x->myBitList.begin();
  vector<RTLVariable*>::iterator ybitit = y->myBitList.begin();
  vector<RTLVariable*>::iterator abitit = a->myBitList.begin();
    
  RTLVariable* rtl_carry_bit = this->createNewVariable("_cbit", 0, false, true);
  PSAClause cl = LogicalGenerator::makeSAClause();
  cl->add(LogicalGenerator::makeBoolLiteral(rtl_carry_bit->myNumber, false));
  myFormula->add(cl);
  RTLVariable* next_rtl_carry_bit;
	      
  while (xbitit != x->myBitList.end() || ybitit != y->myBitList.end()  || abitit != a->myBitList.end() )
  {
    next_rtl_carry_bit = this->createNewVariable("_cbit", 0, false, true);
    if (*abitit == 0)
      reportFailure("bug in RTLParser", false);
    this->writeFullAdder(*abitit, next_rtl_carry_bit, rtl_carry_bit, (xbitit != x->myBitList.end() ? *xbitit : 0), (ybitit != y->myBitList.end() ? *ybitit : 0)); 
    rtl_carry_bit = next_rtl_carry_bit;
    if (xbitit != x->myBitList.end())
      xbitit++;
    if (ybitit != y->myBitList.end())
      ybitit++;
    if (abitit == a->myBitList.end())
      this->reportFailure("incompatible number of bits for the variable " + a->myName);
    abitit++;
  }
							        
  a->myAssigned = true;
  
  return a;  
}

void
RTLParser::writeFullAdder(RTLVariable* sum, RTLVariable* carry,
RTLVariable* a, RTLVariable* b, RTLVariable* c)
{
  TRACE("rtldebug", std::cerr << "\nEnetring writeFullAdder...");
  if (!a->myIsBit) this->reportFailure("the variable " + a->myName + " is not a bit");
  if (b && !b->myIsBit) this->reportFailure("the variable " + b->myName + " is not a bit");
  if (c && !c->myIsBit) this->reportFailure("the variable " + c->myName + " is not a bit");
  if (!sum->myIsBit) this->reportFailure("the variable " + sum->myName + " is not a bit");
  if (!carry->myIsBit) this->reportFailure("the variable " + carry->myName + " is not a bit");

  if (sum->myAssigned)
    this->reportFailure("the variable " + sum->myName + " is already assigned");
  sum->myAssigned = true;

  if (carry->myAssigned)
    this->reportFailure("the variable " + carry->myName + " is already assigned");
  carry->myAssigned = true;
  
  
  // sum = a xor b xor c
  long a_num = a->myNumber;
  long b_num = b ? b->myNumber : 0;
  long c_num = c ? c->myNumber : 0;
  
  // adding gates with two inputs
  
  if (a_num && b_num && c_num)
  {
    RTLVariable* n = this->createNewVariable("_n", 0, true, true);
    RTLVariable* m = this->createNewVariable("_m", 0, true, true);
    RTLVariable* l = this->createNewVariable("_l", 0, true, true);
    RTLVariable* k = this->createNewVariable("_k", 0, true, true);
    RTLVariable* e = this->createNewVariable("_e", 0, true, true);
    
    // n = b and c
    PEquality neq = AlgebraicGenerator::createTypedEquality(eqtXeqAB, n->myNumber, true, b->myNumber, true, c->myNumber, true,  0, true);
    PSAClause ncl = LogicalGenerator::makeSAClause();
    ncl->add(neq);
    myFormula->add(ncl);

    // m = a and c
    PEquality meq = AlgebraicGenerator::createTypedEquality(eqtXeqAB, m->myNumber, true, a->myNumber, true, c->myNumber, true,  0, true);
    PSAClause mcl = LogicalGenerator::makeSAClause();
    mcl->add(meq);
    myFormula->add(mcl);
    
    // l = a and b
    PEquality leq = AlgebraicGenerator::createTypedEquality(eqtXeqAB, l->myNumber, true, a->myNumber, true, b->myNumber, true,  0, true);
    PSAClause lcl = LogicalGenerator::makeSAClause();
    lcl->add(leq);
    myFormula->add(lcl);
    
    // k = a xor b
    PEquality keq = AlgebraicGenerator::createTypedEquality(eqt11m2, k->myNumber, true, a->myNumber, true, b->myNumber, true,  0, true);
    PSAClause kcl = LogicalGenerator::makeSAClause();
    kcl->add(keq);
    myFormula->add(kcl);

    // e = l or m
    PEquality eeq = AlgebraicGenerator::createTypedEquality(eqtXeqAB, e->myNumber, false, l->myNumber, false, m->myNumber, false,  0, true);
    PSAClause ecl = LogicalGenerator::makeSAClause();
    ecl->add(eeq);
    myFormula->add(ecl);

    // sum = k xor c
    PEquality sumeq = AlgebraicGenerator::createTypedEquality(eqt11m2, sum->myNumber, true, k->myNumber, true, c->myNumber, true,  0, true);
    PSAClause sumcl = LogicalGenerator::makeSAClause();
    sumcl->add(sumeq);
    myFormula->add(sumcl);
    
    // carry = e or n
    PEquality carryeq = AlgebraicGenerator::createTypedEquality(eqtXeqAB, carry->myNumber, false, e->myNumber, false, n->myNumber, false,  0, true);
    PSAClause carrycl = LogicalGenerator::makeSAClause();
    carrycl->add(carryeq);
    myFormula->add(carrycl);
  }
  else
  if (b_num || c_num)
  {
    if (!b_num)
    {
      b_num = c_num;
      b = c;
    }
    
    // so, now b_num is not zero
  
    // sum = a xor b
    PEquality keq = AlgebraicGenerator::createTypedEquality(eqt11m2, sum->myNumber, true, a->myNumber, true, b->myNumber, true,  0, true);
    PSAClause kcl = LogicalGenerator::makeSAClause();
    kcl->add(keq);
    myFormula->add(kcl);

    // carry = a and b
    PEquality carryeq = AlgebraicGenerator::createTypedEquality(eqtXeqAB, carry->myNumber, true, a->myNumber, true, b->myNumber, true,  0, true);
    PSAClause carrycl = LogicalGenerator::makeSAClause();
    carrycl->add(carryeq);
    myFormula->add(carrycl);
  }
  else
  if (a_num && !b_num && !c_num)
  {
    // sum = a
    PPolynomial lhs1 = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(a->myNumber));  
    PPolynomial rhs1 = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(sum->myNumber));  
    PEquality eq1 = AlgebraicGenerator::createEquality(lhs1, rhs1);
    PSAClause cl1 = LogicalGenerator::makeSAClause();
    cl1->add(eq1);
    myFormula->add(cl1);
    
    // carry = 0
    PPolynomial lhs2 = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(carry->myNumber));  
    PPolynomial rhs2 = AlgebraicGenerator::makePolynomial();  
    PEquality eq2 = AlgebraicGenerator::createEquality(lhs2, rhs2);
    PSAClause cl2 = LogicalGenerator::makeSAClause();
    cl2->add(eq2);
    myFormula->add(cl2);
  }
  
}


// a=xy
void
RTLParser::writeMult(RTLVariable* a, RTLVariable* x, RTLVariable* y)
{
  int dim = (x->myDimension + y->myDimension);

  if (a == 0)
  {
    a = this->createNewVariable("_mult", dim, false, false);
  }
  else
  {
    if (a->myDimension != dim)
      this->reportFailure("incompatible number of bits for the variable " + a->myName);
  }
  
  

  vector<RTLVariable*>::iterator xbitit = x->myBitList.begin();
  vector<RTLVariable*>::iterator ybitit = y->myBitList.begin();
  
  
  int it = 0;
  
  RTLVariable* sum = 0; 

  for (; xbitit != x->myBitList.end(); xbitit++)
  {
    it++;
    
    RTLVariable* x_bit_mult_y = this->createNewVariable("_psum", y->myDimension + it - 1, true, false);
    vector<RTLVariable*>::iterator xbitmultyit = x_bit_mult_y->myBitList.begin();
    
    for (int j = 1; j <= it - 1; j++)
    {
      PSAClause clause=LogicalGenerator::makeSAClause();
      clause->add(LogicalGenerator::makeBoolLiteral(mySolver->getVarNumber((*xbitmultyit)->myName), false));
      myFormula->add(PDeductionObject(clause));
      xbitmultyit++;
    }
    
    
    for (ybitit = y->myBitList.begin(); ybitit != y->myBitList.end(); ybitit++)
    {
      PEquality eq3 = AlgebraicGenerator::createTypedEquality(eqtXeqAB, mySolver->getVarNumber((*xbitmultyit)->myName), true, 
        mySolver->getVarNumber((*xbitit)->myName), true, mySolver->getVarNumber((*ybitit)->myName), true, 0, false);
      PSAClause cl3 = LogicalGenerator::makeSAClause();
      cl3->add(eq3);
      myFormula->add(cl3);
      xbitmultyit++;
    }
    

    if (it != 1 && it != x->myDimension)
    {
      RTLVariable* cur_sum = this->writeSum(0, x_bit_mult_y, sum);
      sum = cur_sum;
    }
    
    if (it == 1)
      sum = x_bit_mult_y;
      
    if (it == x->myDimension)
    {
      this->writeSum(a, x_bit_mult_y, sum);
    }
    
  }  
  
  a->myAssigned = true;
  return;
}

RTLVariable* 
RTLParser::createNewVariable(string name, long dim, bool assigned, bool is_bit)
{

  if (!name.size())
    this->reportFailure("empty variable name");
    
  if (name[0] >= '0' && name[0] <= '9')
    this->reportFailure("variable name cannot begin on a digit");
  
  // if it is additional variable add a number to it (to avoid equal names)
  if (name[0] == '_')
  {
    name += itos(++myNumberOfCreatedVariables);
  }
  
  // check whether a variable has correct name
  if (name == "INPUT" || name == "input" || name == "OUTPUT" || name == "output" || name == "OR" || name == "or"
  || name == "AND" || name == "and" || name == "xor" || name == "XOR" || name == "nand" || name == "NAND" || name == "nor" || name == "NOR"
  || name == "XNOR" || name == "xnor" || name == "NUM" || name == "num" || name == "SUM" || name == "sum" || name == "MULT" || name == "mult"
  || name == "clause" || name == "CLAUSE"
  || name == "," || name == "(" || name == ")")
  {
    this->reportFailure("bad variable name: " + name);
  }
  
  map<string, RTLVariable*>::const_iterator it = myVariableMap.find(myPrefix + name);
  if (it != myVariableMap.end())
    reportFailure("already defined variable " + name);
  
  string mod_name = string(myPrefix) + string(name);
  RTLVariable* new_var = new RTLVariable(myFormula->getVariableNum(), mod_name, 0, assigned, is_bit);
  myVariableMap.insert(make_pair(new_var->myName, new_var));
  
  Variable var = AlgebraicGenerator::makeVariable(myFormula->getVariableNum() + 1, new_var->myName, mySolver);
  myFormula->addVariable(var);
  new_var->myNumber = var;
  
      
  if (!is_bit)
  {
    for (int i = 1; i <= dim; i++)
    {
      RTLVariable* bit = this->createNewVariable("_bit", 0, false, true);
      new_var->addBit(bit);
    }
    
    if (dim == 1)
      new_var->myIsBit = true;
  }
  else
  {
    new_var->addBit(new_var);
    new_var->myDimension = 1;    
  }
  
  return new_var;
}

void
RTLParser::reportFailure(string s, bool write_line_number) const
{
  if (write_line_number)
    std::cerr << "\nRTLParser error in file " << myFileName << " at string number " << myStringNumber << ": " << s << ".\n";
  else
    std::cerr << "\nRTLParser error: " << s << ".\n";
  exit(-1);
}

void 
RTLParser::extractGateAndVariableNames(string str, string& gate, RTLVariable* &a, RTLVariable* &x, RTLVariable* &y)
// parsing string a = gate ( x , y )
{
    bool only_one_right_var = false;
    bool right_vars_have_to_be_defined = false;
    bool all_vars_have_to_be_bits = false;

    y = 0; // as it will possibly be only one right var
    
    boost::char_separator<char> sep("\t ", "=(,)");
    boost::tokenizer<boost::char_separator<char> > tok(str,sep); // all tokens of the current string
    boost::tokenizer<boost::char_separator<char> >::iterator cur_tok = tok.begin(); // current token
    
    // a
    string a_name = string(*cur_tok);
    // =
    cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
    if (*cur_tok != "=")
      this->reportFailure("\'=\' is missed");
    // gate
    cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
    gate = string(*cur_tok);
    
    if (gate == "buff" || gate == "BUFF" || gate == "not" || gate == "NOT")
    {
      only_one_right_var = true;
      all_vars_have_to_be_bits = true;
    }
    
    // (
    cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
    if (*cur_tok != "(")
      this->reportFailure("\'(\' is missed");
    // x
    cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
    string x_name = string(*cur_tok);
    
    string y_name = "";
    
    if (only_one_right_var)
    {
      // )
      cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
      if (*cur_tok != ")")
        this->reportFailure("\')\' is missed");
      cur_tok++;
      if (cur_tok != tok.end())
        this->reportFailure("end of line expected");
    }
    else
    {
      // ,
      cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
      if (*cur_tok != ",")
        this->reportFailure("\',\' is missed");
      // y
      cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");    
      y_name = string(*cur_tok);
      // )
      cur_tok++; if (cur_tok == tok.end()) this->reportFailure("unexpected end of string");
      if (*cur_tok != ")")
        this->reportFailure("\')\' is missed");
      cur_tok++;
      if (cur_tok != tok.end())
        this->reportFailure("end of line expected");
    }
    
    if (a_name[0] == '_' || x_name[0] == '_' || (!only_one_right_var && y_name[0] == '_'))
      this->reportFailure("variable name should not start with '_'");
      
    if ((a_name == x_name) || (!only_one_right_var && a_name == y_name))
      this->reportFailure("cannot define the variable " + a_name + " by means of itself");
    
    if (gate == "buff" || gate == "BUFF" || gate == "not" || gate == "NOT")
    {
      only_one_right_var = true;
      all_vars_have_to_be_bits = true;
    }
    else
    if (gate == "SUM" || gate == "MULT" || gate == "mult" || gate == "sum")
    {
      right_vars_have_to_be_defined = true;
    }
    else
    if (gate == "AND" || gate == "and" || gate == "xor" || gate == "XOR" || gate == "or" || gate == "OR" || gate == "NOR" || gate == "nor" || gate == "NAND" || gate == "nand" || gate == "xnor" || gate == "XNOR")
    {
      all_vars_have_to_be_bits = true;
    }
    else
    {
      this->reportFailure("wrong gate name: " + gate);
    }
      
    a = this->findVariable(a_name);
    x = this->findVariable(x_name);
    if (!only_one_right_var)
      y = this->findVariable(y_name);
      
    // check conditions
    if (right_vars_have_to_be_defined)
    {
      if (!x)
        this->reportFailure("undefined variable " + x_name);
      if (!only_one_right_var && !y)
        this->reportFailure("undefined variable " + y_name);
    }
    
    if (all_vars_have_to_be_bits)
    {
      if (a && !a->myIsBit)
        this->reportFailure("non-bit variable " + a_name);
      if (x && !x->myIsBit)
        this->reportFailure("non-bit variable " + x_name);
      if (!only_one_right_var && y && !y->myIsBit)
        this->reportFailure("non-bit variable " + y_name);
    }
    
    if (all_vars_have_to_be_bits)
    {
      if (!a)
        a = this->createNewVariable(a_name, 0, true, true);
      else
        a->myAssigned = true;
	
      if (!x)
        x = this->createNewVariable(x_name, 0, false, true);

      if (!only_one_right_var && !y)
        y = this->createNewVariable(y_name, 0, false, true);
	
      return;
    }
    
    if (right_vars_have_to_be_defined && !a)
    {
      int dim = 0;
      if (gate == "SUM" || gate == "sum")
        dim = (x->myDimension >= y->myDimension ? x->myDimension : y->myDimension) + 1;
      else
      if (gate == "MULT" || gate == "mult")
        dim = (x->myDimension + y->myDimension);
      else
        reportFailure("undefined gate");
        
      a = this->createNewVariable(a_name, dim, true, false);
    }    

    return;
}

void
RTLParser::debugPrint() const
{
  std::cerr << "\n--------------------------------------------";
  map<string, RTLVariable*>::const_iterator it = myVariableMap.begin();  
  for (; it != myVariableMap.end(); it++)
    (*it).second->print();
  std::cerr << "\nmyFormula->varnum=" << myFormula->getVariableNum();
  std::cerr << "\n--------------------------------------------";
}

void
RTLVariable::print() const
{
    std::cerr << "\nnum=" << this->myNumber << " name=" << this->myName << " dim=" << this->myDimension << " ass-d=" << this->myAssigned << " bits=";
    if (this->myDimension > 1)
    {
      for (int i = 0; i <= this->myDimension - 1; i++)
        std::cerr << " " << this->myBitList[i]->myName;	
    }
  
}

DeductionObjectSet* 
RTLParser::parseTwo(BooleanAlgebraicSolver* solver, const string name1, const string name2, bool equiv)
{
  myFormula = new AdjDedObjSet(0, solver->getLog(), solver);  
  myPrefix = string("a_");
  this->parseRTL(solver, name1);
  
  
  list<long>* input = myInputVariableList;
  myInputVariableList = 0;

  list<long>* output = myOutputVariableList;
  myOutputVariableList = 0;
  
  this->myClearStructures = false;
  
  myPrefix = "b_";
  this->parseRTL(solver, name2);
  
  if (input->size() != myInputVariableList->size())
    this->reportFailure("input circuits have different number of inputs", false);

  if (output->size() != myOutputVariableList->size())
    this->reportFailure("input circuits have different number of outputs", false);
    
  if (input->size() == 0)
    this->reportFailure("no inputs given", false);

  if (output->size() == 0)
    this->reportFailure("no outputs given", false);
    
  // inputs
  list<long>::iterator i1 = input->begin();
  list<long>::iterator i2 = myInputVariableList->begin();
  while (i1 != input->end())
  {
    PPolynomial lhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(*i1));
    PPolynomial rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(*i2));
    PEquality eq = AlgebraicGenerator::createEquality(lhs, rhs);
    PSAClause cl = LogicalGenerator::makeSAClause();
    cl->add(eq);
    myFormula->add(cl);
    i1++;
    i2++;
  }
  
  if (equiv)
  {
    PSAClause big_or = LogicalGenerator::makeSAClause();
    
    i1 = output->begin();
    i2 = myOutputVariableList->begin();
    int i = 0;
  
    while (i1 != output->end())
    {
      RTLVariable* myxor = this->createNewVariable("_xor" + itos(++i), 0, true, true);
      PEquality eq1 = AlgebraicGenerator::createTypedEquality(eqt11m2, myxor->myNumber, true, *i1, true, *i2, true, 0, true);
      PSAClause cl1 = LogicalGenerator::makeSAClause();
      cl1->add(eq1);
      myFormula->add(cl1);
    
      big_or->add(LogicalGenerator::makeBoolLiteral(myxor->myNumber, 1));
    
      i1++;
      i2++;
    }
    
    myFormula->add(big_or);
  } 
  else
  {
    list<long>::iterator i1 = output->begin();
    list<long>::iterator i2 = myOutputVariableList->begin();
    while (i1 != output->end())
    {
      PPolynomial lhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(*i1));
      PPolynomial rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(*i2));
      PEquality eq = AlgebraicGenerator::createEquality(lhs, rhs);
      PSAClause cl = LogicalGenerator::makeSAClause();
      cl->add(eq);
      myFormula->add(cl);
      i1++;
      i2++;
    }
  } 
  
  
  input->clear();
  delete input;
  output->clear();
  delete output;
  
  this->myClearStructures = true;
  
  return myFormula;
}

bool
RTLParser::isMainVariable(const string name)
{
  if (name.size() <= 2)
    return true;
    
  if (name[2] == '_')
    return false;
    
  return true;
}


void
RTLParser::writeMultAsAddStep(RTLVariable* a, RTLVariable* x, RTLVariable* y)
{
  int dim = (x->myDimension + y->myDimension);

  if (a == 0)
  {
    a = this->createNewVariable("_mult", dim, false, false);
  }
  else
  {
    if (a->myDimension != dim)
      this->reportFailure("incompatible number of bits for variable " + a->myName);
  }
  
  TRACE("rtldebug", cerr << "\nEntering writeMult(" << a->myName << " " << x->myName << " " << y->myName << ")...";);
  
  if (x->myIsBit || y->myIsBit)
  {
    if (y->myIsBit)
    // swap
    {
      RTLVariable* temp = x;
      x = y;
      y = temp;
    }
    // now x is a bit
    
    for (int i = 0; i < y->myDimension; i++)
    {
      PEquality eq = AlgebraicGenerator::createTypedEquality(eqtXeqAB, a->myBitList[i]->myNumber, true, y->myBitList[i]->myNumber, true, x->myBitList[0]->myNumber, true, 0, true);
      a->myBitList[i]->myAssigned = true;
      PSAClause cl = LogicalGenerator::makeSAClause();
      cl->add(eq);
      myFormula->add(cl);      
    }
    
    PPolynomial lhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(a->myBitList[a->myDimension - 1]->myNumber));
    a->myBitList[a->myDimension - 1]->myAssigned = true;
    PPolynomial rhs = AlgebraicGenerator::makePolynomial();
    PEquality eq = AlgebraicGenerator::createEquality(lhs, rhs);
    PSAClause cl = LogicalGenerator::makeSAClause();
    cl->add(eq);
    myFormula->add(cl);
    
    a->myAssigned = true;
    
    return;
  }
  
  TRACE("rtldebug", cerr << "\nInput variables are not bits.";);

  int i, j; // counters
  
  // initializing cells
  pair<RTLVariable*, RTLVariable*> ** outputs = new pair<RTLVariable*, RTLVariable*>* [x->myDimension];  
  RTLVariable*** c = new RTLVariable** [x->myDimension];  
  for (i = 0; i < x->myDimension; i++)
  {
    outputs[i] = new pair<RTLVariable*, RTLVariable*> [y->myDimension];
    c[i] = new RTLVariable* [y->myDimension];
  }
    
  for (i = 0; i < x->myDimension; i++)
    for (j = 0; j < y->myDimension; j++)
    {
      RTLVariable* right = this->createNewVariable("_r_"+itos(i)+"_"+itos(j), 1, false, true);
      RTLVariable* top = this->createNewVariable("_t_"+itos(i)+"_"+itos(j), 1, false, true);
      outputs[i][j] = make_pair(right, top);
      
      RTLVariable* c_var = this->createNewVariable("_c_"+itos(i)+"_"+itos(j), 1, true, true);
      c[i][j] = c_var;
      PEquality eq = AlgebraicGenerator::createTypedEquality(eqtXeqAB, c_var->myNumber, true, x->myBitList[i]->myNumber, true, y->myBitList[j]->myNumber, true, 0, true);
      PSAClause cl = LogicalGenerator::makeSAClause();
      cl->add(eq);
      myFormula->add(cl);
    }
    
  // zero column
  TRACE("rtldebug", cerr << "\nzero-column...");
  for (i = 0; i < x->myDimension; i++)
    this->writeFullAdder(outputs[i][0].first, outputs[i][0].second, c[i][0], 0, 0);

  // lower cell in all columns except the first
  TRACE("rtldebug", cerr << "lower cell...");
  for (i = 1; i < y->myDimension; i++)
    this->writeFullAdder(outputs[0][i].first, outputs[0][i].second, c[0][i], outputs[1][i-1].first, 0);

  // upper cell in first column
  TRACE("rtldebug", cerr << "upper cell...");
  this->writeFullAdder(outputs[x->myDimension - 1][1].first,  outputs[x->myDimension - 1][1].second, c[x->myDimension - 1][1], outputs[x->myDimension - 2][1].second, 0);
  
  // upper cells in all other columns
  TRACE("rtldebug", cerr << "other upper cells...");
  for (i = 2; i < y->myDimension; i++)
    this->writeFullAdder(outputs[x->myDimension - 1][i].first,  outputs[x->myDimension - 1][i].second, c[x->myDimension - 1][i], outputs[x->myDimension - 2][i].second, outputs[x->myDimension - 1][i - 1].second);    
  
  // all other cells
  TRACE("rtldebug", cerr << "all others...");
  for (i = 1; i < x->myDimension - 1; i++)
    for (j = 1; j < y->myDimension; j++)
      this->writeFullAdder(outputs[i][j].first, outputs[i][j].second, c[i][j], outputs[i + 1][j - 1].first, outputs[i - 1][j].second);
  
  // circuit outputs
  for (i = 0; i < y->myDimension; i++)
  {
    PPolynomial lhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(a->myBitList[i]->myNumber));
    PPolynomial rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(outputs[0][i].first->myNumber));
    PEquality eq = AlgebraicGenerator::createEquality(lhs, rhs);
    PSAClause cl = LogicalGenerator::makeSAClause();
    cl->add(eq);
    myFormula->add(cl);
    a->myBitList[i]->myAssigned = true;
  }

  for (i = y->myDimension; i < y->myDimension + x->myDimension - 1; i++)
  {
    PPolynomial lhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(a->myBitList[i]->myNumber));
    PPolynomial rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(outputs[i - y->myDimension + 1][y->myDimension - 1].first->myNumber));
    PEquality eq = AlgebraicGenerator::createEquality(lhs, rhs);
    PSAClause cl = LogicalGenerator::makeSAClause();
    cl->add(eq);
    myFormula->add(cl);
    a->myBitList[i]->myAssigned = true;
  }
  
  PPolynomial lhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(a->myBitList[x->myDimension + y->myDimension - 1]->myNumber));
  PPolynomial rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(outputs[x->myDimension - 1][y->myDimension - 1].second->myNumber));
  PEquality eq = AlgebraicGenerator::createEquality(lhs, rhs);
  PSAClause cl = LogicalGenerator::makeSAClause();
  cl->add(eq);
  myFormula->add(cl);
  a->myBitList[x->myDimension + y->myDimension - 1]->myAssigned = true;
  
  a->myAssigned = true;
  return;
}

// fa: sum, carry, a, b, c
