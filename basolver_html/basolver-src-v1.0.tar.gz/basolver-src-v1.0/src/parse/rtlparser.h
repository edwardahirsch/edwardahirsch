#ifndef __RTLASPARSER_H__
#define __RTLASPARSER_H__



#include "../basicobject/dedobj.h"
#include "../basicobject/simpleobjectset.h"
//#include "../general/solver.h"
#include <vector>
#include <vector>

/**
 * @file rtlparser.h
 * @brief Contains interface for the RTLParser class.
 * @author kulikov
 */
 
/// Forward declarations.
class BooleanAlgebraicSolver;
class RTLVariable;
 
 
/**
 * An interface for an RTL parser. See README file 
 * to find RTL format specification.
 * Summation operation is implemented as in the ripple-carry adder, 
 * multiplication is implemented as in the add-step multiplier.
 */
class RTLParser
{
public: 
  /// Parses and returns RTL formula.
  virtual DeductionObjectSet* 
  parseRTL(BooleanAlgebraicSolver *slv, const std::string fileName);
  
  /// First this procedure parses formulas from two input files.
  /// For distinguishing variable names it adds "a_" and "b_" to the names of variables from the first
  /// and second files, respectively. 
  /// If equiv = true, it adds to the formula several clauses, 
  /// such that two input circuits are equivalent iff the resulted formula
  /// is unsatisfiable. Thus, by solving this formula one checks two input 
  /// circuits for equivalence. More precisely, the procedure 
  /// adds equalities stating that inputs of circuits are equal and 
  /// adds several equalities stating that some two (corresponding) outputs 
  /// of the two input circuits are different.
  /// If equiv=false, it just adds equalities stating that the corresponding outputs
  /// and inputs of two circuits are equal.
  virtual DeductionObjectSet*
  parseTwo(BooleanAlgebraicSolver *slv, const string, const string, bool equiv = false);
  
  /// Destructor. Clears myVariableMap and destructs
  /// all its internal instances. Also clears internal lists.
  virtual
  ~RTLParser();
  
  /// Constructor. Creates internal mas and lists.
  RTLParser();
  
  /// Checks whether an input variable was in one of the input files
  /// (as during parsing complex gates such as SUM and MULT the parser
  /// introduces new variables).
  static bool
  isMainVariable(const string name);
  
private:
  /// Input file name.
  std::string myFileName;

  /// Input file stream.
  std::ifstream* myInputFileStream;
  
  /// Parses string if it contains a simple gate (AND, OR, XOR, NOT, etc).
  void 
  readSimpleGate(std::string);
  
  /// Parses NUM, SUM, MULT gates.
  void
  readComplexGate(std::string);
 
  /// Formula that is filled by this parser.
  DeductionObjectSet*
  myFormula; 
  
  /// A vector storing variables that are already parsed.
  /// We need this map for compatibility check 
  /// (e.g., variables x and y have to be declared before 
  /// an equality z=SUM(x,y)). 
  map<string, RTLVariable*>
  myVariableMap;
  

  /// Checks whether a variable with an input name is presented 
  /// in the internal map.
  RTLVariable*
  findVariable(string) const; 
  
  /// Writes a=x+y in terms of Boolean clauses and equalities 
  /// and adds them to the internal deduction objects set.
  /// A null pointer may be given as a; in this case
  /// this method creates a variable a. Returns a.
  RTLVariable*
  writeSum(RTLVariable* a, RTLVariable* x, RTLVariable* y);

  /// Writes a=x*y in terms of Boolean clauses and equalities 
  /// and adds them to the internal deduction objects set.
  void
  writeMult(RTLVariable* a, RTLVariable* x, RTLVariable* y);

  /// Writes a=x*y in terms of Boolean clauses and equalities 
  /// and adds them to the internal deduction objects set. The multiplication
  /// is implemented in the way as in the add-step circuit.
  void
  writeMultAsAddStep(RTLVariable* a, RTLVariable* x, RTLVariable* y);

  
  /// Writes equalities stating that sum is a sum bit of a, b, and c,
  /// and that carry is a carry bit of this sum.
  void
  writeFullAdder(RTLVariable* sum, RTLVariable* carry,
    RTLVariable* a, RTLVariable* b = 0, RTLVariable* c = 0);

  /// Creates new rtl variable. 
  RTLVariable*
  createNewVariable(string name, long dim, bool assigned, bool is_bit);
  
  /// Reports failure and exits the program.
  /// Writes the number of line where error was detected if 
  /// the second parameter is set to true.
  void 
  reportFailure(string, bool write_line_number = true) const;
  
  /// Given a string, returns the left-hand side variable, the gate name,
  /// and the right-hand side variables.
  void 
  extractGateAndVariableNames(string s, string& gate, RTLVariable* &a, RTLVariable* &x, RTLVariable* &y);
  
  /// Reference to a solver. 
  BooleanAlgebraicSolver*
  mySolver;
  
  /// Prints all internal structures. Needed only for debugging.
  void
  debugPrint() const;
  
  /// List of input variables of an input circuit.
  list<long>* myInputVariableList;
  /// List of output variables of an input circuit.
  list<long>* myOutputVariableList;
  
  /// This feature is used for distinguishing variables of different circuits.
  string
  myPrefix;
  
  /// Whether to clear all internal structures before parsing.
  bool 
  myClearStructures;
  
  /// Number of already created additional variables.
  long
  myNumberOfCreatedVariables;
  
  /// Number of currently parsed string.
  long
  myStringNumber;
};

/// This class is intended to help check compatibility 
/// while parsing an RTL formula. RTLVariable is either a bit 
/// or a vector of bits. myDimension is the number of bits 
/// in this variable. It has value 0 if this variable is just a bit 
/// (in this case, the internal vector is empty).
class RTLVariable
{
friend class RTLParser;

  /// Variable name;
  string 
  myName;
  
  /// Number of this variable.
  long
  myNumber;
  
  /// By the dimension of this variable we mean the number of bits in it.
  /// If it is equal to 1, myBitList has to be empty.
  long
  myDimension;
  
  /// Whether we have already parsed an equality 
  /// of the form this_var = GATE(...), where GATE is 
  /// not NUM.
  long 
  myAssigned;
  
  /// If this variable is not a bit, it is a vector of bits.
  /// Here they are represented as instances of RTLVariable.
  /// The first bit in the vector is the parity bit.
  vector<RTLVariable*>
  myBitList;
  
  /// Constructor. 
  RTLVariable(long num, string name, long dim, bool assigned, bool is_bit);
  
  /// Destructor. Clears myBitList (without destructing its internal instances).
  ~RTLVariable();
  
  
  /// Adds a bit to this variable.
  void
  addBit(RTLVariable*);
  
  /// Prints this variable to std::cerr. Needed for debugging only.
  void 
  print() const;
  
  /// Whether this variable is a bit.
  bool
  myIsBit;
};

#endif


