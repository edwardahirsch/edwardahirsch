#include "cnfparser.h"
#include "../logical/logical.h"
#include "../general/solver.h"
#include "../basicobject/simpleobjectset.h"

/** @author dmitrits 
 *  @brief implementation for cnfparser.h
 **/

  DeductionObjectSet *CNFParser::parseCNF(BooleanAlgebraicSolver *solver, const std::string fileName) 
  {
    myInputFile = fopen(fileName.c_str(),"r");
    if (!myInputFile)
    {
      std::cerr << "CNFParser error: " << fileName << " not found.\n";     
      exit(-1);
    } 
    char ch;
    int canRead=fscanf(myInputFile, "%c", &ch);
    if (canRead==-1)
    {
      std::cerr <<"CNFParser error: cannot read file " << fileName << ".\n";     
      exit(-1);      
    };
    while ((ch!='p') && (canRead!=-1)) 
    {
      readComment();
      canRead=fscanf(myInputFile, "%c", &ch);
    };
    if (ch=='p')
    {
      readProblem(solver);
    }
    else 
    {
      std::cerr << "CNFParser error: cannot find \'p\'.";      
      exit(-1);      
    }
    fclose(myInputFile);
    return myFormula;  
  };
  
  void CNFParser::readComment()
  {
    char ch;
    int canRead=0;
    do
    {
      canRead=fscanf(myInputFile, "%c", &ch);
    }
    while ((ch!='\n') && (canRead!=-1));
  };

  void CNFParser::readProblem(BooleanAlgebraicSolver *slv)
  { 
    char cnf[3];
    int canRead=fscanf(myInputFile,"%s%d%d", cnf, &myVarNumber, &myClauseNumber);
    if (cnf[0]!='c' || cnf[1]!='n' || cnf[2]!='f')
    {
      std::cerr<< "CNFParser error: cannot find \"cnf\".\n";
      exit(-1);      
    };
    if ((canRead==-1) || (myVarNumber<0) || (myClauseNumber<0))
    {
      std::cerr<< "CNFParser error: cannot read problem.\n";
      exit(-1);      
    }
    myFormula = new AdjDedObjSet(0,slv->getLog(),slv);
    for (int i=0; i<myClauseNumber; i++)
    {
      readClause(slv);
    };
  };

  void CNFParser::readClause(BooleanAlgebraicSolver *slv)
  {
    PSAClause clause=LogicalGenerator::makeSAClause();
    long int varId;
    int canRead=fscanf(myInputFile, "%ld", &varId);
    if (canRead==-1)
    {
      std::cerr<< "CNFParser error: cannot read clause.\n";
      exit(-1);      
    };
    while (varId!=0 && abs(varId)<=myVarNumber)
    {
       Variable var = AlgebraicGenerator::makeVariable(abs(varId),"",slv);
       myFormula->addVariable(var);
       PSALiteral literal;
       if (varId>0)
         literal=LogicalGenerator::makeBoolLiteral(var, true);
       else
         literal=LogicalGenerator::makeBoolLiteral(var, false);
       clause->add(literal);
       canRead=fscanf(myInputFile, "%ld", &varId);
       if (canRead==-1)
       {
        std::cerr<< "CNFParser error: cannot read clause.\n";
        exit(-1);      
       };
    };
    if (abs(varId) > myVarNumber)
    {
      std::cerr <<"CNFParser error: variable " << abs(varId) << " was not declared.\n";
      exit(-1);
    };
    myFormula->add(PDeductionObject(clause));
  };

DeductionObjectSet* CNFParser::parseCNF(BooleanAlgebraicSolver *solver, const int* const * const array)
{
  // creating an instance of the class Formula from the input array
  DeductionObjectSet *formula = new AdjDedObjSet(1,solver->getLog(),solver);
  
  int clause_num = 0;
  while (true) // reading clauses
  {
    if (array[clause_num] == 0)
      break;
  
    if (array[clause_num][0] == 0)
      break;
      
    PSAClause clause = LogicalGenerator::makeSAClause();
  
    int lit_num = 0;
    while (true) // reading literals of the current clause
    {
      if (array[clause_num][lit_num] == 0)
        break;
	
      formula->addVariable(abs(array[clause_num][lit_num]));
      
      if (array[clause_num][lit_num] > 0)
        clause->add(LogicalGenerator::makeBoolLiteral(array[clause_num][lit_num], true));

      if (array[clause_num][lit_num] < 0)
        clause->add(LogicalGenerator::makeBoolLiteral(-array[clause_num][lit_num], false));

      lit_num++;
    }
    formula->add(clause);
    clause_num++;
  };
  // end of creating a formula
  return formula;
}

