#include "monomial.h"
#include "misc/assert.h"

/**
 * @file monomial.cc
 * @brief implementation for monomial.h
 */

/* @author dmitrits */

Monomial& Monomial::operator *= (const Coefficient& coeff)
{
  setCoeff((this->getCoeff())*coeff);
  return *this;
}

Monomial& Monomial::operator *=(const PMonomial mon)
{
  return (*this)*=(*mon);
};

Monomial& Monomial::operator *=(const Monomial& mon)
{
  (*this)*=mon.getCoeff();
  PVariableIterator it=mon.getBeginIterator();
  while (!it->equals(*mon.getEndIterator()))
  {
    Variable var=**it;
    (*this)*=var;
    ++*it;
  };  
  return *this;
  
};

void Monomial::multiplyWithoutVariable(Variable var, PMonomial mon)
{
  (*this)*=mon->getCoeff();
  PVariableIterator it=mon->getBeginIterator();
  while (!it->equals(*mon->getEndIterator()))
  {
    if ((**it) != var)
      (*this)*=**it;
    ++*it;
  };  
};

Coefficient
Monomial::getValue(Assignment* a) const
{
  PVariableIterator var_it = this->getBeginIterator();
  PVariableIterator var_end = this->getEndIterator();
  
  for (; !var_it->equals(*var_end); ++*var_it)
  {
    int a_value = a->getValue(**var_it);
    if (a_value == -1)
    {
      std::cerr << "\n";
      a->print(std::cerr);
      exit(-1);
    }
    if (a_value == 0)
      return 0;
  }
  
  
  return this->getCoeff();
}



