#include "polynomial.h"

/**
 * @file polynomial.cc
 * @brief implementation for polynomial.h
 */

/* @author dmitrits */

 

Coefficient
Polynomial::getValue(Assignment* a) const
{
  Coefficient result = 0;

  PMonomialIterator mon_it = this->getBeginIterator();
  PMonomialIterator mon_it_end = this->getEndIterator();
  
  for (; !mon_it->equals(*mon_it_end); ++*mon_it)
    result += ((**mon_it)->getValue(a));
    
  return result;
}

