#include "equality.h"
#include "../algebraic.h"
#include "../../general/solver.h"
/**
 * @file equality.cc
 * @brief implementation for equality.h
 */


/* @author dmitrits */

 
PEquality Equality::substituteVarWithPoly(Variable var, PPolynomial poly) const
{
  return AlgebraicGenerator::makeEqualityWithCloning(this->getLHS()->substituteVarWithPoly(var,poly),
      this->getRHS()->substituteVarWithPoly(var,poly));
}

bool Equality::isDeg2Even() const
{
  return ( (this->getLHS()->getDegree() <= 1) && (this->getRHS()->isDeg2Even()));
}

bool Equality::oddPartEqualsModulo2(const PEquality &eq) const
{
  return ( this->getLHS()->oddPartEqualsModulo2(*(eq->getLHS())) && this->getRHS()->oddPartEqualsModulo2(*(eq->getRHS())));
}

PPolynomial Equality::getEvenPartDiff(const PEquality &eq) const
{
  PPolynomial result = AlgebraicGenerator::makePolynomial();
  // we add the difference of left-hand sides
  if (!result->addEvenPartDiff(*(this->getLHS()),*(eq->getLHS()))) 
  {
    PPolynomial res;
    return res;
  }
  // we add the difference of right-hand sides
  if (!result->addEvenPartDiff(*(eq->getRHS()),*(this->getRHS()))) 
  {
    PPolynomial res;
    return res;
  }
  return result;
}

bool Equality::getXeqAB(Variable &x, bool &posx, Variable &a, bool &posa, Variable &b, bool &posb) const
{
  if (!( (this->getLHS()->isVariable()) && (this->getRHS()->isTwoVariables()) )) return false;
  x = this->getLHS()->getVariable();
  posx = true; posa = true; posb = true;
  return this->getRHS()->getTwoVariables(a,b);
}

bool Equality::getXeqAB(long &x,long &a,long &b) const
{
  if (!( (this->getLHS()->isVariable()) && (this->getRHS()->isTwoVariables()) )) return false;
  x = this->getLHS()->getVariable();
  return this->getRHS()->getTwoVariables(a,b);
}


/*
bool Equality::oddPartEquals(const PEquality &eq) const
{
  if (!this->getLHS()->isVariable()) return false;
  if ( (!eq->getLHS()->isVariable()) || (eq->getLHS()->getVariable() != this->getLHS()->getVariable()) ) return false;
  return this->getRHS()->oddPartEquals(eq->getRHS());
}
*/

bool Equality::getOneOneMinusOne(long &x, long &a, long &b) const
{
  if (!this->getLHS()->isVariable()) return false;
  x = this->getLHS()->getVariable();
  if (!this->getRHS()->getOneOneMinusOne(a,b)) return false;
  return true;
}

bool Equality::getOneOneMinusTwo(long &x, long &a, long &b) const
{
  if (!this->getLHS()->isVariable()) return false;
  x = this->getLHS()->getVariable();
  if (!this->getRHS()->getOneOneMinusTwo(a,b)) return false;
  return true;
}

bool Equality::getOneOneMinusTwoWConst(long &x, long &a, long &b, bool &withconstant) const
{
  if (!this->getLHS()->isVariable()) return false;
  x = this->getLHS()->getVariable();
  if (!this->getRHS()->getOneOneMinusTwoWConst(a,b,withconstant)) return false;
  return true;
}

bool Equality::getXeqABpACpBCm2ABC(Variable& x,bool&px,Variable& a,bool&pa,Variable& b,bool&pb,Variable& c,bool&pc) const
{
  if (!this->getLHS()->isVariable()) return false;
  x = this->getLHS()->getVariable();
  if (!this->getRHS()->getABpACpBCm2ABC(a,b,c)) return false;
  px=true; pa=true; pb=true; pc=true;
  return true;
}

bool Equality::get124(Variable& x,Variable& a,Variable& b,Variable& c,bool&pc) const
{
  if (!this->getLHS()->isVariable()) return false;
  x = this->getLHS()->getVariable();
  if (!this->getRHS()->get124(a,b,c)) return false;
  pc=true;
  return true;
}

bool Equality::isLin2Subject() const
{
  if (!this->getLHS()->isVariable()) return false;
  if (!this->getRHS()->isLin2Subject()) return false;
  return true;
}

bool Equality::getLin2Subject(Variable& a,Variable& b) const
{
  if (!this->getLHS()->isVariable()) return false;
  if (!this->getRHS()->getLin2Subject(a,b)) return false;
  return true;
}

bool Equality::getLin2Subject(Variable& x, Variable& a,Variable& b,Coefficient& c1, Coefficient& c2, Coefficient& c12) const
{
  if (!this->getLHS()->isVariable()) return false;
  x = this->getLHS()->getVariable();
  if (!this->getRHS()->getLin2Subject(a,b,c1,c2,c12)) return false;
  return true;
}

bool Equality::getDeqABpACmABC(Variable& d,bool&pd,Variable& a,bool&pa,Variable& b,bool&pb,Variable& c,bool&pc) const
{
  if (!this->getLHS()->isVariable()) return false;
  d = this->getLHS()->getVariable();
  if (!this->getRHS()->getABpACmABC(a,b,c)) return false;
  pd=true; pa=true; pb=true; pc=true;
  return true;
}

bool Equality::getYeqACpDmACD(Variable& y,bool&py,Variable& a,bool &pa, Variable& c, bool &pc, Variable& d, bool &pd) const
{
  if (!this->getLHS()->isVariable()) return false;
  y = this->getLHS()->getVariable();
  if (!this->getRHS()->getACpDmACD(a,c,d)) return false;
  py=true; pa=true; pc=true; pd=true;
  return true;
}


bool Equality::isVarPresentAndNonAssigned(Variable x)
{
  if (!this->contains(x))  
    return false;
    
  if (this->isFirstType() && this->getLHS()->getVariable() == x)
    return false;

  return true;
}

bool Equality::isXYeq1(Variable& x, bool& x_sign, Variable& y, bool& y_sign) const
{
  // check the case xy=1 for
  if (this->getRHS()->getSize() == 1)
  {
    if (this->getRHS()->getFreeCoefficient() == 1 && 
    (**(this->getLHS()->getBeginIterator()))->getSize() == 2)
    {
      PMonomial mon = **(this->getLHS()->getBeginIterator());
      PVariableIterator it = mon->getBeginIterator();
      x = **it;
      ++*it;
      y = **it;
      x_sign = true;
      y_sign = true;
      
      return true;
      
      
    }
    
    return false;
  }
  
  // check the case x=1+xy;
  if (this->getRHS()->getSize() == 2 && this->getRHS()->getFreeCoefficient() == 1)
  {
    if (this->getRHS()->getFreeCoefficient() != 1)
      return false;
    
    PMonomialIterator mon_it = this->getRHS()->getBeginIterator();
    ++*mon_it;
    
    PMonomial mon = **mon_it;
    if (mon->getSize() != 2 || mon->getCoeff() != 1)
      return false;
      
      
    PVariableIterator it = mon->getBeginIterator();
    x = **it;
    ++*it;
    y = **it;
      
    if (this->getRHS()->getFreeCoefficient() != 1)
      return false;
      
      
    if ((**(this->getLHS()->getBeginIterator()))->getSize() != 1)
      return false;
      
      
    Variable left_var = **((**(this->getLHS()->getBeginIterator()))->getBeginIterator());
    
    if (left_var == x)
    {
      x_sign = true;
      y_sign = false;
      return true;
    }
    else
    {
      if (left_var == y)
      {
        y_sign = true;
        x_sign = false;
        return true;
      }
      else
        return false;
    }
      
    return false;
  }
  
  // check the case x=-y+xy;
  if (this->getRHS()->getSize() == 2 && this->getRHS()->getFreeCoefficient() == 0)
  {
    if (this->getRHS()->getFreeCoefficient() != 0)
      return false;
    
    
    PMonomialIterator mon_it = this->getRHS()->getBeginIterator();
    PMonomial mon = **mon_it;
    
    if (mon->getCoeff() != -1 || mon->getSize() != 1)
      return false;
      
    y = **(mon->getBeginIterator());    
    
    ++*mon_it;
    mon = **mon_it;
    
    if (mon->getCoeff() != 1 || mon->getSize() != 2)
      return false;
    
      
    PVariableIterator it = mon->getBeginIterator();
    if ((**it) == y)
    {
      ++*it;
      x = **it;
    }
    else
    {
      x = **it;
      ++*it;
      if ((**it) != y)
        return false;
    }
    
    if ((**(this->getLHS()->getBeginIterator()))->getSize() != 1)
      return false;
      
    Variable left_var = **((**(this->getLHS()->getBeginIterator()))->getBeginIterator());    
    
    if (left_var == x)
    {
      x_sign = false;
      y_sign = false;
    }
    else
      return false;
    
    return true;    
  }
    

  
  return false;
}


bool 
Equality::isCarryBitEquality() const
{
  if (this->getRHS()->getDegree() > 1)
    return false;
    
  if (this->getLHS()->getDegree() > 1)
    return false;

  if (this->getVariableList()->size() > 5)
    return false;

  bool has_coef_2 = false;
  PMonomialIterator mon_it = this->getRHS()->getBeginIterator();
  while (!mon_it->equals(*(this->getRHS()->getEndIterator())))
  {
    if (abs((**mon_it)->getCoeff()) == 2)
    {
      has_coef_2 = true;
      break;
    }
    ++*mon_it;
  }
  
  if (!has_coef_2)
    return false; 

    
  return true;
}

bool
Equality::isSatisfiedBy(Assignment* a) const
{
  return (this->getLHS()->getValue(a) == this->getRHS()->getValue(a));
}
