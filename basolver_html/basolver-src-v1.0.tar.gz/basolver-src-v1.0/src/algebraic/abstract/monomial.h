#ifndef __MONOMIAL_H__
#define __MONOMIAL_H__

/**
 * @file monomial.h
 * @brief Defines the structure of the Monomial class
 * @author sergey
 */

#include "boost/smart_ptr.hpp"
#include "coefficient.h"
#include "variable.h"
#include "../../indexing/variableiterator.h"
#include "logical/abstract/assignment.h"

/**
 * Forward declarations
 */
class Monomial;
/**
 * smart pointer for \ref Monomial
 */
typedef boost::shared_ptr<Monomial> PMonomial;

/**
 * Abstract monomial class; defines
 * all functions we need from a monomial.
 *
 * \invariant
 * - A monomial does not contain any variable more than once.
 * - If the coefficient is zero, then a monomial contains no variables.  
 */
class Monomial
{
public:
  /**
   * Multiplies by a coefficient
   */
  virtual Monomial& 
  operator *=(const Coefficient& coeff);

  /**
   * Multiplies by a variable
   */
  virtual Monomial&
  operator *=(const Variable var) = 0;
  
  /**
   * Multiplies by another monomial
   */
  virtual Monomial& 
  operator *=(const PMonomial mon);

  /**
   * Multiplies by another monomial
   */
  
  virtual Monomial&
  operator *=(const Monomial& mon);

  /**
   * Multiplies by the given monomial discarding the given variable
   */
  virtual void multiplyWithoutVariable(Variable,PMonomial);
  
  /**
   * Returns true if monomial consists only this two variables
   */    
  virtual bool consistsOfTwoVars(Variable var1, Variable var2) const = 0;
    
  /**
   * Sets the coefficient
   */
  virtual void 
  setCoeff(Coefficient) = 0;

  /**
   * Gets the coefficient
   */
  virtual Coefficient 
  getCoeff() const = 0;

  /**
   * Prints monomial
   */
  virtual std::ostream& 
  print(std::ostream& os,BooleanAlgebraicSolver *slv) = 0;
  
  /**
   * Assigns value (0, 1) to variable 
   * returns if the monomial not equals 0 (Coefficient=0)
   */

  virtual bool assign(Variable var, int value)=0;
  
  /**
   * Substitutes one variable instead another (x:=y)
   */  
  virtual void substituteEqual(Variable x, Variable y)=0; 

  /**
   * Returns begin iterator of variable list ordered my number
   */
  
  virtual PVariableIterator getBeginIterator() const=0;

  /**
   * Returns end iterator of variable list 
   */
  
  virtual PVariableIterator getEndIterator() const=0;

  /**
   * Returns whether monomial contains the given variable
   */
  virtual bool contains(Variable var) const = 0;
  
  /**
   * Compares two monomials:
   * - the monomial with less degree is less;
   * - order of monomial with the same degree is lexicographical
   */
  virtual bool
  isLess(Monomial& mon) const = 0;

  /**
   * Compares two monomials:
   * the monomial with less degree is less;
   * order of monomial with the same degree is lexicographical
   */

  bool operator < (Monomial& mon) const {return isLess(mon);};
  
  /**
   * Compares two monomials:
   * monomials are equals if the sets of there variables are the same;
   * coeffitients may differ
   */

  virtual bool operator == (Monomial& mon) const=0;

  /**
   * Compares two monomials:
   * monomials are equals if the sets of there variables are the same;
   * coeffitients may differ
   */

  bool operator!=(Monomial& monom) const {return ! ((*this)==monom);};

  /**
   * Clones the monomial
   * returns the PMonomial with the same Variables
   */
  virtual PMonomial clone() const = 0;

  /**
   * Returns the second variable of this monomial;
   * if it contains less than two vars, returns var with number 0
   */
  virtual Variable getSecondVariable() const = 0;
  
  /**
   * Checks if monomial represents variable 
   */      
  virtual bool isVariable() const = 0;
  /**
   * Checks if monomial is a single given variable
   */
  virtual bool isVariable(long a) const = 0;
  /**
   * Checks if monomial consists of two variables with given numbers
   */
  virtual bool isTwoVariables(long a,long b) const = 0;
  /**
   * Checks if monomial consists of two variables; assign their values to params
   */
  virtual bool getTwoVariables(long &a, long &b) const = 0;
  /**
   * Checks is monomial consists of three variables; assign them to params
   */
  virtual bool getThreeVariables(Variable &a, Variable &b, Variable &c) const = 0;
  /**
   * Checks if monomial consists of two variables
   */
  virtual bool isTwoVariables() const = 0;
  
  /**
   * Returns variable with the smallest number
   */    
  
  virtual Variable getVariable()=0;
  
  /** 
   * Checks if monomial represents constant
   */    
   
  virtual bool isConstant()=0;     
 
   /**
   * Returns constant - coefficient
   */
  
  virtual Coefficient getConstant() {return this->getCoeff();}; 

      
  /**
   * Virtual destructor
   */   
   
   
  virtual ~Monomial() {}
  
  /**
   * Returns the number of variables
   */    
  
  virtual long int getSize() const=0;
  
  /**
   * Checks if mon divides monomial monomial
   */ 
  
  virtual bool isContain(PMonomial mon) const=0;

  /**
   * Returns qoutient monomial/mon if it is monomial 
   */ 
  
  virtual PMonomial getQuotient(PMonomial mon) const=0;
   /**
   * Applies the assignment and returns the result
   */
  virtual long applyAssignment(bool *) const = 0;

  /// Returns the value of this monomial 
  /// under a given assignment.
  virtual Coefficient
  getValue(Assignment*) const; 
};

#endif

