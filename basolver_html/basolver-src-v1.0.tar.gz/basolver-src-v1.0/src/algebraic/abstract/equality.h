#ifndef __EQUALITY_H__
#define __EQUALITY_H__

/**
 * @file equality.h
 * @brief Defines the structure of the Equality class
 */

#include "boost/smart_ptr.hpp"
#include "polynomial.h"
#include "basicobject/modobj.h"
#include "misc/assert.h"

#include "../../logical/abstract/saliteral.h"


/**
 * Forward declarations
 */
class Equality;
class BooleanAlgebraicSolver;
/**
 * smart pointer for /ref Equality
 */
typedef boost::shared_ptr<Equality> PEquality;

/**
 * Abstract equality class; defines
 * all functions we need from an equality.
 * The general form of equality is poly1=poly2, 
 * where poly1 and poly2 are polynomials of Boolean 
 * variables and constants.
 *  
 * \invariant
 * - The left hand side of an equality does not contain a constant monomial.
 * - The most common divisor of all monomials of equality is 1. 
 * - poly1 and poly2 do not share equal monomials.
 * - If an equality contains at least one non-constant monomial,
 * then its left hand side contains the minimal monomial.
 * - The coefficient of a monomial at the left hand side is positive.
 *  - If the equality represents a=b, where a and b are variables, then a<b
 *  - If the equality is representation of (a xor b xor c =0) in the form a=b+c-2bc, then a<b, a<c.
 * 
 * @see Polynomial 
 */
class Equality : public SALiteral, public ModificationObject
{
public:
  /**
   * returns true if right hand side equals to constant 1.
   */

  virtual bool isPositive() const = 0;
  /**
   * checks whether this is of degree 2 and has even coefficients
   * of its deg 2 monomials
   */
  virtual bool isDeg2Even() const;
  /**
   * clones as object
   */
  virtual PModificationObject cloneObject() const = 0;

  /**
   * returns the variable defined by this equality, if marked; 0 otherwise
   */
  virtual Variable getMainVar() const { 
    return 0; 
  }

  /**
   * marks the variable defined by this equality (0 to unmark)
   */
  virtual void setMainVar(Variable var) { 
    Assert(0,"Equality::setMainVar");
    return; 
  }

  /**
   * assigns values to variables
   */
  virtual AssignReturnType assign(Variable var, int val) = 0;
  
  /**
   * substitutes one variable instead another (x:=y)
   */    
  virtual AssignReturnType substituteEqual(Variable x, Variable y) = 0;
  
  /**
   * substitutes negation of one variable instead another (x:=1-y)
   */    
  virtual AssignReturnType substituteNonEqual(Variable x, Variable y) = 0;

  /**
   * if equality is of form
   * lhs=P+ mQ, where m - monomial P, Q polynomials, P and Q does not have
   * any monomial, contained m.
   * And t2equality is of form m=M+c, where M - monomial
   * rhs:=P+MQ+cQ
   */    
  virtual AssignReturnType substituteMonomial(PEquality t2Equality) = 0;
  
  /**
   * printing method
   */
  virtual std::ostream& print(std::ostream&,BooleanAlgebraicSolver *,bool print_as_dedobj = false) = 0;

  /**
   * checks whether this equality is deleted already
   */
  virtual bool isDeleted() const = 0;
  
  /**
   * erases this equality
   */
  virtual void erase() = 0;
  
  /**
   * unerases this equality
   */
  virtual void unErase() = 0;
  
  /**
   * returns the list of variables occurring in this equality
   */
  virtual PVarList getVariableList() const = 0;
  
  /**
   * returns left hand side polynomial
   */    
  virtual PPolynomial getLHS() const = 0;
  
  /**
   * returns right hand side polynomial
   */    
  virtual PPolynomial getRHS() const = 0;
  
  /**
   * determine the type of equality,
   * returns true if equality is in form of x=0 or x=1, x is variable.
   */
  virtual bool isBoolean() const=0; 
  
  /**
   * determines the type of equality,
   * returns true if equality is in form of x=0 or x=1 or x=y or x=1-y;
   * x and y are variables.
   */
  virtual bool isFirstType() const=0; 

  /**
   * determines the type of equality,
   * returns true if equality is in form m=M+c,
   * where both m and M are monomials containing more than one Boolean 
   * variable, c is an integer constant.
   */
  virtual bool isSecondType() const=0; 

  /**
   * determines the type of equality,
   * returns true if equality is in form a1x1+...+alxl=b1y1+...bnyn
   * where xi, xj - boolean variables; l,n >1; ai, bj integer constants
   */
  virtual bool isThirdType() const=0; 
  
  /**
   * returns true if equality is tautology (0=0)
   */      
  virtual bool isTautology() const=0 ;
  
  /**
   * returns true if equality is contradiction (1=0)
   */      
  virtual bool isUnsatisfiable() const=0;

  /**
   * same as isXeqAB, but x,a,b may be arbitrary,
   * and their values are assigned to the parameters
   */
  virtual bool getXeqAB(long &,long &,long &) const;

  /**
   * same as isXeqAB, but x,a,b may be arbitrary literals,
   * and their variables and posvalues are assigned to the parameters
   */
  virtual bool getXeqAB(Variable &,bool &,Variable &,bool &,Variable &,bool &)  const;

  /**
   * returns that odd parts of these equalities are equal modulo 2
   */
  virtual bool oddPartEqualsModulo2(const PEquality &eq) const;

  /**
   * given two equalities L=2S and L'=2T s.t. L'=L+2P,
   * returns (S-T-P)
   */
  virtual PPolynomial getEvenPartDiff(const PEquality &eq) const;
 
  
 
  /**
   * returns true if the equality looks like
   *   x = a+b-2ab
   * the values of x,a,b are assigned to parameters
   * also checks whether the rhs has a constant
   */
  virtual bool getOneOneMinusTwoWConst(long &,long &,long &,bool &) const;

  /**
   * returns true if the equality looks like
   *   x = a+b-2ab
   * the values of x,a,b are assigned to parameters
   */
  virtual bool getOneOneMinusTwo(long &,long &,long &) const;

 /**
   * returns true if the equality looks likes
   *   x = a+b-ab
   * the values of x,a,b are assigned to parameters
   */
  virtual bool getOneOneMinusOne(long &, long &, long &) const;

  /**
   * checks if we can use this equality as modification object
   */    
  bool isModifier() {return isFirstType() || isSecondType() || isThirdType();};
  
  /**
   * returns boolean variable if equality represents boolean literal (x=1) or (x=0)
   * if equality does not represent boolean literal returns variable with 0 number
   */    
   
  virtual Variable getBooleanVariable()=0; 
  
  /**
   * returns sign of boolean variable if equality represents boolean literal (x=1) or (x=0)
   * (x=1)=> true; (x=0)=>false
   * if equality does not represent boolean literal returns false
   */    
   
  virtual bool getBooleanSign()=0; 

  /**
   * compares two equalities
   */        

  virtual bool operator == (SALiteral& literal) const=0;

  /**
   * tells whether this equality may be subject to BoothSubRule with
   * the given variable; if so, sets the coefficient of the
   * necessary variable (if translated to the left-hand side) and the
   * polynomial that is to be substituted for this variable
   */
  virtual bool isBoothSubSubject(Variable var,Coefficient &coeff,PPolynomial &poly) const {
    Assert(0,"Equality::isBoothSubSubject");
    return false;
  };
  
  /**
   * compares two equalities
   */        

  bool operator!=(SALiteral& literal) const {return ! ((*this)==literal);};

  /**
   * compares two equalities
   */        
  
  virtual bool operator < (SALiteral& literal) const=0;
  /**
   * virtual destructor
   */
  virtual ~Equality() {}
  
  /**
   * returns new Equality with new rhs:= 1 - (old rhs)
   */    
  virtual  PEquality negation() const =0;
  
  /**
   * only for equalities -- boolean literals.
   * x=0 => x;
   * x=1 => 1-x
   */         
  virtual PPolynomial getPolynomialRepresentation() = 0;  
  /// same as above, but without cloning of the representation (if it is kept
  /// with the equality)
  /// defaults to getPolynomialRepresentation
  virtual PPolynomial getPolynomialRepresentationWithoutCloning() {return this->getPolynomialRepresentation();};
  /// same as above, but returns the negated representation (if it is kept
  /// with the equality)
  /// defaults to getPolynomialRepresentation
  /// ONLY MAKES SENSE for \ref BooleanEquality
  virtual PPolynomial getNegatedPolynomialRepresentationWithoutCloning() {return this->getPolynomialRepresentation();};

  /// returns whether the given equality is a negation of this one
  /// only works for \ref BooleanEquality
  virtual bool isNegation(PEquality eq) const { 
    Assert(0,"Equality::isNegation");
    return false;
  };

  /// returns the boolean variable of this equality;
  /// if the equality is not a \ref BooleanEquality, returns 0
  Variable getBooleanVariable() const {
    return 0;
  };
  /// returns the boolean sign of this equality;
  /// if the equality is not a \ref BooleanEquality, returns false
  bool getBooleanSign() const {
    Assert(0,"Equality::getBooleanSign");
    return false;
  };
 
  
  /**
   * returns this equality where the given variable is substituted with the given polynomial
   */
  virtual PEquality substituteVarWithPoly(Variable var, PPolynomial poly) const;
  
  virtual bool getXeqABpACpBCm2ABC(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const;
  virtual bool get124(Variable&,Variable&,Variable&,Variable&,bool&) const;
  virtual bool getDeqABpACmABC(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const;
  virtual bool getYeqACpDmACD(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const;
  virtual bool getYeqACpnAB(Variable &x, bool &px, Variable &a, bool &pa, Variable &c, bool &pc, Variable &b, bool &pb) const {return false;};
 
  virtual bool getLin2Subject(Variable &, Variable &) const;
  virtual bool isLin2Subject() const;
  virtual bool getLin2Subject(Variable&, Variable &, Variable &,Coefficient&,Coefficient&,Coefficient&) const;
  /// checks whether this equality is of the form xy=1
  /// for some literals x and y. If it is, 
  /// this literals are stored in input parameters (as variables and signs).
  virtual bool isXYeq1(Variable&, bool&, Variable&, bool&) const;

  virtual bool getLHSVariable(Variable&) const = 0;

  virtual long getFirstVariableNumber() const = 0;

  /// set variable 1; applicable only for \ref TypedEquality
  virtual void setVar1(Variable) 
  {
    Assert(0,"tried to set var not from typed equality");
  }; 
  
  /// get variable 2; applicable only for \ref TypedEquality
  virtual void setVar2(Variable)
  {
    Assert(0,"tried to set var not from typed equality");
  }; 
  
  /// set variable 3; applicable only for \ref TypedEquality
  virtual void setVar3(Variable)
  {
    Assert(0,"tried to set var not from typed equality");
  }; 
  
  /// set variable 4; applicable only for \ref TypedEquality
  virtual void setVar4(Variable)
  {
    Assert(0,"tried to set var not from typed equality");
  };
 
  /// set variable 5; applicable only for \ref TypedEquality
  virtual void setVar5(Variable)
  {
    Assert(0,"tried to set var not from typed equality");
  };


  /// set sign of variable 1 in the corresponding literal; applicable only for \ref TypedEquality
  virtual void setPos1(bool) 
  {
    Assert(0,"tried to set pos value not from typed equality");
  };
  /// set sign of variable 2 in the corresponding literal; applicable only for \ref TypedEquality
  virtual void setPos2(bool)
  {
    Assert(0,"tried to set pos value not from typed equality");
  };
  /// set sign of variable 3 in the corresponding literal; applicable only for \ref TypedEquality
  virtual void setPos3(bool) 
  {
    Assert(0,"tried to set pos value not from typed equality");
  };
  /// set sign of variable 4 in the corresponding literal; applicable only for \ref TypedEquality
  virtual void setPos4(bool)
  {
    Assert(0,"tried to set pos value not from typed equality");
  };
  /// set sign of variable 5 in the corresponding literal; applicable only for \ref TypedEquality
  virtual void setPos5(bool) 
  {
    Assert(0,"tried to set pos value not from typed equality");
  };


  /**
   * get the type of this equality
   * @see TEqualityType
   */
  virtual TEqualityType getEqType() const {return Special;};

  /**
   * set the type of this equality
   */
  virtual void setEqType(TEqualityType newType)
  {
    Assert(0,"tried to set type not from typed equality");
  }

  /// recalculates equality type
  void recalculateType();
 
  virtual bool getXeqABnew(Variable &, bool &, Variable &, bool &, Variable &, bool &) const {
    Assert(0,"Equality::getXeqABnew");
    return false;
  };
  
  /// checks whether this equality is of the form y=ac+d-acd.
  virtual bool getYeqACpDmACDnew(Variable &, bool &, Variable &, bool &, Variable &, bool &,Variable &,bool &) const {
    Assert(0,"Equality::getYqeACpDmACDnew");
    return false;
  };
  
  virtual bool
  isVarPresentAndNonAssigned(Variable x);
  
  /// checks whether this equality has the form like equality 
  /// representing the fact that the right output of a full adder 
  /// is equal to sum of its inputs minus two carry bits.
  virtual bool
  isCarryBitEquality() const;
  
  /// checks whether this equality is satisfied by a given assignment.
  virtual bool
  isSatisfiedBy(Assignment* a) const;
};



#endif

