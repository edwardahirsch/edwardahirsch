#include "variable.h"

/**
 * @file variable.cc
 * @brief implementation for variable.h
 * @author sergey
 */




