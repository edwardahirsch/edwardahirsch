#ifndef __COEFFICIENT_H__
#define __COEFFICIENT_H__

/**
 * @file coefficient.h
 * @brief typedefs for literal coefficients;
 * may later be developed into a class if needed
 *
 * @author sergey
 **/

/**
 * Coefficient
 */
typedef int Coefficient;

/**
 * Smart pointer for \ref Coefficient; never used,
 * since \ref Coefficient is a basic type
 */
typedef boost::shared_ptr<Coefficient> PCoefficient;

#endif
