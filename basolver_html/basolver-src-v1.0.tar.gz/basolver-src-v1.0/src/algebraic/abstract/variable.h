#ifndef __VARIABLE_H__
#define __VARIABLE_H__

/**
 * @file variable.h
 * @author sergey
 * @brief Contains class description for the basic Variable type
 */

#include <stdio.h>
#include "boost/smart_ptr.hpp"
#include <iostream>
#include <string>
#include <list>
#include <map>
#include "misc/tracer.h"

/**
 * enum for the return type of various assign procedures
 * may be ART_Active, ART_Satisfiable, or ART_Unsatisfiable
 */
typedef enum {
  ART_Active,
  ART_Satisfiable,
  ART_Unsatisfiable
} AssignReturnType;

/// we represent variables as long numbers
typedef long Variable;

/// this is a list of variables
typedef std::list<long> VarList;

/// shared pointer for \ref VarList
typedef boost::shared_ptr<VarList> PVarList;

#endif
