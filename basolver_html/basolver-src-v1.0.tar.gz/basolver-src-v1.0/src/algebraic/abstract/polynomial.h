#ifndef __POLYNOMIAL_H__
#define __POLYNOMIAL_H__

/**
 * @file polynomial.h
 * @brief Defines the structure of the polynomial class
 * @author dmitrits
 */

#include "boost/smart_ptr.hpp"
#include "monomial.h"
#include "indexing/monomialiterator.h"


/**
 * Forward declarations
 */
class Polynomial;
/**
 * smart pointer for \ref Polynomial
 */
typedef boost::shared_ptr<Polynomial> PPolynomial;

/**
 * Abstract polynomial class; defines
 * all functions we need from a polynomial.
 *
 * \invariant
 * - A polynomial does not contain any monomial more than once.
 * - A polynomial contains it's monomial in lexicographical order. 
 */
class Polynomial
{
public:

  /**
   * adds in the arithmetical sense
   */


  virtual void addMonomial(const PMonomial) = 0;
  /**
   * adds in the arithmetical sense
   */

  virtual void addMonomialWithCloning(const PMonomial) = 0;
  /**
   * adds in the arithmetical sense
   */

  virtual Polynomial& operator += (const Polynomial&) =0;
  /**
   * adds in the arithmetical sense
   */

  virtual Polynomial& operator += (const Coefficient&) = 0;

  /**
   * subtracts in the arithmetical sense
   */

  virtual Polynomial& operator -= (const Polynomial&) =0;


  /**
   * multiplies in the arithmetical sense
   */

  virtual Polynomial& operator *= (const Polynomial&) =0;
  /**
   * multiplies in the arithmetical sense
   */

  virtual Polynomial& operator *= (Monomial&) = 0;
  /**
   * multiplies in the arithmetical sense
   */

  virtual Polynomial& operator *= (const Coefficient&) = 0;
  
  /**
   * prints polynomial
   */

  virtual std::ostream& 
  print(std::ostream& os,BooleanAlgebraicSolver *slv=0) = 0;

  /**
   * returns begin iterator
   */        
  virtual PMonomialIterator getBeginIterator() const = 0; 
  
  /**
   * returns end iterator
   */        
  virtual PMonomialIterator getEndIterator() const = 0; 
 
  /**
   * returns the first variable that occurs linearly with even coefficient
   * if none such variables are available, returns 0
   */
  virtual Variable getFirstLinearVariable() = 0;
  /**
   * removes monomial
   */  
  virtual PMonomialIterator remove(PMonomialIterator&) = 0;
  
  /**
   * compares two polynomials
   */        
  virtual bool operator == (Polynomial& polynom) const=0;
  
  /**
   * compares two polynomials
   */        
  bool operator!=(Polynomial& polynom) const {return ! ((*this)==polynom);};
  
  /**
   * compares two polynomials
   * returns 1 if polynomial is less than the parameter
   * returns -1 if polynomial is greater than the parameter
   * returns 0 if they are equal
   */        
  virtual int compare(const Polynomial& polynom) const=0;
  
  
  /**
   * returns number of monomials
   */    
    
   
  virtual long int getSize() const=0; 
  
  /**
   * assigns values to variable
   */    
   
  virtual void assign(Variable var, int value)=0; 
 
  /**
   * substitutes a given variable with a given polynomial
   * returns the result
   */
  virtual PPolynomial substitute(Variable var, PPolynomial poly) const = 0;
  
  /**
   * substitutes one variable instead another (x:=y)
   */    
   
  virtual void substituteEqual(Variable x, Variable y)=0; 
  

  /**
   * substitutes negation of one variable instead another (x:=1-y)
   */    
   
  virtual void substituteNonEqual(Variable x, Variable y)=0;

  /**
   * tells whether the given variable occurs here linearly
   * sets the value of coeff to the coefficient of this variable
   */
  virtual bool occursLinear(Variable var,Coefficient &coeff) const = 0;
  
  /**
   * checks if polynomial represents variable 
   */     
   
  virtual bool isVariable() const =0;

  /**
   * cuts the given variable from this polynomial;
   * if the variable appears positively, multiply it by -1
   * (that is, make x=P from 0=P-x)
   * return false if the variable does not appear or if it has non-unit
   * coefficient; return true otherwise
   */
  virtual bool cutVariable(Variable var) = 0;

  /**
   * substitutes the given variable with the given polynomial and returns
   */
  virtual PPolynomial substituteVarWithPoly(Variable var, PPolynomial poly) const = 0;
  
  /**
   * checks whether polynomial has degree 2 and has even coefficients
   * of its degree 2 monomials
   */
  virtual bool isDeg2Even() const = 0;

  /// checks if polynomial consists of a given variable
  virtual bool isVariable(long) const = 0;
  /// checks if polynomial consists of two given variables
  virtual bool isTwoVariables(long,long) const = 0;
  /// checks if polynomial consists of one monomial with two variables
  virtual bool isTwoVariables() const = 0;
  /**
   * checks if polynomial consists of one monomial with two variables and
   * assign their values to params
   */
  virtual bool getTwoVariables(long &,long &) const = 0;
 
  /**
   * returns variable with the smallest number
   */    
  
  virtual Variable getVariable()=0;

  /**
   * checks whether two polynomials coincide modulo 2
   */
  virtual bool oddPartEqualsModulo2(Polynomial &) const = 0;

  /**
   * adds to this polynomial the even difference between two given polynomials
   * (that is, given L+2S and L'+2T, where L=L'+2P, add S+P-T
   */
  virtual bool addEvenPartDiff(const Polynomial &,const Polynomial &) = 0;
 
  /** 
   * checks if polynomial represents constant
   */    
   
  virtual bool isConstant() const = 0;     
  
  /**
   * returns first coefficient in the list of monomials   
   */
   
  virtual Coefficient getFirstConstant() const = 0; 
   
  /**
   * virtual destructor
   */
  virtual ~Polynomial() {}
 
  
  /**
   * cloning method
   */    
  virtual PPolynomial clone()=0; 
  
  /**
   * returns odd coefficient monomials
   */        
  virtual PPolynomial getOddPart() const=0; 

  /**
   * returns variable from odd part
   */        
  virtual Variable getOddVariable() const = 0;

  /**
   * checks whether this polynomial has coefficients bigger then 2
   */
  virtual bool hasBigCoefficients() const = 0;
  
  /**
   * checks whether polynomial looks like a+b-ab with given a,b
   */
  virtual bool isOneOneMinusOne(long,long) const = 0;
  /**
   * checks whether polynomial looks like a+b-ab
   */
  virtual bool isOneOneMinusOne() const = 0; 
  /**
   * checks whether polynomial looks like a+b-ab; assigns the variable numbers a,b to params
   */
  virtual bool getOneOneMinusOne(long &,long &) const = 0;
 /**
   * checks whether polynomial looks like a+b-2ab with the given a,b
   */
  virtual bool isOneOneMinusTwo(long,long) const = 0;
  /**
   * checks whether polynomial looks like a+b-2ab
   */
  virtual bool isOneOneMinusTwo() const = 0;

  /**
   * checks whether polynomial looks like a+b-2ab, where a,b may be literals
   */
  virtual bool isOneOneMinusTwoWConst() const = 0;
  
  /**
   * checks whether polynomial looks like a+b-2ab; 
   * assigns the variable numbers a,b to params;
   * a,b may be literals; also checks for constant 
   */
  virtual bool getOneOneMinusTwoWConst(long &,long &, bool &withconstant) const = 0;
  
  /**
   * checks whether polynomial looks like a+b-2ab;
   * assigns the variable numbers a,b to params
   */
  virtual bool getOneOneMinusTwo(long &,long &) const = 0;
 /**
   * checks whether polynomial looks like ab+ac+bc-2abc; assigns the variables a,b,c to params
   */
  virtual bool isABpACpBCm2ABC() const = 0;
  /**
   * checks whether polynomial looks like ab+ac+bc-2abc; assigns the variables a,b,c to params
   */
  virtual bool getABpACpBCm2ABC(Variable&,Variable&,Variable&) const = 0;
 /**
   * checks whether polynomial looks like 1+/-(a+b+c-2ab-2ad-2ac+4abc); assigns the variables a,b,c to params
   */
  virtual bool get124(Variable&,Variable&,Variable&) const = 0;
  /**
   * checks whether polynomial looks like ab+ad-abc; assigns the variables a,b,c to params
   */
  virtual bool getABpACmABC(Variable&,Variable&,Variable&) const = 0;

  /**
   * checks whether polynomial looks like ab+ad-abc;
   */
  virtual bool isABpACmABC() const = 0;

  /**
   * checks whether polynomial looks like ac+d-acd; assigns the variables a,c,d to params
   */
  virtual bool getACpDmACD(Variable&,Variable&,Variable&) const = 0;

  /**
   * checks whether polynomial looks like ac+d-acd
   */
  virtual bool isACpDmACD() const = 0;

  /**
   * checks whether polynomial looks like 1+/-(a+b+c-2ab-2ad-2ac+4abc)
   */
  virtual bool is124() const = 0;

  /**
   * checks whether polynomial looks like c1*x+c2*y+c3*xy, where
   * c1 and c2 might be zero; assigns x,y to params
   */
  virtual bool getLin2Subject(Variable&,Variable&) const = 0;

  /**
   * checks whether polynomial looks like c1*x+c2*y+c3*xy, where
   * c1 and c2 might be zero
   */
  virtual bool isLin2Subject() const = 0;

  /**
   * checks whether polynomial looks like linear sum
   */
  virtual bool isLinear() const = 0;

  /**
   * checks whether polynomial looks like c1*x+c2*y+c12*xy, where
   * c1 and c2 might be zero; assigns x,y,c1,c2,c12 to params
   */
  virtual bool getLin2Subject(Variable&,Variable&,Coefficient&,Coefficient&,Coefficient&) const = 0;

  /**
   * returns even coefficient monomials
   */        
   
  virtual PPolynomial getEvenPart() const=0;  

  /**
   * returns linear monomials
   */        
   
  virtual PPolynomial getLinearPart() const=0;  

  /**
   * returns nonlinear monomials
   */        
   
  virtual PPolynomial getNonLinearPart() const=0;  

  /**
    * P=r+MQ where P - polynomial M - monomial (divisor)
    * Q  - partial quotient (Polynomial)
    * r -remainder (Polynomial)
    * There are now monomials in r, that contains M
    * Returns partial Quotient
    */
  virtual PPolynomial getQuotient(PMonomial mon) const=0;

  /// tells whether this polynomial is lexicographically less than
  /// the given one
  virtual bool isLexLess(const PPolynomial poly) const = 0;
  
  /**
    * P=r+MQ where P - polynomial M - monomial (divisor)
    * Q  - partial quotient (Polynomial)
    * r -remainder (Polynomial)
    * There are now monomials in r, that contains M
    * Returns remainder
    */
  virtual PPolynomial getRemainder(PMonomial mon) const=0;

  /**
   * returns a boolean negation of this polynomial, (1-P).
   * 
   */
  virtual PPolynomial getNegation() = 0;


  /**
    * check if variable var has at least 1 entrance
    */

  virtual bool containsVariable(Variable var) const=0; 

  /**
   * cuts the last monomial of this polynomial
   */
  virtual void cutLastMonomial() = 0;
  
  /**
   * adds in list variables from polynomial
   */
  
  virtual PVarList getVarList(PVarList varList) const=0;
  
  /// returns a free coefficient of this polynomial.
  virtual Coefficient
  getFreeCoefficient() const = 0;

  /**
   * returns degree of polynomial
   */

  virtual int
  getDegree() const = 0;
  
  /**
   * returns true if polynomial reprresents variable or 1-variable
   */
  
  virtual bool isLiteral() const = 0;

  /**
   * returns true if polynomial does not contain given variables in linear part
   */
  virtual bool doesNotContain(Variable a, Variable b, Variable c) const = 0;

  /**
   * returns true if polynomial does not contain given variables in linear part
   */
  virtual bool doesNotContain(Variable a, Variable b) const = 0;
  
  /**
   * returns trivial upper bound on the value of polynomial
   */
  
  virtual long getUpperBound() const =0;
  
  /**
   * returns trivial lower bound on the value of polynomial
   */

  virtual long getLowerBound() const=0;
  
  /**
   * checks if poly=1+2S
   */

  virtual bool isObviousOdd() const=0;
  
  /**
   * let us a<b<c - variables, k - constant
   * k(a+b+c-2ac-1) --> (a+b+c-2bc-1)
   * k(a+b+c-2ab-1) --> (a+b+c-2bc-1)
   * k(a+c-b-2ac) --> (-a+b+c-2bc)
   * k(a+b-c-2ab) --> (-a+b+c-2bc) 
   * Saves variables and literal signs.
   */
   
  virtual bool xorTypeNormalize(Variable&, bool&, Variable&, bool&, Variable&, bool&)=0;     

  /**
   * let us a<b - variables, k - constant
   * k(a+b-2ab) --> (-a+b) 
   * k(1-a-b+2ab) --> (1-a-b)
   */  
  
  virtual void squareOfSumNormalize()=0;

  /**
   *  parses representation of k(x-ab), there x, a and b are literals;   
   *  saves variables and literal signs;
   *  returns true if parsing was successful.
   */  
  
  virtual bool parseANDRepresentation(Variable&, bool&, Variable&, bool&, Variable&, bool&) const=0;

  /**
   *  parses representation of k(ab), there a and b are literals, k is a constant;   
   *  saves variables and literal signs;
   *  returns true if parsing was successful.
   */  

  
  virtual bool parseABeq0(Variable& var1, bool& pos1, Variable& var2, bool& pos2) const=0;

  /**
   *  parses representation of k(x-ab), there x, a and b are literals, k is a constant, 
   *  and a=1-x;  
   *  save variables and literal signs;
   *  returns true if parsing was successful.
   */  
  
  virtual bool parseXeqAnotX(Variable& var1, bool& pos1, Variable& var2, bool& pos2, Variable&, bool&) const=0;

  /**
   *  parses representation of x+y-2S, there x and y are literals;
   *  save variables and literal signs and 2S to even,
   *  returns true if parsing was successful.
   */  
  
  
  virtual bool parseAplusB(Variable& var1, bool& pos1, Variable& var2, bool& pos2, PPolynomial& even) const=0;  
  /// returns the coefficient of an input monomial in this 
  /// polynomial. 
  virtual Coefficient
  getCoefficient(PMonomial mon) = 0;
  
  /// applies the assignment
  virtual long applyAssignment(bool *) const = 0;

  ///checks if sum of two polynomials represents (2c+1)X+(2a+1)Y+d+2S,
  /// where X,Y are variables or zeros, (if X==0, then Y==0), c,a,d are integer and S is polynomial; 
  /// sets variable x:=X, y:=Y and
  /// sign_equals:=d is even
  
  virtual bool parseTwoLiteralInSum(PPolynomial another, Variable& x, Variable& y, bool& sign_equals)=0;
  
  /// returns the sum of the values 
  /// of all monomials under given assignment.
  /// @see Monomial::getValue(Assignment*)
  virtual Coefficient
  getValue(Assignment* a) const;
};

#endif
