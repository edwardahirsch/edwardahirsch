#ifndef __ALGEBRAIC_H__
#define __ALGEBRAIC_H__

#include "boost/smart_ptr.hpp"

// Abstract algebraic classes
#include "abstract/variable.h"
#include "abstract/monomial.h"
#include "abstract/polynomial.h"
#include "abstract/equality.h"


/**
 * @file algebraic.h
 * @brief  A class for generating algebraic objects
 * @author sergey
 */

// forward declaration
class BooleanAlgebraicSolver;

/**
 * @class AlgebraicGenerator
 * @brief A class for generating monomials, polynomials, and equalities
 * @author sergey
 */
class AlgebraicGenerator
{
public:


  /**
   * creates a variable
   */
 static Variable makeVariable(long int num);

  /**
   * if input solver does not contain a variable with a given name,
   * creates it, adds it to solver and returns its number. Otherwise,
   * just returns the number of the variables with this name.
   */
 static Variable makeVariable(long int num, const std::string name, BooleanAlgebraicSolver *slv);
  
  /**
   * creates a monomial
   */
 static PMonomial makeMonomial();
  
  /**
   * creates a monomial from another monomial
   */
 static  PMonomial makeMonomial(PMonomial mon);
  
  /**
   * creates a monomial from variable
   */
  static  PMonomial makeMonomial(Variable var);
  
  /**
   * creates monomial from a variable and a coefficient
   */
  static  PMonomial makeMonomial(Coefficient coeff, Variable var);

  /**
   * creates a monomial from 2 variables
   */
  static  PMonomial makeMonomial(Variable var1, Variable var2);
 
 /**
   * creates a monomial from 3 variables
   */
   static PMonomial makeMonomial(Variable var1, Variable var2, Variable var3);

  /**
   * creates a polynomial
   */
   static PPolynomial makePolynomial();

  /**
   * creates a polynomial by monomial
   */
   static PPolynomial makePolynomial(PMonomial monom);

  /**
   * creates a polynomial of the type x+y-2xy or 1-x-y+2xy
   */
   static PPolynomial makeXORPolynomial(Variable var1, bool pos1, Variable var2, bool pos2);

  /**
   * creates a polynomial of the type x or 1-x
   */
   static PPolynomial makePolynomial(Variable var, bool pos);  

  /**
   * creates a equality with cloning of polynomials
   */
   static PEquality makeEqualityWithCloning(PPolynomial left, PPolynomial right);
  
  /**
   * creates a equality without cloning of polynomials
   */

   static PEquality createEquality(PPolynomial left, PPolynomial right);


  /// creates an equality of the type x=ab
   static PEquality createXeqABEquality(Variable, bool, Variable, bool, Variable, bool);
  
  /// creates an equality of the type x=y xor z (x=y+z-2yz)
   static PEquality create11m2Equality(Variable, Variable, Variable, bool);
  
  /// creates an equality of the type y=ac+d-acd
   static PEquality createYeqACpDmACDEquality(Variable, bool, Variable, bool, Variable, bool, Variable, bool);

  /// creates an equality of the type x=ab+ac+bc-2abc
   static PEquality createDeqABpACmABCEquality(Variable,bool,Variable,bool,Variable,bool,Variable,bool);
  
  /// creates an equality of the type x=ab+ac+bc-2abc
   static PEquality createXeqABpACpBCm2ABCEquality(Variable,bool,Variable,bool,Variable,bool,Variable,bool);
  
  /// creates an equality of the type x=ab+ac+bc-2abc
   static PEquality createYeqACpnABEquality(Variable,bool,Variable,bool,Variable,bool,Variable,bool);
  
  /// creates an equality of the type x=a+b+c-2ab-2ac-2bc+4abc
   static PEquality create124Equality(Variable,bool,Variable,bool,Variable,bool,Variable,bool);

  /// creates an equality of the type x=abc
   static PEquality createXeqABCEquality(Variable,bool,Variable,bool,Variable,bool,Variable,bool);
  
  /// creates an equality of the type x=abc
   static PEquality createWeqXmXYZEquality(Variable,bool,Variable,bool,Variable,bool,Variable,bool);
  
  /// creates an equality of the type x=abc
   static PEquality createZeqWXpVXm2WVXEquality(Variable,bool,Variable,bool,Variable,bool,Variable,bool);
  
  /// creates an equality of the type x=abc
   static PEquality createSeqXpVnWm2XWnVEquality(Variable,bool,Variable,bool,Variable,bool,Variable,bool);
  
  
  /// creates an equality of given type with given four or five variables
   static PEquality createTypedEquality(TEqualityType,Variable,bool,Variable,bool,Variable,bool,Variable,bool,Variable v = 0, bool p = false);
   
   /// creates Boolean Equality
   static PEquality createBooleanEquality(Variable var, bool value);
  
  
};

/**
 * @ingroup typedefs
 * 
 * Safe pointer for AlgebraicGenerator class.
 */
typedef boost::shared_ptr<AlgebraicGenerator> PAlgebraicGenerator;

#endif
