#include "algebraic.h"
#include "../misc/tools.h"
#include "../general/solver.h"
#include <stdio.h>
// Implementing algebraic classes
#include "implementation/simplemonomial.h"
#include "implementation/simplepolynomial.h"
#include "implementation/typedequality.h"
#include "implementation/booleanequality.h"
#include "../misc/assert.h"


/**
 * @file algebraic.cc
 * @brief Implementing AlgebraicGenerator class
 * @author sergey
 */


/**
 * Creating variables
 */
Variable AlgebraicGenerator::makeVariable(long int num)
{
  Variable pvar = num;
  return pvar;
}

Variable AlgebraicGenerator::makeVariable(long int num, const std::string nm, BooleanAlgebraicSolver *slv)
{  
  std::string name;
  if (nm == "")
  {
    char tmp[5];
    sprintf(tmp,"p%li",num);
    name = string(tmp);
  }
  else
  {
    name = nm;
  }
  
  for(std::map<long,std::string>::iterator it = slv->getVarNames()->begin(); it != slv->getVarNames()->end();++it)
  {
    if((*it).second == name)
    {
      return (*it).first;
    }
  }

  std::pair<long,std::string> pair;
  pair.first = num, pair.second = name;
  slv->getVarNames()->insert(pair);
  return num;
}

/**
 * Creating a monomial
 */
PMonomial AlgebraicGenerator::makeMonomial()
{
  PMonomial pmon(new SimpleMonomial());
  pmon->setCoeff(1);
  return pmon;
}

PMonomial AlgebraicGenerator::makeMonomial(PMonomial mon)
{
  PMonomial pmon(new SimpleMonomial(mon));
  return pmon;
}
  
/**
 * Creating a monomial from variable   
 */  
PMonomial AlgebraicGenerator::makeMonomial(Variable var)
{
  PMonomial pmon(new SimpleMonomial(var));
  return pmon;
};

/**
 * Creating a monomial from 2 variables
 */  
PMonomial AlgebraicGenerator::makeMonomial(Variable a, Variable b)
{
  PMonomial pmon(new SimpleMonomial(a, b));
  return pmon;
};

/**
 * Creating a monomial from 2 variables or from a variable with coefficient 
 */  
PMonomial AlgebraicGenerator::makeMonomial(Coefficient a, Variable b)
{
  PMonomial pmon(new SimpleMonomial(a, b));
  return pmon;
};

/**
 * Creating a monomial from 3 variables   
 */  
PMonomial AlgebraicGenerator::makeMonomial(Variable var1, Variable var2, Variable var3)
{
  PMonomial pmon(new SimpleMonomial(var1,var2,var3));
  return pmon;
};
 
/**
 * Creating a polynomial
 */
PPolynomial AlgebraicGenerator::makePolynomial()
{
  PPolynomial result(new SimplePolynomial());
  return result;
}

/**
 * Creating a polynomial by monomial
 */
PPolynomial AlgebraicGenerator::makePolynomial(PMonomial monom)
{
  PPolynomial result(new SimplePolynomial(monom));
  return result;
};

PPolynomial AlgebraicGenerator::makePolynomial(Variable var, bool pos)
{
  PMonomial mon(new SimpleMonomial(var));
  PPolynomial res(new SimplePolynomial(mon));
  if (!pos)
  {
    *res *= -1;
    PMonomial mon2(new SimpleMonomial());
    mon2->setCoeff(1);
    res->addMonomial(mon2);
  }
  return res;
};

PPolynomial AlgebraicGenerator::makeXORPolynomial(Variable var1, bool pos1, Variable var2, bool pos2)
{
  PMonomial mon1(new SimpleMonomial(var1));
  PMonomial mon2(new SimpleMonomial(var2));
  PMonomial mon12(new SimpleMonomial(var1,var2));
  mon12->setCoeff(-2);
  PPolynomial res(new SimplePolynomial(mon1));
  res->addMonomial(mon2);
  res->addMonomial(mon12);
  
  if (pos1 xor pos2)
  {
    *res *= -1;
    PMonomial mon3(new SimpleMonomial());
    mon3->setCoeff(1);
    res->addMonomial(mon3);
  }
  return res;
};



/**
 * Making a equality with cloning of polynomials
 */
PEquality AlgebraicGenerator::makeEqualityWithCloning(PPolynomial left, PPolynomial right)
{
  PEquality result(new TypedEquality(left->clone(), right->clone()));
  return result;
}

/**
 * Creating a equality without cloning of polynomials
 */
PEquality AlgebraicGenerator::createEquality(PPolynomial left, PPolynomial right)
{
  PEquality result(new TypedEquality(left, right));
  return result;
}

PEquality AlgebraicGenerator::create11m2Equality(Variable x, Variable a, Variable b, bool wconst)
{
  if (wconst)
  {
    PEquality result2(new TypedEquality(eqt11m2,x,true,a,true,b,true));
    return result2;
  }
  else
  {
    PEquality result2(new TypedEquality(eqt11m2,x,false,a,true,b,true));
    return result2;
  }
}

PEquality AlgebraicGenerator::createXeqABEquality(Variable x, bool px, Variable a, bool pa, Variable b, bool pb)
{
  PEquality result(new TypedEquality(eqtXeqAB,x,px,a,pa,b,pb));
  return result;
}

PEquality AlgebraicGenerator::createXeqABCEquality(Variable x, bool px, Variable a, bool pa, Variable b, bool pb,Variable c,bool pc)
{
  PEquality result(new TypedEquality(eqtXeqABC,x,px,a,pa,b,pb,c,pc));
  return result;
}

PEquality AlgebraicGenerator::createWeqXmXYZEquality(Variable x, bool px, Variable a, bool pa, Variable b, bool pb,Variable c,bool pc)
{
  PEquality result(new TypedEquality(eqtWeqXmXYZ,x,px,a,pa,b,pb,c,pc));
  return result;
}

PEquality AlgebraicGenerator::createYeqACpDmACDEquality(Variable x, bool px, Variable a, bool pa, Variable b, bool pb,Variable c,bool pc)
{
  PEquality result(new TypedEquality(eqtYeqACpDmACD,x,px,a,pa,b,pb,c,pc));
  return result;
}

PEquality AlgebraicGenerator::createXeqABpACpBCm2ABCEquality(Variable x, bool px, Variable a, bool pa, Variable b, bool pb,Variable c,bool pc)
{
  PEquality result(new TypedEquality(eqtXeqABpACpBCm2ABC,x,px,a,pa,b,pb,c,pc));
  return result;
}

PEquality AlgebraicGenerator::create124Equality(Variable x, bool px, Variable a, bool pa, Variable b, bool pb,Variable c,bool pc)
{
  PEquality result(new TypedEquality(eqt124,x,px,a,pa,b,pb,c,pc));
  return result;
}

PEquality AlgebraicGenerator::createYeqACpnABEquality(Variable y, bool py, Variable a, bool pa, Variable c, bool pc,Variable b,bool pb)
{
  PEquality result(new TypedEquality(eqtYeqACpnAB,y,py,a,pa,c,pc,b,pb));
  return result;
}

PEquality AlgebraicGenerator::createZeqWXpVXm2WVXEquality(Variable x, bool px, Variable a, bool pa, Variable b, bool pb,Variable c,bool pc)
{
  PEquality result(new TypedEquality(eqtZeqWXpVXm2WVX,x,px,a,pa,b,pb,c,pc));
  return result;
}

PEquality AlgebraicGenerator::createSeqXpVnWm2XWnVEquality(Variable x, bool px, Variable a, bool pa, Variable b, bool pb,Variable c,bool pc)
{
  PEquality result(new TypedEquality(eqtSeqXpVnWm2XWnV,x,px,a,pa,b,pb,c,pc));
  return result;
}

PEquality AlgebraicGenerator::createDeqABpACmABCEquality(Variable x, bool px, Variable a, bool pa, Variable b, bool pb,Variable c,bool pc)
{
  PEquality result(new TypedEquality(eqtDeqABpACmABC,x,px,a,pa,b,pb,c,pc));
  return result;
}

PEquality AlgebraicGenerator::createTypedEquality(TEqualityType type,Variable v1,bool p1,Variable v2,bool p2,Variable v3,bool p3,Variable v4,bool p4,Variable v5, bool p5)
{
  PEquality result;
  if (v5)
  {
    PEquality result(new TypedEquality(type,v1,p1,v2,p2,v3,p3,v4,p4,v5,p5));
    return result;
  }
  else if (v4)
  {
    PEquality result(new TypedEquality(type,v1,p1,v2,p2,v3,p3,v4,p4));
    return result;
  }
  else
  {
    PEquality result(new TypedEquality(type,v1,p1,v2,p2,v3,p3));
    return result;
  }
}

PEquality AlgebraicGenerator::createBooleanEquality(Variable var, bool value)
{
  return PBooleanEquality(new BooleanEquality(var, value));
};
