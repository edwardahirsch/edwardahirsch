#ifndef __TYPEDEQUALITY_H__
#define __TYPEDEQUALITY_H__

/**
 * @file typedequality.h
 * @brief Contains implementation for the abstract
 * class Equality
 * @author sergey
 */

#include "../abstract/equality.h"


class TypedEquality;
/**
 * smart pointer for \ref TypedEquality
 */
typedef boost::shared_ptr<TypedEquality> PTypedEquality;

/**
 * An implementation for a equality
 */
class TypedEquality : public Equality
{

private:

  /// type
  TEqualityType type;

  /// variables that this equality contains
  Variable var1, var2, var3, var4, var5;

  /// values of variables in literals
  bool pos1, pos2, pos3, pos4, pos5;
  
  /**
   * Shows if this object is marked as deleted
   */    
  bool myIsDeleted;

  /**
   * Left hand side polynomial
   */      
  PPolynomial lhs;
  
  /**
   * Right hand side polynomial
   */    
  PPolynomial rhs;
  
  /**
   *   transforms equality to the correct form (all invariants hold) and set flags.
   *   1) Checking for left hand side do not contain constant
   *   2) Eliminate equal monomials (to the left hand)
   *   3) Checking for Satisfiability
   *   4) Checking for boolean
   *   5) Checking for parsing types: eqtXeqAB, eqtABeq0, eqt11m2
   */        
  AssignReturnType simplify();

  /**
   * divides coefficients to the most common divisor
   */   
  void normalize();


  /**
   * calculates most common Divisor of two numbers
   */    
  Coefficient mcd(Coefficient a, Coefficient b);
  
  /**
   * flag for boolean
   */
   
  bool myIsBoolean;
  
  /**
   * flag for first type
   */

  bool myIsFirstType;


 /**
   * flag for tautology
   */

  bool myIsSatisfiable;

  /**
   * flag for contradiction
   */
  
  bool myIsUnsatisfiable;

  /// sorts all five variables of the equality
  void sortFiveVars(bool&);

  /// sorts all four variables of the equality
  void sortFourVars(bool&);

  /// sorts var2, var3, and var4
  void sortThreeVars(bool&);

  /// sorts var1, var2, and var3
  void sortFirstThreeVars(bool&);


  /// sorts var2 and var3
  void sortTwoVars(bool&);

  /// sort vars and recreate polynomials if needed
  void sortAndRecreatePolynomials();
  
    
public:

  /**
   * constructor with left and right sides
   */
  TypedEquality(PPolynomial left, PPolynomial right) : type(Special),myMainVar(0)
  {
   var1=0; var2=0; var3=0; var4=0; var5=0;
   lhs=left;
   rhs=right;
   simplify();
  };
  
  bool isPositive() const
  {
    return ( (rhs->getSize() == 1) &&
        ( (**rhs->getBeginIterator())->isConstant()) &&
        ( (**rhs->getBeginIterator())->getCoeff() == 1));
  }

  PModificationObject cloneObject() const
  {
    PModificationObject res(new TypedEquality(this));
    return res;
  }

  /**
   * empty constructor
   */
  TypedEquality() {type=Special; var1=0; var2=0; var3=0; var4=0; var5=0;};

  /**
   * constructs from monomial
   */
  TypedEquality(PMonomial mon) {type = Special; var1=0; var2=0; var3=0; var4=0; var5=0;};

   /**
   * constructs from the given type, variables and polynomials
   */
  TypedEquality(TEqualityType type, Variable var1, bool pos1, Variable var2, bool pos2, Variable var3, bool pos3, Variable var4, bool pos4, Variable var5, bool pos5, PPolynomial lhs, PPolynomial rhs);

  /**
   * constructs from the given type and variables
   */
  TypedEquality(TEqualityType type, Variable var1, bool pos1, Variable var2, bool pos2, Variable var3, bool pos3, Variable var4, bool pos4, Variable var5, bool pos5);

  /**
   * constructs from the given type and variables
   */
  TypedEquality(TEqualityType type, Variable var1, bool pos1, Variable var2, bool pos2, Variable var3, bool pos3, Variable var4, bool pos4);
 
  /**
   * constructs from the given type and variables
   */
  TypedEquality(TEqualityType type, Variable var1, bool pos1, Variable var2, bool pos2, Variable var3, bool pos3);

  /**
   * cloning constructor
   */
  TypedEquality(const TypedEquality *);
  
  std::ostream& print(std::ostream&, BooleanAlgebraicSolver *,bool print_as_dedobj = false);

  
  AssignReturnType assign(Variable var, int val);

  PVarList getVariableList() const;
  
  PSALiteral clone() const;

  bool isDeleted() const {return myIsDeleted;};
  void erase() {myIsDeleted=true;};
  void unErase() {myIsDeleted=false;};

  PPolynomial getLHS() const {return lhs;};
  PPolynomial getRHS() const {return rhs;};
  
  
  AssignReturnType substituteEqual(Variable x, Variable y);
  
  
  AssignReturnType substituteNonEqual(Variable x, Variable y);
  
  
  AssignReturnType substituteMonomial(PEquality t2Equality);

  
  
  /**
   * @see Equality::isBoolean
   */
  bool isBoolean() const {return myIsBoolean;}; 
  bool isFirstType() const {return myIsFirstType;}; 
  bool isSecondType() const {return false;}; 
  bool isThirdType() const {return false;}; 
  bool isTautology() const {return myIsSatisfiable;}; 
  bool isUnsatisfiable() const {return myIsUnsatisfiable;}; 
 
 
  /**
   * returns boolean variable if equality represents boolean literal (x=1) or (x=0)
   * if equality does not represent boolean literal returns variable with 0 number
   */    
   
  Variable getBooleanVariable(); 
  
  /**
   * returns sign of boolean variable if equality represents boolean literal (x=1) or (x=0)
   * (x=1)=> true; (x=0)=>false
   * if equality does not represent boolean literal returns false
   */    
  bool getBooleanSign();  
  
  
  /**
   * compares for equality
   */
  bool operator == (SALiteral& literal) const;  
 
  bool operator < (SALiteral& literal) const;
  
  /**
   * returns new Equality with new rhs:= 1 - (old rhs)
   */    
  PEquality negation() const;

  
  PPolynomial getPolynomialRepresentation(); 

  bool getLHSVariable(Variable&) const;

  long getFirstVariableNumber() const {return lhs->getVariable();};
  

  void setVar1(Variable var) {var1 = var;};
  void setVar2(Variable var) {var2 = var;};
  void setVar3(Variable var) {var3 = var;};
  void setVar4(Variable var) {var4 = var;};
  void setVar5(Variable var) {var5 = var;};
  void setPos1(bool pos) {pos1 = pos;};
  void setPos2(bool pos) {pos2 = pos;};
  void setPos3(bool pos) {pos3 = pos;};
  void setPos4(bool pos) {pos4 = pos;};
  void setPos5(bool pos) {pos5 = pos;};
 
  /// returns the first variable of a typed equality, i.e.,
  /// the first variable in the equality type description;
  /// if no such variable is supported for this type, returns 0;
  /// for example, for the type eqtYeqACpnAB, var1=Y, var2=A, var3=C, var4=B, var5=0
  Variable getVar1() const {return var1;};
  /// returns the second variable of a typed equality, i.e.,
  /// the second variable in the equality type description;
  /// if no such variable is supported for this type, returns 0;
  /// for example, for the type eqtYeqACpnAB, var1=Y, var2=A, var3=C, var4=B, var5=0
  Variable getVar2() const {return var2;};
  /// returns the third variable of a typed equality, i.e.,
  /// the third variable in the equality type description;
  /// if no such variable is supported for this type, returns 0;
  /// for example, for the type eqtYeqACpnAB, var1=Y, var2=A, var3=C, var4=B, var5=0
  Variable getVar3() const {return var3;};
  /// returns the fourth variable of a typed equality, i.e.,
  /// the fourth variable in the equality type description;
  /// if no such variable is supported for this type, returns 0;
  /// for example, for the type eqtYeqACpnAB, var1=Y, var2=A, var3=C, var4=B, var5=0
  Variable getVar4() const {return var4;};
  /// returns the fifth variable of a typed equality, i.e.,
  /// the fifth variable in the equality type description;
  /// if no such variable is supported for this type, returns 0;
  /// for example, for the type eqtYeqACpnAB, var1=Y, var2=A, var3=C, var4=B, var5=0
  Variable getVar5() const {return var5;};

  bool getPos1() const {return pos1;};
  bool getPos2() const {return pos2;};
  bool getPos3() const {return pos3;};
  bool getPos4() const {return pos4;};
  bool getPos5() const {return pos5;};
  bool hasOneEquality() const {return true;};

  TEqualityType getEqType() const {return type;};
 
  /**
   * setter for the type.
   */
  void setEqType(TEqualityType newType)
  {
    type = newType;
  }

  
  bool getYeqACpDmACD(Variable &x, bool &posx, Variable &a, bool &posa, Variable &b, bool &posb,Variable &c, bool &posc) const;
  bool getXeqAB(long&,long&,long&) const;
  bool getXeqAB(Variable&,bool&,Variable&,bool&,Variable&,bool&) const;
  bool getOneOneMinusOne(long&,long&,long&) const;
  bool getOneOneMinusTwo(long&,long&,long&) const;
  bool getOneOneMinusTwoWConst(long&,long&,long&,bool&) const;
  bool getXeqABpACpBCm2ABC(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const;
  bool getYeqACpnAB(Variable &x, bool &px, Variable &a, bool &pa, Variable &c, bool &pc, Variable &b, bool &pb) const;
  virtual bool isBoothSubSubject(Variable var,Coefficient &coeff,PPolynomial &poly) const;
 
  PEquality substituteVarWithPoly(Variable var, PPolynomial poly) const;
 
  virtual bool get124(Variable& x,Variable& a,Variable& b,Variable& c,bool&) const;
  virtual bool getDeqABpACmABC(Variable& d,bool&,Variable& a,bool&,Variable& b,bool&,Variable& c,bool&) const;

    /**
     ** returns the variable defined by this equality, if marked; 0 otherwise
     **/
    virtual Variable getMainVar() const { return myMainVar; };

    /**
     ** marks the variable defined by this equality (0 to unmark)
     */
    virtual void setMainVar(Variable var) { myMainVar=var; };
      
private:
    /**
     *  the variable defined by this equality, if marked; 0 otherwise
     **/
    Variable myMainVar;

};

#endif
