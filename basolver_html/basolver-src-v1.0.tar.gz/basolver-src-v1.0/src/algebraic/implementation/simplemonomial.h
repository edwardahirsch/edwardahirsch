#ifndef __SIMPLEMONOMIAL_H__
#define __SIMPLEMONOMIAL_H__

/**
 * @file simplemonomial.h
 * @brief Contains implementation for the abstract
 * class Monomial
 * @author sergey
 */

#include "../abstract/monomial.h"
#include "../../indexing/simplevariableiterator.h"
#include <iostream>

/**
 * An implementation for a monomial.
 *
 * \invariant
 * - Variables are sorted by its numbers in internal list
 * 
 */

/*typedef std::map<long int, Variable> VarMap; 
typedef boost::shared_ptr<VarMap> PVarMap;*/
 
class SimpleMonomial : public Monomial
{

private:
 
  /// Map of variables
  PVarMap myVarMap;
  
  /// Coefficient
  Coefficient myCoeff;

public:
  
  /**
   * Empty constructor
   */
  SimpleMonomial();

  /**
   * Constructs from monomial
   */
  SimpleMonomial(PMonomial mon);

  /**
   * Constructs from variable
   */
  SimpleMonomial(Variable var);

  /**
   * Constructs from two variables or from a variable and coefficient,
   * depending on the value of the boolean
   */
  SimpleMonomial(Variable var1, Variable var2);

  /**
   * Constructs from a variable and a coefficient
   */
  SimpleMonomial(Coefficient coeff, long var);

  /**
   * Constructs from three variables
   */
  SimpleMonomial(Variable var1, Variable var2, Variable var3);
  
  /**
   * Sets the coefficient
   */
  void setCoeff(Coefficient coeff) {myCoeff = coeff;};

  /**
   * Returns the coefficient
   */
  Coefficient getCoeff() const {return myCoeff;};

  Monomial& operator *= (const Variable var);
 
  virtual bool consistsOfTwoVars(Variable var1, Variable var2) const
  {
    return (  ( myVarMap->size() == 2 ) &&
            ( ((*myVarMap->begin()).second == var1) &&
              ((*(++myVarMap->begin())).second == var2) ) ||
            ( ((*myVarMap->begin()).second == var2) &&
              ((*(++myVarMap->begin())).second == var1) ));
  }
  
    
  bool assign(Variable var, int value);

  bool contains(Variable var) const;
  
  
  PVariableIterator getBeginIterator() const;

  PVariableIterator getEndIterator() const
  {
    PVariableIterator res(new SimpleVariableIterator(myVarMap->end()));
    return res;
  };

  bool operator==(Monomial& monom) const;
  
  bool isLess(Monomial& mon) const;
  
  void substituteEqual(Variable x, Variable y); 

  
  PMonomial clone() const;

  std::ostream& print(std::ostream&,BooleanAlgebraicSolver *slv = 0);
   
   
   bool isVariable() const
   {
     return myVarMap->size()==1;
   };
 
   bool isVariable(long num) const
   {
     return ( (myVarMap->size() == 1) && ((*(myVarMap->begin())).second == num) );
   }
  
   bool isTwoVariables() const
   {
     return ( (myVarMap->size() == 2)); 
   }
   
   bool getTwoVariables(long &a, long &b) const
   {
     if (myVarMap->size() != 2) return false;
     a = (*(myVarMap->begin())).second;
     b = (*(++myVarMap->begin())).second;
     return true;   
   }
   
   bool getThreeVariables(Variable &a, Variable &b, Variable &c) const
   {
     if (myVarMap->size() != 3) return false;
     VarMap::iterator it = myVarMap->begin();
     a = (*it).second;
     ++it;
     b = (*it).second;
     ++it;
     c = (*it).second;
     return true;
   }

  
   bool isTwoVariables(long a, long b) const
   {
     return ( (myVarMap->size() == 2) && (
              (  ((*(myVarMap->begin())).second   == a) &&
                 ((*(++myVarMap->begin())).second == b)    )
             || 
              (  ((*(myVarMap->begin())).second   == b) &&
                 ((*(++myVarMap->begin())).second == a)    ) )
            );
   }
  
   
  
  Variable getVariable()
  {
    if (myVarMap->size()!=0)
      return (*(myVarMap->begin())).second;
    return 0; 
  };
  
   
  virtual bool isConstant()
  {
    return myVarMap->size()==0;
  };     
  
  
  virtual long int getSize() const {return myVarMap->size();};
  
  bool isContain(PMonomial mon) const;

  
  PMonomial getQuotient(PMonomial mon) const;
  

  Variable getSecondVariable() const
  {
    if (myVarMap->size() >= 2)
    {
      VarMap::iterator it = myVarMap->begin(); ++it;
      return (*it).second;
    }
    return 0;
  }

  long applyAssignment(bool *sat) const;
 

};

/**
 * smart pointer for \ref SimpleMonomial
 */
typedef boost::shared_ptr<SimpleMonomial> PSimpleMonomial;


#endif
