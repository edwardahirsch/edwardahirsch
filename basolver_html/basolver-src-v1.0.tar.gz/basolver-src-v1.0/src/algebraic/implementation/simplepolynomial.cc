#include "simplepolynomial.h"
#include "simplemonomial.h"
#include "../algebraic.h"

/**
 * @file simplepolynomial.cc
 * @brief implementation for simplepolynomial.h
 */


/* @author dmitrits */

using namespace std;

Variable SimplePolynomial::getFirstLinearVariable()
{
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  std::list<PMonomial>::iterator mend = myMonomList->end();
  for (;mbeg!=mend;++mbeg)
  {
    if ( ((*mbeg)->getSize() == 1) && ((*mbeg)->getCoeff() % 2) )
      return (*mbeg)->getVariable();
  }
  return (Variable)0;
}
 
bool SimplePolynomial::occursLinear(Variable var, Coefficient &coeff) const
{
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  std::list<PMonomial>::iterator mend = myMonomList->end();  
  bool ok = false;
  for (;mbeg != mend;++mbeg)
  {
    if ((*mbeg)->contains(var))
    {
      if ((*mbeg)->getSize() > 1) return false;
      ok=true;
      coeff = (*mbeg)->getCoeff();
    }
  }
  return ok;
}


/**
 * subtraction with cloning
 */
void SimplePolynomial::subtractMonomialWithCloning(const PMonomial mon)
{ 
  if (!mon->getCoeff()) return;
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  while ((mbeg!=myMonomList->end()) && (**mbeg < *mon)) ++mbeg;
  if (mbeg == myMonomList->end())
  {
    PMonomial clone = mon->clone();
    clone->setCoeff(-mon->getCoeff());
    myMonomList->push_back(clone);
    return;
  }
  if (**mbeg == *mon)
  {
    (*mbeg)->setCoeff((*mbeg)->getCoeff() - mon->getCoeff());
    if ((*mbeg)->getCoeff()==0)
    {
      myMonomList->erase(mbeg);
    };
    return;
  }
  PMonomial clone2 = mon->clone();
  clone2->setCoeff(-mon->getCoeff());
  myMonomList->insert(mbeg,clone2);
}

bool SimplePolynomial::cutVariable(Variable var)
{
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  std::list<PMonomial>::iterator mend = myMonomList->end();
  bool negative = false;
  while (mbeg!=mend)
  {
    if ((*mbeg)->isVariable(var))
      break;
    ++mbeg;
  }
  if (mbeg == mend) return false;
  
  if ((*mbeg)->getCoeff() == -1)
  {
    negative = true;
  }
  else if ((*mbeg)->getCoeff() != 1) return false;
  myMonomList->erase(mbeg);
  
  if (!negative)
  {
    mbeg = myMonomList->begin();
    while (mbeg!=mend)
    {
      (*mbeg)->setCoeff(-(*mbeg)->getCoeff());
      ++mbeg;
    }
  }
  return true;
}

/**
 * addition with cloning
 */
void SimplePolynomial::addMonomialWithCloning(const PMonomial mon)
{ 
  if (!mon->getCoeff()) return;
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  while ((mbeg!=myMonomList->end()) && (**mbeg < *mon)) ++mbeg;
  if (mbeg == myMonomList->end())
  {
    myMonomList->push_back(mon->clone());
    return;
  }
  if (**mbeg == *mon)
  {
    (*mbeg)->setCoeff((*mbeg)->getCoeff() + mon->getCoeff());
    if ((*mbeg)->getCoeff()==0)
    {
      myMonomList->erase(mbeg);
    };
    return;
  }
  myMonomList->insert(mbeg,mon->clone());
}

/**
 * addition without cloning
 */
void SimplePolynomial::addMonomial(const PMonomial mon)
{
  
  if (!mon->getCoeff()) return;
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  while ((mbeg!=myMonomList->end()) && (**mbeg < *mon)) ++mbeg;
  if (mbeg == myMonomList->end())
  {
    myMonomList->push_back(mon);
    return;
  }
  if (**mbeg == *mon)
  {
    (*mbeg)->setCoeff((*mbeg)->getCoeff() + mon->getCoeff());
    if ((*mbeg)->getCoeff()==0)
    {
      myMonomList->erase(mbeg);
    };
    return;
  }
  myMonomList->insert(mbeg,mon);
}

Polynomial& SimplePolynomial::operator += (const Coefficient& coef)
{
  
  PMonomial mon(new SimpleMonomial());
  *mon *= coef;
  this->addMonomial(mon);
  return *this;
}

/**
 * Printing
 */
std::ostream& SimplePolynomial::print(std::ostream& os,BooleanAlgebraicSolver *slv) 
{
  if (myMonomList->size()==0) 
  {
    os << 0;
  };    
  std::list<PMonomial>::const_iterator mbeg = myMonomList->begin();
  bool isFirst=true;
  while (mbeg != myMonomList->end())
  {
    if ((!isFirst) && ((*mbeg)->getCoeff()>0)) os << "+";
    flush(os);
    (*mbeg)->print(os,slv);
    ++mbeg;
    isFirst=false;
  }
  return os;
}

Polynomial& SimplePolynomial::operator *= (const Coefficient& coeff)
{
  
  if (!coeff) {myMonomList->clear(); return (*this);};
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  while (mbeg!=myMonomList->end())
  {
    **mbeg *= coeff;
    ++mbeg;
  }
  return *this;
}

Polynomial& SimplePolynomial::operator *= (Monomial& mon)
{

  if (!mon.getCoeff()) {myMonomList->clear(); return (*this);}
  
  SimplePolynomial tmppoly;
  
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  while (mbeg!=myMonomList->end())
  {
    **mbeg *= mon;
    tmppoly.addMonomial(*mbeg);
    ++mbeg;
  }
  myMonomList->clear();
  mbeg = tmppoly.myMonomList->begin();
  while (mbeg != tmppoly.myMonomList->end())
  {
    this->addMonomial(*mbeg);
    ++mbeg;
  }
  tmppoly.myMonomList->clear();
  return *this;
}

bool SimplePolynomial::operator == (Polynomial& polynom) const
{
  
  if (this->getSize()!=polynom.getSize()) return false;
  std::list<PMonomial>::iterator my = myMonomList->begin();
  try
  {
    SimplePolynomial& poly=dynamic_cast<SimplePolynomial&>(polynom);
    std::list<PMonomial>::iterator his = poly.myMonomList->begin();
    while ((my!=myMonomList->end()) && (his!=poly.myMonomList->end()))
    {
      if ( (!((*my)->getCoeff()==(*his)->getCoeff()))  ||  (!(**my==**his)))
      return false;
      ++my;
      ++his;  
    };
    return true;
  }
  catch (std::bad_cast &bc)  
  {
    PMonomialIterator his=polynom.getBeginIterator();
    while ((my!=myMonomList->end()) && !his->equals(*(polynom.getEndIterator())))
    {
      if ( (!((*my)->getCoeff()==(**his)->getCoeff()))  ||  (!(**my==***his)))
      return false;
      ++my;
      ++*his;  
    };
    return true;
  };    
}

bool SimplePolynomial::oddPartEqualsModulo2(Polynomial &polynom) const
{
  std::list<PMonomial>::iterator my = myMonomList->begin();
  try
  {
    SimplePolynomial& poly=dynamic_cast<SimplePolynomial&>(polynom);
    std::list<PMonomial>::iterator his = poly.myMonomList->begin();
    std::list<PMonomial>::iterator hisend = poly.myMonomList->end();
    for (;my != myMonomList->end(); ++my)
    {
      if ((*my)->getCoeff() % 2 == 0) continue;
    
      for (;his!=hisend;++his)
      {
        if ((*his)->getCoeff() % 2) break;
      }
      if ((his==hisend) || (!(**his == **my)) || (((*his)->getCoeff() - (*my)->getCoeff()) % 2))
      {
        return false;
      }
      ++his;
    }
  
    for (;his!=hisend;++his)
    {
      if ((*his)->getCoeff() % 2)
      {
        return false;
      }
    }
  }
  catch (std::bad_cast &bc)  
  {
    PMonomialIterator his = polynom.getBeginIterator();
    PMonomialIterator hisend = polynom.getEndIterator();
 
    for (;my != myMonomList->end(); ++my)
    {
      if ((*my)->getCoeff() % 2 == 0) continue;
    
      for (;!his->equals(*hisend);++*his)
      {
        if ((**his)->getCoeff() % 2) break;
      }
      if (his->equals(*hisend) || (!(***his == **my)) || (((**his)->getCoeff() - (*my)->getCoeff()) % 2))
      {
        return false;
      }
      ++*his;
    }
  
    for (;!his->equals(*hisend);++*his)
    {
      if ((**his)->getCoeff() % 2)
      {
        return false;
      }
    }
  }
  return true;
 
}

bool SimplePolynomial::addEvenPartDiff(const Polynomial &poly1,const Polynomial &poly2)
{
  PMonomialIterator it1=poly1.getBeginIterator();
  PMonomialIterator it2=poly2.getBeginIterator();
  PMonomialIterator end1=poly1.getEndIterator();
  PMonomialIterator end2=poly2.getEndIterator();

  // we run through the first polynomial
  for (;!it1->equals(*end1); ++*it1)
  {
    // if the current monomial has even coefficient, add it and continue
    if ((**it1)->getCoeff() % 2 == 0) 
    {
      this->addMonomialWithCloning(**it1);
      continue;
    }
    
    for (;!it2->equals(*end2);++*it2)
    {
      // if the current monomial has odd coefficient break and take a look at
      // this monomial
      if ((**it2)->getCoeff() % 2) break;
      // else subtract it from the result
      else this->subtractMonomialWithCloning(**it2);
    }
    
    // if the even parts are different return false
    if (it2->equals(*end2) || (!(***it1 == ***it2)) || (((**it1)->getCoeff() - (**it2)->getCoeff()) % 2))
    {
      return false;
    }
    // if two odd monomials differ in coefficients, create their even
    // difference and add it to the result
    else if ( (**it1)->getCoeff() != (**it2)->getCoeff() )
    {
      PMonomial mon = (**it1)->clone();
      mon->setCoeff( (**it1)->getCoeff() - (**it2)->getCoeff() );
      this->addMonomial(mon);
    }
    
    ++*it2;
  }
  
  // in case first polynomial ends before the second one
  for (;!it2->equals(*end2);++*it2)
  {
    if ((**it2)->getCoeff() % 2)
    {
      return false;
    }
    else
      this->subtractMonomialWithCloning(**it2);
  }
  return true;
}
 

long SimplePolynomial::applyAssignment(bool *sat) const
{
  long result = 0;
  std::list<PMonomial>::iterator it=myMonomList->begin();
  std::list<PMonomial>::iterator end=myMonomList->end();
  while (it != end)
  {
    result += (*it)->applyAssignment(sat);
  }
  return result;
}


void SimplePolynomial::assign(Variable var, int value)
{
  
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  std::list<PMonomial>* toAdd=new std::list<PMonomial>;
  while (mbeg!=myMonomList->end())
  {
    PMonomial monom=*mbeg;
    if (monom->contains(var))
    {
      monom->assign(var, value);
      toAdd->push_back(monom);
      mbeg = myMonomList->erase(mbeg);
    }
    else
      mbeg++;;
  }
  for (std::list<PMonomial>::iterator addIter=toAdd->begin(); addIter!=toAdd->end(); ++addIter)
  {
    this->addMonomial(*addIter);
  };
  toAdd->clear();
  delete toAdd;
};

void SimplePolynomial::substituteEqual(Variable x, Variable y)
{
  
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  std::list<PMonomial>* toAdd=new std::list<PMonomial>;
  while (mbeg!=myMonomList->end())
  {
    PMonomial monom=*mbeg;
    if (monom->contains(x))
    {
      monom->substituteEqual(x, y);
      toAdd->push_back(monom);
      mbeg = myMonomList->erase(mbeg);
    }
    else
      mbeg++;;
  }
  for (std::list<PMonomial>::iterator addIter=toAdd->begin(); addIter!=toAdd->end(); ++addIter)
  {
    this->addMonomial(*addIter);
  };
  toAdd->clear();
  delete toAdd;
}; 



void SimplePolynomial::substituteNonEqual(Variable x, Variable y)
{
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  std::list<PMonomial>* toAdd=new std::list<PMonomial>;
  while (mbeg!=myMonomList->end())
  {
    if ((*mbeg)->contains(x))
    {
      PMonomial monomToAssignOne=*mbeg;
      PMonomial monomToSubstituteMinusY=monomToAssignOne->clone();
      monomToAssignOne->assign(x,1);
      monomToSubstituteMinusY->substituteEqual(x,y);
      monomToSubstituteMinusY->setCoeff(-monomToSubstituteMinusY->getCoeff());
      toAdd->push_back(monomToAssignOne);
      toAdd->push_back(monomToSubstituteMinusY);    
    }
    else
    {
      toAdd->push_back(*mbeg);
    }
    
    ++mbeg;
  };    
  myMonomList->clear();
  for (std::list<PMonomial>::iterator addIter=toAdd->begin(); addIter!=toAdd->end(); ++addIter)
  {
    this->addMonomial(*addIter);
  };   
  delete toAdd;
}; 

bool SimplePolynomial::isVariable() const
{
  if (myMonomList->size()==1)
   {
     return (**(this->getBeginIterator()))->isVariable();
   };    
  return false;
};

bool SimplePolynomial::isVariable(long a) const
{
  return ( (myMonomList->size() == 1) &&
      (*(myMonomList->begin()))->isVariable(a) );
}

bool SimplePolynomial::isTwoVariables() const
{
  if (!(myMonomList->size() == 1)) return false;
  return (*(myMonomList->begin()))->isTwoVariables();
}
 
bool SimplePolynomial::getTwoVariables(long &a, long &b) const
{
  if (myMonomList->size() != 1) return false;
  return (*(myMonomList->begin()))->getTwoVariables(a,b);
}
 
 bool SimplePolynomial::isTwoVariables(long a, long b) const
{
  return ( (myMonomList->size() == 1) &&
      (*(myMonomList->begin()))->isTwoVariables(a,b));
}
 
Variable SimplePolynomial::getVariable()
{
  if (this->isConstant())
  {
    return (Variable)0;
  }

  if (!(*myMonomList->begin())->isConstant()) return (*myMonomList->begin())->getVariable();
  else return (*(++myMonomList->begin()))->getVariable();
  
};
  
bool SimplePolynomial::isConstant() const
{
  if (myMonomList->size()==0) return true;
  if (myMonomList->size()==1)
  {
    return ((*myMonomList->begin())->isConstant());
  };    
  return false;
};     

Coefficient SimplePolynomial::getFirstConstant() const
{
  if (myMonomList->size()==0) return 0;
  return (**(this->getBeginIterator()))->getConstant();
};


/**
 * returns 1 if this is less than polynom
 * returns -1 if polynomial is less than this
 * returns 0 is they are equal
 */
int SimplePolynomial::compare(const Polynomial& polynom) const
{
  PMonomialIterator my= this->getBeginIterator();
  PMonomialIterator his = polynom.getBeginIterator();
  while ((!my->equals(*(this->getEndIterator())))&&(!his->equals(*(polynom.getEndIterator()))))
  {
    if (***my<***his) return 1;
    if (***his<***my) return -1;
    ++(*my);
    ++(*his);
  };
  if (!my->equals(*(this->getEndIterator()))) return -1;
  if (!his->equals(*(polynom.getEndIterator()))) return 1;
  return 0;
};


PPolynomial SimplePolynomial::clone()
{
  PPolynomial copy(new SimplePolynomial());
  for(std::list<PMonomial>::iterator it=myMonomList->begin(); it!=myMonomList->end(); ++it)
  {
    copy->addMonomialWithCloning(*it);
  };
  return copy;
}; 

PPolynomial SimplePolynomial::getOddPart() const
{
  PPolynomial oddPart(new SimplePolynomial());
  for(std::list<PMonomial>::iterator it=myMonomList->begin(); it!=myMonomList->end(); ++it)
  {
    if (abs(((*it)->getCoeff())% 2)==1)
      oddPart->addMonomialWithCloning(*it);
  };
  return oddPart;  
}

PPolynomial SimplePolynomial::getEvenPart() const  
{
  PPolynomial evenPart(new SimplePolynomial());
  for(std::list<PMonomial>::iterator it=myMonomList->begin(); it!=myMonomList->end(); ++it)
  {
    if (abs(((*it)->getCoeff())% 2)==0)
      evenPart->addMonomialWithCloning(*it);
  };
  return evenPart;  
};

PPolynomial SimplePolynomial::getLinearPart() const  
{
  PPolynomial linearPart(new SimplePolynomial());
  for(std::list<PMonomial>::iterator it=myMonomList->begin(); it!=myMonomList->end(); ++it)
  {
    if ((*it)->getSize()<=1)
      linearPart->addMonomialWithCloning(*it);
  };
  return linearPart;  
};

PPolynomial SimplePolynomial::getNonLinearPart() const  
{
  PPolynomial nonlinearPart(new SimplePolynomial());
  for(std::list<PMonomial>::iterator it=myMonomList->begin(); it!=myMonomList->end(); ++it)
  {
    if ((*it)->getSize()>1)
      nonlinearPart->addMonomialWithCloning(*it);
  };
  return nonlinearPart;  
};

PPolynomial SimplePolynomial::getNegation()
{
  PPolynomial newPoly = this->clone();
  *newPoly *= -1;
  *newPoly += 1;
  return newPoly;
}

Polynomial& SimplePolynomial::operator *= (const Polynomial& second)
{
  if (!second.getSize())
  {
    myMonomList->clear();
    return (*this);    
  };
  PMonomialIterator iter=second.getBeginIterator(); 
  PPolynomial first=this->clone();
  bool isFirst=true;
  for(;!(iter->equals(*(second.getEndIterator())));++(*iter))
  {
    if (isFirst)    
    {
      PMonomial mon=(**iter);
      (*this) *= (*mon);
      isFirst=false;
    }  
    else
    {
      PPolynomial temp=first->clone();
      (*temp)*=(***iter);
      (*this) += (*temp);
    };  
  };
  return (*this);
};

Polynomial& SimplePolynomial::operator += (const Polynomial& second)
{
  
  PMonomialIterator iter=second.getBeginIterator(); 
  for(;!(iter->equals(*(second.getEndIterator())));++(*iter))
  {
    this->addMonomialWithCloning(**iter);
  };
  return (*this);
};

Polynomial& SimplePolynomial::operator -= (const Polynomial& second)
{
  
  PMonomialIterator iter=second.getBeginIterator(); 
  for(;!(iter->equals(*(second.getEndIterator())));++(*iter))
  {
    PMonomial monom=(**iter)->clone();
    (*monom)*=(-1);
    this->addMonomial(monom);
  };
  return (*this);
};


PPolynomial SimplePolynomial::getQuotient(PMonomial mon) const
{
  PPolynomial quotient(new SimplePolynomial());
  for(std::list<PMonomial>::iterator it=myMonomList->begin(); it!=myMonomList->end(); ++it)
  {
    if ((*it)->isContain(mon))
      quotient->addMonomial((*it)->getQuotient(mon));
  };
  return quotient;
  
};

PPolynomial SimplePolynomial::getRemainder(PMonomial mon) const
{
  PPolynomial remainder(new SimplePolynomial());
  for(std::list<PMonomial>::iterator it=myMonomList->begin(); it!=myMonomList->end(); ++it)
  {
    if (!(*it)->isContain(mon))
      remainder->addMonomialWithCloning(*it);
  };
  return remainder;    
};

Variable SimplePolynomial::getOddVariable() const
{
  for(std::list<PMonomial>::iterator it=myMonomList->begin(); it!=myMonomList->end(); ++it)
  {
    if ( abs(((*it)->getCoeff())% 2)==1  && (!(*it)->isConstant()))
      return (*it)->getVariable();
  };
  return (Variable)0;
}


bool SimplePolynomial::containsVariable(Variable var) const
{
  std::list<PMonomial>::iterator my = myMonomList->begin();
  std::list<PMonomial>::iterator myend = myMonomList->end();
  for(;my!=myend;++my)
  {
    if ((*my)->contains(var)) return true;
  };
  return false;
}; 

bool SimplePolynomial::isDeg2Even() const
{
  std::list<PMonomial>::iterator my = myMonomList->begin();
  std::list<PMonomial>::iterator myend = myMonomList->end();
  bool deg2 = false;
  for(;my!=myend;++my)
  {
    if ((*my)->getSize() > 2) return false;
    if ((*my)->getSize() == 2) 
    {
      deg2 = true;
      if ((*my)->getCoeff() % 2) return false;
    }
  };
  return deg2;
}

bool SimplePolynomial::isOneOneMinusOne(long a,long b) const
{
  if (myMonomList->size() != 3) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  if ( (!(*mon)->isVariable(a)) || (!((*mon)->getCoeff() == 1)) ) return false;
  ++mon;
  if ( (!(*mon)->isVariable(b)) || (!((*mon)->getCoeff() == 1)) ) return false;
  ++mon;
  if ( (!(*mon)->isTwoVariables(a,b)) || (!((*mon)->getCoeff() == -1)) ) return false;
  return true;
}

bool SimplePolynomial::isOneOneMinusOne() const
{
  if (myMonomList->size() != 3) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == 1)) ) return false;
  long a = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == 1)) ) return false;
  long b = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isTwoVariables(a,b)) || (!((*mon)->getCoeff() == -1)) ) return false;
  return true;
} 

bool SimplePolynomial::isLin2Subject() const
{
  if ( (myMonomList->size() > 3) || (myMonomList->size() <= 0)) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  long n1=0,n2=0;
  Variable a,b;
  if (myMonomList->size() > 1)
  {
    if (!(*mon)->isVariable()) return false;
    n1=(*mon)->getVariable();
    if (myMonomList->size() > 2)
    {
      ++mon;
      if (!(*mon)->isVariable()) return false;
      n2 = (*mon)->getVariable();
    }
    ++mon;
  }    
  if ((!(*mon)->getTwoVariables(a,b))) return false;
  if ( (n2!=0) && (b != n2)) return false;
  if ( (n1!=0) && (a != n1) && (b!=n1)) return false; 
  return true;
}

bool SimplePolynomial::isLinear() const
{
  return (this->getDegree()<=1);
}

bool SimplePolynomial::hasBigCoefficients() const
{
  for(std::list<PMonomial>::iterator mon = myMonomList->begin();
      mon !=myMonomList->end();mon++)
  {
    if ((*mon)->isConstant()) continue;
    if (abs((*mon)->getCoeff()) > 2)
      return true;
  }
  return false;
}


bool SimplePolynomial::getLin2Subject(Variable &a, Variable &b) const
{
  if ( (myMonomList->size() > 3) || (myMonomList->size() <= 0) ) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  long n1=0,n2=0;
  if (myMonomList->size() > 1)
  {
    if (!(*mon)->isVariable()) return false;
    n1=(*mon)->getVariable();
    if (myMonomList->size() > 2)
    {
      ++mon;
      if (!(*mon)->isVariable()) return false;
      n2 = (*mon)->getVariable();
    }
    ++mon;
  }    
  if ((!(*mon)->getTwoVariables(a,b))) return false;
  if ( (n2!=0) && (b != n2)) return false;
  if ( (n1!=0) && (a != n1) && (b!=n1)) return false;
  return true;
}

bool SimplePolynomial::getLin2Subject(Variable &a, Variable &b,Coefficient &c1, Coefficient &c2, Coefficient &c12) const
{
  if ((myMonomList->size() > 3) || (myMonomList->size() <= 0)) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  long n1=0,n2=0;
  c1 = 0; c2 = 0; c12 = 0;
  if (myMonomList->size() > 1)
  {
    if (!(*mon)->isVariable()) return false;
    n1=(*mon)->getVariable();
    c1 = (*mon)->getCoeff();
    if (myMonomList->size() > 2)
    {
      ++mon;
      if (!(*mon)->isVariable()) return false;
      n2 = (*mon)->getVariable();
      c2 = (*mon)->getCoeff();
    }
    ++mon;
  }
  if ((!(*mon)->getTwoVariables(a,b))) return false;
  if ( (n2!=0) && (b != n2)) return false;
  if ( (n1!=0) && (a != n1) && (b!=n1)) return false;
  c12 = (*mon)->getCoeff();
  if ( (n2 == 0) && (b == n1) )
  {
    c2 = c1;
    c1 = 0;
  }
  
  return true;
}

bool SimplePolynomial::getOneOneMinusOne(long &a, long &b) const
{
  if (myMonomList->size() != 3) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == 1)) ) return false;
  a = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == 1)) ) return false;
  b = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isTwoVariables(a,b)) || (!((*mon)->getCoeff() == -1)) ) return false;
  return true;
}


bool SimplePolynomial::isOneOneMinusTwo(long a,long b) const
{
  if (myMonomList->size() != 3) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  if ( (!(*mon)->isVariable(a)) || (!((*mon)->getCoeff() == 1)) ) return false;
  ++mon;
  if ( (!(*mon)->isVariable(b)) || (!((*mon)->getCoeff() == 1)) ) return false;
  ++mon;
  if ( (!(*mon)->isTwoVariables(a,b)) || (!((*mon)->getCoeff() == -2)) ) return false;
  return true;
}


bool SimplePolynomial::getOneOneMinusTwo(long &a, long &b) const
{
  if ( (myMonomList->size() != 3)) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
 
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == 1)) ) return false;
  a = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == 1)) ) return false;
  b = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isTwoVariables(a,b)) || (!((*mon)->getCoeff() == -2)) ) return false;
  return true;
}

bool SimplePolynomial::isOneOneMinusTwo() const
{
  long a, b;
  if (myMonomList->size() != 3) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == 1)) ) return false;
  a = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == 1)) ) return false;
  b = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isTwoVariables(a,b)) || (!((*mon)->getCoeff() == -2)) ) return false;
  return true;
}

bool SimplePolynomial::getOneOneMinusTwoWConst(long &a, long &b, bool &withconstant) const
{

  if ( (myMonomList->size() != 3) && (myMonomList->size() != 4) ) return false;
  if (myMonomList->size() == 4) withconstant = true;
  else withconstant = false;

  int coeff = withconstant?-1:1;
  
  std::list<PMonomial>::iterator mon = myMonomList->begin();

  if (withconstant)
  {
    if (!(*mon)->isConstant()) return false;

    if((*mon)->getConstant() == -1)
      coeff = 1;
    else if ((*mon)->getConstant() != 1)
      return false;
    ++mon;
  }
  else if((*mon)->isVariable() && (*mon)->getCoeff() == -coeff)
      coeff = -coeff;

if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == coeff)) ) return false;
  a = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == coeff)) ) return false;
  b = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isTwoVariables(a,b)) || (!((*mon)->getCoeff() == -2*coeff)) ) return false;
  return true;
}

bool SimplePolynomial::isOneOneMinusTwoWConst() const
{
  long a, b;
  bool withconstant;
  if ( (myMonomList->size() != 3) && (myMonomList->size() != 4) ) return false;
  if (myMonomList->size() == 4) withconstant = true;
  else withconstant = false;

  int coeff = withconstant?-1:1;
 
  std::list<PMonomial>::iterator mon = myMonomList->begin();

  
   if (withconstant)
  {
    if (!(*mon)->isConstant()) return false;

    if((*mon)->getConstant() == -1)
      coeff = 1;
    else if ((*mon)->getConstant() != 1)
      return false;
    ++mon;
  }
  else if((*mon)->isVariable() && (*mon)->getCoeff() == -coeff)
      coeff = -coeff;

 if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == coeff)) ) return false;
  a = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == coeff)) ) return false;
  b = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isTwoVariables(a,b)) || (!((*mon)->getCoeff() == -2*coeff)) ) return false;
  return true;
}



void SimplePolynomial::cutLastMonomial() 
{
  
  if (myMonomList->size() != 3) return;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  ++mon; ++mon;
  myMonomList->erase(mon);
}

PVarList SimplePolynomial::getVarList(PVarList varList) const
{ 
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  while (mon!=myMonomList->end())
  {
    PVariableIterator monVar=(*mon)->getBeginIterator();
    while (!monVar->equals(*((*mon)->getEndIterator())))
    {
      std::list<Variable>::iterator vbeg = varList->begin();
      while ((vbeg!=varList->end()) && ((*vbeg) < (**monVar))) ++vbeg;
      if (vbeg == varList->end())
      {
        varList->push_back(**monVar);     
      }
      else if ((**monVar)<(*vbeg))
         varList->insert(vbeg,**monVar);      
      ++(*monVar);
    };    
    ++(mon);
  };
  return varList;
};

Coefficient
SimplePolynomial::getFreeCoefficient() const
{
  if (this->myMonomList->size() == 0)
    return 0;
    
  if ((**(this->getBeginIterator()))->isConstant())
    return ((**(this->getBeginIterator()))->getConstant());

  return 0;
}

bool SimplePolynomial::getABpACpBCm2ABC(Variable& a,Variable& b,Variable& c) const
{
  long an,bn,cn,dn,en,fn,aa,bb,cc;
  if (myMonomList->size() != 4) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  if ( (!(*mon)->getTwoVariables(an,bn)) || (!((*mon)->getCoeff() == 1)) ) return false;
  ++mon;
  if ( (!(*mon)->getTwoVariables(cn,dn)) || (!((*mon)->getCoeff() == 1)) ) return false;
  ++mon;
  if ( (!(*mon)->getTwoVariables(en,fn)) || (!((*mon)->getCoeff() == 1)) ) return false;
  if ( (an == cn) || (an == en))
    aa = an;
  else if (en == cn)
    aa = en;
  else return false;
  if ( (bn == dn) || (bn == fn))
    cc = bn;
  else if (dn == fn)
    cc = dn;
  else return false;
  if ( (an == aa) && (bn == cc) )
  {
    if ((cn == aa) && (dn == en))
      bb = dn;
    else if (cn == fn)
      bb = cn;
    else return false;
  }
  else if (an == aa)
  {
    if ((bn == en) && (fn == cc))
      bb = bn;
    else if ((bn == cn) && (dn == cc))
      bb = bn;
    else return false;
  }
  else
    if ((bn == cc) && ((an == fn) || (an == dn)))
      bb = bn;
    else return false;
    
  ++mon;
  if ( (!(*mon)->getThreeVariables(a,b,c)) || (!((*mon)->getCoeff() == -2)) ) return false;
  
  if (a != aa) return false;
  if (c != cc) return false;
  if (b != bb) return false;
  
  return true;
}

bool SimplePolynomial::isABpACpBCm2ABC() const
{
  long an,bn,cn,dn,en,fn,aa,bb,cc;
  if (myMonomList->size() != 4) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  if ( (!(*mon)->getTwoVariables(an,bn)) || (!((*mon)->getCoeff() == 1)) ) return false;
  ++mon;
  if ( (!(*mon)->getTwoVariables(cn,dn)) || (!((*mon)->getCoeff() == 1)) ) return false;
  ++mon;
  if ( (!(*mon)->getTwoVariables(en,fn)) || (!((*mon)->getCoeff() == 1)) ) return false;
  if ( (an == cn) || (an == en))
    aa = an;
  else if (en == cn)
    aa = en;
  else return false;
  if ( (bn == dn) || (bn == fn))
    cc = bn;
  else if (dn == fn)
    cc = dn;
  else return false;
  if ( (an == aa) && (bn == cc) )
  {
    if ((cn == aa) && (dn == en))
      bb = dn;
    else if (cn == fn)
      bb = cn;
    else return false;
  }
  else if (an == aa)
  {
    if ((bn == en) && (fn == cc))
      bb = bn;
    else if ((bn == cn) && (dn == cc))
      bb = bn;
    else return false;
  }
  else
    if ((bn == cc) && ((an == fn) || (an == dn)))
      bb = bn;
    else return false;
    
  ++mon;
  Variable a,b,c;
  if ( (!(*mon)->getThreeVariables(a,b,c)) || (!((*mon)->getCoeff() == -2)) ) return false;
  
  if (a != aa) return false;
  if (c != cc) return false;
  if (b != bb) return false;
  
  return true;
}

bool SimplePolynomial::get124(Variable& a,Variable& b,Variable& c) const
{
  int withconstant = 1;
  long aa,bb,cc,v1,v2;
  if (myMonomList->size() != 7) 
  {
    if (myMonomList->size() == 8)
      withconstant = -1;
    else
      return false;
  }
  std::list<PMonomial>::iterator mon = myMonomList->begin();
   
  if (withconstant < 0)
  {
    if (!(*mon)->isConstant()) return false;
    if ((*mon)->getConstant() != 1) return false;
    ++mon;
  }

  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == withconstant)) ) return false;
  aa = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == withconstant)) ) return false;
  bb = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == withconstant)) ) return false;
  cc = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->getTwoVariables(v1,v2)) || (!((*mon)->getCoeff() == -2*withconstant)) ) return false;
  if (!( ((v1 == aa) && ((v2 == bb) || (v2 == cc))) || ((v1 == bb) && (v2 == cc))  )) return false;
  ++mon;
  if ( (!(*mon)->getTwoVariables(v1,v2)) || (!((*mon)->getCoeff() == -2*withconstant)) ) return false;
  if (!( ((v1 == aa) && ((v2 == bb) || (v2 == cc))) || ((v1 == bb) && (v2 == cc))  )) return false;
  ++mon;
  if ( (!(*mon)->getTwoVariables(v1,v2)) || (!((*mon)->getCoeff() == -2*withconstant)) ) return false;
  if (!( ((v1 == aa) && ((v2 == bb) || (v2 == cc))) || ((v1 == bb) && (v2 == cc))  )) return false;
  ++mon;
  if ( (!(*mon)->getThreeVariables(a,b,c)) || (!((*mon)->getCoeff() == 4*withconstant)) ) return false;
      
  if (a != aa) return false;
  if (b != bb) return false;
  if (c != cc) return false; 
  return true;
}


bool SimplePolynomial::is124() const
{
  int withconstant = 1;
  long aa,bb,cc,v1,v2;
  if (myMonomList->size() != 7) 
  {
    if (myMonomList->size() == 8)
      withconstant = -1;
    else
      return false;
  }
  std::list<PMonomial>::iterator mon = myMonomList->begin();
   
  if (withconstant < 0)
  {
    if (!(*mon)->isConstant()) return false;
    if ((*mon)->getConstant() != 1) return false;
    ++mon;
  }


  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == withconstant)) ) return false;
  aa = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == withconstant)) ) return false;
  bb = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->isVariable()) || (!((*mon)->getCoeff() == withconstant)) ) return false;
  cc = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->getTwoVariables(v1,v2)) || (!((*mon)->getCoeff() == -2*withconstant)) ) return false;
  if (!( ((v1 == aa) && ((v2 == bb) || (v2 == cc))) || ((v1 == bb) && (v2 == cc))  )) return false;
  ++mon;
  if ( (!(*mon)->getTwoVariables(v1,v2)) || (!((*mon)->getCoeff() == -2*withconstant)) ) return false;
  if (!( ((v1 == aa) && ((v2 == bb) || (v2 == cc))) || ((v1 == bb) && (v2 == cc))  )) return false;
  ++mon;
  if ( (!(*mon)->getTwoVariables(v1,v2)) || (!((*mon)->getCoeff() == -2*withconstant)) ) return false;
  if (!( ((v1 == aa) && ((v2 == bb) || (v2 == cc))) || ((v1 == bb) && (v2 == cc))  )) return false;
  ++mon;
  Variable a,b,c;
  if ( (!(*mon)->getThreeVariables(a,b,c)) || (!((*mon)->getCoeff() == 4*withconstant)) ) return false;
  if (a != aa) return false;
  if (b != bb) return false;
  if (c != cc) return false; 
  return true;
}

bool SimplePolynomial::getABpACmABC(Variable& a,Variable& b,Variable& c) const
{
  if (myMonomList->size() != 3) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  long aa,bb,cc,v1,v2;
  if ( (!(*mon)->getTwoVariables(aa,bb)) || (!((*mon)->getCoeff() == 1)) ) return false;
  ++mon;
  if ( (!(*mon)->getTwoVariables(v1,v2)) || (!((*mon)->getCoeff() == 1)) ) return false;
   if ( (v1==aa) || (v2==aa))
  {
    if (v1==aa)
      cc = v2;
    else cc=v1;
  }
  else if ((v1==bb) || (v2==bb))
  {
    if (v1==bb)
      cc=v2;
    else cc=v1;
    v2 = aa; aa = bb; bb = v2;
  }
  else return false;
 
  ++mon;
  if ( (!(*mon)->getThreeVariables(a,b,c)) || (!((*mon)->getCoeff() == -1)) ) return false;
  if ( ((a!=aa) && (a!=bb) && (a!=cc)) || ( (c!=aa) && (c!=bb) && (c!=cc) ) || ( (b!=bb) && (b!=cc) && (b!=aa) ) ) return false;
  
  
  if (a!=aa)
  {
    Variable temp;
    if (b == aa)
    {
      temp = b;
      b = a;
      a = temp;
    }
    else if (c == aa)
    {
      temp = c;
      c = a;
      a = temp;
    }
  }
  return true;
}

bool SimplePolynomial::isABpACmABC() const
{
  if (myMonomList->size() != 3) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  long aa,bb,cc,v1,v2;
  if ( (!(*mon)->getTwoVariables(aa,bb)) || (!((*mon)->getCoeff() == 1)) ) return false;
  ++mon;
  if ( (!(*mon)->getTwoVariables(v1,v2)) || (!((*mon)->getCoeff() == 1)) ) return false;
  if ( (v1==aa) || (v2==aa))
  {
    if (v1==aa)
      cc = v2;
    else cc=v1;
  }
  else if ((v1==bb) || (v2==bb))
  {
    if (v1==bb)
      cc=v2;
    else cc=v1;
    v2 = aa; aa = bb; bb = v2;
  }
  else return false;
 
  ++mon;
  Variable a,b,c;
  if ( (!(*mon)->getThreeVariables(a,b,c)) || (!((*mon)->getCoeff() == -1)) ) return false;
  if ( ((a!=aa) && (a!=bb) && (a!=cc)) || ( (c!=aa) && (c!=bb) && (c!=cc) ) || ( (b!=bb) && (b!=cc) && (b!=aa) ) ) return false;
  
  
  if (a!=aa)
  {
    Variable temp;
    if (b == aa)
    {
      temp = b;
      b = a;
      a = temp;
    }
    else if (c == aa)
    {
      temp = c;
      c = a;
      a = temp;
    }
  } 
  
  return true;
}

bool SimplePolynomial::getACpDmACD(Variable& a,Variable& c,Variable& d) const
{
  if (myMonomList->size() != 3) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  long aa,cc,dd=0;
  if ( ( (!(*mon)->getTwoVariables(aa,cc)) && (!(*mon)->isVariable())) || (!((*mon)->getCoeff() == 1)) ) return false;
  if ((*mon)->isVariable()) dd = (*mon)->getVariable();
  ++mon;
  if ( ( (dd==0) && (!(*mon)->getVariable())) || ((dd>0) && (!(*mon)->getTwoVariables(aa,cc))) || (!((*mon)->getCoeff() == 1)) ) return false;
  if (dd==0) dd = (*mon)->getVariable();
  ++mon;
  if ( (!(*mon)->getThreeVariables(a,c,d)) || (!((*mon)->getCoeff() == -1)) ) return false;
  if ((a != aa) && (a != dd)) return false;
  if ((c != aa) && (c != cc) && (c != dd)) return false;
  if ((d != cc) && (d != dd)) return false;
  if (a == dd)
  {
    Variable tempd = a;
    a = d; d = tempd;
  }
  else if (c==dd)
  {
    Variable tempdd = c;
    c = d; d = tempdd;
  }
  return true;
}

bool SimplePolynomial::isACpDmACD() const
{
  if (myMonomList->size() != 3) return false;
  std::list<PMonomial>::iterator mon = myMonomList->begin();
  long aa,cc,dd=0;
  if ( ( (!(*mon)->getTwoVariables(aa,cc)) && (!(*mon)->isVariable())) || (!((*mon)->getCoeff() == 1)) ) return false;
  if ((*mon)->isVariable()) dd = (*mon)->getVariable();
  ++mon;
  if ( ( (dd==0) && (!(*mon)->getVariable())) || ((dd>0) && (!(*mon)->getTwoVariables(aa,cc))) || (!((*mon)->getCoeff() == 1)) ) return false;
  if (dd==0) dd = (*mon)->getVariable();
  ++mon;
  Variable a,c,d;
  if ( (!(*mon)->getThreeVariables(a,c,d)) || (!((*mon)->getCoeff() == -1)) ) return false;
  if ((a != aa) && (a != dd)) return false;
  if ((c != aa) && (c != cc) && (c != dd)) return false;
  if ((d != cc) && (d != dd)) return false;
  return true;
}
 
PMonomialIterator SimplePolynomial::remove(PMonomialIterator& cur)
{ 
  
  PSimpleMonomialIterator simpleCur=boost::shared_dynamic_cast<SimpleMonomialIterator, MonomialIterator>(cur);
  if (simpleCur)
  {
    std::list<PMonomial>::iterator it=simpleCur->getListIterator();
    it=myMonomList->erase(it);
    PSimpleMonomialIterator res(new SimpleMonomialIterator(it));
    return res;
  };
  return cur;
}; 

int SimplePolynomial::getDegree() const
{
  if (!myMonomList->size()) return 0;
  std::list<PMonomial>::iterator it=myMonomList->end();
  --it;
  if ((*it).get() == 0) return 0;
  return (*it)->getSize();  
};

bool SimplePolynomial::isLiteral() const
{
  if (this->isVariable() && this->getFirstConstant()==1) return true;
  if (this->getSize()!=2) return false;
  std::list<PMonomial>::iterator it=myMonomList->begin();
  if (((*it)->isConstant()) && ((*it)->getConstant()==1))
  {
    ++it;
    if ((*it)->isVariable() && (*it)->getConstant()==-1) return true;
  };
  return false;
};

bool SimplePolynomial::doesNotContain(Variable a, Variable b, Variable c) const
{
  std::list<PMonomial>::iterator it=myMonomList->begin();
  for (;it!=myMonomList->end();++it)
  {
    if ((*it)->getSize()>1) return true;
    if ((*it)->isVariable() && ((*it)->getVariable()==a)) 
      return false;
    if ((*it)->isVariable() && ((*it)->getVariable()==b)) 
      return false;
    if ((*it)->isVariable() && ((*it)->getVariable()==c)) 
      return false;      
  };
  return true;
};

bool SimplePolynomial::doesNotContain(Variable a, Variable b) const
{
  std::list<PMonomial>::iterator it=myMonomList->begin();
  for (;it!=myMonomList->end();++it)
  {
    if ((*it)->getSize()>1) return true;
    if ((*it)->isVariable() && ((*it)->getVariable()==a)) 
      return false;
    if ((*it)->isVariable() && ((*it)->getVariable()==b)) 
      return false;
  };
  return true;
};

long SimplePolynomial::getUpperBound() const
{
  long ub=0;
  std::list<PMonomial>::iterator it=myMonomList->begin();
  for (;it!=myMonomList->end();++it)
  {
    if ((*it)->isConstant() || (*it)->getCoeff()>0)
      ub+=(*it)->getCoeff();
  };
  return  ub;
}; 
  
  
long SimplePolynomial::getLowerBound() const
{
  long lb=0;
  std::list<PMonomial>::iterator it=myMonomList->begin();
  for (;it!=myMonomList->end();++it)
  {
    if ((*it)->isConstant() || (*it)->getCoeff()<0) lb+=(*it)->getCoeff();
  };
  return  lb;

};

bool SimplePolynomial::isObviousOdd() const
{
  std::list<PMonomial>::iterator it=myMonomList->begin();
  if ((!(*it)->isConstant()) || (! abs((*it)->getCoeff()) % 2))
    return false;
  ++(it);    
  for (;it!=myMonomList->end();++it)
  {
    if ((*it)->getCoeff() %2) return false;
  };
  return true;
};

bool SimplePolynomial::xorTypeNormalize(Variable& var1, bool& pos1, Variable& var2, bool& pos2, Variable& var3, bool& pos3)
{
  if (this->getSize()==4)
  {
    //Without constant
    std::list<PMonomial>::iterator it=myMonomList->begin();
    if (!(*it)->isVariable()) return false;
    Variable p1=(*it)->getVariable();
    Coefficient c1=(*it)->getCoeff();
    ++it;
    if (!(*it)->isVariable()) return false;
    Variable p2=(*it)->getVariable();
    Coefficient c2=(*it)->getCoeff();
    if (abs(c2)!=abs(c1)) return false;
    ++it;
    if (!(*it)->isVariable()) return false;
    Variable p3=(*it)->getVariable();
    Coefficient c3=(*it)->getCoeff();    
    if (abs(c3)!=abs(c1)) return false;
    ++it;
    if ((*it)->getSize()!=2) return false;
    Coefficient c4=(*it)->getCoeff();    
    if (c1*c2*c3*c4<0) return false;
    if (abs(c4)!=2*abs(c1)) return false;
    if ((*it)->isTwoVariables(p2, p3))
    {
      var1=p1; var2=p2; var3=p3;
      pos1=pos2=pos3=true;
      return true;
    } 
    if (((*it)->isTwoVariables(p1, p2) && (c1==c2) && (c1!=c3)) ||
       (((*it)->isTwoVariables(p1, p3)) && (c1==c3) && (c1!=c2)))
    {
      myMonomList->clear();
      PMonomial m1=AlgebraicGenerator::makeMonomial(p1); (*m1)*=(-1);
      PMonomial m2=AlgebraicGenerator::makeMonomial(p2); (*m2)*=p3; (*m2)*=(-2);
      this->addMonomial(m1);
      this->addMonomial(AlgebraicGenerator::makeMonomial(p2));
      this->addMonomial(AlgebraicGenerator::makeMonomial(p3));
      this->addMonomial(m2);      
      var1=p1; var2=p2; var3=p3;
      pos1=pos2=pos3=true;
      return true; 
    };
  }
  else if (this->getSize()==5)
  {  
    // With constant
    std::list<PMonomial>::iterator it=myMonomList->begin();
    if (!(*it)->isConstant()) return false;
    Coefficient c0=(*it)->getCoeff();
    ++it;
    if (!(*it)->isVariable()) return false;
    Variable p1=(*it)->getVariable();
    Coefficient c1=(*it)->getCoeff();
    if (c0!=-c1) return false;
    ++it;
    if (!(*it)->isVariable()) return false;
    Variable p2=(*it)->getVariable();
    Coefficient c2=(*it)->getCoeff();
    if (c2!=c1) return false;
    ++it;
    if (!(*it)->isVariable()) return false;
    Variable p3=(*it)->getVariable();
    Coefficient c3=(*it)->getCoeff();    
    if (c3!=c1) return false;
    ++it;
    if ((*it)->getSize()!=2) return false;
    Coefficient c4=(*it)->getCoeff();    
    if (c4!=-2*c1) return false;    
    if ((*it)->isTwoVariables(p2, p3))
    {
      var1=p1; var2=p2; var3=p3;
      pos1=pos2=true; pos3=false;
      return true;
    };  
    if ((*it)->isTwoVariables(p1, p2) ||
       ((*it)->isTwoVariables(p1, p3)))
    {
      myMonomList->clear();
      PMonomial m0=AlgebraicGenerator::makeMonomial(); (*m0)*=(-1);
      PMonomial m2=AlgebraicGenerator::makeMonomial(p2); (*m2)*=p3; (*m2)*=(-2);
      this->addMonomial(m0);
      this->addMonomial(AlgebraicGenerator::makeMonomial(p1));
      this->addMonomial(AlgebraicGenerator::makeMonomial(p2));
      this->addMonomial(AlgebraicGenerator::makeMonomial(p3));
      this->addMonomial(m2);      
      var1=p1; var2=p2; var3=p3;
      pos1=pos2=true; pos3=false;
      return true;
    };
  };  
  return false;
};     


void SimplePolynomial::squareOfSumNormalize()
{
  if (this->getSize()==3)
  {
    //Without constant
    std::list<PMonomial>::iterator it=myMonomList->begin();
    if (!(*it)->isVariable()) return;
    Variable p1=(*it)->getVariable();
    Coefficient c1=(*it)->getCoeff();
    ++it;
    if (!(*it)->isVariable()) return;
    Variable p2=(*it)->getVariable();
    Coefficient c2=(*it)->getCoeff();
    if (c2!=c1) return;
    ++it;
    if ((*it)->getSize()!=2) return;
    Coefficient c3=(*it)->getCoeff();    
    if (c3!=-2*c1) return;
    if (! (*it)->isTwoVariables(p1, p2)) return;
    myMonomList->clear();
    PMonomial m1=AlgebraicGenerator::makeMonomial(p1); (*m1)*=(-1);
    this->addMonomial(m1);
    this->addMonomial(AlgebraicGenerator::makeMonomial(p2));
  }
  else if (this->getSize()==4)
  {  
    std::list<PMonomial>::iterator it=myMonomList->begin();
    if (!(*it)->isConstant()) return;
    Coefficient c0=(*it)->getCoeff();
    ++it;
    if (!(*it)->isVariable()) return;
    Variable p1=(*it)->getVariable();
    Coefficient c1=(*it)->getCoeff();
    if (c0!=-c1) return;
    ++it;
    if (!(*it)->isVariable()) return;
    Variable p2=(*it)->getVariable();
    Coefficient c2=(*it)->getCoeff();
    if (c2!=c1) return;
    ++it;
    if ((*it)->getSize()!=2) return;
    Coefficient c3=(*it)->getCoeff();    
    if (c3!=-2*c1) return;    
    if (!(*it)->isTwoVariables(p1, p2)) return;
    myMonomList->clear();
    PMonomial m1=AlgebraicGenerator::makeMonomial(p1); (*m1)*=(-1); 
    PMonomial m2=AlgebraicGenerator::makeMonomial(p2); (*m2)*=(-1);
    this->addMonomial(AlgebraicGenerator::makeMonomial());
    this->addMonomial(m1);
    this->addMonomial(m2);
  };  
};     

bool SimplePolynomial::parseANDRepresentation(Variable& var1, bool& pos1, Variable& var2, bool& pos2, Variable& var3, bool& pos3) const
{
  std::list<PMonomial>::iterator it=myMonomList->begin();
  if (this->getSize()==2)
  {
    //-x=ab
    if (!(*it)->isVariable()) return false;
    var1=(*it)->getVariable();
    Coefficient c1=(*it)->getCoeff();
    ++it;
    if ((*it)->getSize()!=2) return false;
    Coefficient c2=(*it)->getCoeff();    
    if (c2!=-c1) return false;
    (*it)->getTwoVariables(var2, var3);
    pos1=pos2=pos3=true;
    return true;
  }
  else if (this->getSize()==3)
  {  
    if ((*it)->isConstant())
    {
      //1-x-ab
      Coefficient c0=(*it)->getCoeff();
      ++it;
      if (!(*it)->isVariable()) return false;
      var1=(*it)->getVariable();
      Coefficient c1=(*it)->getCoeff();
      if (c1!=-c0) return false;
      ++it;
      if ((*it)->getSize()!=2) return false;
      Coefficient c2=(*it)->getCoeff();    
      if (c2!=c1) return false;
      (*it)->getTwoVariables(var2, var3);
      if (var3==var1 || var2==var1) return false;
      pos2=pos3=true;
      pos1=false;
      return true;
    }
    else
    {
      //-x+a-ab
      //-x+b-ab
      if (!(*it)->isVariable()) return false;
      Variable a=(*it)->getVariable();
      Coefficient c1=(*it)->getCoeff();
      ++it;
      if (!(*it)->isVariable()) return false;
      Variable b=(*it)->getVariable();
      Coefficient c2=(*it)->getCoeff();
      if (c1!=-c2) return false;
      ++it;
      if ((*it)->getSize()!=2) return false;
      Coefficient c3=(*it)->getCoeff();    
      if (abs(c3)!=abs(c1)) return false;
      (*it)->getTwoVariables(var2, var3);
      if (b!=var2 && b!=var3)
      {
        Variable swap=b; b=a; a=swap;
	Coefficient t=c1; c1=c2; c2=t;
      };
      if (a!=var2 && a!=var3)
      {
        if (c2!=-c3) return false;
	if (b==var2)
	{
	  var1=a; pos1=true;
	  pos2=true; pos3=false;	  
	  return true;
	};
	if (b==var3)
	{
	  var1=a; pos1=true;
	  pos2=false; pos3=true;	  
	  return true;
	};	
      };

    };
  } else if (this->getSize()==4)
  {
    if (!(*it)->isConstant())
    {
      //-x+a+b-ab
      if (!(*it)->isVariable()) return false;
      Variable a=(*it)->getVariable();
      Coefficient c1=(*it)->getCoeff();
      ++it;
      if (!(*it)->isVariable()) return false;
      Variable b=(*it)->getVariable();
      Coefficient c2=(*it)->getCoeff();
      if (abs(c1)!=abs(c2)) return false;
      ++it;
      if (!(*it)->isVariable()) return false;
      Variable c=(*it)->getVariable();
      Coefficient c3=(*it)->getCoeff();
      if (abs(c1)!=abs(c3)) return false;
      ++it;
      Coefficient norm = 0;
      if (c1*c2>0 && c1*c3<0)
      {
        var1=c; var2=a; var3=b;
        norm=c2;
      }             
      else if (c1*c3>0 && c1*c2<0)
      {
        var1=b; var2=a; var3=c;
        norm=c1;
      }
      else if (c2*c3>0 and c1*c3<0)
      {
        var1=a; var2=b; var3=c;
        norm=c2;
      };
      if ((*it)->getSize()!=2) return false;
      Coefficient c4=(*it)->getCoeff();    
      if (c4!=-norm) return false;
      if (!(*it)->isTwoVariables(var2, var3)) return false;
      pos1=pos2=pos3=false;
      return true;
    }
    else
    {
     //1-x-a+ab
     //1-x-b-ab
      Coefficient c0=(*it)->getCoeff();
      ++it;
      if (!(*it)->isVariable()) return false;
      Variable a=(*it)->getVariable();
      Coefficient c1=(*it)->getCoeff();
      if (c1!=-c0) return false;
      ++it;
      if (!(*it)->isVariable()) return false;
      Variable b=(*it)->getVariable();
      Coefficient c2=(*it)->getCoeff();
      if (c2!=c1) return false;
      ++it;
      if ((*it)->getSize()!=2) return false;
      Coefficient c3=(*it)->getCoeff();    
      if (c3!=c0) return false;
      (*it)->getTwoVariables(var2, var3);
      if ((*it)->contains(a) && !((*it)->contains(b)))
      {
        var1=b;
	if (var2!=a)
	{
	  pos1=false; pos2=false; pos3=true;
	};
	if (var3!=a)
	{
	  pos1=false; pos2=true; pos3=false;
	};
	return true;
      };
      if ((*it)->contains(b) && !((*it)->contains(a)))
      {
        var1=a;
	if (var2!=b)
	{
	  pos1=false; pos2=false; pos3=true;
	};
	if (var3!=b)
	{
	  pos1=false; pos2=true; pos3=false;
	};
	return true;
      };
      
     
    };
     
  }
  else if (this->getSize()==5)
  {
    if (!(*it)->isConstant()) return false;
    Coefficient c0=(*it)->getCoeff();
    ++it;
    if (!(*it)->isVariable()) return false;
    Variable a=(*it)->getVariable();
    Coefficient c1=(*it)->getCoeff();
    if (c1!=-c0) return false;
    ++it;
    if (!(*it)->isVariable()) return false;    
    Variable b=(*it)->getVariable();
    Coefficient c2=(*it)->getCoeff();
    if (c2!=c1) return false;
    ++it;
    if (!(*it)->isVariable()) return false;    
    Variable c=(*it)->getVariable();
    Coefficient c3=(*it)->getCoeff();
    if (c3!=c1) return false;
    ++it;
    if ((*it)->getSize()!=2) return false;
    Coefficient c4=(*it)->getCoeff();    
    if (c4!=c0) return false;
    if ((*it)->contains(a) && (*it)->contains(b))
      var1=c;
    else if ((*it)->contains(a) && (*it)->contains(c))
      var1=b;
    else if ((*it)->contains(b) && (*it)->contains(c))
      var1=a;
    else
      return false;  
    (*it)->getTwoVariables(var2, var3);
    pos1=true; pos2=pos3=false;
    return true;
  };
  return false;
};

PPolynomial SimplePolynomial::substitute(Variable var, PPolynomial poly) const 
{
  std::list<PMonomial>::iterator my = myMonomList->begin();
  std::list<PMonomial>::iterator myend = myMonomList->end();
  PMonomialIterator his = poly->getBeginIterator();
  PMonomialIterator hisend = poly->getEndIterator();

  PPolynomial result = AlgebraicGenerator::makePolynomial();
  PMonomial temp;
  while (my != myend)
  {
    if ((*my)->contains(var))
    {
      for (his=poly->getBeginIterator();!his->equals(*hisend); ++*his)
      {
        temp = (**his)->clone();
        temp->multiplyWithoutVariable(var,*my);
        result->addMonomial(temp);
      }
    }
    else
    {
      result->addMonomialWithCloning(*my);
    }
    ++my;
  }
  return result;
}


Coefficient 
SimplePolynomial::getCoefficient(PMonomial mon)
{
  std::list<PMonomial>::iterator mbeg = myMonomList->begin();
  for (; mbeg != myMonomList->end(); mbeg++)
    if ((**mbeg) == (*mon))
    {
      return ((**mbeg).getCoeff());
    }
      
  return 0;
}


bool 
SimplePolynomial::checkVariable(
PPolynomial& poly, 
list< pair<Variable, bool> >& lit_list, 
long var)
{
  PPolynomial pos = poly->clone();
  PPolynomial neg = poly->clone();
  pos->assign(var, 1);
  neg->assign(var, 0);
  
  if (pos->getSize() == 0) // (1-var) divides this polynomial
  {
    poly = neg;
    lit_list.push_back(make_pair(var, 0));
    return true;
  }

  if (neg->getSize() == 0) // var divides this polynomial
  {
    poly = pos;
    lit_list.push_back(make_pair(var, 1));
    return true;
  }
 
  return false;
}

bool SimplePolynomial::parseABeq0(Variable& var1, bool& pos1, Variable& var2, bool& pos2) const
{
  std::list<PMonomial>::iterator it=myMonomList->begin();
  if (this->getSize()==1)
  {
    //ab=0
    if ((*it)->getSize()!=2) return false;
    (*it)->getTwoVariables(var1, var2);
    pos1=pos2=true;
    return true;
  }
  else if (this->getSize()==2)
  {  
    //0=b-ab
    if (!(*it)->isVariable()) return false;
    var1=(*it)->getVariable();
    Coefficient c1=(*it)->getCoeff();
    ++it;
    if ((*it)->getSize()!=2) return false;
    Coefficient c2=(*it)->getCoeff();    
    if (c2!=-c1) return false;
    Variable temp;
    (*it)->getTwoVariables(var2, temp);
    if (temp!=var1 && var2!=var1) return false;
    if (temp==var1)
    { 
      var1=var2; var2=temp;
      pos2=true;
      pos1=false;
      return true;
    };
    var2=temp;	
    pos1=true;
    pos2=false;
    return true;
  }
  else if (this->getSize()==4)
  {
    //0=1-a-b+ab
    if (!(*it)->isConstant()) return false;
    Coefficient c0=(*it)->getCoeff();
    ++it;
    if (!(*it)->isVariable()) return false;
    var1=(*it)->getVariable();
    Coefficient c1=(*it)->getCoeff();
    if (c1!=-c0) return false;
    ++it;
    if (!(*it)->isVariable()) return false;
    var2=(*it)->getVariable();
    Coefficient c2=(*it)->getCoeff();
    if (c2!=-c0) return false;
    ++it;
    if ((*it)->getSize()!=2) return false;
    Coefficient c3=(*it)->getCoeff();    
    if (c3!=c0) return false;
    if (!(*it)->isTwoVariables(var1, var2)) return false;
    pos1=pos2=false;
    return true;
  };
  return false;
};

bool SimplePolynomial::parseXeqAnotX(Variable& var1, bool& pos1, Variable& var2, bool& pos2, Variable& var3, bool& pos3) const
{
  std::list<PMonomial>::iterator it=myMonomList->begin();
  if (this->getSize()==3)
  {
    if (!(*it)->isConstant())
    {
      //-x+a-xa
      if (!(*it)->isVariable()) return false;
      var1=(*it)->getVariable();
      long c1=(*it)->getCoeff();
      ++it;
      if (!(*it)->isVariable()) return false;
      var2=(*it)->getVariable();
      long c2=(*it)->getCoeff();
      if (c1!=-c2) return false;
      ++it;
      if ((*it)->getSize()!=2) return false;
      if (!(*it)->isTwoVariables(var1, var2)) return false;
      long c3=(*it)->getCoeff();      
      if (abs(c3)!=abs(c2)) return false;
      pos1=pos3=true; 
      pos2=false;
      if (c3==c1)
      {
        var3=var2;
	var2=var1;
	return true;
      };
      var3=var1;
      var1=var2;
      return true;
    }
    else
    {
      long c1=(*it)->getCoeff();
      ++it;
      if (!(*it)->isVariable()) return false;
      long c2=(*it)->getCoeff();
      if ((c2!=-c1) && (c2!=-2*c1)) return false;
      var1=(*it)->getVariable();
      ++it;
      if ((*it)->getSize()!=2) return false;
      (*it)->getTwoVariables(var2, var3);
      if (var2!=var1 && var3!=var1) return false;
      if (var3==var1)
      {
        var3=var2;
	var2=var1;
      };
      long c3=(*it)->getCoeff();
      if (c2==-c1)
      {
        if (c3!=c2) return false;
	pos1=false;
	pos2=pos3=true;
	return true;    
      }
      else
      {
        if (c3!=c1) return false;
	pos1=pos3=false;
	pos2=true;
	return true;    
      }
    }
    }   
    else if (this->getSize()==4)
    {
      if (!(*it)->isConstant()) return false;
      long c0=(*it)->getCoeff();
      ++it;
      if (!(*it)->isVariable()) return false;
      long c1=(*it)->getCoeff();
      var1=(*it)->getVariable();
      ++it;
      if (!(*it)->isVariable()) return false;
      long c2=(*it)->getCoeff();
      var2=(*it)->getVariable();
      ++it;
      if (!(*it)->isTwoVariables(var1, var2)) return false;
      if (((*it)->getCoeff())!=c0) return false;
      pos1=true;
      pos2=pos3=false;      
      if (c1==-2*c0 && c2==-c0)
      {
        var3=var2;
        var2=var1;
	return true;       
      }
      else if (c2==-2*c0 && c1==-c0)
      {
        var3=var1;
	var1=var2;
	return true;
      }
      else return false;
    };
  
  return false;
};

bool SimplePolynomial::parseAplusB(Variable& var1, bool& pos1, Variable& var2, bool& pos2, PPolynomial& even) const
{
  
  PPolynomial odd(new SimplePolynomial());
  PPolynomial even2(new SimplePolynomial());
  even = even2;
  for(std::list<PMonomial>::iterator it=myMonomList->begin(); it!=myMonomList->end(); ++it)
  {
    if (abs(((*it)->getCoeff())% 2)==1)
    {
      if (((*it)->getSize()!=1) && (abs((*it)->getCoeff())!=1)) return false;
      if ((*it)->getSize()>1) return false;
      odd->addMonomialWithCloning(*it);
      if (odd->getSize()>3) return false;
    }  
    else
      even->addMonomial(*it);
  };

  if ((odd->getSize()!=2) && (odd->getSize()!=3)) return false;
  if (odd->getSize()==2)
  {
    PMonomialIterator it=odd->getBeginIterator();
    if (!(**it)->isVariable()) return false;
    if (abs((**it)->getCoeff())!=1) return false;
    var1=(**it)->getVariable();
    pos1=((**it)->getCoeff()==1);
    ++(*it);
    if (!(**it)->isVariable()) return false;
    if (abs((**it)->getCoeff())!=1) return false;
    var2=(**it)->getVariable();
    pos2=((**it)->getCoeff()==1);
    if (pos1!=pos2) return false;
    even=this->getEvenPart();
    if (pos1)
      (*even)*=(-1);  
    pos1=pos2=true;  
    return true;      
  };
  if (odd->getSize()==3)
  {
    PMonomialIterator it=odd->getBeginIterator();
    if (!(**it)->isConstant()) return false;
    PMonomial c=(**it);
    ++(*it);
    if (!(**it)->isVariable()) return false;
    if (abs((**it)->getCoeff())!=1) return false;
    var1=(**it)->getVariable();
    pos1=((**it)->getCoeff()==1);
    ++(*it);
    if (!(**it)->isVariable()) return false;
    if (abs((**it)->getCoeff())!=1) return false;
    var2=(**it)->getVariable();
    pos2=((**it)->getCoeff()==1);
    if (pos1==pos2) return false;
    even=this->getEvenPart();
    c->setCoeff(c->getCoeff()-1);
    even->addMonomial(c);
    (*even)*=(-1);  
    return true;      
  }; 
  return false;        
};

bool 
SimplePolynomial::parseTwoLiteralInSum(PPolynomial another, Variable& x, Variable& y, bool& sign_equals)
{
  PSimplePolynomial poly=boost::shared_dynamic_cast<SimplePolynomial, Polynomial>(another);
  Assert(poly, "Method can be applyed only to SimplePolynomial class");
  std::list<PMonomial>::iterator my=myMonomList->begin();
  std::list<PMonomial>::iterator his=poly->myMonomList->begin();
  Variable var1=0;
  Variable var2=0;
  int c=0;
  int vars_found=0;
  while (my!=myMonomList->end() || his!=poly->myMonomList->end())
  {
    bool not_end=my!=myMonomList->end() && his!=poly->myMonomList->end();
    if ((not_end) && (**my==**his))
    {
      if (abs((*my)->getCoeff()+(*his)->getCoeff()) % 2==0)
      {
        ++my; ++his; continue;
      };
      if (!(*my)->getSize()) 
      {
	c=(*my)->getCoeff()+(*his)->getCoeff();
	++my; ++his; continue;
      };	
      if ((*my)->getSize()!=1) return false;
      if (vars_found>=2) return false;
      if (vars_found==1)
      {
        var2=(*my)->getVariable();
      }	
      else
      {
        var1=(*my)->getVariable();
      }; 	
      ++vars_found;
      ++my; ++his; continue;
    };
    PMonomial mon;
    bool is_my_less;
    if (not_end) 
      is_my_less=(**my)<(**his);
    else  
      is_my_less=(my!=myMonomList->end());
    if (is_my_less) mon=*my;
    else mon=*his;      
    if (abs(mon->getCoeff()) % 2==0)
    {
      if (is_my_less) ++my; else ++his; continue;
    };
    if (!mon->getSize()) 
    {
	c=(mon)->getCoeff();
        if (is_my_less) ++my; else ++his; continue;
    };	
    if (mon->getSize()!=1) return false;
    if (vars_found>=2) return false;
    if (vars_found==1)
    {
      var2=mon->getVariable();
    }  
    else
    {
      var1=mon->getVariable();
    }	
     ++vars_found;
    if (is_my_less) ++my; else ++his; continue;    
  }
  sign_equals=!(abs(c)%2);
  x=y=0;
  if (vars_found>=1) x=var1;
  if (vars_found>=2) y=var2;  
  return true;
};
  
PPolynomial SimplePolynomial::substituteVarWithPoly(Variable var, PPolynomial poly) const
{
  PPolynomial res = AlgebraicGenerator::makePolynomial();
  
  std::list<PMonomial>::iterator my = myMonomList->begin();
  std::list<PMonomial>::iterator myend = myMonomList->end();
  PMonomialIterator his = poly->getBeginIterator();
  PMonomialIterator hisend = poly->getEndIterator();

  PMonomial tempmon;

  for ( ; my!=myend; ++my)
  {
    if (!(*my)->contains(var))
      res->addMonomialWithCloning(*my);
    else
    {
      for (his = poly->getBeginIterator(); !his->equals(*hisend); ++*his)
      {
        tempmon = (**his)->clone();
        tempmon->multiplyWithoutVariable(var,*my);
        res->addMonomial(tempmon);
      }
    }
  }
  return res;
}

