#include "simplemonomial.h"
#include "../../misc/assert.h"
#include "../../general/solver.h"
/**
 * @file simplemonomial.cc
 * @brief Implements the SimpleMonomial class
 */

/* @author dmitrits */

/**
 * A constructor
 */
SimpleMonomial::SimpleMonomial()
{
  PVarMap map(new VarMap);
  myVarMap = map;
  this->setCoeff(1);
}

/**
 * Constructs from monomial
 */
SimpleMonomial::SimpleMonomial(PMonomial mon)
{
  PVarMap map(new VarMap);
  myVarMap = map;
  this->setCoeff(mon->getCoeff());
  PVariableIterator viter=mon->getBeginIterator();
  while (!(viter->equals(*(mon->getEndIterator()))))
  {
    (*this)*=(**viter);
    ++(*viter);
  };
};

/**
 * Constructs from variable
 */
SimpleMonomial::SimpleMonomial(Variable var)
{
  PVarMap map(new VarMap);
  myVarMap = map;
  myVarMap->insert(std::make_pair(var, var));
  this->setCoeff(1);
};

/**
 * Constructs from 2 variables
 */
SimpleMonomial::SimpleMonomial(Variable var1, Variable var2)
{
  PVarMap map(new VarMap);
  myVarMap = map;
  myVarMap->insert(std::make_pair(var1, var1));
  if(var1 != var2)
    myVarMap->insert(std::make_pair(var2, var2));
  this->setCoeff(1);
};

/**
 * Constructs from a var and a coeff
 */
SimpleMonomial::SimpleMonomial(Coefficient coeff, long var)
{
  PVarMap map(new VarMap);
  myVarMap = map;
  (*this)*=var;
  this->setCoeff(coeff);
};

/**
 * Constructs from variable
 */
SimpleMonomial::SimpleMonomial(Variable var1, Variable var2, Variable var3)
{
  PVarMap map(new VarMap);
  myVarMap = map;
  (*this)*=var1;
  (*this)*=var2;
  (*this)*=var3;
  this->setCoeff(1);
};
 
/**
 * Multiplying by a variable
 */
Monomial& SimpleMonomial::operator *= (const Variable var)
{
  VarMap::iterator it=myVarMap->find(var);

  if (it==myVarMap->end())
  {
    myVarMap->insert(std::make_pair(var, var));
  }
  return *this;
}

PVariableIterator SimpleMonomial::getBeginIterator() const
{
  SimpleVariableIterator* psvi=new SimpleVariableIterator(myVarMap->begin());
  PVariableIterator res(psvi);
  return res;
};

/**
 * Printing
 */
std::ostream& SimpleMonomial::print(std::ostream& os,BooleanAlgebraicSolver *slv) 
{
  if (!myCoeff) return os <<"NULL";
  if (myCoeff<0) os <<"-";
  if ((!myVarMap->size())||(abs(myCoeff) != 1)) os << abs(myCoeff);
  VarMap::const_iterator vbeg = myVarMap->begin();
  while (vbeg != myVarMap->end())
  {
    std::pair<long int, Variable> pair=*vbeg;
    if (slv)
      slv->printVar(os,pair.second);
    else
      os << "p" << pair.second;
    ++vbeg;
  }
  return os;
}

bool SimpleMonomial::assign(Variable var, int value)
{
  if (value!=0 && value!=1) return !(myCoeff==0);
  VarMap::iterator it=myVarMap->find(var);
  if (it==myVarMap->end())
  {
    return !(myCoeff==0);
  };
  if (value==1)
  {
    myVarMap->erase(it);
    return !(myCoeff==0);
  };
  myVarMap->clear();
  this->setCoeff(0);
  return false;
};

bool SimpleMonomial::contains(Variable var) const
{
  return (!(myVarMap->find(var) == myVarMap->end()));
}

bool SimpleMonomial::operator==(Monomial& monom) const
{

  if (this->getSize() != monom.getSize()) return false;
  
  VarMap::iterator my=myVarMap->begin();
  VarMap::iterator myend=myVarMap->end();
  try
  {
     SimpleMonomial& mon=dynamic_cast<SimpleMonomial&>(monom);       
     VarMap::iterator his=mon.myVarMap->begin();
     VarMap::iterator hisend=mon.myVarMap->end();
     while ((my!=myend) && (his!=hisend))
     {
       if ((*my).second!=((*his).second)) return false;
       ++my; ++his;    
     };
     if ((my!=myend) || (his!=hisend))
       return false;
     return true;      
  }  
  catch (std::bad_cast &bc)  
  {  
    PVariableIterator his=monom.getBeginIterator();  
    while ((my!=myend) && !his->equals(*(monom.getEndIterator())))
    {
      if ((*my).second!=(*(*his))) return false;
      ++my; ++*his;    
    };
    if ((my!=myend) || !his->equals(*(monom.getEndIterator())))
      return false;
    return true;    
  };
};

bool SimpleMonomial::isLess(Monomial& monom) const
{
  if (this->getSize()<monom.getSize()) return true;
  if (this->getSize()>monom.getSize()) return false;
  
  VarMap::iterator my=myVarMap->begin();
  VarMap::iterator myend=myVarMap->end();
  try
  {
     SimpleMonomial& mon=dynamic_cast<SimpleMonomial&>(monom);       
     VarMap::iterator his=mon.myVarMap->begin();
     VarMap::iterator hisend=mon.myVarMap->end();
     while ((my!=myend) && (his!=hisend))
     {
       if (((*my).second)<((*his).second)) return true;
       if (((*my).second)>((*his).second)) return false;
       ++my; ++his;    
     };
     if (his==hisend) return false;
       return true;     
  }  
  catch (std::bad_cast &bc)  
  {  
    PVariableIterator his=monom.getBeginIterator();  
    while ((my!=myend) && !(his->equals(*(monom.getEndIterator()))))
    {
      if (((*my).second)<(*(*his))) return true;
      if (((*my).second)>(*(*his))) return false;
      ++my; ++*his;    
    };
    if (his->equals(*(monom.getEndIterator()))) return false;
    return true;  
  }; 
  
};
  
PMonomial SimpleMonomial::clone() const
{
  PMonomial mon(new SimpleMonomial());
  mon->setCoeff(myCoeff);
  VarMap::iterator it=myVarMap->begin();
  VarMap::iterator end=myVarMap->end();
  while (it!=end)
  {
    *mon *= (*it).first;    
    ++it;
  }
  return mon;

};

void SimpleMonomial::substituteEqual(Variable x, Variable y)
{
  VarMap::iterator itx=myVarMap->find(x);
  if (itx==myVarMap->end())
  {
    return;
  };
  myVarMap->erase(itx);
  VarMap::iterator ity=myVarMap->find(y);
  if (ity==myVarMap->end())
  {
    (*this)*=y;
    return;
  };
};

bool SimpleMonomial::isContain(PMonomial mon) const
{
  if (((this->getCoeff()) % (mon->getCoeff()))!=0)
    return false;
  PVariableIterator my=this->getBeginIterator();
  PVariableIterator his=mon->getBeginIterator();
  while (!(his->equals(*(mon->getEndIterator()))) &&
        !(my->equals(*(this->getEndIterator()))) )
  {
    if ((**my)==(**his))
    {
      ++(*my);
      ++(*his);      
    }
    else if ((**my)<(**his))
    {
      ++(*my);
    }
    else
    {
      return false;
    };    
  };  
  if (!(his->equals(*(mon->getEndIterator())))) return false;
  return true;
};

PMonomial SimpleMonomial::getQuotient(PMonomial mon) const
{
  PMonomial result(new SimpleMonomial());
  if (!this->isContain(mon)) return result;
  result->setCoeff(this->getCoeff() / mon->getCoeff());
  PVariableIterator my=this->getBeginIterator();
  PVariableIterator his=mon->getBeginIterator();
  while (!(his->equals(*(mon->getEndIterator()))) &&
        !(my->equals(*(this->getEndIterator()))) )
  {
    if ((**my)==(**his))
    {
      ++(*my);
      ++(*his);      
    }
    else if ((**my)<(**his))
    {
      (*result) *= (**my);
      ++(*my);
    }
    else
    {
      Assert(0, "Error, this is impossible situation");
    };
  };  
  while (!(my->equals(*(this->getEndIterator()))))
  {
    (*result) *= (**my);
    ++(*my);
  };
  return result;
};

long SimpleMonomial::applyAssignment(bool *sat) const
{
  PVariableIterator vbeg = this->getBeginIterator();
  PVariableIterator vend = this->getEndIterator();
  while (!vbeg->equals(*vend))
  {
    if (!sat[**vbeg]) return 0;
  }
  return myCoeff;
}
