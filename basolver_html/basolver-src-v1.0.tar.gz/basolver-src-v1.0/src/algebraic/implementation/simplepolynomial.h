#ifndef __SIMPLEPOLYNOMIAL_H__
#define __SIMPLEPOLYNOMIAL_H__

/**
 * @file simplepolynomial.h
 * @brief Contains implementation for the abstract
 * class Polynom
 * @author dmitrits
 */

#include "../abstract/polynomial.h"
#include "indexing/simplemonomialiterator.h"
#include <list>

/**
 * @class SimplePolynomial
 * @brief implementation of the abstract Polynomial class
 */
class SimplePolynomial : public Polynomial
{
private:
  /// list of monomials
  std::list<PMonomial>* myMonomList;
  
public:
   
  /// constructor
  SimplePolynomial()
  {
    myMonomList= new std::list<PMonomial>;
  };    
  
  /// constructs from a monomial
  SimplePolynomial(PMonomial monom)
  {
    myMonomList= new  std::list<PMonomial>;
    addMonomialWithCloning(monom);
  };    



  void addMonomial(const PMonomial mon);
  void addMonomialWithCloning(const PMonomial mon);
  void subtractMonomialWithCloning(const PMonomial mon);
  Variable getFirstLinearVariable();

  
  Polynomial& operator *= (Monomial& mon);
  Polynomial& operator *= (const Coefficient& coeff);
  Polynomial& operator *= (const Polynomial&);
  Polynomial& operator += (const Polynomial&);
  Polynomial& operator -= (const Polynomial&);
  Polynomial& operator += (const Coefficient& coeff);

  PMonomialIterator getBeginIterator() const
  {
     return PMonomialIterator(new SimpleMonomialIterator(myMonomList->begin()));
  }; 
  
  virtual PMonomialIterator remove(PMonomialIterator& cur);
  
  virtual bool occursLinear(Variable var,Coefficient &coeff) const;
  virtual bool hasBigCoefficients() const;
  virtual bool isOneOneMinusOne(long,long) const;
  virtual bool isOneOneMinusOne() const;
  virtual bool getOneOneMinusOne(long &, long &) const;
  virtual bool isOneOneMinusTwoWConst() const;
  virtual bool getOneOneMinusTwoWConst(long &, long &,bool &) const;
  virtual bool isOneOneMinusTwo(long,long) const;
  virtual bool isOneOneMinusTwo() const;
  virtual bool getOneOneMinusTwo(long &, long &) const;
  virtual bool isABpACpBCm2ABC() const;
  virtual bool getABpACpBCm2ABC(Variable&,Variable&,Variable&) const;
  virtual bool get124(Variable&,Variable&,Variable&) const;
  virtual bool is124() const;
  virtual bool getABpACmABC(Variable&,Variable&,Variable&) const;
  virtual bool getACpDmACD(Variable&,Variable&,Variable&) const;
  virtual bool isACpDmACD() const;
  virtual bool isABpACmABC() const;
  virtual bool getLin2Subject(Variable&,Variable&) const;
  virtual bool isLin2Subject() const;
  virtual bool isLinear() const;
  virtual bool getLin2Subject(Variable&,Variable&,Coefficient&,Coefficient&,Coefficient&) const;
  virtual bool isDeg2Even() const;
  virtual bool cutVariable(Variable);

  virtual bool isLexLess(const PPolynomial poly) const {return (this->compare(*poly) == 1);};

  virtual PPolynomial substitute(Variable var, PPolynomial poly) const;
  
  PMonomialIterator getEndIterator() const 
  {
     PMonomialIterator it(new SimpleMonomialIterator(myMonomList->end()));
     return it;
  }; 
  
  bool operator == (Polynomial& polynom) const;

  int compare(const Polynomial& polynom) const;
   
  long int getSize() const
  {
    return myMonomList->size();
  };

  
  std::ostream& 
  print(std::ostream& os,BooleanAlgebraicSolver *slv=0);

  void assign(Variable var, int value); 
  
  void substituteEqual(Variable x, Variable y); 
  
  void substituteNonEqual(Variable x, Variable y); 

  
  
  virtual bool oddPartEqualsModulo2(Polynomial &) const;

  virtual bool addEvenPartDiff(const Polynomial &,const Polynomial &);
 

  virtual long applyAssignment(bool *) const;
  
   
  bool isVariable() const;
  bool isVariable(long) const;
  bool isTwoVariables(long,long) const;
  bool isTwoVariables() const;
  bool getTwoVariables(long&,long&) const;
  
  
  Variable getVariable();
  
   
  bool isConstant() const;
  
   
  Coefficient getFirstConstant() const;

  PPolynomial clone(); 
  
   
  ~SimplePolynomial() 
  {
    myMonomList->clear();
    delete myMonomList;
  };  
  
  PPolynomial getOddPart() const; 

  Variable getOddVariable() const;
    
   
  PPolynomial getEvenPart() const;  

   
  PPolynomial getLinearPart() const;  

   
  PPolynomial getNonLinearPart() const;  


  PPolynomial getQuotient(PMonomial mon) const;
  
  PPolynomial getRemainder(PMonomial mon) const;

  PPolynomial getNegation();
  
  
  
  virtual bool containsVariable(Variable var) const;
   
  virtual void cutLastMonomial();

  PVarList getVarList(PVarList varList) const;

  virtual Coefficient
  getFreeCoefficient() const;
  
  virtual int
  getDegree() const;
  
  virtual bool isLiteral() const;
  
  virtual bool doesNotContain(Variable a, Variable b, Variable c) const;

  virtual bool doesNotContain(Variable a, Variable b) const;
  
  
  
  virtual long getUpperBound() const; 
  
  
  virtual long getLowerBound() const;
  
  virtual bool isObviousOdd() const;
  
  virtual bool xorTypeNormalize(Variable&, bool&, Variable&, bool&, Variable&, bool&);
  
  virtual void squareOfSumNormalize();     
  
  virtual bool parseANDRepresentation(Variable&, bool&, Variable&, bool&, Variable&, bool&) const;
  
  virtual bool parseABeq0(Variable& var1, bool& pos1, Variable& var2, bool& pos2) const;
  
  virtual bool parseXeqAnotX(Variable& var1, bool& pos1, Variable& var2, bool& pos2, Variable&, bool&) const;
  
  virtual bool parseAplusB(Variable& var1, bool& pos1, Variable& var2, bool& pos2, PPolynomial& even) const;  
  
  virtual Coefficient
  getCoefficient(PMonomial mon);
  
  
  /// checks whether var or (1-var) divides an input polynomial.
  /// If yes, adds a literal that divides to an input list and
  /// replaces an input polynomial by poly[l=1].
  bool checkVariable(PPolynomial& poly, 
    std::list< std::pair<Variable, bool> >& lit_list, 
    long var);
    
  
  bool parseTwoLiteralInSum(PPolynomial another, Variable& x, Variable& y, bool& sign_equals);
  
  PPolynomial substituteVarWithPoly(Variable var, PPolynomial poly) const;

};

/**
 * smart pointer for \ref SimplePolynomial
 */
typedef boost::shared_ptr<SimplePolynomial> PSimplePolynomial;

#endif
