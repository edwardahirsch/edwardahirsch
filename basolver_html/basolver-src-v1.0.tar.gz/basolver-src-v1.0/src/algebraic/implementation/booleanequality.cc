#include "booleanequality.h"
#include <typeinfo>
#include "misc/exception.h"

/**
 * @file booleanequality.cc
 * @brief Implements the BooleanEquality class
 */


/* @author dmitrits */


bool BooleanEquality::isNegation(PEquality eq) const
{
    if (!eq->getBooleanVariable())
      return false;
    else
      return ((eq->getBooleanVariable() == myVariable) && (eq->getBooleanSign() == !mySign));
  };

/**
 * Printing
 */
std::ostream& BooleanEquality::print(std::ostream& os, BooleanAlgebraicSolver *slv, bool print_as_dedobj) 
{
  if (!print_as_dedobj && (this->getId() > 0)) os << this->getId() << ": ";
  if (myVariable)
  {
    if (slv)
      slv->printVar(os,myVariable);
    else
      os << "p" << myVariable;
    os << "="<< (mySign ? "1": "0"); 
  }
  else
  {
    os << (mySign ? "0=0" : "1=0");
  } ;
  return os;   
}


PVarList BooleanEquality::getVariableList() const
{
  PVarList varList(new std::list<Variable>);
  if (myVariable)
    varList->push_back(myVariable);
  return varList;
}

/**
 * assigns values to variables
 */
AssignReturnType BooleanEquality::assign(Variable var, int val)
{
  if (!(var==myVariable)) return myStatus;
  if ((mySign && (val!=1)) || (!mySign && (val!=0)))
  {
    myStatus=ART_Unsatisfiable;        
    mySign=false;
  }
  else
  {
    myStatus=ART_Satisfiable;
    mySign=true;
  };
  myVariable=0; 
  return myStatus;
}

/**
 * Cloning
 */
PSALiteral BooleanEquality::clone() const
{
  PSALiteral result(new BooleanEquality(myVariable, mySign));
  return result;
}

AssignReturnType BooleanEquality::substituteEqual(Variable x, Variable y)
{
  if (!(x==myVariable)) return myStatus;
  myVariable=y;
  myLHS->substituteEqual(x,y);
  return myStatus;
};
  
AssignReturnType BooleanEquality::substituteNonEqual(Variable x, Variable y)
{
  if (!(x==myVariable)) return myStatus;
  myVariable=y;
  mySign=!mySign;
  myLHS->substituteEqual(x,y);
  if (myRHS->getFirstConstant())
    *myRHS += (Coefficient)(-1);
  else
    *myRHS += (Coefficient)1;
  return myStatus;
};

AssignReturnType BooleanEquality::substituteMonomial(PEquality t2Equality)
{
  return myStatus;
};



Variable BooleanEquality::getBooleanVariable()
{
  return myVariable;
}; 
  
bool BooleanEquality::getBooleanSign()
{
  return mySign;
}; 

bool BooleanEquality::operator == (SALiteral& literal) const
{
  try
  {
    Equality& equality=dynamic_cast<Equality&>(literal);
    try
    {
      BooleanEquality& boolEquality=dynamic_cast<BooleanEquality&>(equality);
      return ((boolEquality.myVariable==myVariable) 
             && (boolEquality.mySign==mySign));
    }
    catch  (std::bad_cast &bc)  
    {
      PPolynomial rhs=this->getRHS();
      return (((*this->getLHS())==*(equality.getLHS())) 
      && ((*rhs)==*(equality.getRHS())));
    }   
  }
  catch (std::bad_cast &bc)  
  {
    return false;
  };    
};  
 
bool BooleanEquality::operator < (SALiteral& literal) const
{
  try
  {
    Equality& equality=dynamic_cast<Equality&>(literal);
    try
    {
      BooleanEquality& boolEquality=dynamic_cast<BooleanEquality&>(equality);
      if ((boolEquality.myVariable>myVariable)) return true;
      if ((boolEquality.myVariable<myVariable)) return false;
      if (boolEquality.mySign>mySign) return true;
      return false;
    }
    catch  (std::bad_cast &bc)  
    {
      PPolynomial rhs=this->getRHS();
      if ( (AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(myVariable))->compare(*(equality.getLHS()))) == 1) return true;
      switch (this->getLHS()->compare(*(equality.getLHS())))
      {
        case 1: return true; break;
        case -1: return false; break;
        default: return (this->getRHS()->compare(*(equality.getRHS())) == 1);
      }
      return false;
    }   
  }
  catch (std::bad_cast &bc)  
  {
    return false;
  };    
};




PEquality BooleanEquality::negation() const
{
  PEquality res(new BooleanEquality(myVariable, !mySign));
  return res;
};


PPolynomial BooleanEquality::getPolynomialRepresentation()
{
  PPolynomial result=AlgebraicGenerator::makePolynomial();
  result->addMonomial(AlgebraicGenerator::makeMonomial(myVariable)); 
  if (!mySign)
  {
    (*result) *= (-1);
    result->addMonomial(AlgebraicGenerator::makeMonomial()); 
  };
  return result;
}; 


