#ifndef __BOOLEANEQUALITY_H__
#define __BOOLEANEQUALITY_H__

/**
 * @file booleanequality.h
 * @brief Contains implementation for the abstract
 * class Equality (particular for boolean literals x=1, x=0)
 * @author dmitrits
 */

#include "../abstract/equality.h"
#include "../abstract/polynomial.h"
#include "../algebraic.h"
#include "../../general/solver.h"
#include <list>

class BooleanEquality;

/**
 * smart pointer for \ref BooleanEquality
 */
typedef boost::shared_ptr<BooleanEquality> PBooleanEquality;

/**
 * An implementation for a equality
 */
class BooleanEquality : public Equality
{

private:

  /**
   * flag -- is this object marked as deleted
   */    
  
  bool myIsDeleted;

  /**
   * boolean variable
   */    
 
  Variable myVariable;

  /**
   * boolean sign
   */    

  bool mySign;

  /**
   * current equality status (type)
   */    
  
  AssignReturnType myStatus;
 
  /// left-hand side
  PPolynomial myLHS;
  /// right-hand side
  PPolynomial myRHS;
  /// polynomial representation
  PPolynomial myPolyRepresentation;
  /// polynomial representation of the negation
  PPolynomial myNegatedPolyRepresentation;
  
public:

  /**
   * constructor with boolean variable and boolean sign
   */
  BooleanEquality(Variable var, bool sign)
  {
    myVariable=var;
    mySign=sign;
    myStatus=ART_Active;
    myLHS = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(myVariable));
    if (mySign)
    {
      myRHS = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial());
    }
    else
    {
      myRHS = AlgebraicGenerator::makePolynomial();
    }

  };

  bool isPositive() const
  {
    return mySign;
  };

  PModificationObject cloneObject() const
  {
    PModificationObject res(new BooleanEquality(myVariable, mySign));
    return res;
  };


  std::ostream& print(std::ostream&,BooleanAlgebraicSolver *slv,bool print_as_dedobj = true);

  
  AssignReturnType assign(Variable var, int val);

  PVarList getVariableList() const;
  
  PSALiteral clone() const;

  bool isDeleted() const {return myIsDeleted;};

  void erase() {myIsDeleted=true;};

  void unErase() {myIsDeleted=false;};

  PPolynomial getLHS() const 
  {
    return myLHS;
  };
  
  PPolynomial getRHS() const
  {
    return myRHS;
  };

  
  
  AssignReturnType substituteEqual(Variable x, Variable y);
  
  
  AssignReturnType substituteNonEqual(Variable x, Variable y);
  
  
  AssignReturnType substituteMonomial(PEquality t2Equality);

  
   
  bool isBoolean() const {return myStatus==ART_Active;}; 
  bool isFirstType() const {return myStatus==ART_Active;}; 
  bool isSecondType() const {return false;}; 
  bool isThirdType() const {return false;}; 
  bool isTautology() const {return myStatus==ART_Satisfiable;}; 
  bool isUnsatisfiable() const {return myStatus==ART_Unsatisfiable;}; 
  
   
  Variable getBooleanVariable(); 
  
  bool getBooleanSign();  
  

  bool operator == (SALiteral& literal) const;  
 
  bool operator < (SALiteral& literal) const;
  
  PEquality negation() const;

  PPolynomial getPolynomialRepresentation(); 

  PPolynomial getPolynomialRepresentationWithoutCloning() {return myPolyRepresentation;};

  PPolynomial getNegatedPolynomialRepresentationWithoutCloning() {return myNegatedPolyRepresentation;};

  virtual bool isNegation(PEquality eq) const;
  
 
  Variable getBooleanVariable() const {return myVariable;};
  bool getBooleanSign() const {return mySign;};
 
 
  virtual bool getXeqAB(long &x, long &a, long &b) const {return false;};
  virtual bool getOneOneMinusTwo(long &x,long &a,long &b) const {return false;};
  virtual bool getOneOneMinusOne(long &x, long &a, long &b) const {return false;};
  virtual bool getLHSVariable(Variable &x) const {x = myVariable; return true;};

  long getFirstVariableNumber() const {return myVariable;};
  
};

#endif
