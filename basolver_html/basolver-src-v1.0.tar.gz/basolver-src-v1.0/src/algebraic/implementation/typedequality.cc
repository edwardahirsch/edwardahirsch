#include "typedequality.h"
#include <typeinfo>
#include "misc/exception.h"
#include "misc/tools.h"
#include "../../logical/logical.h"
#include "../../general/solver.h"
#include "../algebraic.h"
#include <list>

/**
 * @file typedequality.cc
 * @brief Implements the TypedEquality class
 */
 
/* @author sergey */


/**
 * Constructor
 */  
TypedEquality::TypedEquality(TEqualityType inptype, Variable inpvar1, bool inppos1, Variable inpvar2, bool inppos2, Variable inpvar3, bool inppos3, Variable inpvar4, bool inppos4, Variable inpvar5, bool inppos5, PPolynomial inplhs, PPolynomial inprhs) : type(inptype), var1(inpvar1), var2(inpvar2), var3(inpvar3), var4(inpvar4), var5(inpvar5), pos1(inppos1), pos2(inppos2), pos3(inppos3), pos4(inppos4), pos5(inppos5), lhs(inplhs), rhs(inprhs), myMainVar(0)
{
  switch (inptype)
  {
    default:
      break;
  }
}
 
/**
 * Constructor
 */  
TypedEquality::TypedEquality(TEqualityType inptype, Variable inpvar1, bool inppos1, Variable inpvar2, bool inppos2, Variable inpvar3, bool inppos3, Variable inpvar4, bool inppos4, Variable inpvar5, bool inppos5) : type(inptype), var1(inpvar1), var2(inpvar2), var3(inpvar3), var4(inpvar4), var5(inpvar5), pos1(inppos1), pos2(inppos2), pos3(inppos3), pos4(inppos4), pos5(inppos5), myMainVar(0)
{
    
  
  PPolynomial t1,t2,temp3,temp3n,temp4,temp4n;
  PMonomial mon;
  
  switch (inptype)
  {    
    
    
    case eqtCeqXZmXYpnWYnZp2WXYnZ:
      lhs = AlgebraicGenerator::makePolynomial(var1,pos1);
      rhs = AlgebraicGenerator::makeXORPolynomial(var4,pos4,var5,pos5);
      
      t1 = AlgebraicGenerator::makePolynomial(var3,pos3);
      temp3 = AlgebraicGenerator::makePolynomial(var2,pos2);
      temp3n = AlgebraicGenerator::makePolynomial(var2,!pos2);
      t2 = AlgebraicGenerator::makePolynomial(var2,!pos2);
      temp4 = AlgebraicGenerator::makePolynomial(var4,pos4);
      temp4n = AlgebraicGenerator::makePolynomial(var4,!pos4);
      *temp3n *= *temp4;
      *temp3n *= (Coefficient)-2;
      temp3n->addMonomial(AlgebraicGenerator::makeMonomial());
      *temp4 *= *t2;
      *t1 *= *temp3n;
      *t1 += *temp4;
     
      *rhs *= *t1;
      break;

    case eqtVeqYZnotLS:
    case eqtVeqYZLS:
      
      lhs = AlgebraicGenerator::makePolynomial(var1,pos1);
      rhs = AlgebraicGenerator::makePolynomial(var4,pos4);

      
      mon = AlgebraicGenerator::makeMonomial(var5);
      if (pos5)
        *rhs *= *mon;
      else
      {
        t1 = rhs->clone();
        *rhs *= *mon;
        *rhs *= -1;
        *rhs += *t1;
      }

      if (inptype==eqtVeqYZnotLS)
      {
        *rhs *= -1;
        *rhs += 1;
      }
      
      mon = AlgebraicGenerator::makeMonomial(var2);
      if (pos2)
        *rhs *= *mon;
      else
      {
        t1 = rhs->clone();
        *rhs *= *mon;
        *rhs *= -1;
        *rhs += *t1;
      }

      mon = AlgebraicGenerator::makeMonomial(var3);
      if (pos3)
        *rhs *= *mon;
      else
      {
        t1 = rhs->clone();
        *rhs *= *mon;
        *rhs *= -1;
        *rhs += *t1;
      }
      break;

    default:
      break;
  }
  
  simplify();

}
 
/**
 * Constructor
 */  
TypedEquality::TypedEquality(TEqualityType inptype, Variable inpvar1, bool inppos1, Variable inpvar2, bool inppos2, Variable inpvar3, bool inppos3, Variable inpvar4, bool inppos4) : type(inptype), var1(inpvar1), var2(inpvar2), var3(inpvar3), var4(inpvar4), pos1(inppos1), pos2(inppos2), pos3(inppos3), pos4(inppos4), myMainVar(0)
{  
  var5 = 0;
  PMonomial mon1, mon2, mon3, mon4, mon5, mon6, mon7, mon8, mon9;
  PPolynomial temp,temp1,temp2,temp2n,temp3,temp3n,temp4,temp4n;
  bool ok;

  // Reorder variables if possible
  switch (inptype)
  {
    case eqtYeqACpDmACD:
    case eqtXeqAB:
      sortTwoVars(ok);
      break;

    case eqtXeqABpACpBCm2ABC:
      sortThreeVars(ok);
      break;

    case eqt124:
      sortFourVars(ok);
      break;
      
    default:
      break;
  }
 
  switch (inptype)
  {

    case eqtXeqABC:

      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();
      
      rhs->addMonomial(AlgebraicGenerator::makeMonomial(var2));
      if (!pos2) { *rhs *= -1; rhs->addMonomial(AlgebraicGenerator::makeMonomial()); }

      temp = AlgebraicGenerator::makePolynomial();
      temp->addMonomial(AlgebraicGenerator::makeMonomial(var3));
      if (!pos3) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }
      *rhs *= *temp;
      temp = AlgebraicGenerator::makePolynomial();
      temp->addMonomial(AlgebraicGenerator::makeMonomial(var4));
      if (!pos4) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }
      *rhs *= *temp;
      lhs->addMonomial(AlgebraicGenerator::makeMonomial(var1));
      if (!pos1) 
      { 
        *rhs *= -1; 
        *rhs += (Coefficient)1;
      }

      break;

    case eqtWeqXmXYZ:

      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();
      
      rhs->addMonomial(AlgebraicGenerator::makeMonomial(var2));
      if (!pos2) { *rhs *= -1; rhs->addMonomial(AlgebraicGenerator::makeMonomial()); }

      temp = AlgebraicGenerator::makePolynomial();
      temp->addMonomial(AlgebraicGenerator::makeMonomial(var3));
      if (!pos3) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }
      *rhs *= *temp;
      temp = AlgebraicGenerator::makePolynomial();
      temp->addMonomial(AlgebraicGenerator::makeMonomial(var4));
      if (!pos4) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }
      *rhs *= *temp;
      *rhs *= -1;
      rhs->addMonomial(AlgebraicGenerator::makeMonomial(var2));
      lhs->addMonomial(AlgebraicGenerator::makeMonomial(var1));
      if (!pos1) 
      { 
        *rhs *= -1; 
        *rhs += (Coefficient)1;
      }

      break;

    case eqtSeqXpVnWm2XWnV:
      
      lhs = AlgebraicGenerator::makePolynomial(var1,pos1);
      rhs = AlgebraicGenerator::makePolynomial(var2,pos2);
      temp3 = AlgebraicGenerator::makePolynomial(var3,pos3);
      temp3n = AlgebraicGenerator::makePolynomial(var3,!pos3);
      temp = AlgebraicGenerator::makePolynomial(var3,!pos3);
      temp4 = AlgebraicGenerator::makePolynomial(var4,pos4);
      temp4n = AlgebraicGenerator::makePolynomial(var4,!pos4);
      *temp3n *= *temp4;
      *temp3n *= (Coefficient)-2;
      temp3n->addMonomial(AlgebraicGenerator::makeMonomial());
      *temp4 *= *temp;
      *rhs *= *temp3n;
      *rhs += *temp4;

      break;

    case eqtYeqACpnAB:
      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon3 = AlgebraicGenerator::makeMonomial(var4);
      mon4 = AlgebraicGenerator::makeMonomial(var2,var4);
      mon5 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();
      if (pos2 && pos3 && pos4)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
      }  
      else if (pos2 && !pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon2->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
      }
      else if (!pos2 && pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var3);
        mon2->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
      }
      else if (!pos2 && !pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon6->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
      } 
      else if (pos2 && pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon6->setCoeff(-1);
        mon3->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
      }
      else if (pos2 && !pos3 && !pos4)
      {
        mon3->setCoeff(-1);
        mon2->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }  
      else if (!pos2 && pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon2->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
      }
      else if (!pos2 && !pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var3);
        mon6->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
      }
      else
      {
        Assert(0,"wrong boolean values given");
      }
     
      if (!pos1)
      {
        mon1->setCoeff(-1);
        lhs->addMonomial(mon1);
        lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
        lhs->addMonomial(mon1);
 

      break;

     case eqtYeqACpDmACD:

      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon3 = AlgebraicGenerator::makeMonomial(var4);
      mon4 = AlgebraicGenerator::makeMonomial(var2,var3,var4);
      mon5 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();

      if (pos2 && pos3 && pos4)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
      }  
      else if (pos2 && !pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon8 = AlgebraicGenerator::makeMonomial(var2,var4);
        mon8->setCoeff(-1);
        mon2->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var3);
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon8->setCoeff(-1);
        mon2->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && !pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4); 
        mon9 = AlgebraicGenerator::makeMonomial(var2,var4);
        mon6->setCoeff(-1);
        mon7->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon8);
        rhs->addMonomial(mon9);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
      } 
      else if (pos2 && pos3 && !pos4)
      {
        mon3->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }
      else if (pos2 && !pos3 && !pos4)
      {
        mon8 = AlgebraicGenerator::makeMonomial(var2,var4);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon8);
        rhs->addMonomial(mon5);
      }  
      else if (!pos2 && pos3 && !pos4)
      {
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon8);
        rhs->addMonomial(mon5);
      }
      else if (!pos2 && !pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon8 = AlgebraicGenerator::makeMonomial(var2,var4);
        mon6->setCoeff(-1);
        mon8->setCoeff(-1);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon8);
      }
      else
      {
        Assert(0,"wrong boolean values given");
      }
     
      if (!pos1)
      {
        mon1->setCoeff(-1);
        lhs->addMonomial(mon1);
        lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
        lhs->addMonomial(mon1);
 

      break;
     
    case eqt124:

      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2);
      mon3 = AlgebraicGenerator::makeMonomial(var3);
      mon4 = AlgebraicGenerator::makeMonomial(var4);
      mon5 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon6 = AlgebraicGenerator::makeMonomial(var2,var4);
      mon7 = AlgebraicGenerator::makeMonomial(var3,var4);
      mon8 = AlgebraicGenerator::makeMonomial(var2,var3,var4);
      mon9 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();

 
      if (( pos1 &&  pos2 &&  pos3 &&  pos4) ||
          (!pos1 && !pos2 &&  pos3 &&  pos4) ||
          (!pos1 &&  pos2 && !pos3 &&  pos4) ||
          (!pos1 &&  pos2 &&  pos3 && !pos4) ||
          (!pos1 && !pos2 && !pos3 && !pos4) ||
          ( pos1 && !pos2 && !pos3 &&  pos4) ||
          ( pos1 && !pos2 &&  pos3 && !pos4) ||
          ( pos1 &&  pos2 && !pos3 && !pos4) )
      {
        mon5->setCoeff(-2); 
        mon6->setCoeff(-2);
        mon7->setCoeff(-2);
        mon8->setCoeff(4); 
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);       
        rhs->addMonomial(mon8);
      }
      else 
      if ((!pos1 &&  pos2 &&  pos3 &&  pos4) ||
          ( pos1 && !pos2 &&  pos3 &&  pos4) ||
          ( pos1 &&  pos2 && !pos3 &&  pos4) ||
          ( pos1 &&  pos2 &&  pos3 && !pos4) ||
          (!pos1 && !pos2 && !pos3 &&  pos4) ||
          (!pos1 &&  pos2 && !pos3 && !pos4) ||
          (!pos1 && !pos2 &&  pos3 && !pos4) ||
          ( pos1 && !pos2 && !pos3 && !pos4) )
      {
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        mon5->setCoeff(2); 
        mon6->setCoeff(2);
        mon7->setCoeff(2);
        mon8->setCoeff(-4); 
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);       
        rhs->addMonomial(mon8); 
        rhs->addMonomial(mon9);
      }
      else
      {
        Assert(0,"wrong boolean values given");
      }
      
      lhs->addMonomial(mon1);
 

      break;
 
    case eqtDeqABpACmABC:

      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon3 = AlgebraicGenerator::makeMonomial(var2,var4);
      mon4 = AlgebraicGenerator::makeMonomial(var2,var3,var4);
      mon5 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();

      if (pos2 && pos3 && pos4)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
      }  
      else if (pos2 && !pos3 && pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon2->setCoeff(-1);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon2);
      }
      else if (pos2 && pos3 && !pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon3->setCoeff(-1);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon3);
      }

      else if (!pos2 && pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var3);
        mon7 = AlgebraicGenerator::makeMonomial(var4);
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4); 
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon8->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon8);
      }      
      else if (pos2 && !pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon4);
      }
      else if (!pos2 && !pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon4->setCoeff(-1);
        mon6->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var4);
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon4->setCoeff(-1);
        mon6->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && !pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon6->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon4);
      }
      else
      {
        Assert(0,"wrong boolean values given");
      }
      
      if (!pos1)
      {
        mon1->setCoeff(-1);
        lhs->addMonomial(mon1);
        lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
        lhs->addMonomial(mon1);

      break;
      
      
    case eqtXeqABpACpBCm2ABC:

      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon3 = AlgebraicGenerator::makeMonomial(var2,var4);
      mon4 = AlgebraicGenerator::makeMonomial(var3,var4);
      mon5 = AlgebraicGenerator::makeMonomial(var2,var3,var4);
      mon6 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();

      if (pos2 && pos3 && pos4)
      {
        mon5->setCoeff(-2);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      } 
      else if (pos2 && pos3 && !pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon8 = AlgebraicGenerator::makeMonomial(var3);
        mon5->setCoeff(2);
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (pos2 && !pos3 && pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon8 = AlgebraicGenerator::makeMonomial(var4);
        mon5->setCoeff(2);
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }   
      else if (!pos2 && pos3 && pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon8 = AlgebraicGenerator::makeMonomial(var4);
        mon5->setCoeff(2);
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }  
      else if (!pos2 && !pos3 && pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon8 = AlgebraicGenerator::makeMonomial(var3);
        mon5->setCoeff(-2);
        mon8->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && pos3 && !pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon8 = AlgebraicGenerator::makeMonomial(var4);
        mon5->setCoeff(-2);
        mon8->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
     else if (pos2 && !pos3 && !pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon8 = AlgebraicGenerator::makeMonomial(var4);
        mon5->setCoeff(-2);
        mon8->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && !pos3 && !pos4)
      {
        mon5->setCoeff(2);
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
      }

      else
      {
        Assert(0,"wrong boolean values given to type creation");
      }
 
      if (!pos1)
      {
        mon1->setCoeff(-1);
        lhs->addMonomial(mon1);
        lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
        lhs->addMonomial(mon1);
     
      
      break;
  
    case eqtZeqWXpVXm2WVX:
      
      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2);
      mon3 = AlgebraicGenerator::makeMonomial(var3);
      mon4 = AlgebraicGenerator::makeMonomial(var4);
      mon5 = AlgebraicGenerator::makeMonomial(var3,var4);
      mon6 = AlgebraicGenerator::makeMonomial();

      
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();

      if (pos3 xor pos4)
      {
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        mon5->setCoeff(2);
        rhs->addMonomial(mon6);
      }
      else
      {
        mon5->setCoeff(-2);
      }

     
      
      rhs->addMonomial(mon3);
      rhs->addMonomial(mon4);
      rhs->addMonomial(mon5);
 
      if (pos2)
        *rhs *= *mon2;
      else
      {
        PPolynomial temp = AlgebraicGenerator::makePolynomial();
        temp->addMonomial(mon2);
        *temp *= (Coefficient)-1;
        *temp += 1;
        *rhs *= *temp;
      }
      
      if (!pos1)
      {
        mon1->setCoeff(-1);
        lhs->addMonomial(mon1);
        lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
        lhs->addMonomial(mon1);
      
      
    
      break;


     case eqtCeqYnWYxorZ:
      
      lhs = AlgebraicGenerator::makePolynomial(var1,pos1);
      rhs = AlgebraicGenerator::makeXORPolynomial(var3,pos3,var4,pos4);
      temp1 = AlgebraicGenerator::makePolynomial(var2,!pos2);
      *rhs *= *temp1;
      temp2 = AlgebraicGenerator::makePolynomial(var3,pos3);
      *rhs *= *temp2;
      break;

     case eqtCeqWXYpnWnXY:

      lhs = AlgebraicGenerator::makePolynomial(var1,pos1);
      rhs = AlgebraicGenerator::makePolynomial(var2,pos2);
      temp2n = AlgebraicGenerator::makePolynomial(var2,!pos2);
      temp3 = AlgebraicGenerator::makePolynomial(var3,pos3);
      temp3n = AlgebraicGenerator::makePolynomial(var3,!pos3);
      temp4 = AlgebraicGenerator::makePolynomial(var4,pos4);
      *rhs *= *temp3;
      *rhs *= *temp4;
      *temp2n *= *temp3n;
      *temp2n *= *temp4;
      *rhs += *temp2n;

      break;

  
    case eqtABeq0:
    {
      PEquality a=boost::shared_dynamic_cast<Equality, SALiteral>(LogicalGenerator::makeBoolLiteral(var1,pos1));
      PEquality b=boost::shared_dynamic_cast<Equality, SALiteral>(LogicalGenerator::makeBoolLiteral(var2,pos2));    
      lhs=AlgebraicGenerator::makePolynomial();
      rhs=AlgebraicGenerator::makePolynomial();
      (*lhs)+=*(a->getPolynomialRepresentation());
      (*lhs)*=*(b->getPolynomialRepresentation());
      var3 = 0; var4 = 0;
      break;
    }      
    default:
      Assert(0,"wrong type given to equality creation");
     
      break;
  }    

  if ( ((type == eqtXeqAB) && (var2 == var3)) ||    
     ( (type != eqtXeqAB) && 
       ( (var1 == var2) ||
         (var1 == var3) ||
         (var1 == var4) ||
         (var2 == var3) ||
         (var2 == var4) ||
         (var3 == var4)   )  )  )
    type = Special;

  simplify();

}

/**
 * Constructor
 */  
TypedEquality::TypedEquality(TEqualityType inptype, Variable inpvar1, bool inppos1, Variable inpvar2, bool inppos2, Variable inpvar3, bool inppos3) : type(inptype), var1(inpvar1), var2(inpvar2), var3(inpvar3), pos1(inppos1), pos2(inppos2), pos3(inppos3), myMainVar(0)
{
  var4 = 0; var5 = 0;
  PMonomial mon1, mon2, mon3, mon4, mon5;
  switch (inptype)
  {

    case eqtXeqAB:
      
      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2);
      mon3 = AlgebraicGenerator::makeMonomial(var3);
      mon4 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon5 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial(); 
      lhs->addMonomial(mon1);

     if (!pos1 && !pos2 && !pos3)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
      } 
      else if (pos1 && !pos2 && !pos3)
      {
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }     
      else if (!pos1 && pos2 && !pos3)
      {
        mon2->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }     
      else if (pos1 && pos2 && !pos3)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
      }     
      else if (!pos1 && !pos2 && pos3)
      {
        mon3->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }     
      else if (pos1 && !pos2 && pos3)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
      }     
      else if (!pos1 && pos2 && pos3)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }     
      else if (pos1 && pos2 && pos3)
      {
        rhs->addMonomial(mon4);
      }      
      break;

    case eqt11m2:

      bool ok;
      sortFirstThreeVars(ok);
      
      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2);
      mon3 = AlgebraicGenerator::makeMonomial(var3);
      mon4 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon5 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial(); 
      lhs->addMonomial(mon1);

      if ((  pos1 &&  pos2 &&  pos3) ||
          ( !pos1 && !pos2 &&  pos3) ||
          ( !pos1 &&  pos2 && !pos3))
      {
        mon4->setCoeff(-2);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);        
      }
      else
      {
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(2);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }

      break;    

    
    default:
      Assert(0,"wrong type given to equality creation");
      break;
  }   
 
  if ( ((type == eqtXeqAB) && (var2 == var3)) ||    
     ( (type != eqtXeqAB) && 
        ((var1 == var2) ||
         (var1 == var3) ||
         (var2 == var3)) ) )
    type = Special;
  
  simplify();

}


TypedEquality::TypedEquality(const TypedEquality *eq)
{
  var1 = eq->getVar1();
  var2 = eq->getVar2();
  var3 = eq->getVar3();
  var4 = eq->getVar4();
  pos1 = eq->getPos1();
  pos2 = eq->getPos2();
  pos3 = eq->getPos3();
  pos4 = eq->getPos4();
  var5 = eq->getVar5();
  pos5 = eq->getPos5();
  lhs = eq->getLHS()->clone();
  rhs = eq->getRHS()->clone();
  type = eq->getEqType();
  myMainVar = eq->getMainVar();
}

// new methods for checking everything

bool TypedEquality::getYeqACpDmACD(Variable &x, bool &posx, Variable &a, bool &posa, Variable &c, bool &posc, Variable &d, bool &posd) const 
{
    if (type != eqtYeqACpDmACD) return false;
    x=var1; posx=pos1; a=var2; posa=pos2; c=var3; posc=pos3; d=var4; posd=pos4;
    return true;
}

bool TypedEquality::getXeqAB(Variable &x, bool &posx, Variable &a, bool &posa, Variable &b, bool &posb) const {
    if (type != eqtXeqAB) return false;
    x=var1; posx=pos1; a=var2; posa=pos2; b=var3; posb=pos3;
    return true;
}

bool TypedEquality::getXeqAB(long &x,long &a,long &b) const
{
    if (type != eqtXeqAB) return false;
    x=var1; a=var2; b=var3;
    return true;
}


bool TypedEquality::getOneOneMinusOne(long &x, long &a, long &b) const
{
  if ( (type != eqtXeqAB) || pos1 || pos2 || pos3 ) return false;
  x = var1; a = var2; b = var3;
  return true;
}

bool TypedEquality::getOneOneMinusTwo(long &x, long &a, long &b) const
{
    if (type != eqt11m2) return false;
    x = var1; a = var2; b = var3;
    return true;
}

bool TypedEquality::getOneOneMinusTwoWConst(long &x, long &a, long &b, bool &withconstant) const
{
  if (type != eqt11m2) return false;
  x = var1; a = var2; b = var3;
  if ( (pos1 && pos2 && pos3) || (pos1 && !pos2 && !pos3) || (!pos1 && pos2 && !pos3) || (!pos1 && !pos2 && pos3) ) withconstant = false;
  else withconstant = true;
  return true;
}

bool TypedEquality::getXeqABpACpBCm2ABC(Variable& x,bool&px,Variable& a,bool&pa,Variable& b,bool&pb,Variable& c,bool&pc) const
{
    if (type != eqtXeqABpACpBCm2ABC) return false;
    x = var1; a = var2; b = var3; c = var4;
    px=pos1; pa=pos2; pb=pos3; pc=pos4;
    return true;
}

bool TypedEquality::getYeqACpnAB(Variable& x,bool&px,Variable& a,bool&pa,Variable& c,bool&pc,Variable& b,bool&pb) const
{
    if (type != eqtYeqACpnAB) return false;
    x = var1; a = var2; c = var3; b = var4;
    px=pos1; pa=pos2; pc=pos3; pb=pos4;
    return true;
}

bool TypedEquality::getDeqABpACmABC(Variable& x,bool&px,Variable& a,bool&pa,Variable& b,bool&pb,Variable& c,bool&pc) const
{
  if (type != eqtDeqABpACmABC) return false;
  x = var1; a = var2; b = var3; c = var4;
  px=pos1; pa=pos2; pb=pos3; pc=pos4;
  return true;
}

bool TypedEquality::get124(Variable& x,Variable& a,Variable& b,Variable& c,bool&wc) const
{
  wc=true;
  if (type != eqt124) return false;
  x = var1; a = var2; b = var3; c = var4;
  if (( pos1 &&  pos2 &&  pos3 &&  pos4) ||
      (!pos1 && !pos2 &&  pos3 &&  pos4) ||
      (!pos1 &&  pos2 && !pos3 &&  pos4) ||
      (!pos1 &&  pos2 &&  pos3 && !pos4) ||
      (!pos1 && !pos2 && !pos3 && !pos4) ||
      ( pos1 && !pos2 && !pos3 &&  pos4) ||
      ( pos1 && !pos2 &&  pos3 && !pos4) ||
      ( pos1 &&  pos2 && !pos3 && !pos4) )
    wc = false;
  else
    wc=true;  
  return true;
}



/**
 * Printing
 */
std::ostream& TypedEquality::print(std::ostream& os, BooleanAlgebraicSolver *slv,bool print_as_dedobj) 
{
  if (!print_as_dedobj && (this->getId() > 0)) os << this->getId() << ": ";
  lhs->print(os, slv);
  os <<"=";
  rhs->print(os, slv); 
  os << " [type ";
  switch (type)
  {
    case eqtXeqAB: os << "XeqAB"; break;
    case eqtYeqACpDmACD: os << "YeqACpDmACD"; break;
    case eqtXeqABpACpBCm2ABC: os << "XeqABpACpBCm2ABC"; break;
    case eqt124: os << "eqt124"; break;
    case eqtDeqABpACmABC: os << "eqtDeqABpACmABC "; break;
    case Special: os << "Special"; break;
    case eqt11m2: os << "eqt11m2"; break;
    case eqtABeq0: os << "eqtABeq0"; break; 
    case eqtYeqACpnAB: os << "eqtYeqACpnAB"; break;
    case eqtXeqABC: os << "eqtXeqABC"; break;
    case eqtWeqXmXYZ: os << "eqtWeqXmXYZ"; break;
    case eqtSeqXpVnWm2XWnV: os << "eqtSeqXpVnWm2XWnV"; break;
    case eqtZeqWXpVXm2WVX: os << "eqtZeqWXpVXm2WVX"; break;
    case eqtCeqWXYpnWnXY: os << "eqtCeqWXYpnWnXY"; break;
    case eqtCeqXZmXYpnWYnZp2WXYnZ: os << "eqtCeqXZmXYpnWYnZp2WXYnZ"; break;
    case eqtCeqYnWYxorZ: os << "eqtCeqYnWYxorZ"; break;
    case eqtBackT2Result: os << "eqtBackT2Result"; break;
    case eqtBoothSubResult: os << "eqtBoothSubResult"; break;
    case eqtBoothSubResult2: os << "eqtBoothSubResult2"; break;
    case eqtVeqYZLS: os << "eqtVeqYZLS"; break;                       
    case eqtVeqYZnotLS: os << "eqtVeqYZnotLS"; break; 
    case eqtXORSum: os << "eqtXORSum"; break;
    case eqtXORSumWithLin: os << "eqtXORSumWithLin"; break;
    default: os << "Unknown "; break;
  }

  bool do_literals;
  do_literals = (type != Dummy1 && type != Special && type != eqtBoothSubResult2 && type != eqtBoothSubResult && type != eqtXORSum && type != eqtXORSumWithLin && type != eqtBackT2Result);
  
  if (do_literals)
  {
    os << " on literals ";
    if (!pos1) os << "!";
    if (slv)
      slv->printVar(os,var1);
    else
      os << "p" << var1;
    os << " ";
    if (!pos2) os << "!";
    if (slv)
      slv->printVar(os,var2);
    else
      os << "p" << var2;
    os << " ";
    if (type!=eqtABeq0 && var3)
    {
      if (!pos3) os << "!";
      if (slv)
        slv->printVar(os,var3);
      else
        os << "p" << var3;
      os << " ";
      if ((type != eqtXeqAB) && (type !=eqt11m2) && var4)
      {
        if (!pos4) os << "!";
        if (slv)
          slv->printVar(os,var4);
        else
          os << "p" << var4;
        os << " ";
      }
      if ( (type == eqtVeqYZLS || type == eqtCeqXZmXYpnWYnZp2WXYnZ || type == eqtBoothSubResult || type == Special || type == eqtVeqYZnotLS) && var5)
      {
        if (!pos5) os << "!";
        if (slv)
          slv->printVar(os,var5);
        else
          os << "p" << var5;
        os << " ";
      }
    }
  }
  os << "]";
  return os;
}


PVarList TypedEquality::getVariableList() const
{
  PVarList varList(new std::list<Variable>);

  if ( (type == Boolean) || (type == Special) || (type == LastType) || (type == eqtBoothSubResult2) || (type == eqtBoothSubResult) || (type == eqtXORSum) || (type==eqtXORSumWithLin) || (type == eqtBackT2Result))
  {
    lhs->getVarList(varList);
    rhs->getVarList(varList);
  }
  else
  {
    if (var1) varList->push_back(var1);
    if (var2 && (var2 != var1) ) varList->push_back(var2);
    if (var3 && (var3 != var1) && (var3 != var2) ) varList->push_back(var3);
    if (var4 && (var4 != var1) && (var4 != var2) && (var4 != var3) ) varList->push_back(var4);
    if (var5 && (var5 != var1) && (var5 != var2) && (var5 != var3) && (var5 != var4) ) varList->push_back(var5);
  }
  return varList;
}


/**
 * assigns values to variables
 */
AssignReturnType TypedEquality::assign(Variable var, int val)
{
  lhs->assign(var, val);
  rhs->assign(var, val);

  if ( (type != eqtXORSum) && (type != eqtXORSumWithLin) )
    type = Special;
  
  AssignReturnType result=this->simplify();
  return result;
}

/**
 * Cloning
 */
PSALiteral TypedEquality::clone() const
{
  PSALiteral res(new TypedEquality(this));
  return res;
}

AssignReturnType TypedEquality::substituteEqual(Variable x, Variable y)
{
  {
    if ((var1 != 0) && (var1 == x)) 
      var1 = y; 
    if ((var2 != 0) && (var2 == x)) 
      var2 = y;
    if ((var3 != 0) && (var3 == x)) 
      var3 = y;  
    if ((var4 != 0) && (var4 == x)) 
      var4 = y;
    if ((var5 != 0) && (var5 == x)) 
      var5 = y;
      
    if ((var1 != 0) && (var2 != 0))
    {
      if ( (var1 == var2) && (type != eqtXeqAB) && type != eqtBoothSubResult)  type=Special;
      else if (var3 != 0)
      {
        if ( ( (type != eqtXeqAB) && type != eqtBoothSubResult && (var1 == var3)) || (var2 == var3) )
          type = Special;
        else if (var4 != 0)
        {
          if ( type != eqtBoothSubResult && ((var1 == var4) || (var2 == var4)
              || (var3 == var4)))
            type = Special;
        }
      }
    }
  }
  
  if (type != Special && type != Dummy1 && type!=eqtABeq0 && type!=eqtBoothSubResult2 && type!=eqtBoothSubResult && type != eqtXORSum && type!=eqtXORSumWithLin && type!=eqtBackT2Result)
  {
    sortAndRecreatePolynomials();
  }
  else
  {
    lhs->substituteEqual(x, y);
    rhs->substituteEqual(x, y);
  }
  
  AssignReturnType result=this->simplify();
 
  if (type == eqtBoothSubResult)
  {
    Coefficient coeff = 0;
    this->getRHS()->occursLinear(this->getVar1(),coeff);

    if(std::abs(coeff) == 1)
    {
      *(this->getRHS()) -= *(this->getLHS());
      PMonomial myMonomial = (**(this->getLHS()->getBeginIterator()))->clone();
      myMonomial->substituteEqual(this->getLHS()->getVariable(),this->getVar1());
      myMonomial->setCoeff(-coeff);
      this->getRHS()->addMonomialWithCloning(myMonomial); 
      if(coeff > 0)
      {
        *myMonomial *= -1;
        *(this->getRHS()) *= -1;
      }
      *this->getLHS()-=(*(this->getLHS()->clone()));
      this->getLHS()->addMonomial(myMonomial);
    }
    else if(coeff == 0)
    {
      this->getLHS()->occursLinear(this->getVar1(),coeff);
      // equality contains no Var1
      if(coeff == 0)
      {
        var1 = var2;
        var2 = var3;
        var3 = var4;
        var4 = var5;
        var5 = 0;
      }
    }
  }
  return result;
};
  
AssignReturnType TypedEquality::substituteNonEqual(Variable x, Variable y)
{
  {
    if ((var1 != 0) && (var1 == x)) {var1 = y; pos1 = !pos1;}
    if ((var2 != 0) && (var2 == x)) {var2 = y; pos2 = !pos2;}
    if ((var3 != 0) && (var3 == x)) {var3 = y; pos3 = !pos3;}
    if ((var4 != 0) && (var4 == x)) {var4 = y; pos4 = !pos4;}
    if ((var4 != 0) && (var5 == x)) {var5 = y; pos4 = !pos4;}
 
    if ((var1 != 0) && (var2 != 0))
    {
      if (type != eqtBoothSubResult && (type!=eqtXeqAB) && (var1 == var2)) type=Special;
      else if (var3 != 0)
      {
        if ( ((type != eqtBoothSubResult && type!=eqtXeqAB)&&(var1 == var3)) || (var2 == var3) )
          type = Special;
        else if (var4 != 0)
        {
          if ( type != eqtBoothSubResult && ( (var1 == var4) || (var2 == var4)
              || (var3 == var4)))
            type = Special;
        }
      }
    
    }
  }
  
  if (type != Special && type != Dummy1 && type!=eqtABeq0 && type!=eqtBoothSubResult2 && type!=eqtBoothSubResult && type != eqtXORSum && type!=eqtXORSumWithLin && type != eqtBackT2Result)
  {
    sortAndRecreatePolynomials();
  }
  else
  {
    lhs->substituteNonEqual(x, y);
    rhs->substituteNonEqual(x, y);
  }
  
  AssignReturnType result=this->simplify();
  if (type == eqtBoothSubResult)
  {
    Coefficient coeff = 0;
    this->getRHS()->occursLinear(this->getVar1(),coeff);
    if(std::abs(coeff) == 1)
    {
      *(this->getRHS()) -= *(this->getLHS());
      PMonomial myMonomial = (**(this->getLHS()->getBeginIterator()))->clone();
      myMonomial->substituteEqual(this->getLHS()->getVariable(),this->getVar1());
      myMonomial->setCoeff(-coeff);
      this->getRHS()->addMonomialWithCloning(myMonomial); 
      if(coeff > 0)
      {
        *myMonomial *= -1;
        *(this->getRHS()) *= -1;
      }
      *this->getLHS()-=(*(this->getLHS()->clone()));
      this->getLHS()->addMonomial(myMonomial);
    }
    else if(coeff == 0)
    {
      this->getLHS()->occursLinear(this->getVar1(),coeff);
      // equality contains no Var1
      if(coeff == 0)
      {
        var1 = var2;
        var2 = var3;
        var3 = var4;
        var4 = var5;
        var5 = 0;
      }
    }
  }
  return result;  
};

AssignReturnType TypedEquality::substituteMonomial(PEquality t2Equality)
{
  if (t2Equality->isSecondType())
  {
    PMonomial left=**(t2Equality->getLHS()->getBeginIterator());
    PPolynomial quotient=rhs->getQuotient(left);
    if (quotient->getSize()!=0)
    {
      PPolynomial remainder=rhs->getRemainder(left);
      (*quotient) *= (* t2Equality->getRHS());
      (*remainder)+=(*quotient);
      this->rhs=PPolynomial(remainder);
      AssignReturnType result=this->simplify();
      return result;  
    };
  };
  return ART_Active;
};


/* - The left hand side of an equality does not contain a constant monomial.
   - The most common divisor of all monomials of equality is 1. 
   - poly1 and poly2 do not share equal monomials.
   - If an equality contains at least one non-constant monomial,
   then its left hand side contains the minimal monomial.
   - The coefficient of a monomial at the left hand side is positive.
*/
AssignReturnType TypedEquality::simplify()
{

  myIsBoolean=false; myIsFirstType=false; 
  myIsSatisfiable=false; myIsUnsatisfiable=false; 
  // Copy everything to rhs
  (*rhs)-=(*lhs);
  
  lhs=AlgebraicGenerator::makePolynomial();
  //Checking for Trivial Satisfiability
  if (!rhs->getSize())
  {
    myIsSatisfiable=true;
    return ART_Satisfiable;
  }; 
  //Checking for Trivial Unsatisfiability
  if (rhs->isConstant())
  {
    myIsUnsatisfiable=true;
    return ART_Unsatisfiable;
  }; 

  Variable v1,v2,v3;
  bool p1,p2,p3;
  
  //Commented -- new type parsing
  if ( (type != eqtXORSum) && (type != eqtXORSumWithLin) )
  {
    if (rhs->parseABeq0(v1, p1, v2, p2))
    {
      var1=v1; var2=v2; var3 = 0; var4 = 0; var5 = 0; 
      pos1=p1; pos2=p2;
      type=eqtABeq0;
    }
    else if (rhs->parseXeqAnotX(v1,p1,v2,p2,v3,p3))
    {
      var1=v1; var2=v2; var3=v3; var4 = 0; var5 = 0;
      pos1=p1; pos2=p2; pos3=p3;
      type=eqtXeqAB;
    }
    else  if (rhs->parseANDRepresentation(v1,p1,v2,p2,v3,p3))
    {
      if ((v1!=v2) && (v2!=v3) && (v3!=v1))
      {
        var1=v1; var2=v2; var3=v3; var4 = 0; var5 = 0;
        pos1=p1; pos2=p2; pos3=p3;
        type=eqtXeqAB;
      }
    }
    else    
      if (rhs->xorTypeNormalize(v1,p1,v2,p2,v3,p3))
      {
        var1=v1; var2=v2; var3=v3; var4 = 0; var5 = 0;
        pos1=p1; pos2=p2; pos3=p3;
        type=eqt11m2;
      }
  }
  // 0=x+y-2xy --> 0=-x+y
  // 0=1-x-y+2xy --> 0=1-x-y
  rhs->squareOfSumNormalize();
  //Setting monomial with minimal degree and minimal coefficient to left hand side
  PMonomialIterator right=rhs->getBeginIterator();    
  if ((**right)->isConstant()) ++(*right);
  PMonomial min;
  Coefficient c=10000; //any number
  int cur_degree=rhs->getDegree()+100; //big number
  for (;(!right->equals(*(rhs->getEndIterator())));++(*right))
  {
    if (cur_degree<(**right)->getSize()) break;
    if (cur_degree>(**right)->getSize())
    {
      min=(**right);
      c=abs((**right)->getCoeff());
      cur_degree=(**right)->getSize();
    }
    else
    {
      if (c>abs((**right)->getCoeff())) 
      {
        min=**right;
        c=abs((**right)->getCoeff());
      };
    };
  };
  min=min->clone();
  (*min)*=(-1);
  lhs->addMonomial(min);
  rhs->addMonomial(min);
  this->normalize();

  //Checking for boolean and unsat like 2x=3
  if (lhs->isVariable() && rhs->isConstant())
  { 
    if ((rhs->getFirstConstant()==0) || (rhs->getFirstConstant()==lhs->getFirstConstant()))
    {
      myIsBoolean=true; myIsFirstType=true;
      return ART_Active;
    };
    myIsUnsatisfiable=true;
    return ART_Unsatisfiable;     
  };
  //Checking for first type
  if (lhs->isVariable() && rhs->isVariable())
  {
    if (lhs->getFirstConstant()==rhs->getFirstConstant())
    {
      myIsFirstType=true;
      return ART_Active;
    }; 
    return ART_Active;
  };
  if (lhs->isVariable() && (rhs->getSize()==2))
  {
    PMonomialIterator rightSideMonoms=rhs->getBeginIterator();
    if ((**rightSideMonoms)->isConstant() && (**rightSideMonoms)->getConstant()==lhs->getFirstConstant())        
    {
      ++(*rightSideMonoms);
      if ((**rightSideMonoms)->isVariable() && (**rightSideMonoms)->getCoeff()==-lhs->getFirstConstant())
      {
	myIsFirstType=true;
	return ART_Active;
      };       
    };
  };
  //Checking for 2S=1+2T
  if ((lhs->getFirstConstant() % 2 == 0) && (rhs->isObviousOdd()))
  {
    myIsUnsatisfiable=true;
    return ART_Unsatisfiable;     
  };
  return ART_Active;    
  
};


Coefficient TypedEquality::mcd(Coefficient a, Coefficient b)
{
  Coefficient c;
  a=abs(a); b=abs(b);
  if (a > b)
  {
    c=a; a=b; b=c;
  }; 
  while (a!=0)
  {
    c=b % a; b=a; a=c;    
  };
  return b;
}

void TypedEquality::normalize()
{
  if (!myIsSatisfiable && !myIsUnsatisfiable)
  {
    PMonomialIterator left=lhs->getBeginIterator(), right;
    Coefficient leftmcd=0, rightmcd=0,wholemcd=1;
    bool ok = false;
    leftmcd=(**left)->getCoeff();
    if (leftmcd == 1) ok = true;
     ++(*left);
    if (!ok)
    {
      PMonomialIterator right=rhs->getBeginIterator();
      Coefficient rightmcd=0;    
      while (!right->equals(*(rhs->getEndIterator())))
      {
        rightmcd=this->mcd(rightmcd, (**right)->getCoeff());
        if (rightmcd == 1) break;
        ++(*right);
      }; 
      wholemcd=this->mcd(leftmcd, rightmcd);
    }
    if (lhs->getFirstConstant()<0)
      wholemcd=-wholemcd;
    if (wholemcd != 1)
    {
      left=lhs->getBeginIterator();
      while (!left->equals(*(lhs->getEndIterator())))
      {
        (**left)->setCoeff((**left)->getCoeff()/wholemcd);
        ++(*left);
      };
      right=rhs->getBeginIterator();
      while (!right->equals(*(rhs->getEndIterator())))
      {
        (**right)->setCoeff((**right)->getCoeff()/wholemcd);
        rightmcd=this->mcd(rightmcd, (**right)->getCoeff());
        ++(*right);
      };
    }
  };
};

PEquality TypedEquality::substituteVarWithPoly(Variable var, PPolynomial poly) const
{
  return AlgebraicGenerator::makeEqualityWithCloning(this->getLHS()->substituteVarWithPoly(var,poly),
      this->getRHS()->substituteVarWithPoly(var,poly));
}

Variable TypedEquality::getBooleanVariable()
{
  if (myIsBoolean)
  {
    return lhs->getVariable();
  }
  return (Variable)0;
}; 
  
bool TypedEquality::getBooleanSign()
{
  if (myIsBoolean)
  {
    return (rhs->getFirstConstant()==1);
  }
  return false;  
}; 

bool TypedEquality::operator == (SALiteral& literal) const
{
  try
  {
    Equality& equality=dynamic_cast<Equality&>(literal);
    return ((*lhs==*(equality.getLHS())) && (*rhs==*(equality.getRHS())));
  }
  catch (std::bad_cast &bc)  
  {
    return false;
  };    
};  
 
bool TypedEquality::operator < (SALiteral& literal) const
{
  try
  {
    Equality& equality=dynamic_cast<Equality&>(literal);
    switch (lhs->compare(*(equality.getLHS())))
    {
      case 1: return true; break;
      case -1: return false; break;
      default: return ( (rhs->compare(*(equality.getRHS()))) == 1);
    }
  }
  catch (std::bad_cast &bc)  
  {
    return false;
  };    
  return false;

};

PEquality TypedEquality::negation() const
{
  PPolynomial newRHS=this->rhs->clone();
  (*newRHS)*=(-1);
  newRHS->addMonomial(AlgebraicGenerator::makeMonomial());
  return (AlgebraicGenerator::createEquality(lhs->clone(), newRHS));
};


PPolynomial TypedEquality::getPolynomialRepresentation()
{
  PPolynomial result=AlgebraicGenerator::makePolynomial();
  if (isBoolean())
  {
    result->addMonomial(AlgebraicGenerator::makeMonomial(getBooleanVariable())); 
    if (!getBooleanSign())
    {
      (*result) *= (-1);
      result->addMonomial(AlgebraicGenerator::makeMonomial()); 
    };
  };
  return result;
};
 
bool TypedEquality::getLHSVariable(Variable &x) const
{
  if (lhs->isVariable())
  {
    x = lhs->getVariable();
    return true;
  }
  else
    return false;
}

void TypedEquality::sortFiveVars(bool &ok)
{ 
  if (var1 > var2)
  {
    Tools::switchVars(var2,pos2,var1,pos1);
    ok=false;
  }
  if (var2 > var3)
  {
    Tools::switchVars(var3,pos3,var2,pos2);
    ok=false;
  }
  if (var3 > var4)
  {
    Tools::switchVars(var3,pos3,var4,pos4);
    ok=false;
  }
  if (var4 > var5)
  {
    Tools::switchVars(var5,pos5,var4,pos4);
    ok=false;
  }
  if (var1 > var2)
    Tools::switchVars(var2,pos2,var1,pos1);
  if (var2 > var3)
    Tools::switchVars(var3,pos3,var2,pos2);
  if (var3 > var4)
    Tools::switchVars(var3,pos3,var4,pos4);
  if (var1 > var2)
    Tools::switchVars(var2,pos2,var1,pos1);
  if (var2 > var3)
    Tools::switchVars(var2,pos2,var3,pos3);
  if (var1 > var2)
    Tools::switchVars(var1,pos1,var2,pos2);

}

void TypedEquality::sortFourVars(bool &ok)
{ 
  if (var1 > var2)
  {
    Tools::switchVars(var2,pos2,var1,pos1);
    ok=false;
  }
  if (var2 > var3)
  {
    Tools::switchVars(var3,pos3,var2,pos2);
    ok=false;
  }
  if (var3 > var4)
  {
    Tools::switchVars(var3,pos3,var4,pos4);
    ok=false;
  }
  if (var1 > var2)
    Tools::switchVars(var2,pos2,var1,pos1);
  if (var2 > var3)
    Tools::switchVars(var3,pos3,var2,pos2);
  if (var1 > var2)
    Tools::switchVars(var2,pos2,var1,pos1);
}

void TypedEquality::sortThreeVars(bool &ok)
{ 
  if (var2 > var3)
  {
    Tools::switchVars(var2,pos2,var3,pos3);
    ok=false;
  }
  if (var3 > var4)
  {
    Tools::switchVars(var3,pos3,var4,pos4);
    ok=false;
  }
  if (var2 > var3)
    Tools::switchVars(var2,pos2,var3,pos3);
}

void TypedEquality::sortFirstThreeVars(bool &ok)
{
  if (var1 > var2)
  {
    Tools::switchVars(var2,pos2,var1,pos1);
    ok=false;
  }
  if (var2 > var3)
  {
    Tools::switchVars(var3,pos3,var2,pos2);
    ok=false;
  }
  if (var1 > var2)
    Tools::switchVars(var2,pos2,var1,pos1);
}

void TypedEquality::sortTwoVars(bool &ok)
{
  if (var2 > var3)
  {
    Tools::switchVars(var2,pos2,var3,pos3);
    ok=false;
  }
}

void TypedEquality::sortAndRecreatePolynomials()
{

  bool ok = true;
  
  // Reorder variables if possible
  
  switch (type)
  {
    case eqtYeqACpDmACD:
    case eqtXeqAB:
      sortTwoVars(ok);
      break;

    case eqtXeqABpACpBCm2ABC:
      sortThreeVars(ok);
      break;

    case eqt124:
      sortFourVars(ok);
      break;

    case eqt11m2:
      sortFirstThreeVars(ok);
      
    default:
      break;
  }

  PMonomial mon1, mon2, mon3, mon4, mon5, mon6, mon7, mon8, mon9, mon;
  PPolynomial temp,temp1,temp2,temp2n,temp3,temp3n,temp4,temp4n,t1;

  
  switch (type)
  {   

    case eqtVeqYZnotLS:

      
    case eqtVeqYZLS:

      lhs = AlgebraicGenerator::makePolynomial(var1,pos1);
      rhs = AlgebraicGenerator::makePolynomial(var4,pos4);
 
      mon = AlgebraicGenerator::makeMonomial(var5);
      if (pos5)
        *rhs *= *mon;
      else
      {
        t1 = rhs->clone();
        *t1 *= *mon;
        *rhs *= -1;
        *rhs += *t1;
      }

      if (type==eqtVeqYZnotLS)
      {
        type = eqtVeqYZLS;
        *rhs *= -1;
        *rhs += 1;
      }
      
      mon = AlgebraicGenerator::makeMonomial(var2);
      if (pos2)
        *rhs *= *mon;
      else
      {
        t1 = rhs->clone();
        *t1 *= *mon;
        *rhs *= -1;
        *rhs += *t1;
      }

      mon = AlgebraicGenerator::makeMonomial(var3);
      if (pos3)
        *rhs *= *mon;
      else
      {
        t1 = rhs->clone();
        *t1 *= *mon;
        *rhs *= -1;
        *rhs += *t1;
      }
      *rhs *= -1;
      break;

    case eqtCeqXZmXYpnWYnZp2WXYnZ:

      lhs = AlgebraicGenerator::makePolynomial(var1,pos1);
      rhs = AlgebraicGenerator::makeXORPolynomial(var4,pos4,var5,pos5);
      
      temp1 = AlgebraicGenerator::makePolynomial(var3,pos3);
      temp3 = AlgebraicGenerator::makePolynomial(var2,pos2);
      temp3n = AlgebraicGenerator::makePolynomial(var2,!pos2);
      temp2 = AlgebraicGenerator::makePolynomial(var2,!pos2);
      temp4 = AlgebraicGenerator::makePolynomial(var4,pos4);
      temp4n = AlgebraicGenerator::makePolynomial(var4,!pos4);
      *temp3n *= *temp4;
      *temp3n *= (Coefficient)-2;
      temp3n->addMonomial(AlgebraicGenerator::makeMonomial());
      *temp4 *= *temp2;
      *temp1 *= *temp3n;
      *temp1 += *temp4;
     
      *rhs *= *temp1;
      break;


    case eqtXeqABC:

      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();
      
      rhs->addMonomial(AlgebraicGenerator::makeMonomial(var2));
      if (!pos2) { *rhs *= -1; rhs->addMonomial(AlgebraicGenerator::makeMonomial()); }

      temp = AlgebraicGenerator::makePolynomial();
      temp->addMonomial(AlgebraicGenerator::makeMonomial(var3));
      if (!pos3) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }

      *rhs *= *temp;

      temp = AlgebraicGenerator::makePolynomial();
      temp->addMonomial(AlgebraicGenerator::makeMonomial(var4));
      if (!pos4) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }

      *rhs *= *temp;
 
      lhs->addMonomial(AlgebraicGenerator::makeMonomial(var1));
      if (!pos1) 
      { 
        *rhs *= -1; 
        *rhs += (Coefficient)1;
      }
      break;
 
    case eqtWeqXmXYZ:

      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();
      
      rhs->addMonomial(AlgebraicGenerator::makeMonomial(var2));
      if (!pos2) { *rhs *= -1; rhs->addMonomial(AlgebraicGenerator::makeMonomial()); }

      temp = AlgebraicGenerator::makePolynomial();
      temp->addMonomial(AlgebraicGenerator::makeMonomial(var3));
      if (!pos3) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }
      *rhs *= *temp;
      temp = AlgebraicGenerator::makePolynomial();
      temp->addMonomial(AlgebraicGenerator::makeMonomial(var4));
      if (!pos4) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }

      *rhs *= *temp;
      
      *rhs *= -1;
      rhs->addMonomial(AlgebraicGenerator::makeMonomial(var2));
      
      lhs->addMonomial(AlgebraicGenerator::makeMonomial(var1));
      if (!pos1) 
      { 
        *rhs *= -1; 
        *rhs += (Coefficient)1;
      }

      break;

  
      
    case eqtYeqACpnAB:

      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon3 = AlgebraicGenerator::makeMonomial(var4);
      mon4 = AlgebraicGenerator::makeMonomial(var2,var4);
      mon5 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();


      if (pos2 && pos3 && pos4)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
      }  
      else if (pos2 && !pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon2->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
      }
      else if (!pos2 && pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var3);
        mon2->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
      }
      else if (!pos2 && !pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon6->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
      } 
      else if (pos2 && pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon6->setCoeff(-1);
        mon3->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
      }
      else if (pos2 && !pos3 && !pos4)
      {
        mon3->setCoeff(-1);
        mon2->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }  
      else if (!pos2 && pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon2->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
      }
      else if (!pos2 && !pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var3);
        mon6->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
      }
      else
      {
        Assert(0,"wrong boolean values given");
      }

      if (!pos1)
      {
        mon1->setCoeff(-1);
        lhs->addMonomial(mon1);
        lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
        lhs->addMonomial(mon1);
 

      break;

    case eqtSeqXpVnWm2XWnV:
      
      lhs = AlgebraicGenerator::makePolynomial(var1,pos1);
      rhs = AlgebraicGenerator::makePolynomial(var2,pos2);
      temp3 = AlgebraicGenerator::makePolynomial(var3,pos3);
      temp3n = AlgebraicGenerator::makePolynomial(var3,!pos3);
      temp = AlgebraicGenerator::makePolynomial(var3,!pos3);
      temp4 = AlgebraicGenerator::makePolynomial(var4,pos4);
      temp4n = AlgebraicGenerator::makePolynomial(var4,!pos4);
      *temp3n *= *temp4;
      *temp3n *= (Coefficient)-2;
      temp3n->addMonomial(AlgebraicGenerator::makeMonomial());
      *temp4 *= *temp;
      *rhs *= *temp3n;
      *rhs += *temp4;
      
      break;

        
    case eqtYeqACpDmACD:

      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon3 = AlgebraicGenerator::makeMonomial(var4);
      mon4 = AlgebraicGenerator::makeMonomial(var2,var3,var4);
      mon5 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();

      if (pos2 && pos3 && pos4)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
      }  
      else if (pos2 && !pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon8 = AlgebraicGenerator::makeMonomial(var2,var4);
        mon8->setCoeff(-1);
        mon2->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var3);
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon8->setCoeff(-1);
        mon2->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && !pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4); 
        mon9 = AlgebraicGenerator::makeMonomial(var2,var4);
        mon6->setCoeff(-1);
        mon7->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon8);
        rhs->addMonomial(mon9);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
      } 
      else if (pos2 && pos3 && !pos4)
      {
        mon3->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }
      else if (pos2 && !pos3 && !pos4)
      {
        mon8 = AlgebraicGenerator::makeMonomial(var2,var4);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon8);
        rhs->addMonomial(mon5);
      }  
      else if (!pos2 && pos3 && !pos4)
      {
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon8);
        rhs->addMonomial(mon5);
      }
      else if (!pos2 && !pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon8 = AlgebraicGenerator::makeMonomial(var2,var4);
        mon6->setCoeff(-1);
        mon8->setCoeff(-1);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon8);
      }
      else
      {
        Assert(0,"wrong boolean values given");
      }
      if (!pos1)
      {
        mon1->setCoeff(-1);
        lhs->addMonomial(mon1);
        lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
        lhs->addMonomial(mon1);
 

      break;

      
    case eqt124:

      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2);
      mon3 = AlgebraicGenerator::makeMonomial(var3);
      mon4 = AlgebraicGenerator::makeMonomial(var4);
      mon5 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon6 = AlgebraicGenerator::makeMonomial(var2,var4);
      mon7 = AlgebraicGenerator::makeMonomial(var3,var4);
      mon8 = AlgebraicGenerator::makeMonomial(var2,var3,var4);
      mon9 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();

 
      if (( pos1 &&  pos2 &&  pos3 &&  pos4) ||
          (!pos1 && !pos2 &&  pos3 &&  pos4) ||
          (!pos1 &&  pos2 && !pos3 &&  pos4) ||
          (!pos1 &&  pos2 &&  pos3 && !pos4) ||
          (!pos1 && !pos2 && !pos3 && !pos4) ||
          ( pos1 && !pos2 && !pos3 &&  pos4) ||
          ( pos1 && !pos2 &&  pos3 && !pos4) ||
          ( pos1 &&  pos2 && !pos3 && !pos4) )
      {
        mon5->setCoeff(-2); 
        mon6->setCoeff(-2);
        mon7->setCoeff(-2);
        mon8->setCoeff(4); 
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);       
        rhs->addMonomial(mon8);
      }
      else 
      if ((!pos1 &&  pos2 &&  pos3 &&  pos4) ||
          ( pos1 && !pos2 &&  pos3 &&  pos4) ||
          ( pos1 &&  pos2 && !pos3 &&  pos4) ||
          ( pos1 &&  pos2 &&  pos3 && !pos4) ||
          (!pos1 && !pos2 && !pos3 &&  pos4) ||
          (!pos1 &&  pos2 && !pos3 && !pos4) ||
          (!pos1 && !pos2 &&  pos3 && !pos4) ||
          ( pos1 && !pos2 && !pos3 && !pos4) )
      {
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        mon5->setCoeff(2); 
        mon6->setCoeff(2);
        mon7->setCoeff(2);
        mon8->setCoeff(-4); 
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);       
        rhs->addMonomial(mon8); 
        rhs->addMonomial(mon9);
      }
      else
      {
        Assert(0,"wrong boolean values given");
      }
      
      lhs->addMonomial(mon1);
 

      break;
 
    case eqtDeqABpACmABC:

      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon3 = AlgebraicGenerator::makeMonomial(var2,var4);
      mon4 = AlgebraicGenerator::makeMonomial(var2,var3,var4);

      mon5 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();

      if (pos2 && pos3 && pos4)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
      }  
      else if (pos2 && !pos3 && pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon2->setCoeff(-1);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon2);
      }
      else if (pos2 && pos3 && !pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon3->setCoeff(-1);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon3);
      }
      else if (!pos2 && pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var3);
        mon7 = AlgebraicGenerator::makeMonomial(var4);
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4); 
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon8->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon8);
      }      
      else if (pos2 && !pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon4);
      }
      else if (!pos2 && !pos3 && pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon4->setCoeff(-1);
        mon6->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var4);
        mon8 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon4->setCoeff(-1);
        mon6->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && !pos3 && !pos4)
      {
        mon6 = AlgebraicGenerator::makeMonomial(var2);
        mon7 = AlgebraicGenerator::makeMonomial(var3,var4);
        mon6->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon4);
      }
      else
      {
        Assert(0,"wrong boolean values given");
      }
      
      if (!pos1)
      {
        mon1->setCoeff(-1);
        lhs->addMonomial(mon1);
        lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
        lhs->addMonomial(mon1);

      break;
      
      
    case eqtXeqABpACpBCm2ABC:

      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon3 = AlgebraicGenerator::makeMonomial(var2,var4);
      mon4 = AlgebraicGenerator::makeMonomial(var3,var4);
      mon5 = AlgebraicGenerator::makeMonomial(var2,var3,var4);
      mon6 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();

      if (pos2 && pos3 && pos4)
      {
        mon5->setCoeff(-2);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      } 
      else if (pos2 && pos3 && !pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon8 = AlgebraicGenerator::makeMonomial(var3);
        mon5->setCoeff(2);
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (pos2 && !pos3 && pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon8 = AlgebraicGenerator::makeMonomial(var4);
        mon5->setCoeff(2);
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && pos3 && pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon8 = AlgebraicGenerator::makeMonomial(var4);
        mon5->setCoeff(2);
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && !pos3 && pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon8 = AlgebraicGenerator::makeMonomial(var3);
        mon5->setCoeff(-2);
        mon8->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && pos3 && !pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var2);
        mon8 = AlgebraicGenerator::makeMonomial(var4);
        mon5->setCoeff(-2);
        mon8->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
     else if (pos2 && !pos3 && !pos4)
      {
        mon7 = AlgebraicGenerator::makeMonomial(var3);
        mon8 = AlgebraicGenerator::makeMonomial(var4);
        mon5->setCoeff(-2);
        mon8->setCoeff(-1);
        mon7->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
        rhs->addMonomial(mon7);
        rhs->addMonomial(mon8);
      }
      else if (!pos2 && !pos3 && !pos4)
      {
        mon5->setCoeff(2);
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
        rhs->addMonomial(mon6);
      }

      else
      {
        Assert(0,"wrong boolean values given to type creation");
      }
 
      if (!pos1)
      {
        mon1->setCoeff(-1);
        lhs->addMonomial(mon1);
        lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
        lhs->addMonomial(mon1);
     
      
      break;
   
 
    case eqtXeqAB:
      
      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2);
      mon3 = AlgebraicGenerator::makeMonomial(var3);
      mon4 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon5 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial(); 
      lhs->addMonomial(mon1);
 
     if (!pos1 && !pos2 && !pos3)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
      } 
      else if (pos1 && !pos2 && !pos3)
      {
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }     
      else if (!pos1 && pos2 && !pos3)
      {
        mon2->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }     
      else if (pos1 && pos2 && !pos3)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon4);
      }     
      else if (!pos1 && !pos2 && pos3)
      {
        mon3->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }     
      else if (pos1 && !pos2 && pos3)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
      }     
      else if (!pos1 && pos2 && pos3)
      {
        mon4->setCoeff(-1);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }     
      else if (pos1 && pos2 && pos3)
      {
        rhs->addMonomial(mon4);
      }      
      break;
 
    case eqt11m2:

      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2);
      mon3 = AlgebraicGenerator::makeMonomial(var3);
      mon4 = AlgebraicGenerator::makeMonomial(var2,var3);
      mon5 = AlgebraicGenerator::makeMonomial();
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial(); 
      lhs->addMonomial(mon1);

      if ((  pos1 &&  pos2 &&  pos3) ||
          ( !pos1 && !pos2 &&  pos3) ||
          ( !pos1 &&  pos2 && !pos3) ||
          (  pos1 && !pos2 && !pos3))
      {
        mon4->setCoeff(-2);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);        
      }
      else
      {
        mon2->setCoeff(-1);
        mon3->setCoeff(-1);
        mon4->setCoeff(2);
        rhs->addMonomial(mon2);
        rhs->addMonomial(mon3);
        rhs->addMonomial(mon4);
        rhs->addMonomial(mon5);
      }
      break;

    case eqtZeqWXpVXm2WVX:

      
      mon1 = AlgebraicGenerator::makeMonomial(var1);
      mon2 = AlgebraicGenerator::makeMonomial(var2);
      mon3 = AlgebraicGenerator::makeMonomial(var3);
      mon4 = AlgebraicGenerator::makeMonomial(var4);
      mon5 = AlgebraicGenerator::makeMonomial(var3,var4);
      mon6 = AlgebraicGenerator::makeMonomial();

      
      lhs = AlgebraicGenerator::makePolynomial();
      rhs = AlgebraicGenerator::makePolynomial();

      if (pos3 xor pos4)
      {
        mon3->setCoeff(-1);
        mon4->setCoeff(-1);
        mon5->setCoeff(2);
        rhs->addMonomial(mon6);
      }
      else
      {
        mon5->setCoeff(-2);
      }
 
      rhs->addMonomial(mon3);
      rhs->addMonomial(mon4);
      rhs->addMonomial(mon5);
 
      if (pos2)
        *rhs *= *mon2;
      else
      {
        PPolynomial temp = AlgebraicGenerator::makePolynomial();
        temp->addMonomial(mon2);
        *temp *= (Coefficient)-1;
        *temp += 1;
        *rhs *= *temp;
      }

      if (!pos1)
      {
        mon1->setCoeff(-1);
        lhs->addMonomial(mon1);
        lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
        lhs->addMonomial(mon1);

      

      break;
 
    case eqtCeqYnWYxorZ:
      
      lhs = AlgebraicGenerator::makePolynomial(var1,pos1);
      rhs = AlgebraicGenerator::makeXORPolynomial(var3,pos3,var4,pos4);
      temp1 = AlgebraicGenerator::makePolynomial(var2,!pos2);
      *rhs *= *temp1;
      temp2 = AlgebraicGenerator::makePolynomial(var3,pos3);
      *rhs *= *temp2;
      break;

     case eqtCeqWXYpnWnXY:

      lhs = AlgebraicGenerator::makePolynomial(var1,pos1);
      rhs = AlgebraicGenerator::makePolynomial(var2,pos2);
      temp2n = AlgebraicGenerator::makePolynomial(var2,!pos2);
      temp3 = AlgebraicGenerator::makePolynomial(var3,pos3);
      temp3n = AlgebraicGenerator::makePolynomial(var3,!pos3);
      temp4 = AlgebraicGenerator::makePolynomial(var4,pos4);
      *rhs *= *temp3;
      *rhs *= *temp4;
      *temp2n *= *temp3n;
      *temp2n *= *temp4;
      *rhs += *temp2n;

      break;

    default:
      Assert(0,"wrong type given to equality creation");
     
      break;
  }    
 
  simplify();

}

bool TypedEquality::isBoothSubSubject(Variable var,Coefficient &coeff,PPolynomial &poly) const
{
  if (lhs->occursLinear(var,coeff))
  {
    if ( (type != eqtBoothSubResult)
        && (type != eqtBackT2Result)
        && (type != eqtCeqWXYpnWnXY)
        && (type != eqtZeqWXpVXm2WVX)
        && (type != eqtYeqACpDmACD)
        && (type != eqtCeqXZmXYpnWYnZp2WXYnZ)
        && (rhs->getDegree() > 1)
        && (type != eqt11m2)
        && (type != eqtVeqYZLS)
        && (type != eqtVeqYZnotLS)
        && (type != eqtXeqAB)
        && (type != eqtBoothSubResult2)
        ) 
      return false;
    
    poly = rhs->clone();
    return true;
  }
  else
  {
    if(type == eqtBoothSubResult && this->getVar2() != 0)
    {
      return false;
    }
    
    if (type == eqt11m2)
    {
      poly = lhs->clone();
      *poly -= *rhs;
      PMonomial mon = AlgebraicGenerator::makeMonomial(var);
      mon->setCoeff(1);
      poly->addMonomial(mon);
      coeff = 1;
      return true;
    }
  }
  
  if ((var1 == var || type == Special
        || type == eqtBackT2Result
        ) 
      && rhs->occursLinear(var,coeff))
  {
    poly = lhs->clone();
    *poly -= *rhs;
    PMonomial mon = AlgebraicGenerator::makeMonomial(var);
    mon->setCoeff(coeff);
    poly->addMonomial(mon);
    return true;
  }
  return false;
}
