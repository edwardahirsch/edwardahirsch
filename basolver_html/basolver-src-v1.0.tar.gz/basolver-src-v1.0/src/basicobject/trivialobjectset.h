#ifndef __TRIVIALOBJECTSET_H__
#define __TRIVIALOBJECTSET_H__

#include "../indexing/abstract/objectindex.h"
#include "../misc/tracer.h"
#include "../misc/assert.h"
#include "../backtrack/simplelogentry.h"
#include "../backtrack/log.h"
#include "objectset.h"
#include "../general/solver.h"

/**
 * @file trivialobjectset.h
 * @brief Contains the TrivialObjectSet template.
 */

/**
 * This class implements the set as a simple list and
 * keeps no indices on it.
 */
  template <class T>
  class TrivialObjectSet : public ObjectSet<T>
  {
  public:

    /**
     * typedef for the smart pointer on this template's base class
     */
   typedef boost::shared_ptr<T> PT;
    /**
     * typedef for \ref IndexElement on this template's base class
     */
    typedef IndexElement<T> IE;
    /**
     * typedef for the smart pointer on \ref IndexElement on this template's
     * base class
     */
    typedef boost::shared_ptr<IE> PIE;
    /**
     * typedef for \ref SimpleObjectIndex on this template's base class
     */
    typedef SimpleObjectIndex<T> TIndex;
    /**
     * typedef for the smart pointer on \ref SimpleObjectIndex 
     * on this template's base class
     */
    typedef boost::shared_ptr<TIndex> PTIndex;
    /**
     * typedef for a list of smart pointers on this template's base class
     */ 
    typedef std::list<boost::shared_ptr<T> > TList;
    
    /// \ref TinyIndexElement on the base class
    typedef TinyIndexElement<T> TIE;

    /// smart pointer for \ref TIE
    typedef boost::shared_ptr<TIE> PTIE;
 
    /**
     * typedef for the list of \ref IndexElement elements 
     * on this template's base class
     */
    typedef std::list<PTIE> IEList;
    /**
     * typedef for the iterator on the list of this template's base class
     * elements
     */
    typedef typename TList::iterator TIter;
    /**
     * typedef for \ref SimpleObjectIterator on this template's base class
     */
    typedef SimpleObjectIterator<T> TIterator;
    /**
     * typedef for the smart pointer on \ref SimpleObjectIterator 
     * on this template's base class
     */
    typedef boost::shared_ptr<TIterator> PTIterator;

    /**
     * iterator for \ref IEList
     */
    typedef typename IEList::iterator IEIter;

    /**
     * constructor
     */
    TrivialObjectSet(long num, BooleanAlgebraicSolver *solver) : myVarNum(num) 
    {
      list = new IEList;
      mySolver = solver;
      this->setWriteLog(false);
      mySolver->getStats()->incTrivialObjectSets();
      mySolver->getStats()->incTrivialObjectSets();
    };

    /**
     * unerases
     */
    void unErase(IE *ie) {ie->unErase();};
    
    /**
     * destructor
     */
    ~TrivialObjectSet() {list->clear(); delete list;};

    void
    addVariable(Variable var)
    {
      if (myVarNum < var)
        myVarNum = var;
    }
    /**
     * assigns a value to a variable
     */
    AssignReturnType assign(Variable var, bool val)
    {
      IEIter obegin = list->begin();
      IEIter oend = list->end();
      bool unsat = false;
      while (obegin!=oend)
      {
        PT clone = (*obegin)->getObject()->cloneObject();
        obegin = list->erase(obegin);
        AssignReturnType type = clone->assign(var, val);
        switch(type)
        {
          case ART_Satisfiable:
            break;
          case ART_Unsatisfiable:
            unsat=true;
            break;
          default:
            PIE newpie(new IE(clone,this));
            PTIE newtie(new TIE(newpie));
            list->push_front(newtie);
        }
      }
      if (unsat) return ART_Unsatisfiable;
      if (!list->size()) return ART_Satisfiable;
      return ART_Active;
    }
    
    /**
     * returns the number of variables
     */
    virtual long int getVariableNum() {return myVarNum;}

    /**
     * Adds deduction object to the set.
     */
    virtual void
    add(PT D) {
      if (!D->getId()) D->setId(mySolver->getNextId());
      PIE newpie(new IE(D,this));
      PTIE newtie(new TIE(newpie));
     list->push_back(newtie);
    };

    /**
     * isPresent - trivial here
     */
    bool isPresent(long num) {Assert(0, "Not implemented."); return true;};
    
    /**
     * Delete all objects
     */
    virtual void clear() 
    {
      IEIter beg = list->begin();
      IEIter end = list->end();
      while (beg != end)
      {
        beg = list->erase(beg);
      }
    };
   
    /**
     * test for emptiness
     */
    virtual bool isEmpty() {return (list->size() > 0);};

    /**
     * return the size of the set (in objects)
     */
    virtual long int getSize() {return list->size();};
    
    /**
     * return begin std::list::iterator on
     * the whole set
     */
    virtual typename std::list<PTIE>::const_iterator beginWhole() const {return list->begin();};

    /**
     * return end std::list::iterator on
     * the whole set
     */
    virtual typename std::list<PTIE>::const_iterator endWhole() const {return list->end();};
    
    /**
     * print out the set to the given ostream
     */
    std::ostream& print(std::ostream& os) const;

    /**
     * adds a set
     */
    virtual void addSet(ObjectSet<T> *set)
    {
      PTIterator obegin = set->getBeginIteratorOnWholeSet();
      PTIterator oend = set->getEndIteratorOnWholeSet();
      while (*obegin != *oend)
      {
        PIE newpie(new IE(**obegin,this));
        PTIE newtie(new TIE(newpie));
        list->push_back(newtie);
        ++*obegin;
      }
    }
 
    /**
     * begin iterator
     */
    PTIterator getBeginIteratorOnWholeSet()
    {
      PTIterator res(new TIterator(list->begin(),list));
      return res;
    }

    /**
     * end iterator
     */
    PTIterator getEndIteratorOnWholeSet()
    {
      PTIterator res(new TIterator(list->end(),list));
      return res;
    }

    /**
     * Removes deduction object given by iterator from the set
     */
    PTIterator remove(PTIterator& it)
    {
      if (it->getIE()->getSet() != this)
        return it->getIE()->callSetRemove(it); 
      
      PTIterator next = it->clone();
      ++*next;
      
      list->erase(it->getIterator());

      return next;
    }


    PIE getFirstObjectInVars(long,long,long)
    {
      Assert(0,"index3");
      return ((*(list->begin()))->getIE());
    }
 
    PIE nextObjectInVars()
    {
      Assert(0,"index3");
      return ((*(list->begin()))->getIE());
    } 
    
    PIE currentObjectInVars()
    {
      Assert(0,"index3");
      return ((*(list->begin()))->getIE());
    }


    bool isLastObjectInVars() 
    {
      Assert(0,"index3");
      return true;
    }
 
    /**
     * print in html
     */
    void printHtml(std::ofstream *os,bool firstpage) 
    {
      *os << "<h4>" << this->getName() << "</h4>\n";
      *os << "<table width=\"100%\">\n";
      typename IEList::iterator beg = list->begin();
      typename IEList::iterator end = list->end();
      while (beg != end)
      {
        *os << "<tr><td><font";
        if ((*beg)->isDeleted()) *os << " color=\"#666666\"";
        *os << ">";
	((*beg)->getObject())->print(*os, mySolver);
	
        *os << "</font></td><td><font color=\"#666666\">";
        if ((*beg)->isDeleted()) *os << "DELETED";
        *os << "</font></td></tr>\n";
        ++beg;
      }
      *os << "</table>\n";
    }

    void incSize() {};
    
  private:
    /// list of objects that constitute this set
    IEList *list;
    /// number of occurring variables
    long myVarNum;
    /// the solver
    BooleanAlgebraicSolver *mySolver;
  }; // end of class SimpleObjectSet

/*
 * shared pointer typedefs
 */

/**
 * \ref TrivialObjectSet on \ref DeductionObject
 */
typedef TrivialObjectSet<DeductionObject> TrivDedObjSet;
/**
 * smart pointer for \ref TrivDedObjSet
 */
typedef boost::shared_ptr<TrivDedObjSet> PTrivDedObjSet;

/**
 * \ref TrivialObjectSet on \ref ModificationObject
 */
typedef TrivialObjectSet<ModificationObject> TrivModObjSet;
/**
 * smart pointer for \ref TrivModObjSet
 */
typedef boost::shared_ptr<TrivModObjSet> PTrivModObjSet;

template <class T>
std::ostream& TrivialObjectSet<T>::print(std::ostream& os) const
{
  typename IEList::const_iterator cbeg = list->begin();
  
  if (cbeg==list->end())
  {
    os << "[empty set]";
  }
  
  while (cbeg!=list->end())
  {
    (((*cbeg)->getObject()))->print(os, mySolver);
    if ((*cbeg)->isDeleted()) os << "  DELETED";
    os << "\n";
    ++cbeg;
  }
  return os;
}


#endif

