#ifndef __DEDOBJ_H__
#define __DEDOBJ_H__

/**
 * @file dedobj.h
 * @brief Defines the abstract DeductionObject class.
 * It is used to hold clauses (\ref SAClause is a child 
 * of this class).
 */

#include "boost/smart_ptr.hpp"
#include "object.h"
#include "../logical/abstract/saliteral.h"


class DeductionObject;
/**
 * smart pointer for \ref DeductionObject
 */
typedef boost::shared_ptr<DeductionObject> PDeductionObject;


/**
 * @class DeductionObject
 * @brief Abstract deduction object class. Has \ref SAClause
 * as a child. 
 *
 * The basic difference between \ref DeductionObject
 * and \ref ModificationObject is that modification objects
 * are used for rewriting other objects; if a variable occurs
 * in the left-hand side of a modification object, it basically
 * means that very soon this variable will be eliminated from
 * all other objects and will remain in the set of modifiers 
 * only (to keep it there is needed for discarding possible 
 * duplicates and for calculating the satisfying assignment)
 */
class DeductionObject : public Object
{
public:

  /**
   * constructor
   */
  DeductionObject() {};
 

  virtual bool hasOneEquality() const = 0;
  
  /**
   * destructor
   */
  virtual ~DeductionObject() {};

  /**
   * print out the object
   */
  virtual std::ostream& print(std::ostream&, BooleanAlgebraicSolver *,bool print_as_dedobj = false) = 0;

  /**
   * empty the object
   */
  virtual void empty() = 0;
  
  /**
   * assign a value to a variable
   */
  virtual AssignReturnType assign(Variable var, int val) = 0;

  /**
   * add a literal to a deduction object
   */
  virtual void add(PSALiteral) = 0;

  /**
   * return the list of occurring variables
   */
  virtual PVarList getVariableList() const = 0;

  /**
   * return the list of occurring variables depending
   * on the return type
   */
  virtual PVarList getVariableList(TGetVar rettype) const = 0;

  /**
   * clone this object
   */
  virtual PDeductionObject cloneObject() const = 0;
  
  /**
   * test whether the object is boolean
   */
  virtual bool isBoolean()=0;
 
  virtual bool isPositive(long var) const = 0;
  virtual bool isNegative(long var) const = 0;
  
  /**
   * test whether the object is already satisfiable
   */

  virtual bool isAlreadySatisfied() const = 0; 
 /**
  * checks whether this object is a tautology
  */
  bool isTautology() const {return this->isAlreadySatisfied();};

  /**
   * test whether the object is already unsatisfied 
   */
  virtual bool isUnsatisfiable() const = 0; 
  /**
   * check whether the object is a contradiction;
   * calls \ref isUnsatisfiable , so, perhaps, is obsolete
   */
  bool isContradiction() const {return this->isUnsatisfiable();};


  /**
   * checks whether this is one equality looking like
   * y = ac+d-acd; assigns the variables y,a,c,d to params
   */
  virtual bool getYeqACpDmACD(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const = 0;

  /**
   * checks whether this is one equality looking like
   * d = ab + ac - abc; assigns the variables d,a,b,c to params
   */
  virtual bool getDeqABpACmABC(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const = 0;

  /**
   * checks whether this is one equality looking like
   * y = a+b+c-2ab-2ac-2bc+4abc; assigns y,a,b,c to params
   */
  virtual bool get124(Variable&,Variable&,Variable&,Variable&,bool&) const = 0;

  /**
   * checks whether this is one equality looking likes
   * x = ab+ac+bc-2abc; assigns x,a,b,c to params
   */
  virtual bool getXeqABpACpBCm2ABC(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const = 0;
 

  /**
   * checks whether this is one equality of degree 2 having even
   * coefficients of its deg 2 monomials
   */
  virtual bool isDeg2Even() const {return false;};
  
  /**
   * checks whether this is one equality looking like x=a+b-2ab;
   * assigns x,a,b to params
   */
  virtual bool getOneOneMinusTwoWConst(long &x, long &a, long &b, bool &withconstant) const {return false;};
 /**
   * checks whether this is one equality looking like x=a+b-2ab;
   * assigns x,a,b to params
   */
  virtual bool getOneOneMinusTwo(long &x, long &a, long &b) const {return false;};
  /**
   * checks whether this is one equality looking like x=a+b-ab;
   * assigns x,a,b to params
   */  
  virtual bool getOneOneMinusOne(long &x, long &a, long &b) const {return false;};
 
  /**
   * checks whether this is one equality looking like x=ab;
   * assigns x,a,b to params
   */
  virtual bool getXeqAB(long &,long &,long &) const {return false;};

  /**
   * checks whether this is one equality looking like x=ab;
   * assigns x,a,b to params; x,a,b may be literals
   */
  virtual bool getXeqAB(Variable &,bool &,Variable &,bool &,Variable &,bool &) const {return false;};

  /**
   * checks whether this is a clause of three boolean literals;
   * assigns the variable numbers to params
   */
  virtual bool isBooleanThreeVariables(long &x, long &y, long &z) const {return false;};
  /**
   * checks whether this is a clause of two boolean literals;
   * assigns the variable numbers to params
   */
  virtual bool isBooleanTwoVariables(long &x, long &y) const {return false;};

  /**
   * checks whether this might be subject to Linearization2Rule,
   * namely, whether this has form of x = c1*a+c2*b+c3*ab,
   * where c1 and c2 might be zero; assigns a,b to params
   */ 
  virtual bool getLin2Subject(Variable&,Variable&) const {return false;};
  /**
   * checks whether this might be subject to Linearization2Rule,
   * namely, whether this has form of x = c1*a+c2*b+c3*ab,
   * where c1 and c2 might be zero
   */ 
  virtual bool isLin2Subject() const {return false;};
  /**
   * checks whether this might be subject to Linearization2Rule,
   * namely, whether this has form of x = c1*a+c2*b+c12*ab,
   * where c1 and c2 might be zero, assigns x,a,b,c1,c2,c12 to params
   */ 
  virtual bool getLin2Subject(Variable&,Variable&,Variable&,Coefficient&,Coefficient&,Coefficient&) const {return false;};
  /**
   * tests whether this is one equality with its left-hand side
   * consisting of one variable and returns this variable
   */
  virtual bool getLHSVariable(Variable &) const {return false;};

  /**
   * tests whether this is one equality looking like y=ac+(1-a)b
   * assigns y,a,c,b to params
   */
  virtual bool getYeqACpnAB(Variable &,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const {return false;};

  /**
   * return equality type of this object
   * by default returns type "boolean clause"
   */
  virtual TEqualityType getEqType() const {return Boolean;};
 
  
  
  
  
  
  
  /**
   * checks whether this is one equality looking like x=ab;
   * assigns x,a,b to params;
   * new version for \ref TypedEquality
   */
  virtual bool getXeqABnew(Variable &,bool &,Variable &,bool &, Variable &, bool &) const {return false;};

  /// If this clause is a Boolean binary clause,
  /// returns true and sets the input literals correspondingly.
  /// Otherwise, returns false. Note that a binary clause can 
  /// also be represented as ab=0.
  virtual bool
  getBinaryClauseLiterals(int& lit1, int& lit2) = 0;
};



typedef boost::shared_ptr<DeductionObject> PDeductionObject;
/**
 * localization of /ref IndexElement for /ref DeductionObject
 */
typedef IndexElement<DeductionObject> IEDeduction;
/**
 * smart pointer for /ref IEDeduction
 */
typedef boost::shared_ptr<IEDeduction> PIEDeduction;
/**
 * localization of /ref TinyIndexElement for /ref DeductionObject
 */
typedef TinyIndexElement<DeductionObject> TIEDeduction;
/**
 * smart pointer for /ref TIEDeduction
 */
typedef boost::shared_ptr<TIEDeduction> PTIEDeduction;

#endif
