#ifndef __OBJECT_H__
#define __OBJECT_H__

/**
 * @file object.h
 * @brief Defines the abstract Object class. 
 */

#include "boost/smart_ptr.hpp"
#include "../algebraic/abstract/variable.h"
#include "../misc/statistics.h"

class BooleanAlgebraicSolver;
class Assignment;
template <class T> class ObjectSet;
template <class T> class SimpleObjectIterator;
template <class T> class TinyIndexElement;

/**
 * @struct TVarTreeNode
 * @brief this is a structure used in 
 * generating html output
 */
typedef struct TVarTreeNode
{
  /// reference to the variable
  long var;
  /// its value if assigned
  int val;
  /// number of the file where html output should print to
  long filenum;
  /// references to connected nodes
  TVarTreeNode *parent,*left,*right;
};


/**
 * enumerative type that determines the type of the object; members:
 * eqtXeqABC                       -- x=abc
 * eqtXeqABpACpBCm2ABC             -- x=ab+ac+bc-2abc
 * eqt124                          -- x=a+b+c-2ab-2bc-2ac+4abc (x=a xor b xor c)
 * eqtXeqAB                        -- x=ab
 * eqtABeq0                        -- ab=0
 * eqt11m1                         -- x=a+b-ab
 * eqt11m2                         -- x=a+b-2ab (x=a xor b)
 * eqtDeqABpACmABC                 -- d=ab+ac-abc (d = a(b xor c) )
 * eqtYeqACpDmACD                  -- y=ac+d-acd
 * eqtYeqACpnAB                    -- y=ac+(1-a)b
 * eqtWeqXmXYZ                     -- w=x-xyz
 * eqtZeqWXpVXm2WVX                -- z=wx+vx-2wvx
 * eqtSeqXpVnWm2XWnV               -- s=x+v(1-w)-2xv(1-w)
 * eqtCeqWXYpnWnXY                 -- c=wxy+(1-w)(1-x)y
 * eqtCeqXZmXYpnWYnZp2WXYnZ        -- c=xz+xy+(1-w)y(1-z)+2wxy(1-z)
 * eqtCeqYnWYxorZ                  -- c=y(1-w)(y+z-2yz)
 * eqtVeqYZLS                      -- v=yzls
 * eqtVeqYZnotLS                   -- v=yz(1-ls)
 * eqtBoothSubResult               -- some of the equalities produced by 
 *                                    \ref BoothSubRule (only with --booth)
 * eqtBoothSubResult2              -- same as above
 * eqtBackT2Result                 -- result of \ref BackT2SubstitutionRule
 *                                    (used only with --booth)
 * eqtXORSum                       -- a sum of several equalities representing
 *                                    XOR (eqt11m2 or eqt124)
 * eqtXORSumWithLin                -- a sum of several equalities representing
 *                                    XOR (eqt11m2 or eqt124) and, possibly,
 *                                    some linear equalities
 * Boolean                         -- boolean equalities (x=1 or x=0)
 * Special                         -- all equalities that do not have one of
 *                                    the types specified above 
 * LastType                        -- dummy type for the last entry of the list
 */
typedef enum {               
  eqtXeqABC,
  eqtXeqABpACpBCm2ABC,
  eqt124,
  eqtXeqAB,
  eqtABeq0,
  eqt11m1,
  eqt11m2,
  eqtDeqABpACmABC,
  eqtYeqACpDmACD,
  eqtYeqACpnAB,
  eqtWeqXmXYZ,
  Special,
  Dummy1,
  eqtZeqWXpVXm2WVX,
  eqtSeqXpVnWm2XWnV,
  eqtCeqWXYpnWnXY,
  eqtCeqXZmXYpnWYnZp2WXYnZ,
  eqtCeqYnWYxorZ,
  eqtVeqYZLS,
  eqtVeqYZnotLS,
  eqtBoothSubResult,
  eqtXORSum,
  eqtXORSumWithLin,
  Boolean,
  eqtBoothSubResult2,
  eqtBackT2Result,
  LastType
} TEqualityType;


/**
 * enum for indices, they are usually tied to specific equality types
 */
typedef enum {
  indEqualities,
  indOneOneMinusTwoWConst,
  indOneOneMinusTwo,
  indOneOneMinusOne,
  indDeg2Even,
  indABeq0,
  indXeqAB,
  indXeqABpACpBCm2ABC,
  indDeqABpACmABC,
  ind124,
  indLin2,
  indXeqABC,
  indOR3Addon1,
  indOR3Addon2,
  indWeqXmXYZ,
  indLongXOR,
  indZeqWXpVXm2WVX,
  indSeqXpVnWm2XWnV,
  indCeqWXYpnWnXY,
  indCeqXZmXYpnWYnZp2WXYnZ,
  indCeqYnWYxorZ,
  indVeqYZLS,
  indBoothSubResult,
  indYeqACpDmACD,
  indTwoClauses,
  indGeneral,
  indBoothSubResult2,
  indLast 
} TIndexType;

/// number of indices; don't forget to update if introducing new indices!
#define INDICES_NUM 28


/**
 * a structure used in variables request
 */
enum TGetVar {
  ReturnAll,
  ReturnTopTwo
};

/**
 * @class Object
 * @brief Base class for all objects.
 * \ref DeductionObject and \ref ModificationObject are its children.
 */
class Object
{
  
public:

  /**
   * constructor
   */
  Object();
 
  /**
   * return the list of variables occurring in
   * the object
   */
  virtual PVarList getVariableList() const = 0;

  /**
   * print out the object to the given stream
   * print_as_dedobj flag is used to indicate whether the
   * object should be printed as a \ref DeductionObject (that is,
   * its id should be taken from its wrapper clause, and not from
   * its first object, as a \ref ModificationObject would print itself
   */
  virtual std::ostream& print(std::ostream&, BooleanAlgebraicSolver *, bool print_as_dedobj = false) = 0;

  /**
   * get id
   */
  long getId() const {return myId;};

  /**
   * checks whether the object consists of only one equality
   */
  virtual bool hasOneEquality() const = 0;
 
  /**
   * returns true if the given variable occurs positively
   * returns false otherwise (and by default)
   */
  virtual bool isPositive(long var) const {return false;};

  /**
   * returns true if the given variable occurs negatively
   * returns false otherwise (and by default)
   */
  virtual bool isNegative(long var) const {return false;};
 
  /**
   * set id
   */
  void setId(long id) {myId = id;};

  /**
   * get last occurrence
   */
  TVarTreeNode *getOccurrence() const {return myOccurrence;};

  /**
   * set last occurrence
   */
  void setOccurrence(TVarTreeNode *occur) {myOccurrence = occur;};

  /// returns the number of occurrences
  int getOccNum() {return myOccNum;};
  /// increment the number of occurrences
  void incOccNum() {++myOccNum;};

  /// destructor
  virtual ~Object() {
    };
  
  /// Assigns a value to a variable.
  virtual AssignReturnType 
  assign(Variable var, int value) = 0;
 
  /// return equality type of this; returns Boolean by default
  virtual TEqualityType getEqType() const {return Boolean;};
  
  /// Checks whether an input variable is present and not assigned 
  /// in this object (x is considered assigned in equalities x=1 and x=y).
  virtual bool
  isVarPresentAndNonAssigned(Variable x) = 0;
  
  /// Checks whether this object contains a variable x.
  virtual bool
  contains(Variable x) const;

  /**
   * tells whether is was generated by Lin2Rule or Lin3Rule
   */
  virtual bool isGeneratedByLinearization() const {return isGeneratedByLin;}

  /// sets isGeneratedByLin to true
  virtual void setGeneratedByLinearization() {isGeneratedByLin = true;};
  
  /// Checks whether this object is satisfied by a given assignment. 
  virtual bool
  isSatisfiedBy(Assignment* a) const = 0;

  /// returns the number of literals; returns 1 be default
  /// should be overridden in SAClause
  virtual int getNumberOfLiterals() const {return 1;};

  /// should be overridden by true only in ModificationObject
  virtual bool isModObj() const {return false;}
 
private:

  /// id of this object
  long myId;
  /// a reference to its occurrence in html output
  TVarTreeNode *myOccurrence;
  /// current number of the occurrence
  int myOccNum;
  /// tells whether this object has been generated by Lin2Rule or Lin3Rule
  bool isGeneratedByLin;
  
};

/**
 * @class IndexElement
 * @brief This is the basic element for backtracking.
 * It represents a small entity that is inserted in indices and
 * holds index-specific properties that may not be propagated up
 * to the \ref Object class.
 */
template <class T>
class IndexElement 
{
private:
  ///  the object itself
  boost::shared_ptr<T> myObject;
  /// a reference to the set where this object belongs
  ObjectSet<T> *mySet;
  /// boolean that show whether this object is considered deleted
  bool myDeleted;
  /// list of indices where this element occurs
  std::list<TIndexType> *myIndexList;
  /// list of variables occurring in this element
  std::list<Variable> *myVarList;
  /// if this is set to true, the object will be deleted from all indices
  bool unAdded;
public:

  /// get index list
  std::list<TIndexType> *getIndexList() const {return myIndexList;};
  
  /// typedef for \ref SimpleObjectIterator on the base class
  typedef SimpleObjectIterator<T> TIterator;
  /// smart pointer for \ref TIterator
  typedef boost::shared_ptr<TIterator> PTIterator;

  /// constructor from an object and a set
  IndexElement(boost::shared_ptr<T> object, ObjectSet<T> *set) : myDeleted(false), unAdded(false)
  {
    myObject = object; 
    mySet = set;
    myIndexList = new std::list<TIndexType>;
    myVarList = new std::list<Variable>;
  };

  /// cloning constructor
  IndexElement<T> (const IndexElement<T>& ie) : myDeleted(ie.myDeleted) {myObject = ie.myObject; mySet = ie.mySet; 
    myIndexList = ie.myIndexList; 
    myVarList = ie.myVarList;
  };

  /// returns the object
  boost::shared_ptr<T> getObject() {return myObject;};
  /// checks whether the object is deleted
  bool isDeleted() {return myDeleted;};
  /// sets \ref myDeleted to true
  void erase() {myDeleted = true;};
  /// unerases the object, calling its set's unerase method
  void unErase() {
    if (myDeleted) {
      mySet->unErase(this); 
      myDeleted = false;
    } 
  };
  /// unadds an object, deleting it from its set completely
  void unAdd() {
    unAdded = true; 
    mySet->unAdd(this);
    myIndexList->clear();
    myVarList->clear();
    myObject.reset();
  }

  /// return whether this object is unadded
  bool isUnadded() {return unAdded;};

  /// return the variable list
  std::list<Variable> *getVList() const {return myVarList;};

  /// set \ref myDeleted to be equal to the parameter
  void setDeleted(bool del) {myDeleted = del;};
  
  /**
   * returns pointer to the set
   */
  ObjectSet<T> *getSet() {return mySet;};

  /// removes with set deletion
  void eraseFromSet() {mySet->remove(this);};

  /**
   * calls the remove method on the given iterator
   */
  PTIterator callSetRemove(PTIterator& iter)  
  {
    return mySet->remove(iter);
  }

  /// destructor
  ~IndexElement<T> ()
  {
    myIndexList->clear();
    myVarList->clear();
    if (myIndexList) delete myIndexList;
    if (myVarList) delete myVarList;
  }
  
};


/**
 * Another entity for inserting into indices.
 */
template <class T> 
class TinyIndexElement
{
public:

  /// smart pointer for this class
  typedef boost::shared_ptr<TinyIndexElement <T> > PTIE;
  /// a list of \ref PTIE
  typedef std::list<PTIE> IEList;
  /// an iterator for \ref IEList
  typedef typename IEList::iterator IEIter;
  
  /// constructor
  TinyIndexElement(boost::shared_ptr<IndexElement<T> > inde, IEIter *it = 0) : ie(inde), deleted_at_end(false), deliter(it)
        {};
  
  /// return the index element
  boost::shared_ptr<IndexElement<T> > getIE() {return ie;};

  /// returns whether the basic \ref IndexElement is unadded
  bool isUnadded() {return ie->isUnadded();};
  
  /// return the object itself
  boost::shared_ptr<T> getObject() {return ie->getObject();};

  /// tell whether it is deleted
  bool isDeleted() {return ie->isDeleted();};

  /// get whether this has already been moved to end of file
  bool isDeletedAtEnd() {if (!ie->isDeleted()) {deleted_at_end = false; return false;} return deleted_at_end;};

  /// for test purposes; a method that does not change variables
  bool isDeletedAtEndForPrint() {return deleted_at_end;};
  
  /// set \ref deleted_at_end to true
  void setDeletedAtEnd() {deleted_at_end = true;};

  /// set \ref deleted_at_end to false
  void unDeleteAtEnd() {deleted_at_end = false;};

  /// returns the deleted iterator pointer
  IEIter *getDeletedIterator() {return deliter;};
  
private:
  /// a pointer to the base index element
  boost::shared_ptr<IndexElement<T> > ie;
  /// boolean that tells whether this is deleted and put to the end of the
  /// corresponding list
  bool deleted_at_end;
  /// iterator pointing to the last element which is not deleted and put to
  /// the end of the list
  IEIter *deliter;
};



/**
 * localization of \ref IndexElement for \ref Object
 */
typedef IndexElement<Object> IEGeneral;
/**
 * smart pointer for \ref IEGeneral
 */
typedef boost::shared_ptr<IEGeneral> PIEGeneral;


/**
 * smart pointer for \ref Object
 */
typedef boost::shared_ptr<Object> PObject;

#endif
