#ifndef __MODOBJ_H__
#define __MODOBJ_H__

/**
 * @file modobj.h
 * @brief Defines the abstract ModificationObject class.
 * By means of these objects we simplify other objects.
 * A modification object consists of one equality that usually
 * looks like x=0, x=1 or x=y.
 */

#include "boost/smart_ptr.hpp"
#include "object.h"
#include "../logical/abstract/saliteral.h"
#include "../algebraic/abstract/polynomial.h"

class ModificationObject;
class BooleanAlgebraicSolver;
/**
 * smart pointer for \ref ModificationObject
 */
typedef boost::shared_ptr<ModificationObject> PModificationObject;


/**
 * Modification object is an object of a search space, by means 
 * of which we simplify another objects. For an object to be considered
 * a modification object it has to look like x=0, x=1, x=y or x=1-y.
 * The only possibility for another object to end up as a modifier is
 * to be deleted by \ref SingleOccurrenceRule.
 * 
 * The basic difference between \ref DeductionObject
 * and \ref ModificationObject is that modification objects
 * are used for rewriting other objects; if a variable occurs
 * in the left-hand side of a modification object, it basically
 * means that very soon this variable will be eliminated from
 * all other objects and will remain in the set of modifiers 
 * only (to keep it there is needed for discarding possible 
 * duplicates and for calculating the satisfying assignment.
 *
 * Modifiers obtained by \ref SingleOccurrenceRule do not participate
 * in simplifications and are necessary only to calculate the satisfying
 * assignment (if any).
 */
class ModificationObject : public Object
{
public:

  ModificationObject() {};
  
  /**
   * destructor
   */
  virtual ~ModificationObject()  {
  };

  /**
   * print out the object
   */
  virtual std::ostream& print(std::ostream&, BooleanAlgebraicSolver *,bool print_as_dedobj = false) = 0;

  /**
   * assign a value to a variable
   */
  virtual AssignReturnType assign(Variable var, int val) = 0;

  virtual bool hasOneEquality() const {return true;};
  
  /**
   * return the list of variables occurring here
   */
  virtual PVarList getVariableList() const = 0;

  /**
   * clones the object
   */
  virtual PModificationObject cloneObject() const = 0;
  
  virtual bool isModObj() const {return true;};
  
  /**
   * returns the left-hand side of this object
   * in case it is an equality
   */
  virtual PPolynomial getLHS() const = 0;
  /**
   * returns the right-hand side of this object
   * in case it is an equality
   */
  virtual PPolynomial getRHS() const = 0;
  
  /**
   * checks whether this is a tautology
   */
  virtual bool isTautology() const =0; 

  /**
   * test whether the object is already unsatisfiable 
   */
  virtual bool isUnsatisfiable() const = 0;
  /**
   * checks whether the object is a contradiction already
   */
  bool isContradiction() const {return this->isUnsatisfiable();}; 

  /**
   * Determine the type of modification object
   */
  
  /**
   * checks whether this is boolean
   */
  virtual bool isBoolean() const=0; 
  /**
   * checks whether this is a first type equality
   */
  virtual bool isFirstType() const=0; 
  /**
   * checks whether this is a second type equality
   */ 
  virtual bool isSecondType() const=0; 
  /**
   * checks whether this is a third type equality
   */
  virtual bool isThirdType() const=0; 

  /**
   * checks whether this is one equality looking like x=a+b-2ab;
   * assigns x,a,b to params
   */
  virtual bool getOneOneMinusTwoWConst(long &x, long &a, long &b, bool &withconstant) const = 0;
 /**
   * checks whether this is one equality looking like x=a+b-2ab;
   * assigns x,a,b to params
   */
  virtual bool getOneOneMinusTwo(long &x, long &a, long &b) const = 0;
  /**
   * checks whether this is one equality looking like x=a+b-ab;
   * assigns x,a,b to params
   */
  virtual bool getOneOneMinusOne(long &x, long &a, long &b) const = 0;
  /**
   * checks whether this is one equality looking like x=ab;
   * assigns x,a,b to params
   */
  virtual bool getXeqAB(long &,long &,long &) const {return false;};
  /**
   * checks whether this is one equality looking like x=ab
   */
  virtual bool isXeqAB() const {return false;};
 
  /**
   * returns false; needed for compatibility
   * @see DeductionObject
   */
  virtual bool isLin2Subject() const {return false;};
  /**
   * returns false; needed for compatibility
   * @see DeductionObject
   */
  virtual bool getLin2Subject(Variable&,Variable&,Variable&,Coefficient&,Coefficient&,Coefficient&) const {return false;};

  /**
   * returns false; needed for compatibility
   * @see DeductionObject
   */
  virtual bool getLin2Subject(Variable&,Variable&) const {return false;};

  /**
   * returns false; needed for compatibility
   * @see DeductionObject
   */
  virtual bool isBooleanThreeVariables(long&,long&,long&) const {return false;};
  /**
   * returns false; needed for compatibility
   * @see DeductionObject
   */
  virtual bool isBooleanTwoVariables(long&,long&) const {return false;};
  /**
   * returns whether this has left-hand side of one variable
   * and assigns this variable to the parameter
   */
  virtual bool getLHSVariable(Variable &) const { return false;};

  /**
   * checks whether this is one equality of degree 2 having even
   * coefficients of its deg 2 monomials
   */
  virtual bool isDeg2Even() const {return false;};
 
};

/**
 * smart pointer for \ref ModificationObject
 */
typedef boost::shared_ptr<ModificationObject> PModificationObject;

/**
 * localization of \ref IndexElement for \ref ModificationObject
 */
typedef IndexElement<ModificationObject> IEModification;
/**
 * smart pointer for \ref IEModification
 */
typedef boost::shared_ptr<IEModification> PIEModification;

/**
 * localization of \ref TinyIndexElement for \ref ModificationObject
 */
typedef TinyIndexElement<ModificationObject> TIEModification;
/**
 * smart pointer for \ref IEModification
 */
typedef boost::shared_ptr<TIEModification> PTIEModification;


#endif
