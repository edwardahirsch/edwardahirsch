#ifndef __SIMPLEOBJECTSET_H__
#define __SIMPLEOBJECTSET_H__

#include "objectset.h"
#include "../indexing/abstract/objectindex.h"
#include "../misc/tracer.h"
#include "../misc/assert.h"
#include "../backtrack/simplelogentry.h"
#include "../backtrack/log.h"
#include "../general/solver.h"

/**
 * @file simpleobjectset.h
 * @brief Contains the SimpleObjectSet template.
 */


/**
 * This template implements a set of objects (which may 
 * have different nature, as this is a template) and 
 * keeps several indices for this set of objects. Please
 * refer to descriptions of specific methods for 
 * information on these indices.
 */
  template <class T>
  class SimpleObjectSet : public ObjectSet<T>
  {
  public:

    /**
     * typedef for the smart pointer on this template's base class
     */
   typedef boost::shared_ptr<T> PT;
    /**
     * typedef for \ref IndexElement on this template's base class
     */
    typedef IndexElement<T> IE;
    /**
     * typedef for the smart pointer on \ref IndexElement on this template's
     * base class
     */
    typedef boost::shared_ptr<IE> PIE;
 
    /// \ref TinyIndexElement on the base class
    typedef TinyIndexElement<T> TIE;

    /// smart pointer for \ref TIE
    typedef boost::shared_ptr<TIE> PTIE;
    
    /**
     * typedef for \ref SimpleObjectIndex on this template's base class
     */
    typedef SimpleObjectIndex<T> TIndex;
    /**
     * typedef for the smart pointer on \ref SimpleObjectIndex on this template's base class
     */
    typedef boost::shared_ptr<TIndex> PTIndex;
    /**
     * typedef for a list of smart pointers on this template's base class
     */ 
    typedef std::list<boost::shared_ptr<T> > TList;
    /**
     * typedef for the list of \ref IndexElement elements on this template's base class
     */
    typedef std::list<PTIE> IEList;
    /**
     * typedef for the iterator on the list of this template's base class
     * elements
     */
    typedef typename TList::iterator TIter;
    /**
     * typedef for \ref SimpleObjectIterator on this template's base class
     */
    typedef SimpleObjectIterator<T> TIterator;
    /**
     * typedef for the smart pointer on \ref SimpleObjectIterator on this template's base class
     */
    typedef boost::shared_ptr<TIterator> PTIterator;

    /**
     * unerases
     */
    void unErase(IE *ie)
    {
      if (ie->isDeleted()) 
      {
        size++;
        myIndex->incCounters(ie);
        myIndex->unEraseFromIndices(ie);
      }
    }
    
    /**
     * assigns a value to a variable
     */
    AssignReturnType assign(Variable var, bool val)
    {
      PTIterator obegin = this->begin(var);
      bool unsat = false;
      while (*obegin!=*this->end(var))
      {
        PT clone = (**obegin)->cloneObject();
        
        this->remove(obegin);
         
        AssignReturnType type = clone->assign(var, val);

        switch(type)
        {
          case ART_Satisfiable:
            break;
          case ART_Unsatisfiable:
            unsat=true;
            break;
          default:
            this->add(clone);
        }
        ++*obegin;
      }
      if (unsat) return ART_Unsatisfiable;
      if (!size) return ART_Satisfiable;
      return ART_Active;
    }
   
    /**
     * Constructor.
     * @param num - the number of variables
     * @param log - an instance of the class \ref Log
     * @param solver - the solver to which this set will belong to
     * intended to store all information about made modifications
     */
    SimpleObjectSet(long int num, Log* log, BooleanAlgebraicSolver *solver) : size(0)
    {
      PTIndex indexx(new TIndex(num+1));
      myIndex = indexx;
      mySolver = solver;
      myVariableNum = num;
      myObjectList.clear();
      if (log)
        myLog = log;
      else
        myLog = mySolver->getLog();
      if (mySolver) mySolver->getStats()->incSimpleObjectSets();
    };

    /**
     * checks that indices are ok
     */
    void checkIndexInvariants()
    {
      myIndex->checkInvariants();
    }
    
    /**
     * Add a new variable to index.
     */
    void
    addVariable(Variable var)
    {
      if (myVariableNum >= var) return;
      for (int i=myVariableNum+1; i<=var; ++i)
      {
        mySolver->getVarList()->push_back(i);
        mySolver->setVarValue(i,-1);
        myIndex->addVariable();
        if (myLog)
        {
          PLogEntry letoadd(new AddingVariable(mySolver,mySolver->getVarList(),i));
          myLog->addEntry(letoadd);
        }
      }
      myVariableNum = var;
    }

    /// test prints an index on the given variable
    void testPrint(Variable var)
    {
      myIndex->testPrint(var,mySolver);
    }
 
    ///  test prints an index of the given type
    void testPrint(TIndexType type)
    {
      myIndex->testPrint(type,mySolver);
    }
     
    
    /**
     * returns the number of variables
     */
    long int getVariableNum() {return myVariableNum;}

    /**
     * checks whether the variable with the given number appears in a non-unit clause
     */
    bool isVariableInNonUnitClause(long num)
    {
      return myIndex->isVariableInNonUnitClause(num);
    }
    
    /**
     * Adds deduction object to the set.
     */
    void
    add(PT D)
    {
    
      if (mySolver && !D->getId()) D->setId(mySolver->getNextId());
      PIE ie(new IE(D,this));
      if (this->writesLog())
      {
        PLogEntry letoadd(new AddingDeductionObject<T>(this,&(*ie)));
        if (mySolver) mySolver->getStats()->incLogEntries();
        myLog->addEntry(letoadd);
      }
      size++;
      myIndex->addElement(ie);
      PTIE newtie(new TIE(ie));
      myObjectList.push_back(newtie);
    };
   
    /**
     * Delete all objects
     */
    void clear() {myIndex->clear(); myObjectList.clear(); size = 0;};
   
    /**
     * Adds another object set to this one
     */
    void
    addSet(ObjectSet<T> *set);

    /**
     * checks whether a given variable occurs in this set
     */
    bool occursVar(long num)
    {
      PTIterator it = this->begin(num);
      PTIterator end = this->end(num);
      return (!it->equals(*end));
    }
   

    
    /**
     * Removes deduction object given by index element from the set
     */
    void remove(IE *ie)
    {
      if (!(ie->isDeleted())) 
      {
        if (this->writesLog())
        {
          PLogEntry letoadd(new DeletingDeductionObject<T>(*this,&(*ie)));
	        myLog->addEntry(letoadd);
          myIndex->remove(ie->getObject());
          size--;
          ie->erase();
        }
        else
        {
          ie->unAdd();
        }
      }
    };

   /**
     * Removes deduction object given by iterator from the set
     */
    PTIterator 
    remove(PTIterator& it)
    {
      if (it->getIE()->getSet() != this)
        return it->getIE()->callSetRemove(it); 
          
      if (this->writesLog())
      {
        PLogEntry letoadd(new DeletingDeductionObject<T>(*this,&(*it->getIE())));
        myLog->addEntry(letoadd);
      }
      PTIterator next = it->clone();
      ++*next;
      if (!(it->getIE()->isDeleted())) 
      {
        if (this->writesLog())
        {
          myIndex->remove(**it);
          size--;
          it->getIE()->erase();
        }
        else
        {
          it->getIE()->unAdd();
        }
      }

      return next;
    };
  
    /**
     * Returns the begin iterator on the set of objects
     * containing a given variable in their left-hand sides 
     */
    PTIterator getLHSbegin(long int num) const
    {
      return myIndex->getLHSbegin(num);
    };
    
    /**
     * Returns the end iterator on the set of objects
     * containing a given variable in their left-hand sides
     */
    PTIterator getLHSend(long int num) const
    {
      return myIndex->getLHSend(num);
    };

    /**
     * Returns iterator on the set of objects
     * containing a given variable 
     * pointing to the first element
     */
    PTIterator begin(long int num) const
    {
      return myIndex->begin(num);
    };
    
    /**
     * Returns iterator on the set of objects
     * containing a given variable
     * pointing to the last element.
     */
    PTIterator end(long int num) const
    {
      return myIndex->end(num);
    };

    /**
     * returns end iterator on the
     * whole set (our iterator, not
     * std::list::iterator)
     */
    PTIterator getEndIteratorOnWholeSet()
    {
      PTIterator res(new TIterator(myObjectList.end(),&myObjectList));
      return res;
    };
  
    /// return begin iterator for a given index
    PTIterator getBegin(TIndexType type)
    {
      return myIndex->getBegin(type);
    }

    /// return end iterator for a given index
    PTIterator getEnd(TIndexType type)
    {
      return myIndex->getEnd(type);
    }
  
    /**
     * returns begin iterator on the
     * whole set (our iterator, not
     * std::list::iterator)
     */
    PTIterator getBeginIteratorOnWholeSet()
    {
      PTIterator res(new TIterator(myObjectList.begin(),&myObjectList));
      return res;
    };

    /// unadds the given \ref IndexElement
    virtual void unAdd(IE *ie)
    {
      if (!ie->isDeleted())
      {
        myIndex->remove(ie->getObject());
        myIndex->unAddFromIndices(ie);
        ie->erase();
        --size;
      }
      else
      {
        myIndex->unAddFromIndices(ie);
      }
    }
  
    /**
     * returns the first object whose variables are contained in the given
     * triple
     */
    PIE getFirstObjectInVars(long x, long y, long z)
    {
      return myIndex->firstObjectInVars(x,y,z);
    }

    
    PIE currentObjectInVars()
    {
      return myIndex->currentObjectInVars();
    }

   /**
     * increases the inner iterator on the variables contained in a given
     * triple and returns the next object
     */
    PIE nextObjectInVars()
    {
      return myIndex->nextObjectInVars();
    }

    /**
     * checks whether the inner iterator has reached end
     */
    bool isLastObjectInVars()
    {
      return myIndex->nextObjectInVars();
    }

    /**
     * test for emptiness
     */
    bool isEmpty() {return (size > 0);};

    /**
     * test whether a variable is present
     */
    bool isPresent(long num) {return myIndex->isPresent(num);};

    /**
     * return the size of the set (in objects)
     */
    long int getSize() {return size;};
   
    /// collects garbage in the index
    void collectGarbage() {myIndex->collectGarbage();};
    
    /**
     * destructor
     */
    ~SimpleObjectSet()
    {
    };
  
    /**
     * return begin std::list::iterator on
     * the whole set
     */
    typename std::list<PTIE>::const_iterator beginWhole() const {
      return myObjectList.begin();};

    /**
     * return end std::list::iterator on
     * the whole set
     */
    typename std::list<PTIE>::const_iterator endWhole() const {return myObjectList.end();};

    /**
     * print out the set to the given ostream
     */
    std::ostream& print(std::ostream& os) const;
 
    /**
     * prints in html format
     */
    void printHtml(std::ofstream *os, bool firstpage) 
    {
      *os << "<h4>" << this->getName() << "</h4>\n";
      *os << "<table width=\"100%\">\n";
      typename IEList::const_iterator beg = myObjectList.begin();
      typename IEList::const_iterator end = myObjectList.end();
      int delnum = 0;
      while (beg != end)
      {
        if (!(*beg)->isDeleted())
        {
          *os << "<tr><td";
          if (firstpage) 
          {
            *os << " id=\"" << (*beg)->getObject()->getId() << "-0\"";
            (*beg)->getObject()->incOccNum();
          }
          *os << "><font>";
          (*beg)->getObject()->print(*os,mySolver);
          *os << "</font></td><td><font color=\"#cccccc\">";
          *os << "</font></td></tr>\n";          
        }
        else
        {
          ++delnum;
        }
        ++beg;
      }
      *os << "\n<tr><td colspan=2>";
      *os << "Number of deleted objects = " << delnum;
      *os << "</td></tr></table>\n";
    }
  
    long getPositiveOccurrences(long num)
    {
      return myIndex->getPositiveOccurrences(num);
    }

    long getNegativeOccurrences(long num)
    {
      return myIndex->getNegativeOccurrences(num);
    }

    long getUnitOccurrences(long num)
    {
      return myIndex->getUnitOccurrences(num);
    }

    long getNumberOfNonUnitOccurrences(long num)
    {
      return myIndex->getNumberOfNonUnitOccurrences(num);
    }


    long getNumberOfOccurrences(long num)
    {
      return myIndex->getNumberOfOccurrences(num);
    }
   
    /// increment size
    void incSize() {++size;};

    
  private:
    /// the index (includes all supported indices; see \ref SimpleObjectIndex)
    PTIndex myIndex;
    /// current size of the set
    long int size;
    /// maximal number of a variable
    long int myVariableNum;
    /// list of all objects
    IEList myObjectList;
    /// solver
    BooleanAlgebraicSolver *mySolver;
    
    /// An instance of the class Log. 
    Log* myLog;
  }; // end of class SimpleObjectSet
   

/**
 * add a set of objects
 */
template <class T>
void SimpleObjectSet<T>::addSet(ObjectSet<T> *set)
{
  PTIterator obegin = set->getBeginIteratorOnWholeSet();
  PTIterator oend = set->getEndIteratorOnWholeSet();
  while (*obegin != *oend)
  {
    this->add(**obegin);
    ++*obegin;
  }
}

/**
 * print out the set
 */
template <class T>
std::ostream& SimpleObjectSet<T>::print(std::ostream& os) const
{
  typename std::list<PTIE>::const_iterator cbeg = myObjectList.begin();
  
  if (cbeg==myObjectList.end())
  {
    os << "[empty set]";
  }
  
  while (cbeg!=myObjectList.end())
  {
    if (!(*cbeg)->isDeleted())
    {
      ((*cbeg)->getObject())->print(os,mySolver);
      if ((*cbeg)->isDeleted()) os << "  DELETED";
      os << "\n";
    }
    ++cbeg;
  }

  return os;
}


// Shared pointer typedefs

/**
 * \ref SimpleObjectSet on \ref DeductionObject
 */
typedef SimpleObjectSet<DeductionObject> AdjDedObjSet;
/**
 * smart pointer for \ref AdjDedObjSet
 */
typedef boost::shared_ptr<AdjDedObjSet> PAdjDedObjSet;

/**
 * \ref SimpleObjectSet on \ref ModificationObject
 */
typedef SimpleObjectSet<ModificationObject> AdjModObjSet;
/**
 * smart pointer for \ref AdjModObjSet
 */
typedef boost::shared_ptr<AdjModObjSet> PAdjModObjSet;

#endif

