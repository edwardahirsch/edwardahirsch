#include "object.h"
#include "../misc/output.h"

/**
 * @file object.cc
 * @brief  Contains implementation for object.h
 * @author sergey 
 */



Object::Object()
{
  myId = 0;
    myOccNum = 1;
  myOccurrence=0;
  isGeneratedByLin = false;
}

bool
Object::contains(Variable x) const
{
  std::list<Variable> list = *(this->getVariableList());
  std::list<Variable>::iterator it = list.begin();
  std::list<Variable>::iterator it_end = list.end();

  for (; it != it_end; it++)
    if ((*it) == x)
      return true;
      
  return false;
  
}

