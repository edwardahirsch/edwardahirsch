#ifndef __OBJECTSET_H__
#define __OBJECTSET_H__

#include "../indexing/abstract/objectindex.h"
#include "../misc/tracer.h"
#include "../misc/assert.h"
#include "../backtrack/simplelogentry.h"
#include "../backtrack/log.h"
#include <fstream>

/**
 * @file objectset.h
 * @brief Contains the ObjectSet class. This is the base
 * class for two implementations -- \ref SimpleObjectSet
 * and \ref TrivialObjectSet (that is faster but provides
 * no indices).
 */


//class SimpleEquality;

// forward declaration
class BooleanAlgebraicSolver;

  /**
   * An interface for simple set of deduction objects
   * (set implemented simply as a list).
   */
  template <class T>
  class ObjectSet
  {
  public:

    /// smart pointer for base class
    typedef boost::shared_ptr<T> PT;
    /// \ref SimpleObjectIndex on the base class
    typedef SimpleObjectIndex<T> TIndex;
    /// smart pointer for \ref TIndex
    typedef boost::shared_ptr<TIndex> PTIndex;
    /// list of \ref PT
    typedef std::list<boost::shared_ptr<T> > TList;
    /// iterator for \ref TList
    typedef typename TList::iterator TIter;
    /// \ref SimpleObjectIterator on the base class
    typedef SimpleObjectIterator<T> TIterator;
    /// smart pointer for \ref TIterator
    typedef boost::shared_ptr<TIterator> PTIterator;
    /// index element
    typedef IndexElement<T> IE;
    /// smart pointer for \ref IE
    typedef boost::shared_ptr<IE> PIE;
    /// \ref TinyIndexElement on the base class
    typedef TinyIndexElement<T> TIE;

    /// smart pointer for \ref TIE
    typedef boost::shared_ptr<TIE> PTIE;
 
    ObjectSet() : myWriteLog(false), myName("") {};
    
    /**
     * Returns the writeLog flag
     */
    bool writesLog() {return myWriteLog;};

    /**
     * unerases
     */
    virtual void unErase(IndexElement<T> *ie) = 0;
   
    /**
     * undoes adding
     */
    virtual void unAdd(IndexElement<T> *ie) {Assert(0,"ObjectSet::unAdd");};
    
    /**
     * assigns a value to a variable
     */
    virtual AssignReturnType assign(Variable var, bool val) = 0;
    
    /**
     * Sets the writeLog flag
     */
    void setWriteLog(bool write) {myWriteLog = write;};
    
    /**
     * returns the number of variables
     */
    virtual long int getVariableNum() = 0;

    /**
     * Adds deduction object to the set.
     */
    virtual void
    add(PT D) = 0;

    /**
     * Add a new variable to index.
     */
    virtual void
    addVariable(Variable var) = 0;

    /**
     * checks that indices are ok
     */
    virtual void checkIndexInvariants() {};
 
    /**
     * Delete all objects
     */
    virtual void clear() = 0;
   
    /**
     * Adds another object set to this one
     */
    virtual void
    addSet(ObjectSet<T> *set) 
    {
      Assert(0,"You have called the addSet() method of the ObjectSet class");
    }
   
    /**
     * Returns the number of positive occurrences of a variable with given number
     */
    virtual long getPositiveOccurrences(long num) {Assert(0,"ObjectSet::getPositiveOccurrences"); return 0;};

   /**
     * Returns the number of negative occurrences of a variable with given number
     */
    virtual long getNegativeOccurrences(long num) {Assert(0,"ObjectSet::getNegativeOccurrences"); return 0;};

   /**
     * Returns the number of unit-clause occurrences of a variable with given number
     */
    virtual long getUnitOccurrences(long num) {Assert(0,"ObjectSet::getUnitOccurrences"); return 0;};

   /**
     * Returns the number of occurrences of a variable with given number
     */
    virtual long getNumberOfOccurrences(long num) {Assert(0,"ObjectSet::getNumberOfOccurrences"); return 0;};


    /**
     * Returns the number of occurrences of a variable with given number in
     * non-unit clauses
     */
    virtual long getNumberOfNonUnitOccurrences(long num) {Assert(0,"ObjectSet::getNumberOfNonUnitOccurrences"); return 0;};
 
    /**
     * get begin iterator on equalities with left-hand sides
     * equal to the variable with given number
     */
    virtual PTIterator getLHSbegin(long num) const
    {
      Assert(0,"You have called the getLHSbegin(long) method of the ObjectSet class");
      return PTIterator(new TIterator());
    }
    
    /**
     * get end iterator on equalities with left-hand sides
     * equal to the given variable
     */
    virtual PTIterator getLHSend(long num) const
    {
      Assert(0,"You have called the getLHSend() method of the ObjectSet class");
      return PTIterator(new TIterator());
    }
    /**
     * get begin iterator on equalities with left-hand sides
     * equal to the given variable
     */
    virtual PTIterator getLHSbegin(Variable &x) const
    {
      Assert(0,"You have called the getLHSbegin(Variable) method of the ObjectSet class");
      return PTIterator(new TIterator());
    }
    /**
     * get begin iterator on equalities with left-hand sides
     * equal to the given variable
     */
    virtual PTIterator getLHSend(Variable &x) const
    {
      Assert(0,"You have called the getLHSend(Variable) method of the ObjectSet class");
      return PTIterator(new TIterator());
    }
   
    /**
     * Removes deduction object given by index element from the set
     */
    virtual void
    remove(IE *it)
    {
      Assert(0,"You have called the remove() method of the ObjectSet class");
    }
   /**
     * Removes deduction object given by iterator from the set
     */
    virtual PTIterator 
    remove(PTIterator& it)
    {
      Assert(0,"You have called the remove() method of the ObjectSet class");
      return PTIterator(new TIterator());
    }
  
    /// test prints an index
    virtual void testPrint(Variable var) 
    {
      Assert(0,"testprint");
    }

    /// test prints an index
    virtual void testPrint(TIndexType type) 
    {
      Assert(0,"testprint");
    }

    /// return begin iterator for a given index
    virtual PTIterator getBegin(TIndexType type)
    {
      Assert(0,"getBegin()");
      return PTIterator(new TIterator());
    }

    /// return end iterator for a given index
    virtual PTIterator getEnd(TIndexType type)
    {
      Assert(0,"getEnd()");
      return PTIterator(new TIterator());
    }
    
    /**
     * Returns the first object whose variables are contained in the given
     * triple.
     */
    virtual PIE getFirstObjectInVars(long x, long y, long z) = 0;

    /**
     * returns the current object whose variables are contained in
     * the triple that was given to \ref getFirstObjectInVars.
     * If \ref getFirstObjectInVars was not given, this function
     * may return garbage!
     */
    virtual PIE currentObjectInVars() = 0;
    
    /**
     * Increases the inner iterator on the variables contained in a given
     * triple and returns the next object.
     */
    virtual PIE nextObjectInVars() = 0;

    /**
     * Checks whether the inner iterator has reached end.
     */
    virtual bool isLastObjectInVars() = 0;
    
    /**
     * returns end iterator on the
     * whole set (our iterator, not
     * std::list::iterator)
     */
    virtual PTIterator getEndIteratorOnWholeSet()
    {
      Assert(0,"You have called the getEndIteratorOnWholeSet() method of the ObjectSet class");
      return PTIterator(new TIterator());
    }

    /**
     * says whether this variable is present in the set
     */
    virtual bool isPresent(long num) = 0;
  
    /**
     * returns begin iterator on the
     * whole set (our iterator, not
     * std::list::iterator)
     */
    virtual PTIterator getBeginIteratorOnWholeSet()
    {
       Assert(0,"You have called the getBeginIteratorOnWholeSet() method of the ObjectSet class");
      return PTIterator(new TIterator());
   }
  
   /// Checks whether an input variable appears in some unit clause in this set. 
   virtual bool isVariableInNonUnitClause(Variable var)
   {
     Assert(0,"You've called IsVarInNonUnitClause() method of the ObjectSet class");
     return false;
   }
  
    /**
     * test for emptiness
     */
    virtual bool isEmpty() = 0;

    /**
     * return the size of the set (in objects)
     */
    virtual long int getSize() = 0;
    
    /// destructor
    virtual ~ObjectSet()
    {
    };
  
    /**
     * return begin std::list::iterator on
     * the whole set
     */
    virtual typename std::list<boost::shared_ptr<TinyIndexElement<T> > >::const_iterator beginWhole() const = 0;

    /**
     * return end std::list::iterator on
     * the whole set
     */
    virtual typename std::list<boost::shared_ptr<TinyIndexElement<T> > >::const_iterator endWhole() const = 0;
    
    /**
     * undelete an object
     */
    virtual void unDeleteObject(PT obj)
    {
      Assert(0,"You have called the unDeleteObject() method of the ObjectSet class");
    }
 
    /**
     * print out the set to the given ostream
     */
    virtual std::ostream& print(std::ostream& os) const = 0;
 
    /// get begin iterator for a given variable number
    virtual PTIterator begin(long int num) const
    {
      Assert(0,"begin(long)");
      return PTIterator(new TIterator());
    }

    /// collects garbage in the indices
    virtual void collectGarbage()
    {
    }

    /// get end iterator for a given variable number
    virtual PTIterator end(long int num) const
    {
      Assert(0,"end(long)");
      return PTIterator(new TIterator());
    }
    
    /**
     * print in html format
     */
    virtual void printHtml(std::ofstream *os, bool firstpage) = 0;

    /// increment size
    virtual void incSize() = 0;

    /// get name
    std::string getName() const {return myName;};

    /// set name
    void setName(std::string name) {myName = name;};

  private:
    /// shows whether this set should generate log entries (\ref LogEntry )
    bool myWriteLog;
    /// name of this set
    std::string myName;
    
  }; // end of class SimpleObjectSet

/**
 * localization of \ref ObjectSet for \ref DeductionObject
 */
typedef ObjectSet<DeductionObject> DeductionObjectSet;
/**
 * smart pointer for \ref DeductionObjectSet
 */
typedef boost::shared_ptr<DeductionObjectSet> PDeductionObjectSet;

/**
 * localization of \ref ObjectSet for \ref ModificationObject
 */
typedef ObjectSet<ModificationObject> ModificationObjectSet;
/**
 * smart pointer for \ref ModificationObjectSet
 */
typedef boost::shared_ptr<ModificationObjectSet> PModificationObjectSet;


#endif

