 /** 
  * @file solve.cc
  * @brief Contains implementations of the main interfaces for solving formulas. 
  */
  
/* @author kulikov */
 
#include "solve.h"
#include "algebraic/algebraic.h"
#include "logical/logical.h"
#include "general/solver.h"
#include "misc/output.h"
#include "backtrack/log.h"
#include "backtrack/simplelog.h"
#include "parse/parser.h"
#include "basicobject/simpleobjectset.h"

int* 
solveCNF(const int* const* const array)
{
  // initializing a solver
  BooleanAlgebraicSolver* solver = new BooleanAlgebraicSolver();

  // parsing a formula
  Parser* parser = new Parser();
  DeductionObjectSet* formula = parser->parseCNF(solver, array);
  
  // solving the formula
  bool satisfiable = solver->solve(formula);
  
  int* result = NULL;

  // creating a satisfying assignment (if any)
  if (satisfiable)
  {
    std::map<long, int>* sat_assignment = solver->getSatAssignment();
    result = new int [sat_assignment->size() + 1];
    std::map<long, int>::iterator it = sat_assignment->begin();
    std::map<long, int>::iterator it_end = sat_assignment->end();
    
    int i = 0;
    
    for (; it != it_end; it++)
      if ((*it).second != -1)
      {
        result[i] = (*it).first;
	if ((*it).second == 0)
	  result[i] *= -1;
        i++;
      }
      
    result[i] = 0;
  }
  
  // destructing all initialized structures
  delete formula;
  delete solver;
  delete parser;
    
  // returning
  return result;
}


int* 
solveCNF(const char* file_name)
{
  // initializing a solver
  BooleanAlgebraicSolver* solver = new BooleanAlgebraicSolver();

  // parsing a formula
  Parser* parser = new Parser();
  DeductionObjectSet* formula = parser->parseCNF(solver, file_name);

  // solving a formula
  bool satisfiable = solver->solve(formula);

  int* result = NULL;

  // creating a satisfying assignment (if any)
  if (satisfiable)
  {
    std::map<long, int>* sat_assignment = solver->getSatAssignment();
    result = new int [sat_assignment->size() + 1];
    std::map<long, int>::iterator it = sat_assignment->begin();
    std::map<long, int>::iterator it_end = sat_assignment->end();
    
    int i = 0;
    
    for (; it != it_end; it++)
      if ((*it).second != -1)
      {
        result[i] = (*it).first;
	if ((*it).second == 0)
	  result[i] *= -1;
        i++;
      }
      
    result[i] = 0;
  }
  
  // destructing all initializing structures
  delete formula;
  delete parser;
  delete solver;
 
  // returning
  return result;
}


bool 
checkEquivalence(const char* file_name1, const char* file_name2)
{
  // initializing a solver
  BooleanAlgebraicSolver* solver = new BooleanAlgebraicSolver();

  // parsing a formula
  Parser* parser = new Parser();
  DeductionObjectSet* formula = parser->parseTwo(solver, file_name1, file_name2, true);
  
  // solving a formula
  bool satisfiable = solver->solve(formula);
  
  // destructing all initialized structures
  delete formula;
  delete parser;
  delete solver;

  // returning 
  return !satisfiable;
}


bool 
solve(const char* file_name1, const char* file_name2)
{
  // initializing a solver
  BooleanAlgebraicSolver* solver = new BooleanAlgebraicSolver();

  // parsing a formula
  Parser* parser = new Parser();
  DeductionObjectSet* formula = parser->parseTwo(solver, file_name1, file_name2, false);

  // solving a formula
  bool satisfiable = solver->solve(formula);

  // destructing all initialized structures
  delete formula;
  delete parser;
  delete solver;

  // returning
  return satisfiable;
}

