#ifndef __LOGENTRY_H__
#define __LOGENTRY_H__

#include "boost/smart_ptr.hpp"
#include "../misc/statistics.h"

/**
 * @file logentry.h
 * @brief Declares the LogEntry class
 * @author sergey
 */
 
/**
 * Forward declarations
 */
class LogEntry;
class BooleanAlgebraicSolver;
/**
 * smart pointer for \ref LogEntry
 */
typedef boost::shared_ptr<LogEntry> PLogEntry;

/**
 * @class LogEntry
 * @brief This class is intended to store information 
 * for undoing modifications with the logging mechanism.   
 */
class LogEntry
{
public:

  /**
   * constructor
   */
  LogEntry() {};
  /**
   * destructor
   */
  virtual ~LogEntry() {};
  /**
   * prints out the entry
   */
  virtual std::ostream& print(std::ostream&,BooleanAlgebraicSolver *) const = 0;
  /**
   * undo the recorded action
   */
  virtual void unDo() = 0;
};

#endif
