#include "simplelog.h"

/* @author sergey */

/**
 * @file simplelog.cc
 * @brief Implements the SimpleLog class
 */

SimpleLog::~SimpleLog()
{
  myEntryList.clear();
  mySize = 0;
};

unsigned int SimpleLog::getBookmark() const
{
  return mySize;
};

void SimpleLog::getBackTo(unsigned int bmNumber)
{
  PLogEntry le;
  while (mySize != bmNumber)
  {
    le = *(myEntryList.rbegin());
    le->unDo();
    myEntryList.pop_back();
    --mySize;
    if ((mySize != bmNumber) && le) delete le;
 };
};

void SimpleLog::addEntry(PLogEntry mod)
{
  myEntryList.push_back(mod);
  ++mySize;
}

