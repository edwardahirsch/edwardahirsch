#ifndef __SIMPLEBOOKMARK_H__
#define __SIMPLEBOOKMARK_H__

#include "boost/smart_ptr.hpp"
#include "bookmark.h"

/**
 * @file simplebookmark.h
 * @brief Declares the SimpleBookmark class
 * @author sergey
 */

/**
 * Forward declarations
 */
class SimpleBookmark;
/**
 * smart pointer for \ref SimpleBookmark
 */
typedef boost::shared_ptr<SimpleBookmark> PSimpleBookmark;

/**
 * @class SimpleBookmark
 * @brief This class stores an information about 
 * state of a formula as a number of modifications of 
 * a formula.  
 */
class SimpleBookmark : public Bookmark
{
public:
  /**
   * constructor
   */
  SimpleBookmark(int n) : myNumber(n) {};

  /**
   * destructor
   */
  virtual ~SimpleBookmark() {};
  
  /**
   * equality test
   */
  virtual bool operator==(PBookmark) const;
  
  /**
   * return the number corresponding to this bookmark
   */
  unsigned int getNumber() const {return myNumber;};
  
private:
  /// the number this bookmark represents`
  unsigned int myNumber;
};

#endif
