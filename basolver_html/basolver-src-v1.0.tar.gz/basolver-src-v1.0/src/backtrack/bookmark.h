#ifndef __BOOKMARK_H__
#define __BOOKMARK_H__

#include "boost/smart_ptr.hpp"

/**
 * @file bookmark.h
 * @brief Declares the Bookmark class
 * @author sergey
 */

/**
 * Forward declarations
 */
class Bookmark;

/**
 * smart pointer for \ref Bookmark
 */
typedef boost::shared_ptr<Bookmark> PBookmark;

/**
 * @class Bookmark
 * @brief This class stores an information about 
 * state of our log. Having this bookmark a user 
 * can always return to this state.
 */
class Bookmark
{
public:

  /**
   * constructor
   */
  Bookmark() {};

  /**
   * return the corresponding number
   */
  virtual unsigned int getNumber() const = 0;
  
  /**
   * equality test
   */
  virtual bool operator==(PBookmark) const = 0;
};

/// smart pointer for \ref Bookmark
typedef boost::shared_ptr<Bookmark> PBookmark;

#endif
