#include "simplebookmark.h"

/* @author sergey */

/**
 * @file simplebookmark.cc
 * @brief Implements the SimpleBookmark class
 */

/**
 * equality test
 */
bool SimpleBookmark::operator==(PBookmark bm) const
{
  PSimpleBookmark simple_bm = 
    boost::shared_dynamic_cast<SimpleBookmark, Bookmark>(bm);
    
  return (simple_bm->myNumber == this->myNumber);
};



