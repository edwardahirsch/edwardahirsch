#include "simplelogentry.h"
#include "../general/solver.h"

/* @author sergey */

/**
 * @file simplelogentry.cc
 * @brief Contains implementation of the methods defined in simpleformod.h 
 */


void AddingVariable::unDo()
{
  VarList::iterator vbeg = myVarList->begin();
  while (vbeg != myVarList->end()) ++vbeg;
  if (vbeg!= myVarList->end()) myVarList->erase(vbeg);
};

void DeletingVariable::unDo()
{
  mySolver->setVarValue(myVariable,-1);
};

