#include "log.h"

/* @author sergey */

Log* globalLog;

