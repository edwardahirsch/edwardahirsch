#ifndef __SIMPLELOGENTRY_H__
#define __SIMPLELOGENTRY_H__

#include "boost/smart_ptr.hpp"
#include "logentry.h"
#include "../basicobject/object.h"
#include "../misc/tracer.h"
#include "../algebraic/abstract/variable.h"


/**
 * @file simplelogentry.h
 * @brief Declares children of the abstract LogEntry class.
 * @author sergey
 */

template <class T>
class ObjectSet;

/**
 * @class AddingDeductionObject
 * @brief This class stores information for undoing 
 * the operation of adding a deduction object to a set.
 */
template <class T>
class AddingDeductionObject : public LogEntry
{
public:

  /**
   * typedef for \ref IndexElement on this template's base class
   */
  typedef IndexElement<T> IE;
  
  /**
   * constructor
   */
  AddingDeductionObject(ObjectSet<T> *f, IE *c) : mySet(f), myObject(c) {};

  /**
   * destructor
   */
  ~AddingDeductionObject() {};

  /**
   * print out the entry
   */
   std::ostream& print(std::ostream& os, BooleanAlgebraicSolver *slv) const {
     os << "This is AddObj for ";
     myObject->getObject()->print(os,slv);
     os << "\n"; return os;
   }
  
   /**
    * undo
    */
  void unDo() {
    mySet->unAdd(myObject); 
    myObject->unAdd();
  };
  
private:
  /**
   * a reference to the set to which the object was added
   */
  ObjectSet<T> *mySet;
  /**
   * the element in question
   */
  IndexElement<T> *myObject; 
};

/**
 * @class AddingVariable
 * @brief This class stores information for undoing 
 * the operation of adding a variable to a formula.
 */
class AddingVariable : public LogEntry
{
public:
  /**
   * constructor
   */
  AddingVariable(BooleanAlgebraicSolver *slv, VarList *f, Variable v) : mySolver(slv), myVarList(f), myVariable(v) {};

  /**
   * destructor
   */
  ~AddingVariable() {};

  /**
   * print out the object
   */
   std::ostream& print(std::ostream& os,BooleanAlgebraicSolver *slv) const {os << "This is AddVar for " << myVariable << "\n"; return os;}
  
  /**
   * undo
   */
  void unDo();
  
private:
  /// solver
  BooleanAlgebraicSolver *mySolver;
  /**
   * a reference to the general list of variables
   */
  VarList *myVarList;
  /**
   * the variable in question
   */
  Variable myVariable; 
};

/**
 * @class DeletingVariable
 * @brief This class stores information for undoing 
 * the operation of deleting a variable to a formula.
 */
class DeletingVariable : public LogEntry
{
public:
 
  /// constructor
  DeletingVariable(BooleanAlgebraicSolver *slv, VarList *vlist, Variable v) : mySolver(slv), myVarList(vlist), myVariable(v) {};

  /**
   * destructor
   */
  ~DeletingVariable() {};

  /**
   * print
   */
  std::ostream& print(std::ostream& os, BooleanAlgebraicSolver *slv) const {os << "This is DelVar for " << myVariable << "\n"; return os;}
 
  /**
   * undo
   */
  void unDo();
  
private:
  /// solver
  BooleanAlgebraicSolver *mySolver;
  /**
   * a reference to the general list of variables
   */
  VarList *myVarList;
  /**
   * the variable in question
   */
  Variable myVariable; 
};

/// smart pointer for \ref DeletingVariable
typedef boost::shared_ptr<DeletingVariable> PDeletingVariable;


/**
 * @class DeletingDeductionObject
 * @brief This class stores information for undoing 
 * the operation of deleting an object from a set.
 */
template <class T>
class DeletingDeductionObject : public LogEntry
{
public:
  /**
   * constructor
   */
  DeletingDeductionObject(ObjectSet<T> &f, IndexElement<T> *c) : mySet(&f) {
    myObject = c;
  }

  /**
   * destructor
   */
  ~DeletingDeductionObject() {};

  /**
   * print
   */
  std::ostream& print(std::ostream& os, BooleanAlgebraicSolver *slv) const {
     os << "This is DelObj for ";
     myObject->getObject()->print(os,slv);
     os << "\n"; return os;
   }  
  
   /**
    * undo
    */
   void unDo() {
     myObject->unErase();
     };
  
private:
  /**
   * a reference to the set from which the object was deleted
   */
  ObjectSet<T> *mySet;
  /**
   * the index element in question
   */
  IndexElement<T> *myObject; 
};

/**
 * smart pointer for \ref AddingVariable
 */
typedef boost::shared_ptr<AddingVariable> PAddingVariable;
/**
 * smart pointer for \ref DeletingVariable
 */
typedef boost::shared_ptr<DeletingVariable> PDeletingVariable;
#endif
