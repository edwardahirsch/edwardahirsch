#ifndef __LOG_H__
#define __LOG_H__

#include "boost/smart_ptr.hpp"

#include "bookmark.h"
#include "logentry.h"

/**
 * @file log.h
 * @brief Declares the Log class
 * @author sergey
 */

/**
 * Forward declarations
 */
class Log;
class BooleanAlgebraicSolver;
/**
 * smart pointer for \ref Log
 */
typedef boost::shared_ptr<Log> PLog;

/**
 * @class Log
 * @brief This class stores an information about all 
 * modifications made with a formula. 
 * @author sergey  
 */
class Log
{
public:
  /**
   * Empty constructor
   */
  Log() {};
  /**
   * Empty virtual destructor.
   */
  virtual ~Log() {};
  
  /**
   * Adds an entry to the log.
   */
  virtual void addEntry(PLogEntry) = 0;
  
  /**
   * Returns the current state of the log. 
   */
  virtual unsigned int getBookmark() const = 0;
  /**
   * Gets back to the input bookmark
   */
  virtual void getBackTo(unsigned int) = 0;
  
protected:

  /// solver
  BooleanAlgebraicSolver *mySolver;
  
};

#endif
