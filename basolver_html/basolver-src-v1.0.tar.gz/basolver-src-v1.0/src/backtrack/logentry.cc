#include "logentry.h"

/* @author sergey */

/*std::ostream& operator << (std::ostream& os, const LogEntry& le)
{
  return le.print(os);
}*/
