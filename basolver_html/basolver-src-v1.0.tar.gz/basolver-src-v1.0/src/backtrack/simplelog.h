#ifndef __SIMPLELOG_H__
#define __SIMPLELOG_H__

#include "log.h"
#include "simplebookmark.h"
#include "logentry.h"
#include "boost/smart_ptr.hpp"
#include <list>
#include "../misc/tracer.h"

using namespace std;

/**
 * @file simplelog.h
 * @brief Declares the Log class
 * @author sergey
 */

class Bookmark;
/**
 * smart pointer for \ref Bookmark
 */
typedef boost::shared_ptr<Bookmark> PBookmark;

/**
 * @class SimpleLog
 * @brief This class stores an information about all 
 * modifications made with a formula as a simple list 
 * of 
 */
class SimpleLog : public Log
{
public:
  /**
   * constructor
   */
  SimpleLog(BooleanAlgebraicSolver *solver)  {mySolver = solver; mySize = 0;};

  /**
   * destructor
   */
  ~SimpleLog();
  
  /**
   * add an entry to a log
   */
  void addEntry(PLogEntry mod);
  
  /**
   * Returns the current state of a formula. 
   */
  unsigned int getBookmark() const;

  /**
   * Gets a formula back to the input state.
   */
  void getBackTo(unsigned int);
  
private:
  /// list of \ref LogEntry 
  std::list<PLogEntry> myEntryList;
  /// size of the list
  unsigned long mySize;
};

/**
 * smart pointer for \ref SimpleLog
 */
typedef boost::shared_ptr<SimpleLog> PSimpleLog;

#endif
