#include "solver.h"
#include "../getopt/options.h"
#include "../misc/output.h"
#include "../misc/ruleschecker.h"
#include "../basicobject/simpleobjectset.h"
#include "../basicobject/trivialobjectset.h"
#include "rules/simplification/literalsubstitutionrule.h"
#include "rules/simplification/strongnormalizerule.h"
#include "backtrack/simplelog.h"
#include "variablestatistics.h"
#include "parse/rtlparser.h"
#include "logical/implementation/simpleassignment.h"
#include <string>


#include "../getopt/options.h"
#include "../misc/output.h"

#include "basicobject/simpleobjectset.h"
#include "basicobject/trivialobjectset.h"

#include "rules/simplification/literalsubstitutionrule.h"
#include "rules/simplification/monomialsubstitutionrule.h"
#include "rules/simplification/smartcircuitformtranslation.h"
#include "rules/simplification/binclproc4.h"
#include "rules/simplification/singleocc.h"
#include "rules/simplification/pureliteral.h"
#include "rules/simplification/gatesequiv2.h"
#include "rules/simplification/backt2subst.h"
#include "rules/generation/backlin2.h"
#include "rules/generation/linearization2rule.h"
#include "rules/generation/or3generationrule.h"
#include "rules/generation/xor3generationrule.h"
#include "rules/generation/ororrule.h"
#include "rules/simplification/lin3rule.h"
#include "rules/simplification/subsumption.h"
#include "rules/generation/summationrule.h"
#include "rules/generation/xorsummation.h"
#include "rules/generation/summation2.h"
#include "rules/simplification/strongnormalizerule.h"
#include "rules/generation/or3generationrule2.h"
#include "rules/abstract/generic.h"
#include "rules/generation/orxor3.h"
#include "rules/generation/xoror2part1.h"
#include "rules/generation/xoror2part2.h"
#include "rules/generation/xoror2part3.h"
#include "rules/generation/boothsub.h"
#include "rules/generation/linxorrule.h"
#include "getopt/options.h"
#include <string>



/* @author kulikov */

using namespace std;


/**
 * @file solver.cc
 * @brief Contains implementation of several methods of BooleanAlgebraicSolver.
 */

BooleanAlgebraicSolver::BooleanAlgebraicSolver()
{
  simplifying_by_mod_now = false;
  simplify_by_new_modifiers = true;
    
#ifdef DEBUG
  mydelta = std::vector<int>(30,0);
  myLastChanged = std::vector<int>(30, 0);
  myStatIteration = 0;
  began_split = false;
#endif

  mySolverOptions = new SolverOptions();
  myLog = new SimpleLog(this);
  myStatistics = new Statistics();
  myOutput = new Output(this);
  varNames = new std::map<long,std::string>;
  myListOfDeductionObjectSets = new std::list<DeductionObjectSet *>; 
  myListOfModificationObjectSets = new std::list<ModificationObjectSet *>;
  myVarList = new std::list<Variable>;
  mySatAssignmentMap = 0;
  
  // creating metarules
  myMetaSimplificationRule = (new MetaSimplificationRule(this));
  myMetaGenerationRule = (new MetaGenerationRule(this));
  myLitSubstRule = new LiteralSubstitutionRule(this);
  myStrongNormRule = new StrongNormalizeRule(this);
  
  // creating transfer rule
  myTransferRule = (new TransferRule(this));

  this->fillMetaRules();  
  
  currentTreeDepth = 0;
  
  
  TRACE("testsatassignment",
    myKnownSatAssignment = 0;
    myKnownSatAssignment = new SimpleAssignment();
    ifstream* myFile = new ifstream("assignment");
    if (!(*myFile))
    {
      cerr << "\nNo assignment file";
      exit(-1);
    }
    
    int a = 1;
    (*myFile) >> a;
    while (a != 0)
    {
      myKnownSatAssignment->addLiteral(abs(a), a>0 ? 1 : 0);
      (*myFile) >> a;
    }
    
    std::cerr << "\nTesting this assignment: ";
    myKnownSatAssignment->print(cerr);
    
    delete myFile;
  );
  
}

std::ostream& BooleanAlgebraicSolver::printVar(std::ostream& os, long v) 
{
  std::map<long,std::string>::iterator it = varNames->find(v); 
  if (it != varNames->end())
    os << (*it).second;
  else
    os << "p" << v;
  return os;
}

void BooleanAlgebraicSolver::printVar(std::ostream *os, long v) 
{
  std::map<long,std::string>::iterator it = varNames->find(v); 
  if (it != varNames->end())
    *os << (*it).second;
  else
    *os << "p" << v;
}

void BooleanAlgebraicSolver::setVarValue(long v, int val)
{
  std::map<long,int>::iterator it = varValues.find(v);
  if (it != varValues.end())
    (*it).second = val;
  else
  {
    std::pair<long,int> pair;
    pair.first = v; pair.second = val;
    varValues.insert(pair);
  }
}

int BooleanAlgebraicSolver::getVarValue(long v)
{
  std::map<long,int>::iterator it = varValues.find(v);
  if (it != varValues.end())
    return (*it).second;
  else
    return -1;
}

void BooleanAlgebraicSolver::setVarPriority(long v, int val)
{
  std::map<long,int>::iterator it = varPriorities.find(v);
  if (it != varPriorities.end())
    (*it).second = val;
  else
  {
    std::pair<long,int> pair;
    pair.first = v; pair.second = val;
    varPriorities.insert(pair);
  }
}

int BooleanAlgebraicSolver::getVarPriority(long v)
{
  std::map<long,int>::iterator it = varPriorities.find(v);
  if (it != varPriorities.end())
    return (*it).second;
  else
    return 0;
}

void BooleanAlgebraicSolver::printVarList(std::ostream& os, PVarList vlist)
{
  std::list<Variable>::iterator it = vlist->begin();
  while (it != vlist->end())
  {
    printVar(os, *it);
    os << " ";
  }
}

Statistics *BooleanAlgebraicSolver::getStats() {return myStatistics;};
Output *BooleanAlgebraicSolver::getOutput() {return myOutput;};
Log *BooleanAlgebraicSolver::getLog() {return myLog;};
long BooleanAlgebraicSolver::getNextId() {return myOutput->getNextId();};

void BooleanAlgebraicSolver::clear()
{
  for (list<DeductionObjectSet*>::iterator ded_set_it = myListOfDeductionObjectSets->begin();
  ded_set_it != myListOfDeductionObjectSets->end(); ded_set_it++)
  {
    (*ded_set_it)->clear();
  }
    
  myListOfDeductionObjectSets->clear();

  for (list<ModificationObjectSet*>::iterator mod_set_it = myListOfModificationObjectSets->begin();
  mod_set_it != myListOfModificationObjectSets->end(); mod_set_it++)
  {
    (*mod_set_it)->clear();
  }
    
  myListOfModificationObjectSets->clear();
  myVarList->clear();
  varNames->clear();
  varValues.clear();
  varPriorities.clear();
 
}

BooleanAlgebraicSolver::~BooleanAlgebraicSolver()
{
  // cleaning and deleting the sets
   
  for (list<DeductionObjectSet*>::iterator ded_set_it = myListOfDeductionObjectSets->begin();
  ded_set_it != myListOfDeductionObjectSets->end(); ded_set_it++)
  {
    (*ded_set_it)->clear();
    (*ded_set_it) = 0;
    delete (*ded_set_it);
  }
    
  myListOfDeductionObjectSets->clear();
  delete myListOfDeductionObjectSets;

  for (list<ModificationObjectSet*>::iterator mod_set_it = myListOfModificationObjectSets->begin();
  mod_set_it != myListOfModificationObjectSets->end(); mod_set_it++)
  {
    (*mod_set_it)->clear();
    (*mod_set_it) = 0;
    delete (*mod_set_it);
  }
    
  myListOfModificationObjectSets->clear();
  delete myListOfModificationObjectSets;
  
  // deleting the rules
  delete myMetaSimplificationRule;
  delete myMetaGenerationRule;
  delete myTransferRule;
  delete myLitSubstRule;
  delete myStrongNormRule;

  delete myVarList;

  varValues.clear();
  varPriorities.clear();
  if (mySatAssignmentMap)
  {
    mySatAssignmentMap->clear();
    delete mySatAssignmentMap;
  }
  
  delete mySolverOptions;
 
  delete varNames;  
  delete myLog;
  delete myStatistics;
  delete myOutput;
  
  TRACE("testsatassignment",
  if (myKnownSatAssignment)
    delete myKnownSatAssignment;
  );
    
  if (myDedWrapperSet)
    delete myDedWrapperSet;
  if (myDedWrapper2Set)
    delete myDedWrapper2Set;
  if (myDedWrapper3Set)
    delete myDedWrapper3Set;
  if (myNewNewObjects)
    delete myNewNewObjects;
    
  if (myModifiers)
    delete myModifiers;
}

void BooleanAlgebraicSolver::collectGarbage()
{
  std::list<DeductionObjectSet *>::iterator it = this->getListOfDeductionObjectSets()->begin();
  std::list<DeductionObjectSet *>::iterator end = this->getListOfDeductionObjectSets()->end();
  
  while (it != end)
  {
    (*it)->collectGarbage();
    ++it;
  }
  
  std::list<ModificationObjectSet *>::iterator mit = this->getListOfModificationObjectSets()->begin();
  std::list<ModificationObjectSet *>::iterator mend = this->getListOfModificationObjectSets()->end();
  
  while (mit != mend)
  {
    (*mit)->collectGarbage();
    ++mit;
  }
}


void 
BooleanAlgebraicSolver::calculateSatAssignment()
{
  // Note that we assume that all modifiers are in myModifiers

  // map stores variable values; special value "-1" is
  // for non-independent unassigned variable
  mySatAssignmentMap = new std::map<long, int>; 

  // we will cycle through all modifiers
  PModificationObjectIterator cur_mod;
  PModificationObjectIterator mod_end;

  // first of all, mark non-independent unassigned variables
  cur_mod = myModifiers->getBeginIteratorOnWholeSet();
  mod_end = myModifiers->getEndIteratorOnWholeSet();
  for(;!(cur_mod->equals(*mod_end)); ++(*cur_mod))
  {
    PEquality eq=boost::shared_dynamic_cast<Equality, ModificationObject>(**cur_mod);
    if (eq->getMainVar() > 0)
    {
       mySatAssignmentMap->insert(std::make_pair(eq->getMainVar(),-1));
    }
  }
  // repeat everything until no variable was set
  bool newvalue;
  do { 
    newvalue = false;
    // cycle extracting Boolean modifiers and substituting their values
    bool smthassigned;
    do {
      smthassigned = false;
      // scan for Boolean modifiers
      cur_mod = myModifiers->getBeginIteratorOnWholeSet();
      mod_end = myModifiers->getEndIteratorOnWholeSet();
      for(;!(cur_mod->equals(*mod_end)); )
      {
        PEquality eq=boost::shared_dynamic_cast<Equality, ModificationObject>(**cur_mod);
        if (eq->isBoolean())
        {
           mySatAssignmentMap->erase(eq->getBooleanVariable());
           mySatAssignmentMap->insert(std::make_pair(eq->getBooleanVariable(),eq->getBooleanSign()));
           cur_mod=myModifiers->remove(cur_mod);
        }
        else
          ++*cur_mod;
      }
      // simplify everything by our values
      cur_mod = myModifiers->getBeginIteratorOnWholeSet();
      mod_end = myModifiers->getEndIteratorOnWholeSet();
      for(;!(cur_mod->equals(*mod_end)); ++(*cur_mod))
      {
        PEquality eq=boost::shared_dynamic_cast<Equality, ModificationObject>(**cur_mod);
        bool assigned;
        PVarList vl;
        std::list<Variable>::iterator vbeg; 
        std::list<Variable>::iterator vend; 
        do
        {
          assigned=false;
          vl = eq->getVariableList();
          vbeg = vl->begin();
          vend = vl->end();
          for (;vbeg!=vend;vbeg++)
          {
    	    std::map<long, int>::iterator it1=mySatAssignmentMap->find(*vbeg);
            if (it1!=mySatAssignmentMap->end()) if ((*it1).second != -1)
            {
              eq->assign(*vbeg,(*it1).second);
              assigned=true;
              smthassigned=true;
              break;
            }
          }
        } while (assigned);
      }
    } while (smthassigned);
    // take transitive closure of non-independent variables
    bool changed_tc;
    do
    {
      changed_tc = false;
      cur_mod = myModifiers->getBeginIteratorOnWholeSet();
      mod_end = myModifiers->getEndIteratorOnWholeSet();
      for(;!(cur_mod->equals(*mod_end)); ++(*cur_mod))
      {
        PEquality eq=boost::shared_dynamic_cast<Equality, ModificationObject>(**cur_mod);
        if (!eq->isBoolean()) if (eq->getMainVar() == 0)
         { 
          PVarList vl = eq->getVariableList();
          if (vl->size() == 2)
          {
            std::list<Variable>::iterator vbeg = vl->begin();
            Variable var1=*vbeg;
            Variable var2=*(++vbeg);
    	    std::map<long, int>::iterator it1=mySatAssignmentMap->find(var1);
    	    std::map<long, int>::iterator it2=mySatAssignmentMap->find(var2);
       	    if (it1==mySatAssignmentMap->end()) // 1st variable is independent
              {
                if (it2!=mySatAssignmentMap->end()) // 2nd variable is non-independent
                {
                  changed_tc = true;
                  mySatAssignmentMap->insert(std::make_pair(var1,-1));
                }
              }
              else if (it2==mySatAssignmentMap->end()) // 2nd variable is independent, 1st is not
              {
                changed_tc = true;
                mySatAssignmentMap->insert(std::make_pair(var2,-1));
              }
            }
        }
      }
    }
    while (changed_tc);

   std::map<long, int>::iterator it=mySatAssignmentMap->begin();
    // take an independent variable and simplify everything by it
    for(VarList::iterator vit=myVarList->begin(); vit!=myVarList->end();++vit)
    {
      std::map<long, int>::iterator it=mySatAssignmentMap->find((*vit));
      if (it==mySatAssignmentMap->end()) //found it!
      {
        newvalue = true;
        mySatAssignmentMap->erase(*vit);
        mySatAssignmentMap->insert(std::make_pair(*vit,1));
        break;
      }
    }
  } while (newvalue);

};

void
BooleanAlgebraicSolver::printSatAssignment()
{
  std::cout << "s SATISFIABLE\n";
  std::map<long, int>::iterator it=mySatAssignmentMap->begin();
  int i=0;
  // We print only in_line values on one line
  const int in_line=10;
  // Printing sat assignment (see Sat Competition rules)
  
  if (this->mySolverOptions->myFileName2.size() == 0)
  // cnf 
  {
  for(;it!=mySatAssignmentMap->end();++it) if ((*it).second != -1)
  {
    i++;
    if (i==1) std::cout << "v ";
    if (! (*it).second) std::cout << "-";
    std::cout << (*it).first <<" ";
    if (i==in_line)
    {
      i=0;
      std::cout <<"\n";
    };  
  };
  if (i==0) std::cout <<"v ";
  std::cout <<"0\n";
  }
  else
  {
    for(;it!=mySatAssignmentMap->end();++it) if ((*it).second != -1)
    {
      string name = (*(this->varNames->find((*it).first))).second;
      i++;
      if (i==1) std::cout << "v ";
      std::cout << name << "=" << (*it).second << " ";
      if (i==in_line)
      {
        i=0;
        std::cout <<"\n";
      };  
    };
    if (i==0) std::cout <<"v ";
    std::cout <<"0\n";
  }
}


std::pair<Variable,int> BooleanAlgebraicSolver::getNextLiteral()
{
  VarList::iterator varit = myVarList->begin(), varend = myVarList->end();
  Assert(myVarList->rbegin() != myVarList->rend(), "No more variables...");

  VariableStatistics statbest, // initialized by its constructor
                     statcur;

  Variable varbest=0;

  for ( ; varit != varend ; varit++)
    if (getVarValue(*varit) < 0) // check all UNASSIGNED variables
    {
      // Fill statcur
      statcur.occTotal=myClauses->getNumberOfOccurrences(*varit);
      statcur.occIn2Clauses=
	(statcur.occIn3Clauses=
	(statcur.occInBClauses=
        (statcur.occInXeqABasX=
        (statcur.occInXeqABasAB=
        (statcur.occInABeq0=
        (statcur.occInt11m2=
        (statcur.occInt124=
        (statcur.occIn3VarsSpecial=
        (statcur.occAllNice=
        (statcur.recent=
	0))))))))));

      statcur.pri=getVarPriority(*varit);

  
      // The following code is repeated from variablestatistics.cc for optimization
  
      // if a variable does not occur, we do not need it anyway
      if (statcur.occTotal==0) { ; }
      else if ((statcur.pri > statbest.pri) && (statbest.occTotal!=0)) { ; }
      else
      //  end of the repeated code
      {
        PDeductionObjectIterator clsit=myClauses->begin(*varit);
        PDeductionObjectIterator clsend=myClauses->end(*varit);
        for (; !(clsit->equals(*clsend)); ++(*clsit)) 
        //search for clauses of various types containing *varit 
        {
          PSAClause myclause = (((boost::shared_dynamic_cast<SAClause,DeductionObject>(**clsit))));
  
          if (myclause->isBoolean()) 
          {
            statcur.occInBClauses++;
            statcur.occAllNice++;
            switch (myclause->getNumberOfLiterals())
            {
              case 2: statcur.occIn2Clauses++; break;
              case 3: statcur.occIn3Clauses++; break;
            }
          }
          else
          {
            Assert((myclause->hasOneEquality()), "getNextLiteral(): non-Boolean clause contains several equalities?!");
            PEquality eq = myclause->getEquality();
            switch(eq->getEqType())
            {
              case eqtXeqAB: 	
	        if (eq->getVar1()==*varit) statcur.occInXeqABasX++;
  	        else statcur.occInXeqABasAB++;
                statcur.occAllNice++;
                if ((**clsit)->getId() > statcur.recent) 
                statcur.recent=(**clsit)->getId();
	        break;
          
	      case eqtABeq0:	
	        statcur.occInABeq0++; 
                statcur.occAllNice++;
                if ((**clsit)->getId() > statcur.recent) 
                statcur.recent=(**clsit)->getId();
	        break;
          
	      case eqt11m2:	
	        statcur.occInt11m2++;
                statcur.occAllNice++;
                if ((**clsit)->getId() > statcur.recent) 
                statcur.recent=(**clsit)->getId();
	        break;
          
	      case eqt124:	
	        statcur.occInt124++; 
	        break;
          
	      case Special:	
	        if ((eq->getVariableList())->size()==3)
	        {
                  statcur.occIn3VarsSpecial++;
	          if (eq->getRHS()->getDegree()<=1)
                  statcur.occAllNice++;
                  if ((**clsit)->getId() > statcur.recent) 
                  statcur.recent=(**clsit)->getId();
	        }
	        else
                {
                  if ((eq->getVariableList())->size()<3)
	          {
	            statcur.occIn3VarsSpecial+=2;
                    statcur.occAllNice++;
                    if ((**clsit)->getId() > statcur.recent) 
                    statcur.recent=(**clsit)->getId();
	          }
                  Assert(((eq->getVariableList())->size()>3), "getNextLiteral(): short equality of unknown type");
                }
	        break;
            
	      default: 
	        break; // do nothing for complicated types
        
	    } // end of switch(eq->getEqType())
      
          } // end of if (myclause->isBoolean()) 
    
        } // end of searching for clauses of various types containing *varit 

        // Check whether it is better than statbest, and copy everything if so
        if (statbest.isBetter(statcur))
        {
          statbest=statcur;
          varbest=*varit;
          TRACE("nextlit", std::cerr << "New best: " << 
            (*(varNames->find(varbest))).second
	    <<" P: " << statcur.pri
    	    <<" R: " << statcur.recent
    	    <<" 2-cl: " << statcur.occIn2Clauses
    	    <<" 3-cl: " << statcur.occIn3Clauses
    	    <<" B-cl: " << statcur.occInBClauses
            <<" Xeqab: " <<  statcur.occInXeqABasX
	    <<" xeqAB: " << statcur.occInXeqABasAB
            <<" ABeq0: " << statcur.occInABeq0
	    <<" t11m2: " << statcur.occInt11m2
    	    <<" t124: " << statcur.occInt124
            <<" 3Spec: " << statcur.occIn3VarsSpecial
	    <<" AllNice: " << statcur.occAllNice
            <<" Total: " << statcur.occTotal
	    << "\n";); // end of trace
        } // end of checking whether it is better than statbest, and copy everything if so
    
      }
    
    } // end of checking all UNASSIGNED variables

  std::pair<Variable,int> res;
  res.first = varbest; 
  Assert(res.first>0, "getNextLiteral(): No variable for splitting.");
  res.second = 1; 

  // Search through myClauses and count how much would we get from setting
  // this literal to one. We omit some derived and complicated equalities.
  int positive=0;
  PDeductionObjectIterator ithk, itend;
  ithk=myClauses->begin(varbest);
  itend=myClauses->end(varbest);
  for (; !(ithk->equals(*itend)); ++(*ithk)) 
  {
    PSAClause myclause = (((boost::shared_dynamic_cast<SAClause,DeductionObject>(**ithk))));
    Variable x,a,b;
    bool sx,sa,sb;   //signs of x,a,b
    if (myclause->isBoolean()) 
    {
      SALiteralIterator itclause=myclause->begin();
      SALiteralIterator itclauseend=myclause->end();
      PEquality eq; 
      
      for (;itclause!=itclauseend ;itclause++)
      {
        eq = boost::shared_dynamic_cast<Equality,SALiteral>(*itclause);
        if (eq->getLHS()->getVariable()==varbest)
        {
          switch(myclause->getNumberOfLiterals())
          { 
            case 2: positive += 2*(1-2*eq->getRHS()->getFirstConstant()); break;
            case 3: positive += (2*eq->getRHS()->getFirstConstant()-1); break;
            default: positive += 2*(2*eq->getRHS()->getFirstConstant()-1);
          }
          break;
        }
      }
      
    } // end of if (myclause->isBoolean()) 
    else if (((myclause->getEquality())->getXeqAB(x,sx,a,sa,b,sb)))
    {
      if (x==varbest) 
        positive+=sx*4-2; // will get values of two more variables
    }
    else if (((myclause->getEquality())->getEqType()==eqtABeq0))
    {
      a=myclause->getEquality()->getVar1();
      sa=myclause->getEquality()->getPos1();
      b=myclause->getEquality()->getVar2();
      sb=myclause->getEquality()->getPos2();
      if (a==varbest) positive+=2*sa-1;
      else 
      {
        Assert((b==varbest),"getNextLiteral(): b!=varbest in ABeq0");
        positive+=2*sb-1;
      }
    }
  } // end of for (; !(ithk->equals(*itend)); ++(*ithk)) 
  
  res.second = (positive > 0); 
  return res; 
}


void 
BooleanAlgebraicSolver::simplifyAllObjectsByNewModifiers()
{
  if (simplifying_by_mod_now)
    return;
    
    
  simplifying_by_mod_now = true;  

  
  while (myTempModSet->getSize() != 0)
  {
    PModificationObjectIterator it = myTempModSet->getBeginIteratorOnWholeSet();
    myModWrapperSet->clear();
    myModWrapperSet->add(**it);
    myTempModSet->remove(it);
    
    myOutput->printText("\n<BR>A new modifier was generated. Simplify current objects by this modifier.\n<BR>We put new modifier to ModWrapperSet.");
    myOutput->htmlCustomPrintSetPage();
     
    myOutput->printText("\n<BR>(LitSubstRule)(myTempDedSet, myModWrapperSet, myTempModSet, true)");
    (*myLitSubstRule)(myTempDedSet, myModWrapperSet, myTempModSet, true);
    myOutput->htmlCustomPrintSetPage();


    myOutput->printText("\n<BR>(LitSubstRule)(myTempDedSet, myClauses, myModWrapperSet)");
    (*myLitSubstRule)(myTempDedSet, myClauses, myModWrapperSet);
    myOutput->htmlCustomPrintSetPage();
    
    myOutput->printText("\n<BR>(LitSubstRule)(myTempDedSet, myNewClauses, myModWrapperSet)");
    (*myLitSubstRule)(myTempDedSet, myNewClauses, myModWrapperSet);
    myOutput->htmlCustomPrintSetPage();
    
    myOutput->printText("\n<BR>(LitSubstRule)(myTempDedSet, myRecentClauses, myModWrapperSet)");
    (*myLitSubstRule)(myTempDedSet, myRecentClauses, myModWrapperSet);
    myOutput->htmlCustomPrintSetPage();

    myOutput->printText("\n<BR>(LitSubstRule)(myTempDedSet, myNewObjects, myModWrapperSet)");
    (*myLitSubstRule)(myTempDedSet, myNewObjects, myModWrapperSet);
    myOutput->htmlCustomPrintSetPage();
    
    myOutput->printText("\n<BR>myModifiers += myModWrapperSet");    
    myModifiers->addSet(myModWrapperSet);
    myModWrapperSet->clear();
    
    myOutput->printText("\n<BR>(TransferRule)(myTempDedSet, myNewObjects, myTempModSet);");
    (*myTransferRule)(myTempDedSet, myNewObjects, myTempModSet);
    myOutput->htmlCustomPrintSetPage();
  }
  
  Assert(myTempModSet->getSize() == 0, "Bug.");
  
  simplifying_by_mod_now = false;  
  return;
}


void
BooleanAlgebraicSolver::processNewObject(
  const Rule* rule, 
  PDeductionObject new_obj,
  DeductionObjectSet* set,
  Object* pre1,
  Object* pre2,
  Object* pre3,
  Object* pre4,
  std::string str)
{
  if (!new_obj->getId()) new_obj->setId(myOutput->getNextId());
    
  myNewNewObjects->add(new_obj);
  this->processNewObjects(rule, set, pre1, pre2, pre3, pre4, str);
  
  return;
}

// variable for statistics
//long my_count = 0;

void
BooleanAlgebraicSolver::processNewObjects(
  const Rule* rule, 
  DeductionObjectSet* set,
  Object* pre1,
  Object* pre2,
  Object* pre3,
  Object* pre4,
  std::string str)
{
  PDeductionObjectIterator it = myNewNewObjects->getBeginIteratorOnWholeSet();
  PDeductionObjectIterator it_end = myNewNewObjects->getEndIteratorOnWholeSet();
  
  while (!it->equals(*it_end))
  {
    PDeductionObject new_obj = **it;
    
#ifdef DEBUG
  bool test_sat_assignment = false;
  if (test_sat_assignment)
  {
    bool all_premises_satisfied = true;
    if (all_premises_satisfied && pre1 && !pre1->isSatisfiedBy(myKnownSatAssignment))
      all_premises_satisfied = false;
    if (all_premises_satisfied && pre2 && !pre2->isSatisfiedBy(myKnownSatAssignment))
      all_premises_satisfied = false;
    if (all_premises_satisfied && pre3 && !pre3->isSatisfiedBy(myKnownSatAssignment))
      all_premises_satisfied = false;
    if (all_premises_satisfied && pre4 && !pre4->isSatisfiedBy(myKnownSatAssignment))
      all_premises_satisfied = false;

  
    if (!new_obj->isSatisfiedBy(myKnownSatAssignment))
    {
      cerr << "\n\nThe object generated by " << rule->getName() << " is not satisfied: \n";
      new_obj->print(cerr, this);
      
      if (all_premises_satisfied)
      {
        cerr << "\nBug in " << rule->getName() << ":\n";
	if (pre1)
	  pre1->print(cerr, this);
	cerr << "\n\n";
	if (pre2)
	  pre2->print(cerr, this);
	cerr << "\n\n---------------------------------\n\n";
	new_obj->print(cerr, this);
	cerr << "\n\nInput assignment satisfies all premises but not the result";
        //cerr << "\nBut all premises are satisfied! Bug!\n";
	exit(-1);
      }
      
    }
  }
#endif

  this->getStats()->incObjects();
    
    // print about object creation to html output
    myOutput->printGenerationRuleApplication(rule, &(*new_obj), pre1, pre2, pre3, pre4, str);
    
    TRACE("ruleschecker", 
    RulesChecker::check(this, rule, &(*new_obj), pre1, pre2, pre3, pre4);
    );
    
    if (new_obj->isTautology())
    {
      myOutput->printObjectRecognition(&(*new_obj), "tautology");
      it = myNewNewObjects->remove(it);
      continue;
    }
   
    if (new_obj->isContradiction())
    {
      throw std::string("contradiction");
    }
    
    // We touched this object; hence, set its priority.
    int pri=0;
    Assert((pri==0),"solver.cc: pri=0 initialisation has failed.");
    if (rule->getName() == "GatesEquivalence2Rule") pri=1;
    else if (rule->getName() == "Back And Substitution Rule") pri=-10;
    else if (rule->getName() == "Lin3Rule") pri=-1;

    if (pri!=0)
    {
      PVarList vl=new_obj->getVariableList();
      VarList::iterator vit=vl->begin();
      VarList::iterator vend=vl->end();
      Assert((vit!=vend),"Nontrivial empty object in TransferRule");
      for (;vit!=vend;++vit)
      {
        if (getVarPriority(*vit)==0)
        {                     
          setVarPriority(*vit,pri);
        }
        else 
        {
        }
      }
    }

    TRACE("rulesstat", 
      {
        rule->incNumberOfGeneratedObjects();
        //my_count++;
        //if (my_count % 100 == 0)
          //this->printCurrentStatistics();
	if (myInnerCycleIteration % 100 == 0)
	  this->printCurrentStatistics();
      };);
    
      ++*it;
  }
  
  
  if (rule->getName()!="StrongNormalizeRule")
  {
    // move all objects from myNewNewObjects to myDedWrapperSet
    myDedWrapperSet->clear();
    myDedWrapper2Set->clear();
    myDedWrapper3Set->clear();
    myDedWrapperSet->addSet(myNewNewObjects);
    myNewNewObjects->clear();
    
    while (myDedWrapperSet->getSize())
    {
      myDedWrapper2Set->clear();
      (*myStrongNormRule)(myDedWrapper2Set, myDedWrapperSet);
      myDedWrapper3Set->addSet(myDedWrapperSet);
      myDedWrapperSet->clear();
      myDedWrapperSet->addSet(myDedWrapper2Set);
    };
    
    myNewNewObjects->addSet(myDedWrapper3Set);
  };
  
  
  
  if (this->simplify_by_new_modifiers && !simplifying_by_mod_now)
  {
    (*myTransferRule)(myNewNewObjects, set, myTempModSet);
  }
  else
  {
    set->addSet(myNewNewObjects);
    myNewNewObjects->clear();
  }

  long curTotal = 0;
  list<DeductionObjectSet *>::iterator beg = myListOfDeductionObjectSets->begin();
  list<DeductionObjectSet *>::iterator end = myListOfDeductionObjectSets->end();
  while (beg != end)
  {
    curTotal += (*beg)->getSize();
    ++beg;
  }
  list<ModificationObjectSet *>::iterator mbeg = myListOfModificationObjectSets->begin();
  list<ModificationObjectSet *>::iterator mend = myListOfModificationObjectSets->end();
  while (mbeg != mend)
  {
    curTotal += (*mbeg)->getSize();
    ++mbeg;
  }

  myStatistics->updateMaxTotalSize(curTotal);  
  
  return;
}

int 
BooleanAlgebraicSolver::getNumberOfNonAssignedVariables() const
{
  int result = 0;
  
  std::list<Variable>::iterator it = this->myVarList->begin();
  std::list<Variable>::iterator it_end = this->myVarList->end();
  
  for (; it != it_end; it++)
  {
    for (list<DeductionObjectSet*>::iterator ded_set_it = myListOfDeductionObjectSets->begin();
    ded_set_it != myListOfDeductionObjectSets->end(); ded_set_it++)
    {
      if ((*ded_set_it)->isPresent(*it))
      {
        result++;
	break;
      }
    }
  };
  
  return result;
}


void BooleanAlgebraicSolver::printCurrentStatistics() const
{
#ifdef DEBUG
  myStatIteration++;
  int num = 0;
  int total = 0;
  std::cerr << "\n----------------------------STATISTICS--------------------------------------\n";
  std::cerr << "\n\t\t\t\t\t\t   objects \ttime \tlast changed (#outer cycle)";
  std::cerr << "\nGENERATION RULES:";
  std::list<GenerationRule*> list = myMetaGenerationRule->getList();
  std::list<GenerationRule*>::iterator it = list.begin();
  std::list<GenerationRule*>::iterator it_end = list.end();
  for (; it != it_end; it++)
  {
    if ((*it) != NULL)
      std::cerr << "\n" << (*it)->getName();

    
    for (unsigned int i = 1; i <= 50-(*it)->getName().length(); i++)
      std::cerr << " ";
    std::cerr << (*it)->getNumberOfGeneratedObjects();
    total += (*it)->getNumberOfGeneratedObjects();
    std:: cerr << "\t(+";
    int nt = (*it)->getNumberOfGeneratedObjects() - mydelta[++num];
    std::cerr << nt << ")";
    mydelta[num] = (*it)->getNumberOfGeneratedObjects();
    std::cerr << "\t" << (double) (*it)->getTime();
    if (nt != 0)
      myLastChanged[num] = myOuterCycleIteration;
    std::cerr << "\t" << myLastChanged[num];
  }
  
  
  std::cerr << "\n\nSIMPLIFICATION RULES:";
  std::list<SimplificationRule*> slist = myMetaSimplificationRule->getList();
  std::list<SimplificationRule*>::iterator sit = slist.begin();
  std::list<SimplificationRule*>::iterator sit_end = slist.end();
  for (; sit != sit_end; sit++)
  {
    if ((*sit) != NULL)
      std::cerr << "\n" << (*sit)->getName();
   
    for (unsigned int j = 1; j <= 50-(*sit)->getName().length(); j++)
      std::cerr << " ";
    std::cerr << (*sit)->getNumberOfGeneratedObjects();
    total += (*sit)->getNumberOfGeneratedObjects();
    std:: cerr << "\t(+";
    int nt = (*sit)->getNumberOfGeneratedObjects() - mydelta[++num];
    std::cerr << nt << ")";
    mydelta[num] = (*sit)->getNumberOfGeneratedObjects();
    std::cerr << "\t" << (double) (*sit)->getTime();
    if (nt != 0)
      myLastChanged[num] = myOuterCycleIteration;
    std::cerr << "\t" << myLastChanged[num];
  }

  std::cerr << "\n\nTOTAL (GENERATED):\t\t\t\t" << total;
  std::cerr << "\n----------------------------------------------------------------------------\n";
  std::cerr << "current tree depth is " << this->currentTreeDepth;
  
  long total_objects = 0;
  std::cerr << "\nset sizes: ";
  std::cerr << " |c|=" << myClauses->getSize();  total_objects += myClauses->getSize();
  std::cerr << " |nc|=" << myNewClauses->getSize();   total_objects += myNewClauses->getSize();
  std::cerr << " |rc|=" << myRecentClauses->getSize();   total_objects += myRecentClauses->getSize();
  std::cerr << " |am|=" << myModifiers->getSize();  total_objects += myModifiers->getSize();
  std::cerr << " |no|=" << myNewObjects->getSize();   total_objects += myNewObjects->getSize();
  std::cerr << " |nno|=" << myNewNewObjects->getSize(); total_objects += myNewNewObjects->getSize();
  std::cerr << " |tms|=" << myTempModSet->getSize(); total_objects += myTempModSet->getSize();
  std::cerr << " total=" << total_objects;
  std::cerr << "\nnumber of vars that are still present (and not assigned) is " << this->getNumberOfNonAssignedVariables();
  std::cerr << "\nouter cycle iteration: " << myOuterCycleIteration;
  std::cerr << "\ninner cycle iteration: " << myInnerCycleIteration;
  std::cerr << "\n----------------------------------------------------------------------------\n";    
#endif
}

MetaGenerationRule *BooleanAlgebraicSolver::getMetaGenerationRule() { return myMetaGenerationRule; };
MetaSimplificationRule *BooleanAlgebraicSolver::getMetaSimplificationRule() { return myMetaSimplificationRule; };
list<DeductionObjectSet*> *BooleanAlgebraicSolver::getListOfDeductionObjectSets() const {return myListOfDeductionObjectSets;}; 
list<ModificationObjectSet*> *BooleanAlgebraicSolver::getListOfModificationObjectSets() const {return myListOfModificationObjectSets;};
DeductionObjectSet* BooleanAlgebraicSolver::getClauses() { return myClauses;};
DeductionObjectSet* BooleanAlgebraicSolver::getNewObjects() {return myNewObjects;};
DeductionObjectSet* BooleanAlgebraicSolver::getNewClauses() {return myNewClauses;};
DeductionObjectSet* BooleanAlgebraicSolver::getNewNewObjects() {return myNewNewObjects;};
ModificationObjectSet* BooleanAlgebraicSolver::getTempModSet() {return myTempModSet;};
DeductionObjectSet* BooleanAlgebraicSolver::getTempDedSet() {return myTempDedSet;};
ModificationObjectSet* BooleanAlgebraicSolver::getModWrapperSet() {return myModWrapperSet;};
ModificationObjectSet* BooleanAlgebraicSolver::getModifiers() {return myModifiers;};
DeductionObjectSet* BooleanAlgebraicSolver::getRecentClauses() {return myRecentClauses;};
VarList* BooleanAlgebraicSolver::getVarList() {return myVarList;};

long
BooleanAlgebraicSolver::getVarNumber(string name) const
{
  map<long, string>::const_iterator it = varNames->begin();
  map<long, string>::const_iterator end = varNames->end();
  for (; it != end; it++)
  {
    if ((*it).second == name)
      return ((*it).first);
  }
  
  Assert(0, "Bug");
  
  return 0;
}

void BooleanAlgebraicSolver::fillMetaRules()
{
  myMetaGenerationRule->clear();
  myMetaSimplificationRule->clear();
  
  // filling in metarules

  // GenerationRule:
  myMetaGenerationRule->addRule(new Linearization2Rule(this));
  myMetaGenerationRule->addRule(new SummationRule(this));
  myMetaGenerationRule->addRule(new XORSummationRule(this));
  myMetaGenerationRule->addRule(new Summation2Rule(this));
  myMetaGenerationRule->addRule(new OR3GenerationRule(this));
  myMetaGenerationRule->addRule(new XOR3GenerationRule(this));
  myMetaGenerationRule->addRule(new OR3GenerationRule2(this));
  myMetaGenerationRule->addRule(new BackLinearization2Rule(this));
  myMetaGenerationRule->addRule(new LinXORRule(this));
  
  // dummy booth part
 
  myMetaGenerationRule->addRule(new XOROR2Part1Rule(this));
  
  if (this->getOptions()->myUseBooth)
  {
    //myMetaSimplificationRule->addRule(new XOROR2Part3Rule(this));
    myMetaGenerationRule->addRule(new XOROR2Part3Rule(this));
    myMetaGenerationRule->addRule(new XOROR2Part2Rule(this));
    myMetaGenerationRule->addRule(new ORXOR3Rule(this));
    myMetaGenerationRule->addRule(new BoothSubRule(this));
    myMetaGenerationRule->addRule(new ORORRule(this));
  }
  
  // SimplificationRule:
  myMetaSimplificationRule->addRule(new PureLiteralRule(this));
  myMetaSimplificationRule->addRule(new SingleOccurrenceRule(this));
  myMetaSimplificationRule->addRule(new SmartCircuitFormTranslationRule(this));
  myMetaSimplificationRule->addRule(new SimpleSubsumption(this));
  myMetaSimplificationRule->addRule(new BinaryClausesProcessing4Rule(this));
  myMetaSimplificationRule->addRule(new GatesEquivalence2Rule(this));
  myMetaSimplificationRule->addRule(new Lin3Rule(this));
  myMetaSimplificationRule->addRule(new MonomialSubstitutionRule(this));  
  myMetaSimplificationRule->addRule(new BackT2SubstitutionRule(this));

}

void BooleanAlgebraicSolver::setOptions(Options o)
{
  this->getOptions()->set(o);
  this->fillMetaRules();
  if (this->getOptions()->myNoSets)
    this->getOutput()->setNoSets(1);
}



