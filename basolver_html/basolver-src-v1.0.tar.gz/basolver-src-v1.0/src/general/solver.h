#ifndef __SOLVER_H__
#define __SOLVER_H__

#include "../algebraic/algebraic.h"
#include "../basicobject/objectset.h"
#include "../rules/abstract/transferrule.h"
#include "../rules/abstract/simplrule.h"
#include "../rules/abstract/genrule.h"
#include "../backtrack/simplelogentry.h"
#include "solveroptions.h"
#include "../getopt/options.h"


using namespace std;


/**
 * @file solver.h
 * @brief Contains an interface for the BooleanAlgebraicSolver class.
 */


// Forward declarations.
class LiteralSubstitutionRule;
class StrongNormalizeRule;
class TransferRule;
class Output;
class Assignment;

/**
 * @class BooleanAlgebraicSolver
 * @brief A class intended to solve formulas. 
 * Below we give a brief description of this class and its internal structures.
 * For more details, see documentation.
 *
 * \section Main structures
 *
 * The main internal structures of the BooleanAlgebraicSolver 
 * are the following: 
 * - deduction object sets (myClauses, myNewClauses, myNewObjects, myNewNewObjects, myTempDedSet)
 * - modification object sets (myModifiers, myModWrapperSet, myTempModSet)
 * - simplification metarule 
 * - generation metarule
 * 
 * Different internal sets are intended to preserve the property that each rule is applied at least once 
 * to each group of objects. For example, when a new modifier is generated we simplify all objects by means 
 * of this modifier and put it to myModifiers (in case an input formula is satisfiable, this set is used 
 * for constructing a satisfying assignment). Rules are used to produce new objects. However, while generation rules
 * just produce new object(s) from a group of objects, a simplification rule has to remove at least 
 * one of its premises. 
 *
 * \section Solving formulas
 * 
 * To solve a formula convert it to an instance of DeductionObjectSet (by using the class Parser) and give this
 * set to a method solve(). This will initialize all internal structures of the solver and 
 * call the main algorithm of the solver. After solving a formula 
 * you can call BooleanAlgebraicSolver::printSatisfyingAssignment() method, which prints the result in standard form 
 * (SATISFIABLE/UNSATISFIABLE and satisfying assignment if any) to the standard output (std::cout). Instead 
 * of printing the results, you can get a satisfying assignment by calling getSatAssignment() method.
 * Also, after solving the formula statistics is available (use BooleanAlgebraicSolver::use getStats() method).
 * 
 *
 * \section The main algorithm
 * 
 * Below we describe the methods where the main algorithm is implemented. They can be tuned
 * to change the solving process.
 * 
 * - solve(DeductionObjectSet* ) - initializes all internal structures of the solver and calls the main algorithm
 * - mainCycle() - contains implementation of the main algorithm
 * - getNextLiteral() - returns a literal for splitting on
 * - getSatAssignment() - returns a satisfying assignment if any (can be called only after solve())
 * - processNewObject() - called for each new object; currently does the following: prints object generation
 * to an output; checks whether a new objects is either contradiction or tautology; check whether it is a modifier;
 * adds a new object to a corresponding set
 * 
 * \section Additional structures
 *
 * Here we describe additional features of the BooleanAlgebraicSolver class.
 *
 * Features:
 * - myOutput - an instance of the class \ref Output; needed to creating an html output of the solving process
 * - myLog - an instance of the class ref Log; intended to perform backtracking
 * - varValues - a map containing variable values assigned during splittings
 * - varNames - a map containing names of variables; used when an input formula is given in iscas format; 
 * by default the name of a variable is just its number; however you can set any name (std::string) to any variable 
 * - myStatistics - an instance of the class \ref Statistics; stores statistics of solving process
 * - VarList - a list of all variables of an input formula 
 * - mySolverOptions - an instance of the class \ref SolverOptions
 * - currentTreeDepth - current depth of the search tree
 * - myListOfDeductionObjectSets, myListOfModificationObjectSets - lists of all internal sets of a particular type
 *
 */
class BooleanAlgebraicSolver
{
public:
  /// Constructor. 
  /// All internal structures of BooleanAlgebraicSolver should be initialized here.
  BooleanAlgebraicSolver();
  
  /// Destructor.
  virtual 
  ~BooleanAlgebraicSolver();
  
  /// Implements the main algorithm of basolver.
  virtual bool 
  solve(DeductionObjectSet*);
  
  /// Returns the list of all deduction object sets.
  /// This list has to be created in the constructor.
  list<DeductionObjectSet*> *getListOfDeductionObjectSets() const;

  /// Returns the list of all modification object sets.
  /// This list has to be created in the constructor.
  list<ModificationObjectSet*> *getListOfModificationObjectSets() const;
  
  /// Returns the set Clauses.
  virtual DeductionObjectSet* getClauses();
  /// Returns the set NewObjects.   
  virtual DeductionObjectSet* getNewObjects();
  /// Returns the set NewClauses.
  virtual DeductionObjectSet* getNewClauses();
  /// Returns the set NewNewObjects.
  virtual DeductionObjectSet* getNewNewObjects();
  /// Returns the set TempModSet.
  virtual ModificationObjectSet* getTempModSet();
  /// Returns the set TempDedSet.
  virtual DeductionObjectSet* getTempDedSet();
  /// Returns the set ModWrapperSet.
  virtual ModificationObjectSet* getModWrapperSet();
  /// Returns the set Modifiers.
  virtual ModificationObjectSet* getModifiers();
  /// Returns the set RecentClauses.
  virtual DeductionObjectSet* getRecentClauses();

  /// Returns the list of variables.   
  virtual VarList *getVarList();

  /// Returns the solver's statistics 
  Statistics *getStats();

  /// Returns the solver's log
  Log *getLog();
  
  /// Returns the solver's output
  Output *getOutput();

  /// Returns next id for an object
  long getNextId();

  /// Returns the generation metarule. 
  virtual MetaGenerationRule *getMetaGenerationRule();
  /// Returns the simplification metarule. 
  virtual MetaSimplificationRule *getMetaSimplificationRule();
 
  /// Prints out the current rule statistics.
  virtual void 
  printCurrentStatistics() const;
 
  /// Outputs the current tree depth.
  virtual long 
  getCurrentTreeDepth() const {return currentTreeDepth;};
  
  /// Prints satisfying assignment to std::cout.
  virtual void 
  printSatAssignment();
 
  /// Returns a reference to the options of the solver.
  virtual SolverOptions*
  getOptions()
  {
    return mySolverOptions;
  }

  /// Sets the options for the solver.
  virtual void setOptions(Options o);

  /// Clears the set lists and var lists for another solver start.
  void clear();
  
  /// Gets a variable's value.
  int getVarValue(long v);

  /// Sets a variable's value.
  void setVarValue(long v, int val);

  /// Gets a variable's priority.
  int getVarPriority(long v);

  /// Sets a variable's priority.
  void setVarPriority(long v, int val);

  /// Prints a variable to the given output stream.
  std::ostream& 
  printVar(std::ostream& os, long v);

  /// Prints a variable to the given output stream.
  void 
  printVar(std::ostream *os, long v);


  /// Prints the given varlist to the given stream.
  void 
  printVarList(std::ostream& os, PVarList vlist);

  /// Returns a reference to the variable names map.
  std::map<long,std::string>*
  getVarNames() 
  {return varNames;};
  
  /// Returns variable number by its name. If it is not present,
  /// returns 0.
  long
  getVarNumber(std::string name) const;

  /// Collects garbage in all sets of the solver.
  void 
  collectGarbage();
  
protected:
  /// Solver options.
  SolverOptions* mySolverOptions;
 
  /// This map holds the names of the variables.
  std::map<long,std::string>*
  varNames;

  /// This map holds the current values of the variables.
  std::map<long,int> 
  varValues;
 
  /// This map holds the current priorities (-10000..10000) of the variables;
  /// the smaller priority is, with higher probability we
  /// consider the variable for splitting.
  std::map<long,int> 
  varPriorities;

  /// The list of all deduction object sets.
  list<DeductionObjectSet*>* 
  myListOfDeductionObjectSets;

  /// The list of all modification object sets.
  list<ModificationObjectSet*>*
  myListOfModificationObjectSets;

  // sets used in the proof search process
  
  /// Clauses (see documentation and the main algorithm for detailed description of what 
  /// objects this set contains)
  DeductionObjectSet*
  myClauses;
  /// NewClauses (see documentation and the main algorithm for detailed description of what 
  /// objects this set contains)
  DeductionObjectSet*
  myNewClauses;
  
  /// NewObjects (see documentation and the main algorithm for detailed description of what 
  /// objects this set contains)
  DeductionObjectSet*
  myNewObjects;
  /// RecentClauses (see documentation and the main algorithm for detailed description of what 
  /// objects this set contains)
  DeductionObjectSet*
  myRecentClauses;

  /// This set stores new modifiers
  ModificationObjectSet*
  myTempModSet;

  /// We use this set just for wrapping 
  /// a modifier by means of which we simplify objects
  /// in the method simplifyAllObjectsByNewModifiers().
  ModificationObjectSet*
  myModWrapperSet;

  /// Used just for applying StrongNormalizeRule to new objects.
  DeductionObjectSet*
  myDedWrapperSet;
  /// Used just for applying StrongNormalizeRule to new objects.
  DeductionObjectSet*
  myDedWrapper2Set;
  /// Used just for applying StrongNormalizeRule to new objects.
  DeductionObjectSet*
  myDedWrapper3Set;

  /// This set contains all deduced modifiers.
  ModificationObjectSet*
  myModifiers;

  /// Just a temporary set for storing deduction objects
  /// while simplifying by modifiers.
  DeductionObjectSet*
  myTempDedSet;

  /// Just a set for put new objects (while simplifying by a new modifier).
  DeductionObjectSet*
  myNewNewObjects;
  
  /// Current tree depth; needed for statistics.
  long 
  currentTreeDepth;
 
  /// Statistics.
  Statistics*
  myStatistics;

  /// Html output.
  Output*
  myOutput;

  /// Rules used in the proof search process

  /// Transfer rule (\ref TransferRule).
  TransferRule*
  myTransferRule;
  /// Generation metarule (\ref MetaGenerationRule).
  MetaGenerationRule*
  myMetaGenerationRule;
  /// Simplification metarule (\ref MetaSimplificationRule).
  MetaSimplificationRule*
  myMetaSimplificationRule;
  
  /// Rule needed for simplifying objects by new modifiers.
  LiteralSubstitutionRule* 
  myLitSubstRule;
  
  /// Rule need for simplifying new objects by means of themselves.
  StrongNormalizeRule* 
  myStrongNormRule;

  /// Variable list
  VarList*
  myVarList;
  
  /// This flag is intended to prevent recursive simplifying by modifiers.
  bool 
  simplifying_by_mod_now;
  
  /// Whether to simplify by new modifiers.
  bool 
  simplify_by_new_modifiers;

#ifdef DEBUG
  /// The following features are needed just for debugging
  /// and used only under appropriate trace.

  /// How many objects was generated by each rule
  mutable std::vector<int> 
  mydelta;
  /// Whether splitting has already began.
  mutable bool 
  began_split;
  /// The number of times the method printCurrentStatistics was called.
  mutable long 
  myStatIteration;
  /// The number of the last iteration (of printCurrentStatistics()) when a rule produced 
  /// something.
  mutable std::vector<int> 
  myLastChanged;
  
  /// This assignment is used only for debugging.
  Assignment* 
  myKnownSatAssignment;
  
  /// The outer cycle iteration number.
  long
  myOuterCycleIteration;

  /// The inner cycle iteration number.
  long
  myInnerCycleIteration;
#endif


  /// Returns the next literal for splitting.
  virtual std::pair<Variable,int> 
  getNextLiteral();
  
  /// Calculates the satisfying assignment (if any).
  /// Called from the main cycle only after solving a formula.
  virtual void
  calculateSatAssignment();
  
  /// Implements the (recursive) cycle of the main algorithm.
  virtual bool 
  mainCycle();
  
  /// Calculates the number of variables 
  /// that are still not assigned (note that x
  /// is considered as assigned if some of the solver sets
  /// contain an equality x=y). 
  int
  getNumberOfNonAssignedVariables() const;

  /// This map is used when calculating satisfying assignments;
  /// this pointer is NULL until a satisfying assignment is found
  /// and the need for outputting it has arisen.
  std::map<long, int>* 
  mySatAssignmentMap;

  /// Debug only -- number of variables
  //int myNumberOfVars;
  
  /// myLog is intended to store the information 
  /// about all modifications made with the solver sets.
  Log* 
  myLog;
  
  /// Contains information about assigned values.
  //Assignment* 
  //myAssignment;
  
  /// Fills in metarules with necessary rules.
  void
  fillMetaRules();
  
public:

  /// Returns a satisfying assignment. 
  virtual 
  std::map<long, int>*
  getSatAssignment()
  {
    return mySatAssignmentMap;
  }
  
  /// Simplifies all sets of the solver 
  /// by new modifiers (if any). This method is 
  /// called from processNewObjects(), at this moment 
  /// new mods are in myTempModSet.
  virtual void 
  simplifyAllObjectsByNewModifiers();
  
  /// Does the same as processNewObjects() but for single object.
  /// (Actually this method just adds new object to myNewNewObjects set and 
  /// calls processNewObjects() method.)
  /// See processNewObjects() for parameters description.
  virtual void
  processNewObject(const Rule* rule, PDeductionObject new_obj, DeductionObjectSet* set, Object* pre1 = 0, Object* pre2 = 0, Object* pre3 = 0, Object* pre4 = 0, std::string str = "");
  
  /// Processes new objects. 
  /// It is supposed that all new objects are already put into myNewNewObjects set
  /// before call of this procedure.
  /// For each new object (from myNewNewObjects) the procedure does the following:
  /// - prints the fact about object creation to html output;
  /// - if an input object is a modifier simplifies 
  ///   all current object by it (note that all new objects 
  ///   are also simplified by this modifier); 
  /// - if a new object is a contradiction throws the string "contradiction";
  /// - adds a new object to an input set.
  /// Parameters:
  /// @param rule - a rule that generated new objects
  /// @param set - a set new objects have to be added to
  /// @param pre1, pre2, pre3, pre4 - premises of a rule application (needed for html output)
  /// @param str - optional string for html output
  virtual void 
  processNewObjects(const Rule* rule, DeductionObjectSet* set, Object* pre1 = 0, Object* pre2 = 0, Object* pre3 = 0, Object* pre4 = 0, std::string str = "");
};

#endif
