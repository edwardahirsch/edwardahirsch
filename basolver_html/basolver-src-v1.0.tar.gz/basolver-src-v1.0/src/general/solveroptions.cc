#include "solveroptions.h"
#include "getopt/options.h"

/**
 * @file solveroptions.cc
 * @brief implementation for solveroptions.h
 */

void
SolverOptions::set(Options o)
{
  this->myFileName = std::string(o.getFileName());
  this->myFileName2 = std::string(o.getFileName2());
  this->myNoSets = o.getNoSets();
  this->myWriteHtmlOutput = o.getHtmlOutput();
  this->myUseBooth = o.getUseRulesForBooth();
  this->myEquivChecking = o.getEquivChecking();
}


