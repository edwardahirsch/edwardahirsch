#include "misc/assert.h" 
#include "misc/tracer.h" 
#include "variablestatistics.h"
#include <string>

/* @author hirsch */


/**
 * @file variablestatistics.cc
 * @brief Contains implementation of the isBetter method of VariableStatistics.
 */
bool VariableStatistics::isBetter(VariableStatistics &stat2)
{
  // if a variable does not occur, we do not need it anyway
  if (stat2.occTotal==0) return false;
  else if (occTotal==0) return true;
  // priority set by derivation rules
  else if (stat2.pri < pri) return true;
  else if (stat2.pri > pri) return false;
  // be tolerant w.r.t. different Boolean clauses
  else if (4*stat2.occIn2Clauses +
           2*stat2.occIn3Clauses +
           1*stat2.occInBClauses > 
           4*occIn2Clauses +
           2*occIn3Clauses +
           1*occInBClauses) return true;
  else if (4*stat2.occIn2Clauses +
           2*stat2.occIn3Clauses +
           1*stat2.occInBClauses < 
           4*occIn2Clauses +
           2*occIn3Clauses +
           1*occInBClauses) return false;
  // 2-clauses are always good.
  else if (stat2.occIn2Clauses > occIn2Clauses) return true;
  else if (stat2.occIn2Clauses < occIn2Clauses) return false;
  // 3-clauses may become 2-clauses, which are always good.
  else if (stat2.occIn3Clauses > occIn3Clauses) return true;
  else if (stat2.occIn3Clauses < occIn3Clauses) return false;
  // Eliminate Boolean clauses, they are uneasy.
  else if (stat2.occInBClauses > occInBClauses) return true;
  else if (stat2.occInBClauses < occInBClauses) return false;
  else if (stat2.occInABeq0 > occInABeq0) return true;
  else if (stat2.occInABeq0 < occInABeq0) return false;
  else if (stat2.occInXeqABasX > occInXeqABasX) return true;
  else if (stat2.occInXeqABasX < occInXeqABasX) return false;
  else if (stat2.occInXeqABasAB+stat2.occInt11m2 > occInXeqABasAB+occInt11m2) return true;
  else if (stat2.occInXeqABasAB+stat2.occInt11m2 < occInXeqABasAB+occInt11m2) return false;
  else if (stat2.occInt124+stat2.occIn3VarsSpecial > occInt124+occIn3VarsSpecial) return true;
  else if (stat2.occInt124+stat2.occIn3VarsSpecial < occInt124+occIn3VarsSpecial) return false;
  else if (stat2.occAllNice > occAllNice) return true;
  else if (stat2.occAllNice < occAllNice) return false;
  else if (stat2.occTotal > occTotal) return true;
  else if (stat2.occTotal < occTotal) return false;
  else return false;
  Assert(0,"isBetter(): should not come here");
  return false;
}

