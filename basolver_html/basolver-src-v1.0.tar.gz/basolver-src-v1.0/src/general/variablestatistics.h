/**
  * @class VariableStatistics
  * @brief Statistics needed to decide whether splitting on this variable is good.
  */
class VariableStatistics
{
  public:
    /// Priority (set by derivation rules)
    long pri;
    /// The Id of the most recent object containing the variable
    long recent;
    /// The number of occurrences in 2-clauses
    long occIn2Clauses;
    /// The number of occurrences in 3-clauses
    long occIn3Clauses;
    /// The total number of occurrences in Boolean clauses
    long occInBClauses;
    /// The number of occurrences in X=AB as X
    long occInXeqABasX;
    /// The number of occurrences in X=AB as A or B
    long occInXeqABasAB;
    /// The number of occurrences in AB=0 
    long occInABeq0;
    /// The number of occurrences in 2-xors 
    long occInt11m2;
    /// The number of occurrences in 3-xors 
    long occInt124;
    /// The number of occurrences in 3 variables equalities of type Special
    long occIn3VarsSpecial;
    /// The total number of interesting occurrences
    long occAllNice;
    /// The total number of occurrences
    long occTotal;
    
    /// Constructor. Initializes all numbers by -1.
    VariableStatistics()
    { 
      occIn2Clauses=
	(occIn3Clauses=
	(occInBClauses=
        (occInXeqABasX=
        (occInXeqABasAB=
        (occInABeq0=
        (occInt11m2=
        (occInt124=
        (occIn3VarsSpecial=
	(occAllNice=
        (occTotal=
	(recent=
	-1)))))))))));
      pri = 10001;
    }
    
  /**
   * Returns true is stat2 is better for splitting than our statistics.
   */
  virtual bool
  isBetter(VariableStatistics &stat2);
};

