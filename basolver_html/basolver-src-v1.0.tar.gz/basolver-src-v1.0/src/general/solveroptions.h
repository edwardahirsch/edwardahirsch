#ifndef __solveroptions_h__
#define __solveroptions_h__

#include <string>

/// Forward declaration.
class Options;

using namespace std;

/**
  * @class SolverOptions
  * @brief Contains information about solver options 
  * (whether to write html output, whether to use specific rules for Booth multipliers, etc).
  */
class SolverOptions
{
public:
  /// Constructor. By default all flags have the value False. 
  SolverOptions()
  {
    myWriteHtmlOutput = false;
    myEquivChecking = false;
    myFileName = "";
    myFileName2 = "";
    myNoSets = false;
    myUseBooth = false;
  };
  
  /// Sets all options from a command line options.
  /// Note that options not specified in input instance 
  /// are assigned default values of the command line parser.
  void
  set(Options);

  /// Whether to write html output.
  bool myWriteHtmlOutput;
  
  /// Whether to check the equivalence of two input circuits.
  bool myEquivChecking;
  
  /// Whether to write sets of objects in the html output.
  bool myNoSets;
  
  /// Should use additional rules for Booth multipliers?
  bool myUseBooth;
  
  /// Input file name.
  string myFileName;

  /// Second input file name (if any).
  string myFileName2;
  
  /// Prints options to a stream.
  ostream& print(ostream&) const;
};

#endif

