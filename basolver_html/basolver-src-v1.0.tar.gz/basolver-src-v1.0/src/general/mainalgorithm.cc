#include "solver.h"
#include "../getopt/options.h"
#include "../misc/output.h"

#include "basicobject/simpleobjectset.h"
#include "basicobject/trivialobjectset.h"

#include "rules/simplification/literalsubstitutionrule.h"
#include "rules/simplification/monomialsubstitutionrule.h"
#include "rules/simplification/smartcircuitformtranslation.h"
#include "rules/simplification/binclproc4.h"
#include "rules/simplification/singleocc.h"
#include "rules/simplification/pureliteral.h"
#include "rules/simplification/gatesequiv2.h"
#include "rules/simplification/backt2subst.h"
#include "rules/generation/backlin2.h"
#include "rules/generation/linearization2rule.h"
#include "rules/generation/or3generationrule.h"
#include "rules/generation/xor3generationrule.h"
#include "rules/generation/ororrule.h"
#include "rules/simplification/lin3rule.h"
#include "rules/simplification/subsumption.h"
#include "rules/generation/summationrule.h"
#include "rules/generation/xorsummation.h"
#include "rules/generation/summation2.h"
#include "rules/simplification/strongnormalizerule.h"
#include "rules/generation/or3generationrule2.h"
#include "rules/abstract/generic.h"
#include "rules/generation/orxor3.h"
#include "rules/generation/xoror2part1.h"
#include "rules/generation/xoror2part2.h"
#include "rules/generation/xoror2part3.h"
#include "rules/generation/boothsub.h"
#include "rules/generation/linxorrule.h"
#include "getopt/options.h"
#include <string>

/**
 * @author kulikov
 * @brief implements the main algorithm of our solver
 */

bool BooleanAlgebraicSolver::solve(DeductionObjectSet *input_formula)
{
  this->getOutput()->init();
  this->getStats()->startTimer();
  this->varValues.clear();
 
  // creating sets used in search process
  myClauses = new AdjDedObjSet(input_formula->getVariableNum(), myLog,this);
  myClauses->setName("myClauses");
  myListOfDeductionObjectSets->push_back(myClauses);
  
  myNewObjects = (new AdjDedObjSet(input_formula->getVariableNum(), myLog,this));
  myNewObjects->setName("myNewObjects");
  myListOfDeductionObjectSets->push_back(myNewObjects);
  
  myNewNewObjects = (new TrivDedObjSet(input_formula->getVariableNum(), this));
  myNewNewObjects->setName("myNewNewObjects");
  
  myNewClauses = (new AdjDedObjSet(input_formula->getVariableNum(), myLog,this));
  myNewClauses->setName("myNewClauses");
  myListOfDeductionObjectSets->push_back(myNewClauses);

  myRecentClauses = (new AdjDedObjSet(input_formula->getVariableNum(), myLog,this));
  myRecentClauses->setName("myRecentClauses");
  myListOfDeductionObjectSets->push_back(myRecentClauses);

  myTempModSet = (new AdjModObjSet(input_formula->getVariableNum(), myLog,this));
  myTempModSet->setName("myTempModSet");
  myListOfModificationObjectSets->push_back(myTempModSet);

  myModWrapperSet = (new AdjModObjSet(input_formula->getVariableNum(), myLog, this));
  myModWrapperSet->setName("myModWrapperSet");
  myListOfModificationObjectSets->push_back(myModWrapperSet);

  myDedWrapperSet = (new TrivDedObjSet(input_formula->getVariableNum(),this));
  myDedWrapperSet->setName("myDedWrapperSet");

  myDedWrapper3Set = (new TrivDedObjSet(input_formula->getVariableNum(),this));
  myDedWrapper3Set->setName("myDedWrapper3Set");
  
  myDedWrapper2Set = (new TrivDedObjSet(input_formula->getVariableNum(), this));
  myDedWrapper2Set->setName("myDedWrapper2Set");


  myTempDedSet = (new AdjDedObjSet(input_formula->getVariableNum(), myLog, this));
  myTempDedSet->setName("myTempDedSet");
  myListOfDeductionObjectSets->push_back(myTempDedSet);

  myModifiers = (new AdjModObjSet(input_formula->getVariableNum(), myLog, this));
  myModifiers->setName("myModifiers");

  this->getOutput()->updateSetLists();
  
  myOutput->htmlPrintFirstPage(input_formula);
  myOutput->htmlPrintPreprocess();
  
  (*myTransferRule)(input_formula, myRecentClauses, myTempModSet);

  myOutput->endPrintPreprocess();

#ifdef DEBUG  
  myOuterCycleIteration = 0;
  myInnerCycleIteration = 0;
#endif
  
  // call for the main cycle
  bool satisfiable =  this->mainCycle();
  
  TRACE("rulesstat", this->printCurrentStatistics());

  if (satisfiable)
    this->calculateSatAssignment();
  
  myStatistics->stopTimer();  

  return satisfiable;  
}


bool BooleanAlgebraicSolver::mainCycle() 
{
  TRACE("testsatassignment", cerr << "\n\n-------------------------------------------\n\n";
  cerr << "\nEntering new branch"; cerr << "\n\n-------------------------------------------\n\n";);
  // remember the initial state of a formula
  unsigned int bookmark = myLog->getBookmark();
  
  //increment statistics
  myStatistics->incTreeNodes();
  if (currentTreeDepth)
  {
    myClauses->setWriteLog(1);
    myModifiers->setWriteLog(1);
  }
  ++currentTreeDepth;
  myStatistics->setTreeDepthToMax(currentTreeDepth);

// the following try loop 
// is intended to catch the contradiction
try
{
  
  myOutput->beginSplitting();
  
  this->simplifyAllObjectsByNewModifiers();
  
  do 
  {
#ifdef DEBUG  
    myOuterCycleIteration++;    
#endif
  
    this->simplifyAllObjectsByNewModifiers();
  
    do 
    {
#ifdef DEBUG      
      myInnerCycleIteration++;  
#endif
      
      myOutput->printText("\n<HR><BR><B>Step 2iA0. MetaSimplificationRule(NewObjects, ListOfDeductionObjectSets, ListOfModificationObjectSets)</B>");
      (*myMetaSimplificationRule)(myNewObjects, myListOfDeductionObjectSets);
      myOutput->htmlCustomPrintSetPage();
  
      myOutput->printText("\n<HR><BR><B>Step 2iB. MetaSimplificationRule(NewObjects, RecentClauses, NewClauses, false)</B>");
      (*myMetaSimplificationRule)(myNewObjects, myRecentClauses, myNewClauses, false);
      myOutput->htmlCustomPrintSetPage();

      myOutput->printText("\n<HR><BR><B>Step 2iC. MetaSimplificationRule(NewObjects, RecentClauses, Clauses, true)</B>");
      (*myMetaSimplificationRule)(myNewObjects, myRecentClauses, myClauses, true);
      myOutput->htmlCustomPrintSetPage();
      
      myOutput->printText("\n<HR><BR><B>Step 2iD. move all objects from RecentClauses to New Clauses</B>");
      myNewClauses->addSet(myRecentClauses);
      myRecentClauses->clear();
      myOutput->htmlCustomPrintSetPage();

      myOutput->printText("\n<HR><BR><B>Step 2iE. move all objects from NewObjects to Clauses</B>");
      myRecentClauses->addSet(myNewObjects);
      myNewObjects->clear();
      myOutput->htmlCustomPrintSetPage();
    }
    while (myRecentClauses->getSize() != 0);

    Assert(myRecentClauses->getSize() == 0, "Bug");
    Assert(myNewObjects->getSize() == 0, "Bug");
    
    int x = currentTreeDepth;
    while (!(x & 1)) 
      x=x>>1;
    if (x==1)
    {
      myOutput->printText("\n<HR><BR><B>Step 2iiA. MetaGenerationRule(NewObjects, NewClause, Clauses)</B>");
      (((*myMetaGenerationRule)(myNewObjects, myNewClauses, myClauses)));
      myOutput->htmlCustomPrintSetPage();
    }
    else 
    {
       myOutput->printText("\n<HR><BR><B>Step 2iiA. MetaGenerationRule(NewObjects, NewClause, Clauses) SKIPPED</B>");
    }
    
    myOutput->printText("\n<HR><BR><B>Step 2iiB. move all objects from NewClauses to Clauses</B>");
    myClauses->addSet(myNewClauses);
    myNewClauses->clear();
    myOutput->htmlCustomPrintSetPage();

    myOutput->printText("\n<HR><BR><B>Step 2iiC. move all objects from NewObjects to RecentClauses</B>");
    myRecentClauses->addSet(myNewObjects);
    myNewObjects->clear();
    myOutput->htmlCustomPrintSetPage();
  }
  while (myNewClauses->getSize() != 0 || myRecentClauses->getSize() != 0);
  
  myOutput->htmlCustomPrintSetPage();

  if (myClauses->getSize() == 0)
  {
    myOutput->printText("\n<HR><BR><B>Step 2b. Stop search as Clauses is empty. The input formula is satisfiable.</B>");
    myOutput->moveUpClose();
    return 1;
  }


  // SPLITTING
#ifdef DEBUG  
  began_split = true;
#endif
  

  // remember the state of the formula
  bookmark = myLog->getBookmark();
  
  if (myClauses->getSize() == 0)
  {
    myOutput->printText("\n<HR><BR><B>Stop search and do not go into splitting here as all relevant sets are empty. The input formula is satisfiable.</B>");
    myOutput->printSatisfyingAssignmentPage(true);
    this->printSatAssignment();
    myOutput->moveUpClose();
    return 1;
  }
  
  std::pair<Variable,int> splitpair = getNextLiteral();

  // CASE splitVar=first value
  myOutput->endSplitting(splitpair.first,splitpair.second);
  myOutput->moveDownLeft();
  
  PLogEntry deleteVariable(new DeletingVariable(this,myVarList,splitpair.first));
  myLog->addEntry(deleteVariable);
  setVarValue(splitpair.first,splitpair.second);

  PModificationObject neg_unit_clause = LogicalGenerator::makeUnitClause(splitpair.first, splitpair.second);
  myTempModSet->add(neg_unit_clause);

  std::map<long,int>pri; //will save varPriorities for a while
  pri.clear(); //for sure
  
  std::map<long, int>::iterator pit=varPriorities.begin();
  for(;pit!=varPriorities.end();++pit) if ((*pit).second != 0)
  {
      pri.insert(std::make_pair((*pit).first,(*pit).second));
  }
  if (mainCycle())
  {
    myOutput->moveUp();
    return 1;
  }
  pit=pri.begin();
  varPriorities.clear();
  for(;pit!=pri.end();++pit) if ((*pit).second != 0)
  {
      varPriorities.insert(std::make_pair((*pit).first,(*pit).second));
  }
  pri.clear();//clean up 
  
  myOutput->moveUp();
  myLog->getBackTo(bookmark);

  // CASE splitVar=1-first value
  PLogEntry deleteVariable2(new DeletingVariable(this,myVarList,splitpair.first));
  myLog->addEntry(deleteVariable2);
  setVarValue(splitpair.first,1-splitpair.second);

  myOutput->moveDownRight();
  
  
  PModificationObject pos_unit_clause = LogicalGenerator::makeUnitClause(splitpair.first, 1-splitpair.second);
  
  myTempModSet->add(pos_unit_clause);
  
  if (mainCycle())
  {
    --currentTreeDepth;
    myOutput->moveUp();
    return 1;
  }
  
  --currentTreeDepth;
  myOutput->moveUp();
  return 0;

}
catch (std::string s)
{
  if (s.compare("contradiction") == 0)
  {
    myOutput->printText("\n<HR><BR><B>Cut this branch as a contradiction was found</B>");
    myLog->getBackTo(bookmark);
    myOutput->closeStream();
    // we need to refine these sets
    // as the transfering operation possibly 
    // was interrupted by throwing an exception
    // reporting that a contradiction was found
    myNewClauses->clear();
    myNewObjects->clear();
    myRecentClauses->clear();
    myTempDedSet->clear();
    myTempModSet->clear();
    myNewNewObjects->clear();
    myDedWrapperSet->clear();
    myDedWrapper2Set->clear();
    myDedWrapper3Set->clear();
    myModWrapperSet->clear();
    --currentTreeDepth;
    simplifying_by_mod_now = false;
    return false;
  }
}

  return false;
}

