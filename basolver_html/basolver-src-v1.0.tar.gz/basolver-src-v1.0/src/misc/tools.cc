#include "tools.h"

/**
 * @author sergey 
 * @brief implementation for tools.h
 **/

void Tools::switchVars(Variable &v1, bool &p1, Variable &v2, bool &p2)
{
  Variable temp = v1; bool ptemp = p1;
  v1 = v2; p1 = p2;
  v2 = temp; p2 = ptemp;
}

VarPair Tools::checkIntersectionByTwoVariables(Variable &x1, Variable &x2, Variable &x3, Variable &y1, Variable &y2, Variable &y3)
{
  if (x1 == y1)
  {
    if (x2 == y2)
      return VarPair(x3,y3);
    else if (x2 == y3)
      return VarPair(x3,y2);
    else if (x3 == y2)
      return VarPair(x2,y3);
    else if (x3 == y3)
      return VarPair(x2,y2);
    else return VarPair(Variable(),Variable());
  }
  else if (x1 == y2)
  {
    if (x2 == y1)
      return VarPair(x3,y3);
    else if (x2 == y3)
      return VarPair(x3,y1);
    else if (x3 == y1)
      return VarPair(x2,y3);
    else if (x3 == y3)
      return VarPair(x2,y1);
    else return VarPair(Variable(),Variable());
  }
  else if (x1 == y3)
  {
    if (x2 == y1)
      return VarPair(x3,y2);
    else if (x2 == y2)
      return VarPair(x3,y1);
    else if (x3 == y2)
      return VarPair(x2,y1);
    else if (x3 == y1)
      return VarPair(x2,y2);
    else return VarPair(Variable(),Variable());
  }
  else
  {
    if (x2 == y1)
    {
      if (x3 == y2)
        return VarPair(x1,y3);
      else if (x3 == y3)
        return VarPair(x1,y2);
      else return VarPair(Variable(),Variable());
    }  
    else if (x2 == y2)
    {
      if (x3 == y1)
        return VarPair(x1,y3);
      else if (x3 == y3)
        return VarPair(x1,y1);
      else return VarPair(Variable(),Variable());
    }   
    else if (x2 == y3)
    {
      if (x3 == y2)
        return VarPair(x1,y1);
      else if (x3 == y1)
        return VarPair(x1,y2);
      else return VarPair(Variable(),Variable());
    }
  }
  
  return VarPair(Variable(),Variable());
}
  
bool Tools::chooseUnique(Variable v1,bool p1,Variable v2,bool p2,Variable v3,bool p3,Variable v4,bool p4,Variable v5,bool p5,Variable v6,bool p6,Variable v7,bool p7,Variable& o1,bool& op1,Variable& o2,bool& op2,Variable& o3,bool& op3,Variable& o4,bool& op4)
{
  o1 = v1; op1 = p1;  
  if (v2 == v5)
  {
    o2 = v3; op2 = p3;
    o3 = v4; op3 = p4;
    if ( (v6 == v3) || (v6 == v4) )
    {
      o4 = v7; op4 = p7;
    }
    else
    {
      o4 = v6; op4 = p6;
    }
  }
  else if (v3 == v5)
  {
    o2 = v2; op2 = p2;
    o3 = v4; op3 = p4;
    if ( (v6 == v2) || (v6 == v4) )
    {
      o4 = v7; op4 = p7;
    }
    else
    {
      o4 = v6; op4 = p6;
    }
  }
  else if (v4 == v5)
  {
    o2 = v2; op2 = p2;
    o3 = v3; op3 = p3;
    if ( (v6 == v3) || (v6 == v2) )
    {
      o4 = v7; op4 = p7;
    }
    else
    {
      o4 = v6; op4 = p6;
    }
  }
  else return false;
  return true;
}
