#ifndef __OUTPUT_H__
#define __OUTPUT_H__

#include "boost/smart_ptr.hpp"
#include "../general/solver.h"
#include "../algebraic/abstract/variable.h"
#include "../basicobject/simpleobjectset.h"
#include <iostream>
#include <fstream>
#include <sstream>

/**
 * @file output.h
 * @brief Declares the Output class
 * @author sergey
 */

/**
 * Forward declarations
 */
class Output;
/**
 * smart pointer for \ref Output
 */
typedef boost::shared_ptr<Output> POutput;

/**
 * @class Output
 * @brief This class stores an information about all 
 * modifications made with a formula. 
 * @author sergey  
 */
class Output
{
public:
  /**
   * constructor.
   */
  Output(BooleanAlgebraicSolver *solver);

  /// initializing everything
  /// call this procedure AFTER setting
  /// command-line options in the solver
  void init();
  
  /**
   * destructor.
   */
  ~Output();
  
  /**
   * Adds an entry to the Output.
   */
  void writeSplitting(const DeductionObjectSet *formula, const Variable& var);

  /**
   * returns the next id
   */
  long long getNextId() {return ++myLastId;};
  
  /**
   * Adds an entry to the Output
   */
  void writeSplittingBegin(const PDeductionObjectSet& dedset, const PModificationObjectSet& modset);

  /**
   * end the split, close file
   */
  void writeSplittingEnd(const Variable &var);
  
  /**
   * prints text to output stream
   */
  void printText(char *text) {if (myOutputFormat==1) *myStream << text;};
  
  /**
   * print the current state of solver sets to a file
   * and link to that file
   */
  void htmlCustomPrintSetPage();
  
  /**
   * print the application of a modification rule
   */
  void printModificationRuleApplication(const Rule *rule, Object *object1, Object *object2, std::string str = "");
  
  /**
   * print the application of a rule that results in object deletion
   */
  void printObjectDeletion(const Rule *rule, Object *deleted, Object *object1, Object *object2, Object *object3, Object *object4, std::string str = "");
  
  /**
   * print the deletion of an object
   */
  void printThatRuleDeletedObject(const Rule *rule, Object *object, DeductionObjectSet *objectset);

  /**
   * print the deletion of an object
   */
  void printThatRuleDeletedObject(const std::string rulename, Object *object, DeductionObjectSet *objectset);

  /**
   * print the application of a generation rule
   */
  void printGenerationRuleApplication(const Rule *rule, Object *object, std::string str = "");
 
  /**
   * print the application of a generation rule with premises
   */
  void printGenerationRuleApplication(const Rule *rule, Object *object, Object *object1, Object *object2, Object *object3, Object *object4, std::string str = "", bool print_as_dedobj = false);

  /**
   * print the application of a generation rule with seven premises
   * created for Linearization3Rule. of course
   */
  void printGenerationRuleApplication(const Rule *rule, Object *object, Object *object1, Object *object2, Object *object3, Object *object4, Object *object5, Object *object6, Object *object7);

  /// set the value of myNoSets
  void setNoSets(bool val) {myNoSets = val;};

  /**
   * print the application of a modification rule with premises
   */
  void printModificationRuleApplication(const Rule *rule, Object *object, Object *object1, Object *object2, Object *object3, Object *object4, std::string str = "");
  
  /**
   * print the recognition of an object (as a clause, or modifier, or contradiction, or tautology)
   */
  void printObjectRecognition(Object* object, std::string type, bool print_as_dedobj = false);
  
  /**
   * get to next step
   */
  void nextStep();

  /**
   * print the beginning of an iteration
   */
  void printIterationBegin();

  /**
   * print the end of an iteration
   */
  void printIterationEnd();
  
  /**
   * return the current splitting number
   */
  long long getSplitNum() {return mySplitNum;};

  /**
   * returns whether the first page has been printed
   */
  bool firstPagePrinted() {return myFirstPagePrinted;};

  /// print a page with satisfying assignment
  void printSatisfyingAssignmentPage(bool);
  /// begin a splitting
  void beginSplitting();
  /// end a splitting
  void endSplitting(Variable var,int first);
  /// move down and left on the splitting tree
  void moveDownLeft() {if (myOutputFormat == 1) vcur = vcur->left;};
  /// move up on the splitting tree
  void moveUp() {
    if (myOutputFormat == 1) {
      vcur = vcur->parent;
      myIterNum = 0;
    }
  };
  /// move up on the splitting tree and close the file
  void moveUpClose() {
    if (myStream)
    {
      myStream->close(); 
    } 
    if (myOutputFormat == 1) {
      vcur = vcur->parent;
      myIterNum = 0;
    }
  };
  /// move down and right on the splitting tree
  void moveDownRight() {if (myOutputFormat == 1) vcur = vcur->right;};

  /// close the current stream
  void closeStream() {
    if (myOutputFormat == 1)
    {
      if (myStream) myStream->close();
    }
  };

  /// print a page with current sets
  void htmlPrintSetPageToStream(std::ofstream *os);
  /// print a preprocessing page
  void htmlPrintPreprocess();
  /// end printing preprocessing
  void endPrintPreprocess();
  /// print the title page with the given set as input
  void htmlPrintFirstPage(DeductionObjectSet *set);
  /// print an object without incrementing its occurrences
  void printObjectWithoutIncrementing(Object *object, std::ofstream *os, bool print_as_dedobj = false);
  /// print an object to myStream
  void printObjectWithoutIncrementingToCurrentStream(Object *object)
  {
    printObjectWithoutIncrementing(object,myStream);
  }

  /// set something_happened to true
  void somethingHappened() {something_happened = true;};
  /// print an object and increment its occurrences
  void printObject(Object *object, bool print_as_dedobj = false);
  /// update the set size lists (call this after the number of sets in the solver
  /// changes)
  void updateSetLists();
  
private:

  /// current number of set pages printed
  long long myCustomSetNum;
  /// current number of the output file
  long long myFilenum;
  /// has the first page been printed?
  bool myFirstPagePrinted;
  
  /// attach a variable to the left child of the current node
  void attachLeft(Variable var);
  /// attach a variable to the right child of the current node
  void attachRight(Variable var);
  
  /// return file name
  void getFileName(char *, TVarTreeNode *);
  /// get the depth and number of the current splitting
  void getSplitParams(TVarTreeNode *,long long &,long long &);
  
  /// print standard html header
  void htmlPrintHeader(std::ofstream *os);
  /// print standard html footer
  void htmlPrintFooter(std::ofstream *os);
  /// print bread crumbs
  void htmlPrintBreadCrumbs(std::ofstream *os);

  /// print the page of sets
  void htmlPrintSetPage(bool);
  
  /// splitting tree nodes
  TVarTreeNode *top,*vcur;

  /// handle for the current stream
  std::ofstream *myStream;
  /// number of splitting, number of the current iteration
  long long mySplitNum, myIterNum;
  /// output format
  int myOutputFormat; // 0 = text (not implemented yet), 1 = html
  /// output directory
  char myDirName[50];
  /// last object id
  long long myLastId;
  /// reference to the solver
  BooleanAlgebraicSolver *mySolver;
  /// checks whether something has happened in order to create a new userset
  /// file
  bool something_happened;
  /// list of sizes of deduction object sets
  std::list<long> myDedSizesList;
  /// list of sizes of modification object sets
  std::list<long> myModSizesList;
  /// if we should not print the sets, set this to 1
  bool myNoSets;
};

#endif
