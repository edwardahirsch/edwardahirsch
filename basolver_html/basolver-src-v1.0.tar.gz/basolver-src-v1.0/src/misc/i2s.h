/** @file i2s.h
 * @brief Contains interface of procedure converting integer to string. 
 */


#include <string>
#include <limits.h>

#if INT_MAX > 2147483647
#error need to increase size of buffer
#endif

/// Implements a missing function that maps an integer to the string
extern std::string itos(int number);
