#ifndef __RULESCHECKER_H__
#define __RULESCHECKER_H__

#include "boost/smart_ptr.hpp"
#include "../algebraic/abstract/variable.h"
#include "../basicobject/simpleobjectset.h"
#include <iostream>
#include <fstream>
#include <sstream>

/**
 * @file ruleschecker.h
 * @brief Declares the RulesChecker class.
 * This class is intended to verify the correctness 
 * of rules.
 */
 
using namespace std;
 
/// This class is intended to verify the correctness 
/// of rules.
class RulesChecker
{
public:
  /// Checks whether each assignment satisfying premises 
  /// satisfies also the conclusion.
  static bool 
  check(BooleanAlgebraicSolver *slv, const Rule* rule, Object* result, Object* obj1, Object* obj2, Object* obj3, Object* obj4);
  
private:
  /// Checks whether an input object is satisfied by an input assignment.
  static bool
  isSatisfied(Object* obj, PVarList var_list, vector<int> assignment);  
  
};

#endif

