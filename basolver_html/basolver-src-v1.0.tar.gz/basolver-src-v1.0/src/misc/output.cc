#include "output.h"
//#include "../getopt/options.h"
#include "ruleschecker.h"
#include <fstream>
#include <sstream>
#include <sys/stat.h>

/**
 * @author sergey 
 * @brief implementation for output.h
 **/

using namespace std;

//Output* globalOutput;

/**
 * constructor
 */
Output::Output(BooleanAlgebraicSolver *solver) : myCustomSetNum(0), myFilenum(0), mySplitNum(0), myOutputFormat(1), myLastId(0), mySolver(solver), something_happened(true), myNoSets(0)
{
}

void Output::updateSetLists()
{
  myDedSizesList.clear();
  myModSizesList.clear();
  std::list<DeductionObjectSet *>::iterator it = mySolver->getListOfDeductionObjectSets()->begin();
  std::list<DeductionObjectSet *>::iterator end = mySolver->getListOfDeductionObjectSets()->end();
  while (it != end)
  {
    myDedSizesList.push_back(0);
    ++it;
  }
  std::list<ModificationObjectSet *>::iterator mit = mySolver->getListOfModificationObjectSets()->begin();
  std::list<ModificationObjectSet *>::iterator mend = mySolver->getListOfModificationObjectSets()->end();
  while (mit != mend)
  {
    myModSizesList.push_back(0);
    ++mit;
  }
}

void Output::init()
{
  top = new TVarTreeNode;
  top->parent = top;
  vcur = top;
  myFirstPagePrinted = false;
  myStream = NULL;
  if (mySolver->getOptions()->myWriteHtmlOutput)
  {
    mkdir("Outputs",0xFFFF);
    std::time_t now;
    std::time(&now);
    std::tm myTime;
    myTime = *std::localtime(&now);
    sprintf(myDirName,"Outputs/%04i%02i%02i%02i%02i%02i",
        myTime.tm_year+1900,myTime.tm_mon+1,myTime.tm_mday,myTime.tm_hour,
        myTime.tm_min,myTime.tm_sec);
    mkdir(myDirName,0xFFFF);
  }
  else 
  {
    myOutputFormat = 0;
  }
}

/**
 * print a rule application
 */
void Output::printModificationRuleApplication(const Rule *rule, Object *object1, Object *object2,std::string str)
{
  if (myOutputFormat == 1)
  {
    *myStream << "\n<br><p>Object ";
    printObject(object1);
    *myStream << " modified by the " << rule->getName();
    if (str.length() > 0) *myStream << " [" << str << "]";
    *myStream << ":<br>";
    printObject(object2);
    myStream->flush();
  }
}

/**
 * print a rule application
 */
void Output::printGenerationRuleApplication(const Rule *rule, Object *object,std::string str)
{
  if (myOutputFormat == 1)
  {
    *myStream << "\n<br><p>Object created by the " << rule->getName();
    if (str.length() > 0) *myStream << " [" << str << "]:<br>";
    printObject(object);
    myStream->flush();
    something_happened = true;
  }
}


void Output::printGenerationRuleApplication(const Rule *rule, Object *object, Object *object1, Object *object2, Object *object3, Object *object4,std::string str, bool print_as_dedobj)
{
  if (myOutputFormat == 1)
  {
    *myStream << "<p>Object created by the " << rule->getName();
    if (str.length() > 0) *myStream << " [" << str << "]";
    if (object1)
      *myStream << ":<p>\n<table>\n<tr><td>Premises: </td><td>";
    if (object1) {printObjectWithoutIncrementing(object1,myStream, print_as_dedobj); *myStream << "<br>";};
    if (object2) {printObjectWithoutIncrementing(object2,myStream, print_as_dedobj); *myStream << "<br>";};
    if (object3) {printObjectWithoutIncrementing(object3,myStream, print_as_dedobj); *myStream << "<br>";};
    if (object4) {printObjectWithoutIncrementing(object4,myStream, print_as_dedobj); *myStream << "<br>";};
    *myStream << "</td></tr>\n<tr><td>Generated: </td><td><b>";
    printObject(object);
    *myStream << "</b></td></tr></table>\n<p>";
    myStream->flush();
    something_happened = true;
  }
}

void Output::printGenerationRuleApplication(const Rule *rule, Object *object, Object *object1, Object *object2, Object *object3, Object *object4, Object *object5, Object *object6, Object *object7)
{
  if (myOutputFormat == 1)
  {
    *myStream << "<p>Object created by the " << rule->getName() << ":<p>";
    *myStream << "\n<table>\n<tr><td>Premises: </td><td>";
    printObjectWithoutIncrementing(object1,myStream); *myStream << "<br>";
    if (object2) {printObjectWithoutIncrementing(object2,myStream); *myStream << "<br>\n";};
    if (object3) {printObjectWithoutIncrementing(object3,myStream); *myStream << "<br>\n";};
    if (object4) {printObjectWithoutIncrementing(object4,myStream); *myStream << "<br>\n";};
    if (object5) {printObjectWithoutIncrementing(object4,myStream); *myStream << "<br>\n";};
    if (object6) {printObjectWithoutIncrementing(object4,myStream); *myStream << "<br>\n";};
    if (object7) {printObjectWithoutIncrementing(object4,myStream); *myStream << "<br>\n";};
    *myStream << "</td></tr><tr><td>Generated: </td><td><b>";
    printObject(object);
    *myStream << "</b></td></tr></table>\n<p>";
    myStream->flush();
    something_happened = true;
  }
 
  
}


void Output::printModificationRuleApplication(const Rule *rule, Object *object, Object *object1, Object *object2, Object *object3, Object *object4,std::string str)
{
  if (myOutputFormat == 1)
  {
    *myStream << "<p>Object modified by the " << rule->getName();
    if (str.length() > 0) *myStream << " [" << str << "]:<br>";
    *myStream << "<table><tr><td>Premises: </td><td>";
    printObjectWithoutIncrementing(object1,myStream); *myStream << "<br>";
    if (object2) {printObjectWithoutIncrementing(object2,myStream); *myStream << "<br>\n";};
    if (object3) {printObjectWithoutIncrementing(object3,myStream); *myStream << "<br>\n";};
    if (object4) {printObjectWithoutIncrementing(object4,myStream); *myStream << "<br>\n";};
    *myStream << "</td></tr><tr><td>Generated: </td><td><b>";
    printObject(object);
    *myStream << "</b></td></tr></table>\n<p>";
    myStream->flush();
    something_happened = true;
  }
}

void Output::printObjectDeletion(const Rule *rule, Object *deleted, Object *object1, Object *object2, Object *object3, Object *object4,std::string str)
{
  if (myOutputFormat == 1)
  {
    if (rule)
    {
      *myStream << "<p>Object deleted by the " << rule->getName();
      if (str.length() > 0) *myStream << " [" << str << "]\n";
      *myStream << ":<table><tr><td>Premises: </td><td>";
      printObjectWithoutIncrementing(object1,myStream); *myStream << "<br>";
      if (object2) {printObjectWithoutIncrementing(object2,myStream); *myStream << "<br>\n";};
      if (object3) {printObjectWithoutIncrementing(object3,myStream); *myStream << "<br>\n";};
      if (object4) {printObjectWithoutIncrementing(object4,myStream); *myStream << "<br>\n";};
      *myStream << "</td></tr><tr><td>Deleted object: </td><td><b>";
    }
    else
      *myStream << "<p>Object deleted because of the pure occurrence of one of its variables:<br>\n";
    printObject(deleted);
    if (rule)
      *myStream << "</b></td></tr></table><p>\n";
    else
      *myStream << "</p>\n";
    myStream->flush();
    something_happened = true;
  }
}

void Output::printThatRuleDeletedObject(const Rule *rule, Object *deleted, DeductionObjectSet *objectset)
{
  if (myOutputFormat == 1)
  {
    printThatRuleDeletedObject(rule->getName(), deleted, objectset);
  }
}

void Output::printThatRuleDeletedObject(const std::string rulename, Object *deleted, DeductionObjectSet *objectset)
{
  if (myOutputFormat == 1)
  {
    *myStream << "<p>" << rulename << " has deleted ";
    printObjectWithoutIncrementing(deleted,myStream);
    *myStream << " from " << objectset->getName();
    myStream->flush();
    something_happened = true;
  }
}
 

/**
 * destructor
 */
Output::~Output()
{
  if (myOutputFormat == 1)
  {
    myStream->flush();
    myStream->close();
    delete myStream;
  }
  delete top;
}

/**
 * write a splitting
 **/
void Output::writeSplittingBegin(const PDeductionObjectSet & dedset, const PModificationObjectSet& modset)
{
  if (myOutputFormat == 1)
  {
  ++mySplitNum; myIterNum = 0;
  char myFullFileName[100] = "";
  char fname[30];
  sprintf(&(fname[0]),"%05lld.html",mySplitNum);
  strcat(myFullFileName,myDirName);
  strcat(myFullFileName,fname);
  myStream = new std::ofstream(myFullFileName);
    *myStream << "<html>\n<head>\n<title> Splitting #" << mySplitNum;
    *myStream << "</title>\n</head>\n<body>";
    *myStream << "<table width=\"600\"><tr><td width=\"100\">";
    char tmp[10];
    sprintf(&(tmp[0]),"%05lld",mySplitNum-1);
    if (mySplitNum > 1)
      *myStream << "<a href=\"splits" << tmp << ".html\">Previous split</a>";    *myStream << "</td><td width=\"400\"></td><td width=\"100\">\n<a href=\"";
    sprintf(&(tmp[0]),"%05lld",mySplitNum+1);
    *myStream << "splits" << tmp;
    *myStream << ".html\">Next split</a></td></tr></table>";
    *myStream << "<p>As input we received the set of deduction objects:\n<p><pre>";
    dedset->print(*myStream);
    *myStream << "</pre><p>And modification objects:<p><pre>";
    modset->print(*myStream);
    *myStream << "</pre>";
    myStream->flush();
  }
}

void Output::writeSplittingEnd(const Variable& var)
{
  if (myOutputFormat == 1)
  {
    *myStream << "<h2><a name=\"" << mySplitNum << "\">Splitting number " << mySplitNum << " by variable "; 
    mySolver->printVar(myStream, var);    
    *myStream << "</a>\n</h2>";
    *myStream << "</body></html>";
    myStream->flush();
    myStream->close();
    delete myStream;
  }
}

/**
 * write a splitting
 */
void Output::writeSplitting(const DeductionObjectSet *formula, const Variable& var)
{
  ++mySplitNum;
  char myFullFileName[100] = "";
  char fname[30];
  sprintf(&(fname[0]),"%05lld.html",mySplitNum);
  strcat(myFullFileName,myDirName);
  strcat(myFullFileName,"/splits");
  strcat(myFullFileName,fname);
  myStream = new std::ofstream(myFullFileName);
  if (myOutputFormat == 1)
  {
    *myStream << "<html>\n<head>\n<title> Splitting #" << mySplitNum;
    *myStream << "</title>\n</head>\n<body>";
    *myStream << "<table width=\"600\"><tr><td width=\"100\">";
    char tmp[10];
    sprintf(&(tmp[0]),"%05lld",mySplitNum-1);
   if (mySplitNum > 1)
      *myStream << "<a href=\"../" << tmp << "/split.html\">Previous split</a>";
    *myStream << "</td><td width=\"400\"></td><td width=\"100\">\n<a href=\"../";
    sprintf(&(tmp[0]),"%05lld",mySplitNum+1);
    *myStream << tmp;
    *myStream << "/split.html\">Next split</a></td></tr></table>";
    *myStream << "<h2>Splitting number " << mySplitNum << " by variable ";
    mySolver->printVar(myStream, var);
    *myStream << "</h2>",
    *myStream << "<p>As input we received the formula:\n<p><pre>";
    formula->print(*myStream);
    *myStream << "</pre>";
    *myStream << "</body></html>";
    myStream->flush();
    myStream->close();
  }
  delete myStream;
}

/**
 * prepare the next output step
 */
void Output::nextStep()
{
  if (myOutputFormat == 1)
  {
    std::ostringstream myFullFileName;
    std::ostringstream myFileName;
    
    char s[31];
    sprintf(&(s[0]),"%05lld.html",mySplitNum);
    myFileName << s;
    sprintf(&(s[0]),"%05lld.html",mySplitNum-2);
    // close previous file
            
    if (mySplitNum>1)
    {
      *myStream << "</PRE><P><A HREF=\"" << s << "\">PREVIOUS</A> "
        << "<A HREF=\"" << myFileName.str().c_str() << "\">NEXT</A></P>"
        << "</BODY></HTML>" << std::endl;
      myStream->close();
      delete myStream;
    }

    // create file
    myFullFileName << "Outputs/";
    myFullFileName << myFileName.str().c_str();
    myStream = new std::ofstream(myFullFileName.str().c_str());
    
    if(!*myStream)
      throw CommentedException("Failed to create output file.\n");
  }
  ++mySplitNum;
  something_happened = true;
}

/**
 * print an object in html format
 */
void Output::printObject(Object *object, bool print_as_dedobj)
{
  printObjectWithoutIncrementing(object, myStream,print_as_dedobj);
  object->setOccurrence(vcur);
  object->incOccNum();
}

void Output::printObjectWithoutIncrementing(Object *object, std::ofstream *os, bool print_as_dedobj)
{
  char s[12]; long long sL,sN;
  TVarTreeNode *node = object->getOccurrence();
  if (node == 0) node = vcur;
  getSplitParams(node,sL,sN);
  if ( (sL==0) && (sN==0))
  {
    if (object->getOccNum())
      sprintf(&(s[0]),"0.html#");
    else
      sprintf(&(s[0]),"index.html#");
  }
  else
    sprintf(&(s[0]),"%llds%ld.html#",sL,node->filenum);
  *os << "<a name=\"" << object->getId() << "-" << object->getOccNum() << "\"";
  if (object->getOccNum())
    *os << " href=\"" << s << object->getId() << "-" << (object->getOccNum()-1) << "\"";
  *os << ">";
  object->print(*os,mySolver,print_as_dedobj);
  *os << "</a>";
  
}

void Output::attachLeft(Variable var)
{
  vcur->left = new TVarTreeNode; vcur->left->parent = vcur;
  vcur->left->var = var; vcur->left->val = 0;
  vcur->left->left = NULL; vcur->left->right = NULL;
  vcur->left->filenum = myFilenum + 1; ++myFilenum;
}

void Output::attachRight(Variable var)
{
  vcur->right = new TVarTreeNode; vcur->right->parent = vcur;
  vcur->right->var = var; vcur->right->val = 1;
  vcur->right->left = NULL; vcur->right->right = NULL;
  vcur->right->filenum = myFilenum + 1; ++myFilenum;
}

void Output::getSplitParams(TVarTreeNode *inpnode, long long &splitLev, long long &splitNum)
{
  if (inpnode == top)
  {
    splitLev = 0; splitNum = 0; return;
  }
  splitLev = 1;
  splitNum = 1;
  TVarTreeNode *node = inpnode;
  while (node!=top)
  {
    ++splitLev;
    node = node->parent;
  }
}

void Output::getFileName(char *str, TVarTreeNode *node)
{
  long long sLev, sNum;
  getSplitParams(node,sLev,sNum);
  sprintf(str,"%llds%ld.html",sLev,node->filenum);
}

void Output::htmlPrintHeader(std::ofstream *os)
{
  *os << "<html>\n<head>\n<title>Basolver HTML output</title>\n</head>\n\n<body>";
}

void Output::htmlPrintFooter(std::ofstream *os)
{
  *os << "\n</body>\n</html>\n";
}

void Output::htmlPrintBreadCrumbs(std::ofstream *os)
{
  *os << "<table width=\"100%\">\n<tr> <td>\n";
  long long sLev, sNum; TVarTreeNode *node = vcur;
  while (node != top)
  {
    getSplitParams(node,sLev,sNum);
    *os << " <a href=\"" << sLev << "s" << node->filenum << ".html\">";
    mySolver->printVar(os,node->var);
    *os << " = " << mySolver->getVarValue(node->var) << "</a>";
    *os << " << ";
   node = node->parent;
  }
  *os << "<a href=\"0.html\">Top</a> << <a href=\"pre.html\">Preprocess</a> << <a href=\"index.html\">Home</a>";
  *os << "\n</td></tr></table>\n\n";
}

void Output::beginSplitting()
{
  if (myOutputFormat != 1) return;
   
  char s[255] = ""; char ss[255] = "";
  if (vcur==top)
    strcpy(s,"0.html");
  else
    this->getFileName(&(s[0]),vcur);
  strcpy(ss,myDirName);
  strcat(ss,"/");  
  strcat(ss,s);
    
  myStream = new std::ofstream(ss);

  
  htmlPrintHeader(myStream);
  htmlPrintBreadCrumbs(myStream);

  something_happened = true;
  
  this->htmlCustomPrintSetPage();
    
  myIterNum = 0;
}

void Output::htmlPrintSetPage(bool begin)
{
  char s[255] = ""; char ss[255] = "";
  strcpy(ss,myDirName);
  if (begin) strcat(ss,"/beg"); else strcat(ss,"/end");
  this->getFileName(&(s[0]),vcur);
  strcat(ss,s);
  
  std::ofstream *os = new std::ofstream(ss);
  htmlPrintSetPageToStream(os);
  os->close();
  delete os;
}

void Output::printSatisfyingAssignmentPage(bool sat)
{
  if (myOutputFormat != 1) return;
  char s[255]; strcpy(s,myDirName); strcat(s,"/solution.html");
  *myStream << "\n<p>You can view the <b><a href=\"solution.html\">satisfying assignment page</a>.\n\n";
  std::ofstream *os = new std::ofstream(s);

  htmlPrintHeader(os);

  if (sat)
  {
    *os << "<h2>Satisfying assignment page</h2>";
    htmlPrintBreadCrumbs(os);
    std::map<long, int>* varValue;
    varValue = mySolver->getSatAssignment();
    std::map<long, int>::iterator it=varValue->begin();
    // Printing sat assignment (see Sat Competition rules)
    for(;it!=varValue->end();++it) if ((*it).second != -1)
    {
      mySolver->printVar(os,(*it).first);
      if (! (*it).second) *os << " = 0;<br>";
      else *os << " = 1;<br>";
    };         

  }
  else
  {
    *os << "<h2>Unsatisfiable</h2>\n\nThe input formula was unsatisfiable. Therefore, we can give you no information concerning its satisfying assignment... [sigh]...";
  }
    
    
  htmlPrintFooter(os);
  os->close();
  delete os;
}

void Output::htmlCustomPrintSetPage()
{
  if (myOutputFormat != 1) return;
  if (myNoSets) return;

  std::list<DeductionObjectSet *>::iterator it = mySolver->getListOfDeductionObjectSets()->begin();
  std::list<DeductionObjectSet *>::iterator end = mySolver->getListOfDeductionObjectSets()->end();
  std::list<long>::iterator sit = myDedSizesList.begin();
  std::list<long>::iterator send = myDedSizesList.end();

  bool changed = false;

  while (it != end)
  {
    if (*it)
    {
      if ((*it)->getSize() != (*sit))
      {
        changed = true;
        (*sit) = (*it)->getSize();
      }
    }
    ++it; ++sit;  
  }
  
  std::list<ModificationObjectSet *>::iterator mit = mySolver->getListOfModificationObjectSets()->begin();
  std::list<ModificationObjectSet *>::iterator mend = mySolver->getListOfModificationObjectSets()->end();
  sit = myModSizesList.begin();
  send = myModSizesList.end();

  while (mit != mend)
  {
    if (*mit)
    {
      if ((*mit)->getSize() != (*sit))
      {
        changed = true;
        (*sit) = (*mit)->getSize();
      }
    }
    ++mit; ++sit;
  }
 
  
  if (changed)
  {    
    char s[40] = ""; char ss[20] = "";
    strcpy(s,myDirName);
    sprintf(&(ss[0]),"/userset%lld.html",myCustomSetNum);
    ++myCustomSetNum;
    strcat(s,ss);
    
    *myStream << "<p>You can view the current state of <a href=\"userset" << (myCustomSetNum-1) << ".html\">solver sets</a></p>";
    
    std::ofstream* os = new std::ofstream(s);
    htmlPrintSetPageToStream(os);
    os->close();
    delete os;
    something_happened = false;
  }
  else
  {
    *myStream << "<p>You can view the current state of <a href=\"userset" << (myCustomSetNum-1) << ".html\">solver sets</a></p>"; 
  }
}

void Output::htmlPrintSetPageToStream(std::ofstream *os)
{
  htmlPrintHeader(os);
  
  list<DeductionObjectSet*> *d_lst = mySolver->getListOfDeductionObjectSets();
  list<DeductionObjectSet*>::iterator d_it = d_lst->begin();
  list<DeductionObjectSet*>::iterator d_end = d_lst->end();
  for (; d_it != d_end; d_it++)
    (*d_it)->printHtml(os, false);
    
  mySolver->getModifiers()->printHtml(os, false);

  list<ModificationObjectSet*> *m_lst = mySolver->getListOfModificationObjectSets();
  list<ModificationObjectSet*>::iterator m_it = m_lst->begin();
  list<ModificationObjectSet*>::iterator m_end = m_lst->end();
  for (; m_it != m_end; m_it++)
    (*m_it)->printHtml(os, false);

  *os << "\n\n";
  
  VarList *var_list = mySolver->getVarList();
  VarList::iterator it = var_list->begin();
  *os << "\n\n<p>Present and non-assigned variables:";
  int total = 0;
  for (; it != var_list->end(); ++it)
  {
    if (mySolver->getClauses()->isPresent(*it) || 
    mySolver->getNewClauses()->isPresent(*it) ||
    mySolver->getRecentClauses()->isPresent(*it))
    {
      *os << (*(mySolver->getVarNames()->find(*it))).second << ", ";
      total++;
    }
  }
  *os << " (total = " << total << ")";
  
  htmlPrintFooter(os);
}

void Output::endSplitting(Variable var,int first)
{
  if (myOutputFormat != 1) return;

  this->htmlPrintSetPage(false);
  
  attachLeft(var);
  attachRight(var);
 
  char s[255]; char ss[255];
  getFileName(s,vcur->left);
  getFileName(ss,vcur->right);

  *myStream << "\n\n<table width=100%><tr><td width=\"150\"><a href=\"" << s << "\">";
  mySolver->printVar(myStream,var);
  *myStream << " = " << first << "</a></td>\n<td width=\"150\"><a href=\"" << ss << "\">";
  mySolver->printVar(myStream,var);
  *myStream << " = " << 1-first << "</a></td>\n</tr></table>";

  htmlPrintFooter(myStream);
  myStream->close();
  delete myStream;
}

void Output::htmlPrintPreprocess()
{
  if (myOutputFormat != 1) return;
  char s[255] = ""; strcpy(s,myDirName); strcat(s,"/");
  myStream = new std::ofstream(strcat(s,"pre.html"));
  htmlPrintHeader(myStream);
  *myStream << "\n<h3>Preprocessing</h3>\n\n";
  myIterNum = 0;
}

void Output::endPrintPreprocess()
{
  if (myOutputFormat != 1) return;
  *myStream << "<p>Preprocessing ends. Proceed to the <a href=\"0.html\">first iteration</a> of the main cycle.\n\n";
  htmlPrintFooter(myStream);
  myStream->close();
  myIterNum = 0;
  something_happened = true;
}

void Output::htmlPrintFirstPage(DeductionObjectSet *set)
{
  if (myOutputFormat != 1) return;
  myFirstPagePrinted = true;
  char s[255] = ""; strcpy(s,myDirName); strcat(s,"/index.html");
  std::ofstream *os = new std::ofstream(s);
  htmlPrintHeader(os);

  *os << "<h3>Welcome</h3>\n<p>This page begins the .html output of the Basolver project.</p>\n";
  *os << "Please proceed to <a href=\"pre.html\">preprocessing</a> or the <a href=\"0.html\">first iteration</a> of the main cycle.\n";
  *os << "<p>You may also view the <a href=\"solution.html\">solution</a> immediately (note: is not created if the solver returns UNSATISFIABLE.</p>\n";

  *os << "The program received the following formula as input:\n\n<p>";
  set->printHtml(os,true);
      
  htmlPrintFooter(os);
  os->close();
  delete os;
}

void Output::printObjectRecognition(Object* object, std::string type, bool print_as_dedobj)
{
  if (myOutputFormat != 1)
    return;
    
  *myStream << "\n<BR><BR>Object ";
  this->printObject(object, print_as_dedobj);
  *myStream << " was recognized as a " << type;
  something_happened = true;
}

void Output::printIterationBegin()
{
  if (myOutputFormat != 1) return;
  ++myIterNum;
  
  *myStream << "\n<h4>Inner cycle iteration number " << myIterNum << "</h4>\n";
}

void Output::printIterationEnd()
{
  if (myOutputFormat != 1) return;
}
