#include "../algebraic/abstract/variable.h"

/**
 * @file tools.h
 * @brief contains standard procedures that may be used throughout
 * the whole project
 * @author sergey
 */

/// a pair of variables
typedef std::pair<Variable, Variable> VarPair;

/**
 * implements static methods that may be used throughout the whole project
 */
class Tools
{

public:
  
  /**
   * checks whether the given two sets of three variables each
   * coincide in two variables; the given sets are not
   * assumed to have any order; this procedure returns the pair
   * of non-coinciding variables, first element from the first
   * three parameters, second element - from the second set;
   * if the sets do not coincide by two elements, returns a pair
   * of empty smart pointers
   */
  static VarPair checkIntersectionByTwoVariables(Variable &x1, Variable &x2, Variable &x3, Variable &y1, Variable &y2, Variable &y3);

  /**
   * choose four unique variables from the given six and assign them to
   * the given parameters; discard the fifth variable
   */
  static bool chooseUnique(Variable,bool,Variable,bool,Variable,bool,Variable,bool,Variable,bool,Variable,bool,Variable,bool,Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&);


  /// switch values of two variables   
  static void switchVars(Variable &v1, bool &p1, Variable &v2, bool &p2);
};
