#ifndef __TIMER_H_
#define __TIMER_H_
#define TIMER_H 
/**
 * @file timer.h
 * This file contains an implementation of Timer class.
 */

#include <sys/time.h>
#include <sys/times.h>
/** 
 * Simple Timer class implementation.
 */
class Timer
{
public:
  /**
   * a constructor.
   */
  Timer() 
  {
    reset(); 
  };

  /**
   *  resets timer.
   */
  void
  reset()
  {
    stopped = true;
    elapsedSec = 0;
  };
  
  /**
   * starts the timer.
   */
  void
  start()    
  {
    if (stopped)   
    {
      stopped = false;
      times(&startTime);
    };
  };

  /**
   * stops the timer.
   */
  void
  stop()
  {
    if (!stopped)
    {
      stopped = true;
      struct tms currTime;
      times(&currTime);
      elapsedSec += getSecondsDifference(startTime, currTime);
    };
  };
  
  /**
   * returns seconds elapsed from start of timer.
   */
  double
  elapsedSeconds()
  {
    if (stopped) 
      return elapsedSec; 
    
    struct tms currTime;
    times(&currTime);
    return elapsedSec + getSecondsDifference(startTime, currTime);
  };

private:  
  /// get difference between two times in seconds
  double
  getSecondsDifference(struct tms& timeFrom, struct tms& timeTo)
  {
    unsigned int timeToTime = timeTo.tms_utime + timeTo.tms_cutime;
    unsigned int timeFromTime = timeFrom.tms_utime + timeFrom.tms_cutime;
    
    unsigned int dsec = timeToTime - timeFromTime;
    return (static_cast<double>(dsec))/100.; 
  }

private:
  /// is the timer stopped?
  bool          stopped;
  /// elapsed time in seconds
  double        elapsedSec; // in seconds 
  /// time when we started the timer
  struct tms    startTime;
}; // class Timer
#endif // __TIMER_H_
