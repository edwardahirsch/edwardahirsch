#include "statistics.h"

/**
 * @author sergey 
 * @brief implementation for statistics.h
 **/

Statistics *globalStatistics;

Statistics::Statistics()
{
  myClauses = 0;
  myTreeNodes = 0;
  myLiterals = 0;
  myLogEntries = 0;
  myObjects = 0;
  myDeductionObjects = 0;
  myModificationObjects = 0;
  myDeletedObjects = 0;
  myDeletedLiterals = 0;
  myDeletedDeductionObjects = 0;
  myDeletedModificationObjects = 0;
  mySimpleObjectSets = 0;
  myTrivialObjectSets = 0;
  myTreeDepth = 0;
  myMaxTotalSize = 0;
}

void Statistics::print(std::ostream& os)
{
  os << "c Elapsed time: " << this->getElapsedTime() << " seconds\nc\n";  
  os << "c Tree nodes (splittings): " << myTreeNodes << "\n";
  os << "c Tree depth: " << myTreeDepth << "\n";
  os << "c Log entries generated: " << myLogEntries << "\n";
  os << "c Total objects generated: " << myObjects << "\n";
  os << "c Maximal total size of all sets: " << myMaxTotalSize << "\n";
  os << "c Adjacency list-based object sets created: " << mySimpleObjectSets << "\n";
  os << "c Trivial list-based object sets created: " << myTrivialObjectSets << "\n";
}
