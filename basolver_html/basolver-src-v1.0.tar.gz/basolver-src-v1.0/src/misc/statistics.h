#ifndef __STATISTICS_H__
#define __STATISTICS_H__

#include <iostream>
#include "timer.h"

/**
 * @class Statistics
 * @brief This class is responsible for
 * collecting and outputting information about
 * different parameters of the solver's work
 */
class Statistics
{
private:
  
  /// number of clauses
  long myClauses;
  /// number of tree nodes
  long myTreeNodes;
  /// number of literals
  long myLiterals;
  /// number of log entries (\ref LogEntry)
  long myLogEntries;
  /// number of objects (\ref Object)
  long myObjects;
  /// number of deduction objects (\ref DeductionObject)
  long myDeductionObjects;
  /// number of modification objects (\ref ModificationObject)
  long myModificationObjects;
  /// number of deleted objects
  long myDeletedObjects;
  /// number of deleted literals
  long myDeletedLiterals;
  /// number of deleted \ref DeductionObject
  long myDeletedDeductionObjects;
  /// number of deleted \ref ModificationObject
  long myDeletedModificationObjects;
  /// tree depth
  long myTreeDepth;
  /// maximal total size
  long myMaxTotalSize;
  /// number of simple object sets
  long mySimpleObjectSets;
  /// number of trivial object sets
  long myTrivialObjectSets;

  /// timer
  Timer timer;

public:
  /// increment \ref myClauses
  void incClauses() {++myClauses;};
  /// increment \ref myTreeNodes
  void incTreeNodes() {++myTreeNodes;};
  /// increment \ref myLiterals
  void incLiterals() {++myLiterals;};
  /// increment \ref myLogEntries
  void incLogEntries() {++myLogEntries;};
  /// increment \ref myObjects
  void incObjects() {++myObjects;};
  /// increment \ref myDeductionObjects
  void incDeductionObjects() {++myDeductionObjects;};
  /// increment \ref myModificationObjects
  void incModificationObjects() {++myModificationObjects;};
  /// increment \ref myDeletedObjects
  void incDeletedObjects() {++myDeletedObjects;};
  /// increment \ref myDeletedLiterals
  void incDeletedLiterals() {++myDeletedLiterals;};
  /// increment \ref myDeletedModificationObjects
  void incDeletedModificationObjects() {++myDeletedModificationObjects;};
  /// increment \ref myDeletedDeductionObjects
  void incDeletedDeductionObjects() {++myDeletedDeductionObjects;};
  /// increment \ref mySimpleObjectSets
  void incSimpleObjectSets() {++mySimpleObjectSets;};
  /// increment \ref myTrivialObjectSets
  void incTrivialObjectSets() {++myTrivialObjectSets;};
  /// update maximal total size
  void updateMaxTotalSize(long curTotalSize) {if (curTotalSize > myMaxTotalSize) myMaxTotalSize = curTotalSize;};

  /// start the timer
  void startTimer() {timer.start();};
  /// stop the timer
  void stopTimer() {timer.stop();};
  /// get elapsed time
  double getElapsedTime() {return timer.elapsedSeconds();};
  
  /// increment \ref myTreeDepth
  void incTreeDepth() {++myTreeDepth;};
  /// set \ref myTreeDepth equal to param
  void setTreeDepth(long depth) {myTreeDepth = depth;};
  /// returns the tree depth (\ref myTreeDepth)
  long getTreeDepth() {return myTreeDepth;};
  /// sets tree depth to be the maximum of the current
  /// value and the given value
  void setTreeDepthToMax(long depth) {if (myTreeDepth < depth) myTreeDepth = depth;};

  /// print out the statistics
  void print(std::ostream& os);
  /// constructor
  Statistics();
};

#endif
