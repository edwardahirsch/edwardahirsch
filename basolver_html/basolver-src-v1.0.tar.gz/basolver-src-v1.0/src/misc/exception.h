#ifndef __MISC_EXCEPTION_H__ 
#define __MISC_EXCEPTION_H__ 

#include <string>
#include "misc/printable.h"

/**
 * @file exception.h
 * @brief Contains Exception interface.
 */

/** 
 * @brief Exception is surely what you can throw to identify problems. 
 *
 * It is also possible to print it out after catching: printable things are 
 * "exception.what()" identifying what really happened, and "expection.module()"
 * showing the module (logical part of code) where it's happened. So, this would
 * be the correct code:
 * @code
 *    try 
 *    {
 *      ...
 *    }
 *    catch (Exception &e)
 *    {
 *        cout << "Exception in " << e.module() << ": " << e.what() << '\n';
 *    }
 * @endcode
 * NB: you cannot say "Exception e" above, since Exception is abstract type.
 */

  /**
   * Main interface class in Exception namespace.
   */
  class Exception 
  { 
    /**
     * This class showing the module (logical part of code) where relative 
     * Exception happened.
     */
    class PrintableModule : public Printable<Exception> 
    {
    public:
      /**
       * A constructor.
       */
      PrintableModule(const Exception *e) : Printable<Exception>(e) 
      { }
      
      /**
       * A typical member printing class information. 
       */
      virtual void 
      print(std::ostream &os) const 
      { 
        p->module(os); 
      }
    };
    
    /**
     * @class PrintableWhat
     * This class identifying what really happened, the reason of Exception.
     */
    class PrintableWhat : public Printable<Exception> 
    {
    public:
      /**
       * A constructor.
       */
      PrintableWhat(const Exception *e) : Printable<Exception>(e) 
      {  }    
     
      /**
       * A typical member printing class information.
       */
      virtual void 
      print(std::ostream &os) const 
      {
        p->what(os); 
      }
    };
    
  public:
    /**
     * A member giving access to the module of Exception.
     * @return the module
     */ 
    PrintableModule 
    module() const 
    {
      return PrintableModule(this);
    }
    
    /**
     * A member giving access to the what happened information of Exception.
     */
    PrintableWhat   
    what() const 
    {
      return PrintableWhat(this);
    }
    
    /**
     * A constructor.
     */ 
    Exception() 
    { }
    
    /**
     * A destructor.
     */
    virtual 
    ~Exception() 
    { }
    
    /**
     * A member printing module information of the Exception.
     */
    virtual void 
    module(std::ostream &os) const = 0;
    
    /**
     * A member printing what happened information of the Exception.
     */
    virtual void 
    what(std::ostream &os) const = 0;
  };
  
  /**
   * system-wide exceptions go here...
   */ 
  class SystemException : public Exception 
  {
  public:
    /**
     * A member printing the Exception happened with the system.
     */
    virtual void
    module (std::ostream& os) const
    {
      os << "system";                              
    }
  };
  
  /** Reports on system operation failures.
   */
  class CommentedException : public SystemException
  {
    /// comment string
    std::string comment;
  public:
    /**
     * A constructer.
     */
    CommentedException(std::string c) :
      comment(c)
    { }
        
    virtual void
    what (std::ostream& os) const
    {
      os << comment;
    }
  };
    
  /**
   * Exception of not implemented code.
   */
  class NotImplemented : public SystemException 
  {
  public:
    /**
     * Return the reason of the exception.
     */
    virtual void 
    what (std::ostream& os) const 
    {
      os << "not implemented";
    }
  };
    
  /**
   * Out of memory exception.
   */
  class OutOfMemory : public SystemException 
  {
  public:
    /**
     * Return the reason of the exception.
     */
    virtual void 
      what (std::ostream& os) const 
      {
        os << "out of memory";
      }
  };

#endif /* __MISC_EXCEPTION_H__ */ 
