#include "ruleschecker.h"
#include <fstream>
#include <sstream>
#include <sys/stat.h>

/**
 * @author kulikov 
 * @brief implementation for ruleschecker.h
 **/

using namespace std;
    
bool
RulesChecker::check(BooleanAlgebraicSolver *slv, const Rule* rule, Object* result, Object* obj1, Object* obj2, Object* obj3, Object* obj4)
{
  int myMinNumberOfVariables = 12;
  int myMaxNumberOfVariables = 16;

  if (!obj1 && !obj2 && !obj3 && !obj4)
  {
    std::cerr << "\nI cannot check this case, as no premise is given (rule: " << rule->getName() << "). Skipping.";
    return true;
  }
  DeductionObject* res_ded_obj = dynamic_cast<DeductionObject*>(result);
  if (res_ded_obj == 0)
  {
    return true;
    std::cerr << "\nStrange: " << " rule" << rule->getName() << " result=";
    result->print(std::cerr, slv);
    exit(-1);
  }
  
  if (res_ded_obj->isTautology())
    return true;
    
  if (res_ded_obj->isBoolean())
    return true;
    
  list<Object*> object_list;  
  if (obj1)
    object_list.push_back(obj1);
  if (obj2)
    object_list.push_back(obj2);
  if (obj3)
    object_list.push_back(obj3);
  if (obj4)
    object_list.push_back(obj4);
    
  PVarList var_list = result->getVariableList();

  for (list<Object*>::iterator obj_it = object_list.begin();
  obj_it != object_list.end(); obj_it++)
  {
    PVarList temp_list = (*obj_it)->getVariableList();
    
    for (list<Variable>::iterator temp_var_it = temp_list->begin();
    temp_var_it != temp_list->end(); temp_var_it++)
    {
      bool already_appears = false;
      
      for (list<Variable>::iterator var_it = var_list->begin();
      var_it != var_list->end(); var_it++)
      {
        if ((*var_it) == (*temp_var_it))
	{
	  already_appears = true;
	  break;
	}
      }      
      
      if (!already_appears)
        var_list->push_back(*temp_var_it);
    }
    
    temp_list->clear();
  }
  
  // now var_list contains all variables appearing in 
  // input objects
  
  int var_num = var_list->size();
  
  if (var_num > myMaxNumberOfVariables && var_num < myMinNumberOfVariables)
  {
    if (var_num > myMaxNumberOfVariables)
      std::cerr << "\n" << rule->getName() << ": " << var_num;
    return true;
  }
  else
    std::cerr << ".";
  
  
  vector<int> assignment(var_num + 1, 0);
  bool all_assignments_enumerated = false;
  
  while (!all_assignments_enumerated)
  { 
    bool all_premises_satisfied = true;

    for (list<Object*>::iterator obj_it = object_list.begin();
    obj_it != object_list.end(); obj_it++)
    {
      if (!isSatisfied(*obj_it, var_list, assignment))
      {
        all_premises_satisfied = false;
	break;
      }
    }
    
    if (all_premises_satisfied)
    {
      if (!isSatisfied(result, var_list, assignment))
      {
        std::cerr << "\n\nIt seems that there is a bug in " << rule->getName() << " :";
        std::cerr << "\nReason:";
        if (obj1)
        {
          std::cerr << "\nPremise: ";
          obj1->print(std::cerr, slv);
        }
        if (obj2)
        {
          std::cerr << "\nPremise: ";
          obj2->print(std::cerr, slv);
        }
        if (obj3)
        {
          std::cerr << "\nPremise: ";
          obj3->print(std::cerr, slv);
        }
        if (obj4)
        {
          std::cerr << "\nPremise: ";
          obj4->print(std::cerr, slv);
        }
	std::cerr << "\n-----------------------------------";  
	std::cerr << "\nResult: ";
  result->print(std::cerr,slv);
	  
        std::cerr << "\nAssignment: ";
	int num = 1;
        for (list<Variable>::iterator var_it = var_list->begin();
        var_it != var_list->end(); var_it++)
	{
	  std::cerr << " p" << (*var_it) << "=" << assignment[num];
	  num++;
	}
	std::cerr << " satisfies all premises, but not the result.\n\n\n";
        	
	exit(-1);
      }
    }
    
    // taking another assignment
    int i;
    
    for (i = 1; i <= var_num; i++)
    {
      if (assignment[i] == 1)
        assignment[i] = 0;
      else
        break;
    }
    
    if (i == (var_num + 1))
      all_assignments_enumerated = true;
    else
      assignment[i] = 1;
  } 
  
  
  assignment.clear();
  var_list->clear();
  object_list.clear();
  return true;
}

bool
RulesChecker::isSatisfied(Object* obj, PVarList var_list, vector<int> assignment)
{
  SAClause* ded_obj = dynamic_cast<SAClause*>(obj);
  Equality* mod_obj = dynamic_cast<Equality*>(obj);
  
  bool result = false;
  
  if (ded_obj == 0 && mod_obj == 0)
  {
    Assert(0, "\nStrange!..");
  }
  
  if (ded_obj != 0)
  {
    PSAClause clone = (ded_obj->clone());
    int num = 1; 
    for (std::list<Variable>::iterator var_it = var_list->begin(); 
    var_it != var_list->end(); var_it++)
    {
      clone->assign(*var_it, assignment[num]);
      num++;  
    }
    
    if (clone->isTautology())
      result = true;
      
    if (clone->isContradiction())
      result = false;
  }    
    
  if (mod_obj != 0)
  {
    PSALiteral clone = (mod_obj->clone());
    
    PEquality clone_eq = boost::shared_dynamic_cast<Equality, SALiteral>(clone);
    
    Assert(clone_eq, "\nStrange");
    
    int num = 1; 
    for (std::list<Variable>::iterator var_it = var_list->begin(); 
    var_it != var_list->end(); var_it++)
    {
      clone_eq->assign(*var_it, assignment[num]);
      num++;  
    }
    
    if (clone_eq->isTautology())
      result = true;
      
    if (clone_eq->isContradiction())
      result = false;
  }    

  
  return result;
}


