#ifndef __MISC_PRINTABLE_H__ 
#define __MISC_PRINTABLE_H__ 
/**
 * @file printable.h
 * This file contains Printable interface.
 */

#include <iostream>
/**
 * Printable is something that can be put to ostream. 
 *
 *  That means that if class T has @code Printable<Something> @endcode
 *  as its base class, and T properly defines virtual member 
 *  @code 
 *    print(ostream&);
 *  @endcode you can write 
 *  @code 
 *    os << t;
 *  @endcode
 *  where @b os is @b ostream and @b t is @b T.
 *   
 *  IMPORTANT: Since "printability" will most probably be used for complex
 *  objects, @code Printable<T> @endcode stores only pointer to T. So this may 
 *  break if @b T will be destroyed (e.g. if it is automatic variable) after 
 *  printable is created but before it is actually "printed". So printables 
 *  should only be used "locally", or with long-living objects. Actually, this 
 *  mechanism was introduced for exceptions (see misc/exception.h), where 
 *  Exception is not destroyed until it is printed out.
 *  
 *  An alternative would be for Printable to copy its contents when printable 
 *  is created. I'm not sure it is worth caring. Anyway, use it with care.
 */ 
template<class T>
class Printable 
{
protected:
  /// What will be printed
  const T    *p; 
public:
  /// A constructor.
  Printable(const T *t) : p(t) 
  { };
  
  /// A destructor.
  virtual 
  ~Printable() 
  { };
  
  /**
   * This method does user-defined printing.
   */
  virtual void 
  print(std::ostream &os) const = 0; 
  
  /**
   * This method implements std-like environment for input/output.
   */
  inline friend std::ostream& 
  operator << (std::ostream &os, const Printable<T> &p) 
  {
    p.print(os);
    return os;
  };
};
     
/**
 * This is specialization of Printable class for pointers 
 * (to avoid pointer-to-pointer).
 */
template<class T>
class Printable<T*> 
{
protected:
  /// What will be printed
  const T    *p;  
public:
  /// A constructor.
  Printable(const T *t) : p(t) 
  { };
  
  /// A destructor.
  virtual ~Printable() 
  { };
  
  // if we erase everything we must put 0
  /// This method implements user-defined printing.
  virtual void print(std::ostream &os) const = 0;  
 
  /**
   * This method implements std-like environment for input/output.
   */
  inline friend std::ostream& operator << (std::ostream &os, const Printable<T> &p) 
  {
    p.print(os);
    return os;
  };
};
#endif /* __MISC_PRINTABLE_H__ */ 
