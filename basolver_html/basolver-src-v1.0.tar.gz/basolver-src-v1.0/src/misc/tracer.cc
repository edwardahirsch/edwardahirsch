#include "tracer.h"

/**
 * @file tracer.cc
 * @brief Contains implementation of trace methods (needed for convenient debugging). 
 */

#ifdef USE_TRACING
std::set<std::string> *
traceSet()
{
    static std::set<std::string>* mySet = 0;
    if (!mySet)
    {
        mySet = new std::set<std::string>;
    }
    return mySet;
}
#endif
