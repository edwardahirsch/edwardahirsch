#ifndef __MISC_ASSERT_H__
#define __MISC_ASSERT_H__

#include <string>
#include <iostream>
#include <sstream>
#include "config.h"
#include "misc/exception.h"

/**
 * @file assert.h
 * @brief Contains interfaces of assertions (mostly needed for parsing).
 */


  /**
   * A class of system exceptions that is thrown by Assert macro.
   */
  class AssertionFailed : public SystemException 
  { 
    /// comment
    std::string comment;
    /// filename
    std::string file;
    
    
    
    /// number of the line
    int    line;
  public:
    /**
     * A constructor.
     */
    AssertionFailed(std::string c, std::string f, int l) : 
      comment(c), file(f), line(l) 
    { }
    
    /**
     * A member that gives information about the reason of exception.
     */
    virtual void 
    what(std::ostream &os) const
    {
      os << "assertion \"" << comment << "\" failed in " << file << ":" << line;
    }
  }; // AssertionFailed : public SystemException 
    
  /**
   * An important class of exception that allow to trace the exceptions.
   * It contains all levels of exceptions.
   */
  class TraceException : public SystemException 
  {
    /// comment
    std::string comment;
    /// filename
    std::string file;
    /// number of the line
    int         line;
  public:
    /**
     * A constucter.
     */
    TraceException(std::string c, std::string f, int l) :
      comment(c), file(f), line(l) 
    { }
    
    /**
     * A member that gives information about the reason of exception.
     */
    virtual void 
    what(std::ostream &os) const
    {
      os << comment <<std::endl << "failed in " << file << ":" << line;
    }
  }; // TraceException : public SystemException


/** @def Assert(cond,comment)
 * This macro try to assert condition. If it failed throw an exception.
 */
#ifdef DEBUG
#define Assert(cond,comment) \
   (static_cast<void> (cond ? 0 : throw AssertionFailed(comment, __FILE__, __LINE__)))
#else
#define Assert(cond,comment) 
#endif

/**
 * @def TRY(s)
 * A macro that separated code in blocks, after each blocks a Trace exceptions
 * will throw. This help to follow the "way" of exception in all files.
 */
#ifdef DEBUG
#define TRY(s) \
  try  \
  {    \
    s; \
  }    \
  catch(Exceptions::Exception &e) \
  { \
    std::ostringstream ost; \
    e.what(ost); \
    (static_cast<void> (throw TraceException(ost.str(),__FILE__, __LINE__))); \
  }
#else
#define TRY(s) \
  { \
    s;\
  }
#endif

#endif // __MISC_ASSERT_H__

