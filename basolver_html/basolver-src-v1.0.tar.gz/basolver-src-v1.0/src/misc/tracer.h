/** @file tracer.h
 * @brief Contains interfaces of structures needed for convenient debugging. 
 */

/**
 *  @fn inline bool checkTrace(const std::string& str)
 *  @brief Returns true if tracing on this string is on
 *  @see TRACE
 */

/**
 *  @fn inline void setTrace(const std::string& str)
 *  @param str string to start traceing on
 *  @brief Initiates tracing on the string
 *  @see TRACE
 */

/**
 *  @fn inline void clearTrace(const std::string& str)
 *  @param str string to stop traceing on
 *  @brief Stops tracing on the string
 *  @see TRACE
 */

/**
 *  @def TRACE(n,s)
 *  @brief This macros is used for tracing. 
 *
 *  It is given two arguments. The first argument is a string, the second is
 *  an operator.  If USE_TRACING is not defined (implied by DEBUG), it does
 *  nothing.  Otherwise, it is used for tracing.  If tracing on the given
 *  string was switched on by setTrace, the operator is executed. It might be
 *  very convinient to put TRACE calls into the program and switch tracing on
 *  depending on the command line. Allows to see the program behavior without
 *  recompiling it.
 *
 *  Sample usage:
 *   
 *  @verbatim
 *  int
 *  main()
 *  {
 *      const std::string module = "This module";
 *      setTrace(module);
 *      TRACE(module,{
 *                       std::cout << "Here ";
 *                       std::cout << " I am\n";
 *                   });
 *      clearTrace(module);
 *      TRACE(module,{
 *              std::cout << "And here \n";
 *      });
 *      return 0;
 *  @endverbatim
 */


#ifndef __TRACER_H__
#define __TRACER_H__
#include <iostream>
#include <string>
#include <set>
#include "config.h"

#ifdef USE_TRACING
extern std::set<std::string> * traceSet();

inline bool
checkTrace(const std::string& str)
{
    if (traceSet()->count(str))
        return true;
    else 
        return false;
}

inline void
setTrace(const std::string& str)
{
    if (!checkTrace(str))
        traceSet()->insert(str);
}

inline void
clearTrace(const std::string& str)
{
    if (checkTrace(str))
        traceSet()->erase(str);
}

#define TRACE(n,s) if(checkTrace(n)) { \
        s; \
     }
#else
inline void
setTrace(const std::string&)
{ }
inline void
clearTrace(const std::string&)
{ }
inline bool
checkTrace(const std::string& str)
{ return false; }
#define TRACE(n,s)
#endif
#endif // __TRACER_H__
//}
