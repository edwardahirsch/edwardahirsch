#ifndef __summation2rule_h__
#define __summation2rule_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"

/// Forward declaration.
class BooleanAlgebraicSolver;

/**
 * @@file summation2.h
 * Contains Summation2Rule interface.
 */

/**
 * @@class Summation2Rule
 * @@brief implements Summation2 rule
 * (see documentation for details)
 */
class Summation2Rule : public GenerationRule
{
public:
  /// Constructor.
  Summation2Rule(BooleanAlgebraicSolver* s) : mySolver(s) {};


  virtual void 
  operator() (DeductionObjectSet* returned_set, 
              DeductionObjectSet* new_set, 
	      DeductionObjectSet* old_set);

  std::string
  getName() const {return "Summation2 Rule";};

private:  
  /// Produces an object x=a+cS
  /// if obj2 is of the form b=a+S.
  PDeductionObject
  operator() (
  Variable x, bool x_sign,
  Variable a, bool a_sign,
  Variable b, bool b_sign,
  Variable c, bool c_sign,
  PDeductionObject obj2);
  
  /// Reference to the solver.
  BooleanAlgebraicSolver* mySolver;
};
#endif

