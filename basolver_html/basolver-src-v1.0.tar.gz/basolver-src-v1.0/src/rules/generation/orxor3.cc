#include "orxor3.h"

/**
 * @file orxor3.cc
 * @brief implementation for orxor3.h
 * @author sergey
 */


PDeductionObjectIterator ORXOR3Rule::getBeginIterator1(DeductionObjectSet *set) const
{
  return set->getBegin(indXeqAB);
}
  
PDeductionObjectIterator ORXOR3Rule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEnd(indXeqAB);
}
  
bool ORXOR3Rule::checkObject1(PDeductionObject obj) const
{
  return (obj->getEqType() == eqtXeqAB);
}

bool ORXOR3Rule::checkObject2(PDeductionObject obj) const
{
  return (obj->getEqType() == eqt124);
}

Variable ORXOR3Rule::getVarForIndex(PEquality eq)
{
  return eq->getVar1();
}

bool ORXOR3Rule::checkObjectMatch(PEquality obj1,PEquality obj2)
{

  varY = obj1->getVar1();
  posY = obj1->getPos1();
  varV = obj1->getVar2();
  posV = obj1->getPos2();
  varW = obj1->getVar3();
  posW = obj1->getPos3();

  bool posSecondObject = obj2->getPos1() xor obj2->getPos2() xor obj2->getPos3() xor obj2->getPos4();
  
  if ((varY == varV) || (varY == varW)) return false;
  
  if (obj2->getVar1() == varY)
  {
    if (!assignVariables(obj2->getVar2(), obj2->getVar3(), obj2->getVar4(), posSecondObject)) return false;
  }
  else if (obj2->getVar2() == varY)
  {
    if (!assignVariables(obj2->getVar1(), obj2->getVar3(), obj2->getVar4(), posSecondObject)) return false;
  }
  else if (obj2->getVar3() == varY)
  {
    if (!assignVariables(obj2->getVar1(), obj2->getVar2(), obj2->getVar4(), posSecondObject)) return false;
  }
  else if (obj2->getVar4() == varY)
  {
    if (!assignVariables(obj2->getVar1(), obj2->getVar2(), obj2->getVar3(), posSecondObject)) return false;
  }
  else return false;
   
  
  if ( (varX == varY) || (varX == varV) || (varX == varW) || (varS == varY) || (varS == varV) || (varS == varW) )
    return false;
  
  return true;

}

bool ORXOR3Rule::createResult(PDeductionObject object1, PDeductionObject object2, DeductionObjectSet *result_set, PEquality obj1, PEquality obj2) 
{
 
  PEquality resultEquality;
  
  resultEquality = AlgebraicGenerator::createSeqXpVnWm2XWnVEquality(varS,posS,varX,posX,varV,posV,varW,posW);
  
  
  if (!resultEquality->isTautology())
  {
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);
    mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);
    return true;
  }
  return false;
}


bool ORXOR3Rule::assignVariables(Variable Var2,Variable Var3,Variable Var4,bool posSecond)
{
  if ((Var2 == varV) || (Var2 == varW))
    {
      if (Var2 == varW)
      {
      }
      else if (Var2 == varV)
      {
        varS = varW; posS = posW;
        varW = varV; posW = posV;
        varV = varS; posV = posS;
      }
      varS = Var3;
      posS = !posSecond xor posW xor posY;
      varX = Var4;
      posX = true;
    }
    else if ((Var3 == varV) || (Var3 == varW))
    {
      if (Var3 == varW)
      {
      }
      else if (Var3 == varV)
      {
        varS = varW; posS = posW;
        varW = varV; posW = posV;
        varV = varS; posV = posS;
      }
      varS = Var2;
      posS = !posSecond xor posW xor posY;
      varX = Var4;
      posX = true;
    }
    else if ((Var4 == varV) || (Var4 == varW))
    {
      if (Var4 == varW)
      {
      }
      else if (Var4 == varV)
      {
        varS = varW; posS = posW;
        varW = varV; posW = posV;
        varV = varS; posV = posS;
      }
      varS = Var2;
      posS = !posSecond xor posW xor posY;
      varX = Var3;
      posX = true;
    }
    else return false;

    return true;
}

