#ifndef __xor3generationrule_h__
#define __xor3generationrule_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../general/solver.h"

/**
 * @file xor3generationrule.h
 * @brief Contains implementation of XOR3GenerationRule class
 * @author sergey
 */

/**
 * @class XOR3GenerationRule
 * @brief implements XOR3GenerationRule
 * (see documentation for details)
 */
class XOR3GenerationRule: public GenerationRule//2
{
public:

  /// Constructor
  XOR3GenerationRule(BooleanAlgebraicSolver *s) : mySolver(s) {};

  /// Destructor
  virtual ~XOR3GenerationRule() {};
  
  /**
   * Generates object from two given objects; currently returns an empty
   * object
   */  
  virtual PDeductionObject
  operator() (const PDeductionObject&, const PDeductionObject&) const 
  {
    PDeductionObject obj;
    return obj;
  }

  /**
   * main interface: generates from newset and set, puts into returned_set;
   * if (use_new_only) does not check set vs set
   */
  virtual void
  operator() (DeductionObjectSet* returned_set, DeductionObjectSet* dedset, DeductionObjectSet* newset, bool use_new_obj) const;

  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set, DeductionObjectSet* old_set)
  {
    (*this)(returned_set,old_set,new_set,true);
  }

  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set)
  {
    DeductionObjectSet* objset = 0;
    (*this)(returned_set,objset,new_set,true);
  }
  
  std::string getName() const {return "XOR3GenerationRule";};

private:
  /// solver
  BooleanAlgebraicSolver *mySolver;
  /**
   * Creates the resulting equality with given variables
   * and adds it to the given set
   */
  void createResult(int j,Variable a, Variable b, Variable c, Variable d, Variable y, bool wconst1, bool wconst2, DeductionObjectSet* result_set, PDeductionObject premise1, PDeductionObject premise2) const;
};
#endif

