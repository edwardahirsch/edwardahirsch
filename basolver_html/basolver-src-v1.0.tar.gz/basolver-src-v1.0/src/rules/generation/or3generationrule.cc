#include "or3generationrule.h"
#include "../../misc/output.h"
/**
 * @file or3generationrule.cc
 * @brief implementation for or3generationrule.h
 * @author sergey
 */




void 
OR3GenerationRule::operator()(
DeductionObjectSet* result_set, 
DeductionObjectSet* ded_obj,
DeductionObjectSet* new_obj,
bool use_new_obj) const
{


 
  bool has_old_obj = false;
  if (ded_obj != 0) has_old_obj = true;
  if (use_new_obj && (!new_obj->getSize())) return;
  PDeductionObjectIterator it1 = new_obj->getBegin(indXeqAB);
  PDeductionObjectIterator newend = new_obj->getEnd(indXeqAB);
  PDeductionObjectIterator it2,end2,newend2;
  PDeductionObjectIterator end1;
  if (has_old_obj) end1= ded_obj->getEnd(indXeqAB);
  else end1 = newend;
  Variable l1, l2, l3;
  Variable v1,v2,v3,v4, varl, var1, var2, var3, varForIndex;
  bool has_new_premise1, has_new_premise2;
  bool p1,p2,p3,p4;
  bool pol,po1,po2,po3;
  has_new_premise1 = true;
  while(!(it1->equals(*end1)))
  {
    // a standard block of code to switch from the new set to the old one,
    // keeping in mind where we currently are (to determine later
    // whether new objects participate in the derivation)
    if (it1->equals(*newend)) 
    {
      has_new_premise1 = false;
      if (!has_old_obj) break;
      it1 = ded_obj->getBegin(indXeqAB);
      if (it1->equals(*end1)) break;
    }

    PSAClause clause1=(boost::shared_dynamic_cast<SAClause, DeductionObject>((**it1)));
    if (!clause1){++*it1; continue;}

    // get variables of the first premise
    if (!(**it1)->getXeqAB(v1,p1,v2,p2,v3,p3)) {++*it1; continue;}
    PEquality equality1=boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin()));  
    varForIndex = v1;
    if (varForIndex==0) {++*it1; continue;}

    
// making new iterators
	
    it2=new_obj->begin(varForIndex);
    newend2=new_obj->end(varForIndex);
    if (has_old_obj)
      end2=ded_obj->end(varForIndex);
    else end2 = newend2;
    has_new_premise2 = true;
    

    while (!(it2->equals(*end2)))
    {
 
      if (it2->equals(*newend2))
      {       
        has_new_premise2 = false;
		   
        // if new objects are already done with,
		    // there is no point to continue
        if ( (use_new_obj && !has_new_premise1) || (!has_old_obj))
          break;
        else
          it2 = ded_obj->begin(varForIndex);
        if (it2->equals(*end2)) break;
      }
      // first rule:
      // d = ab   y = c + d - cd
      // -----------------------
      //    y = ab + c - abc
      if ((**it2)->getXeqAB(l1,po1,l2,po2,l3,po3))
      {
        if ( ( (l2 == varForIndex) && (p1 == !po2)) || ( (l3 == varForIndex) && (p1 == !po3) ) )
        {
          if ((((**it1)->getId())!=(**it2)->getId()))
          {
            
            Variable not_d;  // variable c
            bool pnot_d;      // its boolean value

            
            if (l2 == varForIndex) 
            {
              not_d = l3; 
              pnot_d = !po3;
            }
            else
            {
              not_d = l2;
              pnot_d = !po2;
            }

            // we have initialized not_d = c
            // if c=d in the second premise, continue
            if(not_d == v1){++*it2; continue;}
            
            PEquality resultEquality = AlgebraicGenerator::createYeqACpDmACDEquality(l1,!po1,v2,p2,v3,p3,not_d,pnot_d);
                       
            if (!resultEquality->isTautology())
            {
              PSAClause clause=LogicalGenerator::makeSAClause();
              clause->add(resultEquality);
              mySolver->processNewObject(this,clause,result_set,&(***it1),&(***it2),NULL,NULL,"part 1");
            }            
          } 
        }
      }      
     
      // second rule:
      // d = ab    y = ac + d - acd
      // --------------------------
      //    y = ac+ ab - abc
      //    
      // and fourth rule:
      //  w=x+y+z-xy-xz-yz+xyz     x=ab
      //  ------------------------------
      //     w=ab+y+z-aby-abz-yz+abyz
      
      else if ( ((**it2)->getYeqACpDmACD(varl,pol,var1,po1,var2,po2,var3,po3)) && (var3 == varForIndex) && (po3==p1))
      {
        Variable a,b,c;
        bool pa,pb,pc;
        
        // in what follows we take care of recognizing
        // the literals a and c
        
        if ((v3 == var1) && (p3==po1))
        {
          a = v3; b = v2; c = var2;
          pa=p3;pb=p2;pc=po2;
        }
        else if ((v3 == var2)&&(p3==po2))
        {
          a = v3; b = v2; c = var1;
          pa=p3;pb=p2;pc=po1;
        }
        else if ((v2 == var1)&&(p2==po1))
        {
          a = v2; b = v3; c = var2;
          pa=p2;pb=p3;pc=po2;
        }
        else if ((v2 == var2)&&(p2==po2))
        {
          a  = v2;  b  = v3;  c  = var1;
          pa = p2;  pb = p3;  pc = po1;
        }
        else {++*it2; continue;}
        
        // creating equality
        PEquality resultEquality = AlgebraicGenerator::createDeqABpACmABCEquality(varl,pol,a,pa,b,pb,c,pc);
 
        if (!resultEquality->isTautology())
        {
          PSAClause clause=LogicalGenerator::makeSAClause();
          clause->add(resultEquality);
           
          mySolver->processNewObject(this,clause,result_set,&(***it1),&(***it2),NULL,NULL,"part 2");
        
        }
      }
      
      ++*it2;
    }
 
    mySolver->simplifyAllObjectsByNewModifiers();
    ++*it1;
 }

  // third rule:
  // d = ab + ac - abc    y = bc + d - bcd
  // -------------------------------------
  //         y = ab + ac + bc - 2abc
  //

  it1 = new_obj->getBegin(indDeqABpACmABC);
  newend = new_obj->getEnd(indDeqABpACmABC);  
  if (has_old_obj) end1 = ded_obj->getEnd(indDeqABpACmABC);
  else end1 = newend;
  has_new_premise1 = true;
  it1 = new_obj->getBegin(indDeqABpACmABC);
  
  while (!(it1->equals(*end1)))
  {
    // a standard block of code to switch from the new set to the old one,
    // keeping in mind where we currently are (to determine later
    // whether new objects participate in the derivation)
    if (it1->equals(*newend)) 
    {
      has_new_premise1 = false;
      if (!has_old_obj) break;
      it1 = ded_obj->getBegin(indDeqABpACmABC);
      if (it1->equals(*end1)) break;
    }
    if (!(**it1)->getDeqABpACmABC(v1,p1,v2,p2,v3,p3,v4,p4)) {++*it1; continue;}
    varForIndex = v1;
    if (varForIndex==0) {++*it1; continue;}
    it2=new_obj->begin(varForIndex);
    newend2 = new_obj->end(varForIndex);
    if (has_old_obj) end2=ded_obj->end(varForIndex);
    else end2 = newend2;
    while (!(it2->equals(*end2)))
    {
      
      if (it2->equals(*newend2)) 
      {       
        has_new_premise2 = false;
        if ( (use_new_obj && !has_new_premise1) || (!has_old_obj) )
          break;
        else
		      it2 = ded_obj->begin(varForIndex);
        if (it2->equals(*end2)) break;
      }      
      if ( ((**it2)->getYeqACpDmACD(varl,pol,var1,po1,var2,po2,var3,po3)) && (var3 == varForIndex) && (p1==po3) )
      {
        Variable a,b,c,y;
        bool pa,pb,pc,py;
        y = varl; py = pol;  // set y value
        a = v2;   pa = p2;   // set a value

        // check for different variants of mutual positioning of b and c
        if ((v3 == var1) && (v4 == var2) && (p3==po1) && (p4==po2))
        {
          b  = v3; c  = v4;
          pb = p3; pc = p4;
        }
        else if ((v3 == var2) && (v4 == var1) && (p3==po2) && (p4==po1))
        {
          b  = v4; c  = v3;
          pb = p4; pc = p3;
        }
        else {++*it2; continue;}

        PEquality resultEquality = AlgebraicGenerator::createXeqABpACpBCm2ABCEquality(y,py,a,pa,b,pb,c,pc);
        
        if (!resultEquality->isTautology())
        {
          PSAClause clause=LogicalGenerator::makeSAClause();
          clause->add(resultEquality);
          mySolver->processNewObject(this,clause,result_set,&(***it1),&(***it2),NULL,NULL,"part 3");
        }
      }

      ++*it2;
    }

    
    mySolver->simplifyAllObjectsByNewModifiers();
    ++*it1;
  }
}

