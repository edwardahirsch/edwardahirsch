#include "summationrule.h"

/**
 * @file summationrule.cc
 * @brief implementation for summationrule.h
 * @author dmitrits
 */


void
SummationRule::operator() (DeductionObjectSet* returned_set, 
 				  DeductionObjectSet* newset,
                                  DeductionObjectSet* dedset)
{
  PDeductionObjectIterator it1 = newset->getBeginIteratorOnWholeSet();
  PDeductionObjectIterator it2;
  PDeductionObjectIterator end;
  PDeductionObjectIterator end1;
  end1=newset->getEndIteratorOnWholeSet();
  while (!(it1->equals(*end1)))
  {
    Variable varForIndex;
    PSAClause clause1 = 
      (boost::shared_dynamic_cast<SAClause, DeductionObject>(**it1));
    if (!clause1)  {++(*it1); continue;}
    if (clause1->getNumberOfLiterals()>1) {++(*it1); continue;}
    PEquality equality1 = 
      boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin()));
    if(!(equality1->getLHS()->isVariable()))  {++(*it1); continue;}
    if((equality1->getLHS()->getFirstConstant()!=1)) {++(*it1); continue;}
    if((equality1->getRHS()->getDegree()>2))   {++(*it1); continue;}
    bool is_left_positive;
    if (equality1->getRHS()->getDegree()==1)
    {
      varForIndex = equality1->getLHS()->getVariable();    
      is_left_positive=true;
    }
    else
    {
      //Checking some curious properties (see doc)
      if (!(this->checkForValid(equality1, dedset, newset, is_left_positive, varForIndex)))
      {
        ++(*it1); continue;
      }
    };
    it2=newset->begin(varForIndex);    
    end=newset->end(varForIndex);
    this->searchForSecond(returned_set,it1, equality1, varForIndex, it2, end,dedset,newset, true, is_left_positive);
    it2=dedset->begin(varForIndex);
    end=dedset->end(varForIndex);
    this->searchForSecond(returned_set,it1, equality1, varForIndex, it2, end,dedset,newset, false, is_left_positive);
    mySolver->simplifyAllObjectsByNewModifiers();
    ++(*it1);
  };    
};
				     
bool SummationRule::searchForSecond(
        DeductionObjectSet* returned_set, PDeductionObjectIterator it1, PEquality equality1,
	Variable var1, PDeductionObjectIterator it2, 
	PDeductionObjectIterator end, 
        DeductionObjectSet* dedset, DeductionObjectSet* newset, bool checkid, bool is_left_positive)
{
    while(!(it2->equals(*end)))
    {
      PSAClause clause2=(boost::shared_dynamic_cast<SAClause, DeductionObject>((**it2)));
      if (!clause2) {++(*it2); continue;};
      if (clause2->getNumberOfLiterals()>1) {++(*it2); continue;};
      PEquality equality2=boost::shared_dynamic_cast<Equality, SALiteral>(*(clause2->begin()));  
      if (equality2->getRHS()->getDegree()>2 
          ) 
      {
        ++(*it2); continue;
      };
      
      if (!equality2->getLHS()->isVariable()) {++(*it2); continue;}; 
      if (equality2->getLHS()->getFirstConstant()!=1) {++(*it2); continue;}; 
      if (equality1->getRHS()->getDegree()!=1 && equality2->getRHS()->getDegree()!=1) {++(*it2); continue;};
      bool is_left_positive2;
      if (equality2->getRHS()->getDegree()==1)
      {
        if (equality2->getLHS()->getVariable()!=var1)
	      {
	        ++(*it2); continue;
	      };

        second_is_valid = true;
        is_left_positive2 = true;
      }
      else
      {
        Variable var2 = 0;

        second_is_valid = 
          this->checkForValid(equality2, dedset, newset, is_left_positive2, var2);

        if (var1!=var2)
        {
          ++(*it2); continue;
        };
      };      
      if ((((**it1)->getId())!=(**it2)->getId()))
      {
        if (!checkid || ((((**it1)->getId())<(**it2)->getId())))
        {
          PDeductionObject obj= this->getSum((**it2), (**it1), (is_left_positive != is_left_positive2), returned_set);
        };
      };
      ++(*it2); 
    }
    return false;
}		

PDeductionObject
SummationRule::getSum(const PDeductionObject& dobj1, const PDeductionObject& dobj2, bool not_left, DeductionObjectSet* returned_set) const
{
  PSAClause result;
  PSAClause clause1=(boost::shared_dynamic_cast<SAClause, DeductionObject>(dobj1));
  PSAClause clause2=(boost::shared_dynamic_cast<SAClause, DeductionObject>(dobj2));
  PEquality equality1=boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin()));
  PEquality equality2=boost::shared_dynamic_cast<Equality, SALiteral>(*(clause2->begin()));
  if ((equality1->getRHS()->getDegree()!=1) && (equality2->getRHS()->getDegree()!=1)) return result;
  PMonomialIterator it=equality1->getRHS()->getBeginIterator();
  for(;!(it->equals(*(equality1->getRHS()->getEndIterator())));++(*it))
  {
    if((**it)->getSize()>1 && abs((**it)->getCoeff()) % 2 != 0)
      return result;	  
  };
  it=equality2->getRHS()->getBeginIterator();
  for(;!(it->equals(*(equality2->getRHS()->getEndIterator())));++(*it))
  {
    if((**it)->getSize()>1 && abs((**it)->getCoeff()) % 2 != 0)
      return result;	  
  };

  
  PPolynomial right;
  PPolynomial left;
  if (!not_left)
  {
    right=equality2->getRHS()->clone();
    left=equality2->getLHS()->clone();
    (*left)+=(*(equality1->getRHS()));
    (*right)+=(*(equality1->getLHS()));
  }
  else
  {
    right=equality2->getRHS()->clone();
    (*right)+=*(equality1->getRHS());
    left=equality2->getLHS()->clone();
    (*left)+=*(equality1->getLHS());
  };
  PEquality resEq=AlgebraicGenerator::createEquality(left, right);
  it=resEq->getRHS()->getBeginIterator();
  // reporting about unsatisfiable result
  if (resEq->isUnsatisfiable())
  {
    result=LogicalGenerator::makeSAClause();
    result->add(resEq);
    mySolver->processNewObject(this, result, returned_set, &(*dobj1),&(*dobj2),NULL,NULL, "Summation");
    return result;      
  }
  // We deduce contradiction in case of not all restrictions to the premises hold.
  else if(!second_is_valid)
    return result;
  for(;!(it->equals(*(resEq->getRHS()->getEndIterator())));++(*it))
  {
    if((**it)->getSize()>1 && abs((**it)->getCoeff()) % 2 != 0)
      return result;	  
  };

  PPolynomial poly1 = equality1->getRHS()->getEvenPart();
  *poly1 += -poly1->getFreeCoefficient();
  PPolynomial poly2 = equality2->getRHS()->getEvenPart();
  *poly2 += -poly2->getFreeCoefficient();
  Variable newLHS = resEq->getLHS()->getVariable();
  PPolynomial poly3 = resEq->getRHS()->getEvenPart();
  *poly3 += -poly3->getFreeCoefficient();

  // restriction (g)  -- verified by dmitrits
  // we don't really nead sum of two true linears (without even part)
  // if $S+T$ is linear and doesn't contains even monomials then number of
  // variables in it should be equals to number of monomials in even parts of
  // $T$ and $S$ and T and S are not empty
  if(poly3->getSize() == 0 
      && (int) resEq->getVariableList()->size() != poly1->getSize() + poly2->getSize()
      && poly1->getSize()!=0 &&  poly2->getSize()!=0 
      )
  {
    return result;
  }
  // restriction (j)  -- verified by dmitrits
  // if $S+T$ is linear and contains even monomials then variable in lhs of
  // equlity $0=S+T$ is not from even parts of $T$ and $S$;
  if(poly3->getSize() != 0 &&
      resEq->getRHS()->getDegree()==1 &&
      (poly1->containsVariable(newLHS) || poly2->containsVariable(newLHS)))
  {
    return result;
  }

  // restriction (i)  -- verified by dmitrits
  // if $S+T$ is linear and contains even monomials then the size of even part
  // should
  // be equal to sum of even part sizes of $T$ and $S$;
  if(poly3->getSize() != 0 
      && resEq->getRHS()->getDegree() == 1
      && poly3->getSize() != poly1->getSize() + poly2->getSize()
    )
  {
    return result;
  }

  PPolynomial poly4 = equality1->getRHS()->getOddPart();
  PPolynomial poly5 = equality2->getRHS()->getOddPart();
  PVarList varList  = PVarList(new std::list<Variable>);
  poly3->getVarList(varList);

  //restriction (l) -- verified by dmitrits
  //if $S+T$ is linear and contains even monomials then monomial in odd part of
  // $S+T$ should not contains variables from even parts of $T$ and $S$;
  if(poly3->getSize() != 0 
      && resEq->getRHS()->getDegree() == 1
  )
  {
    for(std::list<Variable>::iterator vbeg = varList->begin(); vbeg!=varList->end();vbeg++)
    {
      if((poly4->containsVariable(*vbeg) || poly5->containsVariable(*vbeg)))
      {
        return result;
      }
    }
  }
  
  varList->clear();
  poly1->getVarList(varList);
  // restriction (k)  -- verified by dmitrits
  // if $S+T$ is linear then the variables from even parts of $T$ and
  // variables from even parts of $S$ are disjoint.
  if(resEq->getRHS()->getDegree() == 1)
  {
    for(std::list<Variable>::iterator vbeg = varList->begin(); vbeg!=varList->end();vbeg++)
    {
      if(poly2->containsVariable(*vbeg))
      {
        return result;
      }
    }
  }
   
  if (!resEq->getRHS()->hasBigCoefficients())
  {
    result=LogicalGenerator::makeSAClause();
    result->add(resEq);
    mySolver->processNewObject(this, result, returned_set, &(*dobj1),&(*dobj2),NULL,NULL, "Summation");
    return result;      
  }
  return result;
};

bool SummationRule::checkForValid(PEquality equality, DeductionObjectSet* dedset, 
                   DeductionObjectSet* newset, bool& is_left_positive,
		   Variable& var)
{
  if (equality->getEqType()==eqtXORSum) return false;
  bool just_verify=false;
  Variable cur=equality->getLHS()->getVariable();
  bool verified=false;
  
  if (!(dedset->isVariableInNonUnitClause(cur)) && 
      !(newset->isVariableInNonUnitClause(cur)) &&
      !(mySolver->getNewObjects()->isVariableInNonUnitClause(cur)) 
      )
  {
    is_left_positive=true;
    var=cur;
    just_verify=true;
  }
  else
   verified=true;	  
  
  PMonomialIterator mon=equality->getRHS()->getBeginIterator();
  bool var_found=false;
  for(;!mon->equals(*equality->getRHS()->getEndIterator());++(*mon))
  {
    if ((**mon)->getSize()>1) break;
    if (!verified && ((**mon)->getSize()==1))
    {
      cur=(**mon)->getVariable();
      verified= ((dedset->isVariableInNonUnitClause(cur)) ||  
       (newset->isVariableInNonUnitClause(cur)) 
       || mySolver->getNewObjects()->isVariableInNonUnitClause(cur)
       );
    };    
    if (!just_verify && !var_found && ((**mon)->getSize()==1) && (abs((**mon)->getCoeff())==1))
    {
      cur=(**mon)->getVariable();
      if (!(dedset->isVariableInNonUnitClause(cur)) &&  
          !(newset->isVariableInNonUnitClause(cur)) 
          && !(mySolver->getNewObjects()->isVariableInNonUnitClause(cur))
          )
      {
        var_found=true;
	var=cur;
        is_left_positive=((**mon)->getCoeff()==-1);
        just_verify=true;
      };	  
    };
    if (verified && (var_found || just_verify)) return true;     	
  };      
  if (verified && (var_found || just_verify)) return true;     	
  return false;  
};		   

