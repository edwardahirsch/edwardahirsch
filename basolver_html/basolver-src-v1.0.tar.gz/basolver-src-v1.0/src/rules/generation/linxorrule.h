#ifndef __linxorrule_h__
#define __linxorrule_h__

#include "../abstract/generic.h"

/**
 * @file linxorrule.h
 * @brief Contains LinXORRule class.
 * @author dmitrits
 */

/// This rule proceeds as follows:
///
///    v = xy+xz=2xyz    w = xy+xz-2xyz
///
///  ----------------------------------
///
///         0 = -v+yz+w

class LinXORRule : public GenericTwoPremiseRule
{
  
public:

  /// constructor
  LinXORRule(BooleanAlgebraicSolver* s) {mySolver=s;};
  
  virtual std::string getName() const {return "LinXORRule";};

protected:

  virtual PDeductionObjectIterator getBeginIterator1(DeductionObjectSet *) const;
  virtual PDeductionObjectIterator getEndIterator1(DeductionObjectSet *) const;
  virtual PDeductionObjectIterator getBeginIterator2(DeductionObjectSet *) const;
  virtual PDeductionObjectIterator getEndIterator2(DeductionObjectSet *) const;

  virtual bool checkObject1(PDeductionObject) const;
  virtual bool checkObject2(PDeductionObject) const;
  
  virtual Variable getVarForIndex(PEquality);

  virtual bool checkObjectMatch(PEquality,PEquality);

  virtual bool createResult(PDeductionObject, PDeductionObject, DeductionObjectSet *, PEquality, PEquality);


private:

  /// show do we really need to reverse equalities before count sum
  bool reverse; 
};


#endif
