#ifndef __boothsub_h__
#define __boothsub_h__

#include "../abstract/gensubrule.h"

/**
 * @file boothsub.h
 * @brief Contains BoothSubRule class.
 * @author sergey
 */

/// The rule substitutes equalities of certain types
/// into equalities of other types (mostly Special or
/// BoothSubResult) to perform the inference needed to
/// prove equivalence of Booth multipliers. The rule
/// has multiple restrictions and special conditions
/// on its applications. Please refer to the documentation
/// for more details.


class BoothSubRule : public GenericTwoPremiseRule
{
  
public:

  /// constructor
  BoothSubRule(BooleanAlgebraicSolver* s) { mySolver = s; myCurIndex = indCeqXZmXYpnWYnZp2WXYnZ; mySecondVariable = false; wasLeft=false; applied=0;}
  /// returns the name of this rule 
  virtual std::string getName() const {return "BoothSubRule";};

protected:

  PDeductionObjectIterator getBeginIterator1(DeductionObjectSet *) const;
  virtual bool checkObject1(PDeductionObject obj) const;
  virtual bool checkObject2(PDeductionObject obj) const {return true;};
  PDeductionObjectIterator getEndIterator1(DeductionObjectSet *) const;
  virtual Variable getVarForIndex(PEquality) {return 0;};
  virtual Variable getNextVarForIndex(PEquality);
  virtual bool checkObjectMatch(PEquality,PEquality) {return true;};
  virtual bool createResult(PDeductionObject, PDeductionObject, DeductionObjectSet *, PEquality, PEquality);
  virtual int whichOneToDelete(PEquality,PEquality) const;
  virtual bool swapIterator1();
  virtual bool manyVarsForIndex() const {return true;}; 

private:

  /// the variable which should be substituted
  Variable myVariable;

  /// the polynomial which this variable should be substituted for
  PPolynomial myPolynomial;

  /// the type of the result
  TEqualityType myType;

  /// current index type
  TIndexType myCurIndex;

  /// shows whether we have switched to the index on the second variable
  /// in the case of eqtBoothSubResult
  bool mySecondVariable;
  
  /// Show if index by left variable was already created
  bool wasLeft;
  
  /// iterator for current index variable;
  PMonomialIterator currentLinear;  
  
  /// iterator for last monomial;
  PMonomialIterator endLinear;  
  
  /// number of generated objects
  int applied;  
};


#endif
