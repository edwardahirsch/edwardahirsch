#include "linxorrule.h"

/**
 * @file linxorrule.cc
 * @brief implementation for linxorrule.h
 * @author dmitrits
 */


PDeductionObjectIterator LinXORRule::getBeginIterator1(DeductionObjectSet *set) const
{
  return set->getBegin(indXeqABpACpBCm2ABC);
}
  
PDeductionObjectIterator LinXORRule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEnd(indXeqABpACpBCm2ABC);
}
  
PDeductionObjectIterator LinXORRule::getBeginIterator2(DeductionObjectSet *set) const
{
   return set->getBegin(indZeqWXpVXm2WVX);
}
 
PDeductionObjectIterator LinXORRule::getEndIterator2(DeductionObjectSet *set) const
{
  return set->getEnd(indZeqWXpVXm2WVX);
}


bool LinXORRule::checkObject1(PDeductionObject obj) const
{
  return true;
}


bool LinXORRule::checkObject2(PDeductionObject obj) const
{
  return obj->getEqType()==eqtZeqWXpVXm2WVX;
}

Variable LinXORRule::getVarForIndex(PEquality eq)
{
  return eq->getVar4();
}

bool LinXORRule::checkObjectMatch(PEquality obj1,PEquality obj2)
{ 
  PMonomialIterator mon1=obj1->getRHS()->getEndIterator();
  --(*mon1);
  PMonomialIterator mon2=obj2->getRHS()->getEndIterator();
  --(*mon2);
  if (!((***mon1)==(***mon2))) return false;
  reverse=(((**mon1)->getCoeff())==((**mon2)->getCoeff()));
  if ((obj1->getVar1()==obj2->getVar1()) && (obj1->getPos1()==obj2->getPos1())) return false;
  return true;
}   

bool LinXORRule::createResult(PDeductionObject object1, PDeductionObject object2, DeductionObjectSet *result_set, PEquality obj1, PEquality obj2)
{
  PPolynomial left=obj1->getLHS()->clone();
  PPolynomial right=obj1->getRHS()->clone();
  if (reverse)
  {
    (*left)+=(*obj2->getRHS());
    (*right)+=(*obj2->getLHS());
  }
  else
  {
    (*left)+=(*obj2->getLHS());
    (*right)+=(*obj2->getRHS());
  };
  PEquality resultEquality=AlgebraicGenerator::createEquality(left, right);
  PSAClause clause=LogicalGenerator::makeSAClause();
  clause->add(resultEquality);
  mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);
  return true;
}

