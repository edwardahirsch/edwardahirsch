#ifndef __summationrule_h__
#define __summationrule_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../misc/output.h"
/**
 * @file summationrule.h
 * @brief Contains implementation of summation rule
 * @author dmitrits
 */

/**
 * @class SummationRule
 * @brief implements summation rule
 * (see documentation for details)
 */
class SummationRule: public GenerationRule
{
public:
  /// Constructor.
  SummationRule(BooleanAlgebraicSolver* s): mySolver(s) {};

  std::string
  getName() const {return "SummationRule";};

  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set, DeductionObjectSet* old_set);

  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set)
  {
    DeductionObjectSet* objset = 0;
    (*this)(returned_set,new_set, objset);
  }

private:
  /**
   * This variable store the result of checkForValid function for second
   * equality.
   */
  bool second_is_valid;

  /**
   * Searches for second premise.
   * Main operator finds first object, and ask this procedure to find next.
   * Returns true only with TRACE summationremove. It means that we need remove first object. 
   */
  bool searchForSecond(
        DeductionObjectSet* returned_set, PDeductionObjectIterator it1, PEquality equality1,	
	Variable var1,
	PDeductionObjectIterator it2, PDeductionObjectIterator end, 
        DeductionObjectSet* dedset,
        DeductionObjectSet* newset, bool checkid, bool not_left);

  /**
   * Returns the sum of two objects
   * bool parameter shows the order of summation 
   * false -- left1+left2=right1+right2
   * true -- left1+right2=left2+right1
   */
   
  PDeductionObject
  getSum(const PDeductionObject& dobj1, const PDeductionObject& dobj2, bool not_left, DeductionObjectSet* returned_set) const;
	
  /// Checks
  /// 1) Finds first minimal monomial M=+-1*v (in equality), there v 
  ///  has no entrance in not unit clause
  /// 2) Checks, that v==var
  /// 3) Checks that equality contains variable with entrance in not unit clause
  bool checkForValid(PEquality equality, DeductionObjectSet* dedset, 
                   DeductionObjectSet* newset, bool& is_left_positive,
		   Variable& var);
   /// solver
  BooleanAlgebraicSolver *mySolver;

  
};
#endif
