#include "xorsummation.h"

/**
 * @file xorsummation.cc
 * @brief implementation for xorsummation.h
 * @author sergey
 */

PDeductionObjectIterator XORSummationRule::getBeginIterator1(DeductionObjectSet *set) const
{
  return set->getBeginIteratorOnWholeSet();
}
  
PDeductionObjectIterator XORSummationRule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEndIteratorOnWholeSet();
}
  
PDeductionObjectIterator XORSummationRule::getBeginIterator2(DeductionObjectSet *set) const
{
  return set->getBeginIteratorOnWholeSet();
}
 
PDeductionObjectIterator XORSummationRule::getEndIterator2(DeductionObjectSet *set) const
{
  return set->getEndIteratorOnWholeSet();
}

bool XORSummationRule::checkObject(PDeductionObject obj) const
{
  PSAClause clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(obj);
  if (!clause) return false;
  PEquality equality=clause->getEquality();
  if (!equality) return false;
  if (!equality->getLHS()->isVariable()) return false;
  PMonomialIterator mon=equality->getRHS()->getEndIterator();
  PMonomialIterator beg=equality->getRHS()->getBeginIterator();
  do
  {
    --(*mon);
    if ((**mon)->getSize()!=2) break;
    if (abs((**mon)->getCoeff()) % 2 !=0) return false;
  }
  while (!mon->equals(*beg));  
  return true;
}

bool XORSummationRule::checkObject1(PDeductionObject obj) const
{
  PSAClause clause=boost::shared_dynamic_cast<SAClause,DeductionObject>(obj);
  PEquality equality=clause->getEquality();
  if ((**(equality->getLHS()->getBeginIterator()))->getCoeff()!=1) return false;
  if (equality->getEqType()==Special && equality->getRHS()->getDegree()==1)
  {
     PMonomialIterator mon=equality->getRHS()->getBeginIterator();
     PMonomialIterator end=equality->getRHS()->getEndIterator();
    while (!mon->equals(*end))
    {
      if ((**mon)->getSize() && abs((**mon)->getCoeff())!=1) return false;
      ++(*mon);
    }
    return true;
  };
  if (!equality->getLHS()->isVariable()) return false;  
  if (equality->getEqType()==eqtXORSumWithLin)
    return true;
  return ((obj->getEqType()==eqt11m2) || (obj->getEqType()==eqtXORSum));
}


bool XORSummationRule::checkObject2(PDeductionObject obj) const
{
  return this->checkObject1(obj);
}

Variable XORSummationRule::getVarForIndex(PEquality eq)
{
  return eq->getLHS()->getVariable();
}

bool XORSummationRule::checkObjectMatch(PEquality obj1,PEquality obj2)
{ 
  if (obj1->getLHS()->getVariable()!=obj2->getLHS()->getVariable()) return false;
  if (obj1->getRHS()->getDegree()==1 && obj2->getEqType()!=eqt11m2 && obj2->getEqType()!=eqtXORSum) return false;
  if (obj2->getRHS()->getDegree()==1 && obj1->getEqType()!=eqt11m2 && obj1->getEqType()!=eqtXORSum) return false;
  if (obj1->getEqType()==eqtXORSumWithLin && obj2->getEqType()==eqtXORSumWithLin) return false; 
  return true;
}   

bool XORSummationRule::createResult(PDeductionObject object1, PDeductionObject object2, DeductionObjectSet *result_set, PEquality obj1, PEquality obj2)
{
  result_created=false;
  if (object1->getId()>=object2->getId()) return false;
  PEquality equality1=obj1;
  PSAClause clause2=boost::shared_dynamic_cast<SAClause, DeductionObject>(object2);
  PEquality equality2=obj2;
  PEquality resultEquality=AlgebraicGenerator::makeEqualityWithCloning(equality1->getRHS(), equality2->getRHS());
  if (resultEquality->isUnsatisfiable())
  {
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);
    mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);
    result_created=false;
    return false;
  };
  if (!resultEquality->getLHS()->isVariable()) return false;
  if (!resultEquality->isTautology())
  {
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);
    if (!this->checkObject(clause)) return false; 
    resultEquality->setEqType(eqtXORSum);
    if (obj1->getEqType()==eqtXORSumWithLin || obj2->getEqType()==eqtXORSumWithLin
        || obj1->getRHS()->getDegree()==1 || obj2->getRHS()->getDegree()==1)
      resultEquality->setEqType(eqtXORSumWithLin);	
    mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);
    result_created=true;
    return true;
  }
  return false;
}

int XORSummationRule::whichOneToDelete(PEquality eq1, PEquality eq2) const
{
  if (!result_created) return 0;
  if ((eq1->getEqType()==eqtXORSum) || (eq1->getEqType()==eqtXORSumWithLin)) return 1;
  if ((eq2->getEqType()==eqtXORSum) || (eq2->getEqType()==eqtXORSumWithLin)) return 2;
  return 0;
};
