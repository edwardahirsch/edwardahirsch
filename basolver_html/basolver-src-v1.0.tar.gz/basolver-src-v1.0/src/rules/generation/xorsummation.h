#ifndef __xorsummation_h__
#define __xorsummation_h__

#include "../abstract/generic.h"

/**
 * @file xorsummation.h
 * @brief Contains XORSummationRule class.
 * @author dmitrits
 */

/// This rule proceeds as follows:
///
///    y = S    y = T
///
///  -----------------------
///
///         0 = T-S
///
/// with some restriction (see doc)
class XORSummationRule : public GenericTwoPremiseRule
{
  
public:

  /// constructor
  XORSummationRule(BooleanAlgebraicSolver* s) {mySolver=s;};
  /// returns the name of the rule
  virtual std::string getName() const {return "XORSummationRule";};

protected:

  virtual PDeductionObjectIterator getBeginIterator1(DeductionObjectSet *) const;
  virtual PDeductionObjectIterator getEndIterator1(DeductionObjectSet *) const;
  virtual PDeductionObjectIterator getBeginIterator2(DeductionObjectSet *) const;
  virtual PDeductionObjectIterator getEndIterator2(DeductionObjectSet *) const;

  /// checks the object to see whether it is subject to xorsummation
  bool checkObject(PDeductionObject) const;
  
  virtual bool checkObject1(PDeductionObject) const;
  virtual bool checkObject2(PDeductionObject) const;
  
  /// sets index to left variable of first permise
  virtual Variable getVarForIndex(PEquality);

  virtual bool checkObjectMatch(PEquality,PEquality);

  virtual bool createResult(PDeductionObject, PDeductionObject, DeductionObjectSet *, PEquality, PEquality);

  virtual int whichOneToDelete(PEquality, PEquality) const;
  
private:

  /// a flag that shows whether a result was created
  bool result_created;
};


#endif
