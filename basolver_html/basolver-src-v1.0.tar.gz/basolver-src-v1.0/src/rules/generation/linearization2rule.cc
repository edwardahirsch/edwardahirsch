#include "linearization2rule.h"
#include "../../misc/output.h"

/**
 * @file linearization2rule.cc
 * @brief implementation for linearization2rule.h
 * @author sergey
 */



void
Linearization2Rule::operator()(
DeductionObjectSet* result_set,
DeductionObjectSet* ded_obj,
DeductionObjectSet* new_obj,
bool use_new_obj)
{

  // this variable is responsible for the possibility
  // of getting NULL as ded_obj
  bool has_old_obj = false;
  if (ded_obj != 0) has_old_obj = true;
  PDeductionObjectIterator it1 = new_obj->getBegin(indXeqAB);
  PDeductionObjectIterator it2,end2,newend2;
  PDeductionObjectIterator newend = new_obj->getEnd(indXeqAB);
  PDeductionObjectIterator end1;

  if (has_old_obj)
    end1 = ded_obj->getEnd(indXeqAB);
  else
    end1 = newend;
  
  
  bool has_new_premise1 = true, has_new_premise2;
  Variable a,b,c,d,x,y;
  bool posx,posa,posb,withconstant;

  for (; !(it1->equals(*end1)); ++(*it1))
  {
    // a standard block of code to switch from the new set to the old one,
    // keeping in mind where we currently are (to determine later
    // whether new objects participate in the derivation)
    if (it1->equals(*newend))
    {
      has_new_premise1 = false;
      if (!has_old_obj) break;
      it1 = ded_obj->getBegin(indXeqAB);
      if (it1->equals(*end1)) break;
    }


    if (!(**it1)->getXeqAB(x,posx,a,posa,b,posb)) continue;
    if (a < 0) continue;
    
    // creating second iterator
    it2=new_obj->begin(a);
    newend2=new_obj->end(a);
    if (has_old_obj)
      end2=ded_obj->end(a);
    else
      end2=newend2;
    
    for (; !(it2->equals(*end2)); ++(*it2))
    {
      if (it2->equals(*newend2)) 
      {     
        has_new_premise2 = false;
        // if new objects are already done with,
        // there is no point to continue
        if ( (use_new_obj && !has_new_premise1) || (!has_old_obj) )
          break;
        it2 = ded_obj->begin(a);
        if (it2->equals(*end2)) break;
      }
      // the following line checks an equality to be like y=c+d-2cd
      // or y=1-c-d+2cd (which one it is is put into withconstant)
      if (!(**it2)->getOneOneMinusTwoWConst(y,c,d,withconstant)) continue;

      // New restriction
      PSAClause it2clause; 
      it2clause=boost::shared_dynamic_cast<SAClause,DeductionObject>(**it2);
      Variable indexvar;
      int match;
      match=1;
      if ((a == c) && (b == d))
        indexvar=y;
      else if ( (a == y) && (b == c))
        indexvar=d;
      else if ( (a == y) && (b == d))
        indexvar=c;
      else
      { 
        match=0;
      }
      if (match) 
      {
        int foundXor=this->checkRestriction(mySolver->getClauses(), indexvar, it2clause, false);
        if (foundXor<2)  
          foundXor+=this->checkRestriction(mySolver->getNewClauses(), indexvar, it2clause, false);
        if (foundXor<2)  
          foundXor+=this->checkRestriction(mySolver->getRecentClauses(), indexvar, it2clause, false);
        if (foundXor<2)  
          foundXor+=this->checkRestriction(mySolver->getNewObjects(), indexvar, it2clause, true);	  
        if (foundXor==1) continue;	
      } //end of new restriction
      
      if ((a == c) && (b == d))
      {

        createResult2(x,posx,a,posa,b,posb,y,!withconstant,**it1,**it2,result_set); 
      }
      else if ( (a == y) && (b == c))
      {

        createResult2(x,posx,a,posa,b,posb,d,!withconstant,**it1,**it2,result_set);
      }
      else if ( (a == y) && (b == d))
      {

        createResult2(x,posx,a,posa,b,posb,c,!withconstant,**it1,**it2,result_set);
      }
    }
      

    mySolver->simplifyAllObjectsByNewModifiers();
  }
}


void Linearization2Rule::createResult2(Variable x, bool posx, Variable a, bool posa, Variable b, bool posb, Variable y, bool posy, PDeductionObject premise1, PDeductionObject premise2, DeductionObjectSet* result_set) const
{
  PPolynomial resultLHS = AlgebraicGenerator::makePolynomial();
  PPolynomial resultRHS = AlgebraicGenerator::makePolynomial();
  PMonomial mona = AlgebraicGenerator::makeMonomial(a); 
  PMonomial monb = AlgebraicGenerator::makeMonomial(b); 
  PMonomial monx = AlgebraicGenerator::makeMonomial(x);
  PMonomial mony = AlgebraicGenerator::makeMonomial(y); 
  PMonomial mon1 = AlgebraicGenerator::makeMonomial();
  
  if (posx && posa && posb)
    monx->setCoeff(-2);
  else if (!posx && posa && posb)
  {
    monx->setCoeff(2);
    mon1->setCoeff(-2);
    resultRHS->addMonomial(mon1);
  } 
  else if (posx && !posa && posb)
  {
    monb->setCoeff(-1);
    monx->setCoeff(2);
  } 
  else if (!posx && !posa && posb)
  {
    monx->setCoeff(-2);
    mon1->setCoeff(2);
    monb->setCoeff(-1);
    resultRHS->addMonomial(mon1);
  }
  else if (posx && posa && !posb)
  {
    mona->setCoeff(-1);
    monx->setCoeff(2);
  }  
  else if (!posx && posa && !posb)
  {
    monx->setCoeff(-2);
    mona->setCoeff(-1);
    mon1->setCoeff(2);
    resultRHS->addMonomial(mon1);
  } 
  else if (posx && !posa && !posb)
  {
    monx->setCoeff(-2);
    mon1->setCoeff(2);
    mona->setCoeff(-1);
    monb->setCoeff(-1);
    resultRHS->addMonomial(mon1);
  }
  else if (!posx && !posa && !posb)
  {
    monx->setCoeff(2);
    mona->setCoeff(-1);
    monb->setCoeff(-1);
  }

  if (posy)
    mony->setCoeff(-1);
  else
  {
    PMonomial mon2 = AlgebraicGenerator::makeMonomial();
    mon2->setCoeff(-1);
    resultRHS->addMonomial(mon2);
  }
 
  resultRHS->addMonomial(mony);
  resultRHS->addMonomial(mona);
  resultRHS->addMonomial(monb);
  resultRHS->addMonomial(monx);

  PEquality resultEquality=AlgebraicGenerator::createEquality(AlgebraicGenerator::makePolynomial(),resultRHS);    

  resultEquality->setVar1(a);
  resultEquality->setPos1(true);
  resultEquality->setVar2(b);
  resultEquality->setPos2(true);
  resultEquality->setVar3(y);
  resultEquality->setPos3(true);
  resultEquality->setVar4(x);
  resultEquality->setPos4(true);
  resultEquality->setVar5(0);

  if (!resultEquality->isTautology())
  {
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);
  

    clause->setGeneratedByLinearization();

      
    mySolver->processNewObject(this,clause,result_set,&(*premise1),&(*premise2),NULL,NULL);
  }  
}
 

void 
Linearization2Rule::operator()(
DeductionObjectSet* result_set, 
DeductionObjectSet* ded_obj) const
{
  
  PDeductionObjectIterator it1 = ded_obj->getBeginIteratorOnWholeSet();
  PDeductionObjectIterator it2;
  PDeductionObjectIterator end;
  for (; !(it1->equals(*ded_obj->getEndIteratorOnWholeSet())); ++(*it1))
  {
    PSAClause clause1=(boost::shared_dynamic_cast<SAClause, DeductionObject>((**it1)));
    if (!clause1) continue;
    if (clause1->getNumberOfLiterals()>1) continue;
    PEquality equality1=boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin()));  
    if (!equality1->getLHS()->isVariable()) continue;
    if (equality1->getLHS()->getFirstConstant()!=1) continue;
    Variable varForIndex=equality1->getRHS()->getVariable();
    if (varForIndex!=0)
    {
      it2=ded_obj->begin(varForIndex);
      end=ded_obj->end(varForIndex);
    }
    else
    {
      it2 = it1->clone();
      end=ded_obj->getEndIteratorOnWholeSet();
    };
    for (; !(it2->equals(*end)); ++(*it2))
    {
      PSAClause clause2=(boost::shared_dynamic_cast<SAClause, DeductionObject>((**it2)));
      if (!clause2) continue;
      if (clause2->getNumberOfLiterals()>1) continue;
      PEquality equality2=boost::shared_dynamic_cast<Equality, SALiteral>(*(clause2->begin()));  
      if (!equality2->getLHS()->isVariable()) continue; 
      if (equality2->getLHS()->getFirstConstant()!=1) continue;   
       if ((((**it1)->getId())<(**it2)->getId()))
      {
        PDeductionObject obj = this->operator()((**it1), (**it2));
        if (obj.get() != 0)
        {
          if (! obj->isTautology())
          {
            result_set->add(obj);
            mySolver->getOutput()->printGenerationRuleApplication(this,&(*obj),&(***it1),&(***it2),NULL,NULL);
          }
        } 
      };	 
    }
  }
  //return result_set;
}


//DeductionObjectSet*
PDeductionObject
Linearization2Rule::operator() (const PDeductionObject& dobj1, const PDeductionObject& dobj2) const
{
  PDeductionObject result;
  int size1,size2; Variable y,z;
  Coefficient c1y,c2y,c1z,c2z,c1yz,c2yz;
  PSAClause clause1=boost::shared_dynamic_cast<SAClause, DeductionObject>(dobj1);
  PSAClause clause2=boost::shared_dynamic_cast<SAClause, DeductionObject>(dobj2);
  if ((clause1 && clause2) && (clause1->getNumberOfLiterals()==1)
     && (clause2->getNumberOfLiterals()==1))
  {
    PEquality equality1=boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin()));
    PEquality equality2=boost::shared_dynamic_cast<Equality, SALiteral>(*(clause2->begin()));
    size1 = equality1->getRHS()->getSize();
    size2 = equality2->getRHS()->getSize();
    if ( (equality1 && equality2) && (equality1->getLHS()->getSize() == 1) && (equality2->getLHS()->getSize() == 1) &&
        (size1 <= 3) && (size2 <=3) &&
         (!((**(equality1->getLHS()->getBeginIterator())) == (**(equality2->getLHS()->getBeginIterator()))))  )
    {
      if (equality1->getRHS()->isConstant()) return result;
      if (equality2->getRHS()->isConstant()) return result;
      PMonomialIterator mon1 = equality1->getRHS()->getBeginIterator();
      PMonomialIterator mon2 = equality2->getRHS()->getBeginIterator();
      if ( (size1 == 3) && (size2 == 3))
      {     
        if ( (**mon1)->getSize() != 1) return result;
        if (!((**mon1) == (**mon2))) return result;
        y = (**mon1)->getVariable();
        c1y = (**mon1)->getCoeff();
        c2y = (**mon2)->getCoeff();
        ++*mon1; ++*mon2;
        if ( (**mon1)->getSize() != 1) return result;
        if (!((**mon1) == (**mon2))) return result;
        c1z = (**mon1)->getCoeff();
        c2z = (**mon2)->getCoeff();
        z = (**mon1)->getVariable();
        ++*mon1; ++*mon2;
        if ( !(**mon1)->isTwoVariables(y,z)) return result;
        if (!((**mon1) == (**mon2))) return result;
        c1yz = (**mon1)->getCoeff();
        c2yz = (**mon2)->getCoeff();
      }
      else if (size1 == 3)
      {
        if ( (**mon1)->getSize() != 1) return result;
        y = (**mon1)->getVariable();
        c1y = (**mon1)->getCoeff();
        ++*mon1;
        if ( (**mon1)->getSize() != 1) return result;
        c1z = (**mon1)->getCoeff();
        z = (**mon1)->getVariable();
        ++*mon1;
        if ( !(**mon1)->isTwoVariables(y,z)) return result;
        c1yz = (**mon1)->getCoeff();
        if (size2 == 1)
        {
          if ((**mon2)->isConstant()) return result;
          if (!(**mon2)->isTwoVariables(y,z)) return result;
          c2y = 0; c2z = 0; c2yz = (**mon2)->getCoeff();
        }
        else
        {
          if (size2 != 2) return result;
          if ((**mon2)->getSize() != 1) return result;
          if ( (**mon2)->getVariable() == y)
          {
            c2y = (**mon2)->getCoeff(); c2z = 0;
          }
          else if ((**mon2)->getVariable() == z)
          {
            c2z = (**mon2)->getCoeff(); c2y = 0;
          }
          else return result;
          ++*mon2;
          if (!(**mon2)->isTwoVariables(y,z)) return result;
          c2yz = (**mon2)->getCoeff();
        }
      }
      else if (size2 == 3)
      {
        if ( (**mon2)->getSize() != 1) return result;
        y = (**mon2)->getVariable();
        c2y = (**mon2)->getCoeff();
        ++*mon2;
        if ( (**mon2)->getSize() != 1) return result;
        c2z = (**mon2)->getCoeff();
        z = (**mon2)->getVariable();
        ++*mon2;
        if ( !(**mon2)->isTwoVariables(y,z)) return result;
        c2yz = (**mon2)->getCoeff();
        if (size1 == 1)
        {
          if ((**mon1)->isConstant()) return result;
          if (!(**mon1)->isTwoVariables(y,z)) return result;
          c1y = 0; c1z = 0; c1yz = (**mon1)->getCoeff();
        }
        else
        {
          if (size1 != 2) return result;
          if ((**mon1)->getSize() != 1) return result;
          if ( (**mon1)->getVariable() == y)
          {
            c1y = (**mon1)->getCoeff(); c1z = 0;
          }
          else if ((**mon1)->getVariable() == z)
          {
            c1z = (**mon1)->getCoeff(); c1y = 0;
          }
          else return result;
          ++*mon1;
          if (!(**mon1)->isTwoVariables(y,z)) return result;
          c1yz = (**mon1)->getCoeff();
        }
      }
      else return result;
      PPolynomial resultLHS = AlgebraicGenerator::makePolynomial();
      resultLHS->addMonomial((**(equality1->getLHS()->getBeginIterator()))->clone());
      *resultLHS *= c2yz;
      PPolynomial resultRHS = AlgebraicGenerator::makePolynomial();
      PMonomial monom1 = AlgebraicGenerator::makeMonomial(y);
      monom1->setCoeff(c2yz*c1y - c1yz*c2y);
      PMonomial monom2 = AlgebraicGenerator::makeMonomial(z); 
      monom2->setCoeff(c2yz*c1z - c1yz*c2z);
      PMonomial monom3 = (**(equality2->getLHS()->getBeginIterator()))->clone();
      monom3->setCoeff(c1yz);
      resultRHS->addMonomial(monom1);
      resultRHS->addMonomial(monom2);
      resultRHS->addMonomial(monom3);
      
      PEquality resultEquality=AlgebraicGenerator::createEquality(resultLHS,resultRHS);
              
      if (!resultEquality->isTautology())
      {
        PSAClause clause=LogicalGenerator::makeSAClause();
        clause->add(resultEquality);
        result=clause;
      };
    };
  };
  return result;
};

int Linearization2Rule::checkRestriction(DeductionObjectSet* myset, Variable indexvar, PSAClause it2clause, bool may_be_modifier) const
{
  int foundXOR=0;
  PDeductionObjectIterator ithack;
  PDeductionObjectIterator itend;
  ithack=myset->begin(indexvar);
  itend=myset->end(indexvar);
  Variable hi,hj,hk;
  bool hc;
  for (; !(ithack->equals(*itend)); ++(*ithack))
  {
    PSAClause myclause=(((boost::shared_dynamic_cast<SAClause,DeductionObject>(**ithack))));
    if (may_be_modifier && (((boost::shared_dynamic_cast<SAClause,DeductionObject>(**ithack))->getEquality())->isModifier())) continue;
    if (!((myclause->getEquality())->getEqType()==eqt11m2)) // Not a small XOR - found it!
    {
      return 2;
    }
    else if (!(*myclause==*it2clause)) 
    {
        (**ithack)->getOneOneMinusTwoWConst(hi,hj,hk,hc);
      if (indexvar==hi) hi=hk;
        else if (indexvar==hj) hj=hk;      	
      if (mySolver->getNewClauses()->isVariableInNonUnitClause(hi))
      continue;
      if (mySolver->getRecentClauses()->isVariableInNonUnitClause(hi))
      continue;
      if (mySolver->getNewObjects()->isVariableInNonUnitClause(hi))
        continue;
      if (mySolver->getClauses()->isVariableInNonUnitClause(hi))
        continue;
      if (mySolver->getNewClauses()->isVariableInNonUnitClause(hj))
         continue;
      if (mySolver->getRecentClauses()->isVariableInNonUnitClause(hj))
        continue;
      if (mySolver->getNewObjects()->isVariableInNonUnitClause(hj))
        continue;
      if (mySolver->getClauses()->isVariableInNonUnitClause(hj))
        continue;
       
      foundXOR++;
      if (foundXOR>=2) return 2;
    }
     else ;
  }
  return foundXOR;
};


