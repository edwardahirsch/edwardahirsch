#ifndef __ororrule_h__
#define __ororrule_h__

#include "../abstract/gensubrule.h"

/**
 * @file ororrule.h
 * @brief Contains ORORRule class.
 * @author sergey
 */

/// This rule proceeds as follows:
///    v = xyz    x = ls
///  -----------------------
///         v = yzls
class ORORRule : public GenericTwoPremiseRule
{
  
public:

  /// constructor
  ORORRule(BooleanAlgebraicSolver* s) { mySolver = s; myCurVariable = 1;}
  
  virtual std::string getName() const {return "ORORRule";};

protected:

  PDeductionObjectIterator getBeginIterator1(DeductionObjectSet *) const;
  virtual bool checkObject1(PDeductionObject obj) const {return (obj->getEqType() == eqtXeqABC);};
  virtual bool checkObject2(PDeductionObject obj) const {return (obj->getEqType() == eqtXeqAB);};
  PDeductionObjectIterator getEndIterator1(DeductionObjectSet *) const;
  virtual Variable getVarForIndex(PEquality);
  virtual bool checkObjectMatch(PEquality,PEquality) {return true;};
  virtual bool createResult(PDeductionObject, PDeductionObject, DeductionObjectSet *, PEquality, PEquality);
  virtual int whichOneToDelete(PEquality,PEquality) const {return 0;};
  virtual bool swapIterator1();

private:

  /// the variable which should be substituted
  Variable myVariable;

  /// the polynomial which this variable should be substituted for
  PPolynomial myPolynomial;

  /// the type of the result
  TEqualityType myType;

  /// integer to tell over which variable of the first premise we are
  /// iterating
  int myCurVariable;
};


#endif
