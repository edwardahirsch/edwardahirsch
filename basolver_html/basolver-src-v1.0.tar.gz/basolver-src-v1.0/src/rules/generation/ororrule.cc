#include "ororrule.h"

/**
 * @file ororrule.cc
 * @brief implementation for ororrule.h
 * @author sergey
 */


Variable ORORRule::getVarForIndex(PEquality eq)
{
  switch (myCurVariable)
  {
    case 1:
      myVariable = eq->getVar2();
      break;
    case 2:
      myVariable = eq->getVar3();
      break;
    default:
      myVariable = eq->getVar4();
      break;
  }
  return myVariable;
}



bool ORORRule::createResult(PDeductionObject object1, PDeductionObject object2, DeductionObjectSet *result_set, PEquality obj1, PEquality obj2) 
{
  
  PEquality resultEquality;

  Variable varY,varZ,varL,varS,varV;
  bool posY,posZ,posL,posS,posV;
  TEqualityType type = eqtVeqYZLS;
  
  if (obj2->getEqType() != eqtXeqAB) return false;
 
  varV = obj1->getVar1(); posV = obj1->getPos1();
  varL = obj2->getVar2(); posL = obj2->getPos2();
  varS = obj2->getVar3(); posS = obj2->getPos3();
 

  if (myVariable == obj1->getVar2())
  {

    if (obj1->getVar2() != obj2->getVar1())
      return false;
    
    varY = obj1->getVar3(); posY = obj1->getPos3();
    varZ = obj1->getVar4(); posZ = obj1->getPos4();

    if(obj1->getPos2() != obj2->getPos1())
    {
      type = eqtVeqYZnotLS;
    }
  }
  else if (myVariable == obj1->getVar3())
  {

    if (obj1->getVar3() != obj2->getVar1())
      return false;
    varY = obj1->getVar2(); posY = obj1->getPos2();
    varZ = obj1->getVar4(); posZ = obj1->getPos4();
    if(obj1->getPos3() != obj2->getPos1())
    {
      type = eqtVeqYZnotLS;
    }
  }
  else if (myVariable == obj1->getVar4())
  {

    if (obj1->getVar4() != obj2->getVar1())
      return false;
    varY = obj1->getVar2(); posY = obj1->getPos2();
    varZ = obj1->getVar3(); posZ = obj1->getPos3();
    if(obj1->getPos4() != obj2->getPos1())
    {
      type = eqtVeqYZnotLS;
    }
  }
  else return false;


  resultEquality = AlgebraicGenerator::createTypedEquality(type,varV,posV,varY,posY,varZ,posZ,varL,posL,varS,posS); 
    
  
  if (!resultEquality->isTautology())
  {
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);
    mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);

    return true;
  }
  return false;
}

PDeductionObjectIterator ORORRule::getBeginIterator1(DeductionObjectSet *set) const
{
  return set->getBegin(indXeqABC);
}
  
PDeductionObjectIterator ORORRule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEnd(indXeqABC);
}

bool ORORRule::swapIterator1()
{
  switch (myCurVariable)
  {
    case 1:
      myCurVariable = 2;
      return true;
    case 2:
      myCurVariable = 3;
      return true;
    default:
      myCurVariable = 1;
      return false;
  }
  return false;
}

