#include "backlin2.h"
#include "../../misc/output.h"

/**
 * @file backlin2.cc
 * @brief implementation for backlin2.h
 */

/* @author kulikov */

PDeductionObject
BackLinearization2Rule::operator()(
PDeductionObject obj1,
PDeductionObject obj2, 
Variable input_l)
{

  PSAClause clause1 = boost::shared_dynamic_cast<SAClause, DeductionObject>(obj1);
  PSAClause clause2 = boost::shared_dynamic_cast<SAClause, DeductionObject>(obj2);
  Assert((clause1 && clause2), "Input objects are not clauses.");
  
  if (clause1->getNumberOfLiterals() != 1 || clause2->getNumberOfLiterals() != 1)
  {
    PDeductionObject res;
    return res;
  }
    
  PEquality eq1 = boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin()));
  PEquality eq2 = boost::shared_dynamic_cast<Equality, SALiteral>(*(clause2->begin()));
  Assert((eq1 && eq2), "Input clauses contain something strange.");
  
  PDeductionObject res;
  // check restrictions on the linear premise:
  if (!eq1->isCarryBitEquality())
  {
    return res;
  }
  // end check restrictions
  
  Variable c, l, g;
  bool c_sign, l_sign, g_sign;
  bool is_xeqab = false;
  is_xeqab = eq2->getXeqAB(c, c_sign, l, l_sign, g, g_sign);
  

  Assert(is_xeqab, "Bug.");
  
  Assert((input_l == l || input_l == g), "Bug.");
  
  // swap l and g if we are given g as an input var
  if (input_l == g)
  {
    Variable temp_var = l;
    bool temp_sign = l_sign;
    l = g;
    l_sign = g_sign;
    g = temp_var;
    g_sign = temp_sign;
  }

  // check restrictions on the quadratic premise:
  // check if g is an input (i.e., not a result of some gate) 
  if (!this->checkRestriction(mySolver->getClauses(), g))
    return res;
  if (!this->checkRestriction(mySolver->getNewClauses(),g))
    return res;
  if (!this->checkRestriction(mySolver->getRecentClauses(),g))
    return res;
  if (!this->checkRestriction(mySolver->getNewObjects(),g))
    return res;
  // end check restrictions
  
  
  PMonomial l_mon = AlgebraicGenerator::makeMonomial(l);
  PMonomial g_mon = AlgebraicGenerator::makeMonomial(g);
  PPolynomial l_poly = AlgebraicGenerator::makePolynomial(l_mon);
  
  Coefficient l_coef = 0;
  
  l_coef = -eq1->getLHS()->getCoefficient(l_mon);
  if (l_coef == 0)
    l_coef = (eq1->getRHS()->getCoefficient(l_mon));
    
  if (abs(l_coef) != 1)
  {
    PDeductionObject res;
    return res;
  }
    
  PPolynomial result_poly = eq1->getRHS()->clone();
  (*result_poly) -= (*(eq1->getLHS()));
  
  if (l_coef == 1)
  {
    (*result_poly) -= (*l_poly);  
    (*result_poly) *= (-1);
  }
  else
  {
    (*result_poly) += (*l_poly);  
  }
    
  if (!l_sign)
  {
    (*result_poly) *= (-1);
    result_poly->addMonomial(AlgebraicGenerator::makeMonomial());
  }
  
  PPolynomial g_lit = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(g));
  PPolynomial c_lit = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(c));

  if (!g_sign)
  {
    (*g_lit) *= (-1);
    g_lit->addMonomial(AlgebraicGenerator::makeMonomial());
  }

  if (!c_sign)
  {
    (*c_lit) *= (-1);
    c_lit->addMonomial(AlgebraicGenerator::makeMonomial());
  }
  

  (*result_poly) *= (*g_lit);
  (*result_poly) -= (*c_lit);
  
  PEquality result_equality = AlgebraicGenerator::makeEqualityWithCloning(result_poly, AlgebraicGenerator::makePolynomial());
  PSAClause result_clause = LogicalGenerator::makeSAClause();
  result_clause->add(result_equality);
  
  return result_clause;
}

void
BackLinearization2Rule::operator()(
DeductionObjectSet* returned_set,
DeductionObjectSet* new_set, 
DeductionObjectSet* old_set)
{
  // first process the case when the second premise (c=lg)
  // is from new_set
  PDeductionObjectIterator second_pre_it = new_set->getBegin(indXeqAB);
  PDeductionObjectIterator end_second_pre_it = new_set->getEnd(indXeqAB);
  
  for (; !second_pre_it->equals(*end_second_pre_it); ++*second_pre_it)
  {
    Variable l, g, c;
    bool l_sign, g_sign, c_sign;
    (**second_pre_it)->getXeqAB(c, c_sign, l, l_sign, g, g_sign);
    
    Variable current_var = l;
    for (int i = 1; i <= 2; i++)
    {
      if (i == 1)
        current_var = l;
      if (i == 2)
        current_var = g;
    
      // iterating all clauses from new_set and old_set 
      // which contain variable current_var
      PDeductionObjectIterator first_pre_it = new_set->begin(current_var);
      bool first_pre_it_is_in_old = true;
      PDeductionObjectIterator old_end = old_set->end(current_var);
      PDeductionObjectIterator new_end = new_set->end(current_var);
    
      while (!first_pre_it->equals(*old_end))
      {
        if (first_pre_it->equals(*new_end))
        {
          first_pre_it = old_set->begin(current_var);
	  first_pre_it_is_in_old = false;
	  continue;
        }
	
        PDeductionObject new_obj = (*this)(**first_pre_it, **second_pre_it, current_var);
        if (new_obj.get() != 0)
	{
	  PDeductionObject premise = **first_pre_it;
          mySolver->processNewObject(this, new_obj, returned_set, &(*premise), &(***second_pre_it));
	}
          
	++*first_pre_it;
      }
    }
    
    mySolver->simplifyAllObjectsByNewModifiers();
  }
  
  // now process the case when the second premise is from old_set
  // (in this case the first premise has to be from new_set!)
  second_pre_it = old_set->getBegin(indXeqAB);
  end_second_pre_it = old_set->getEnd(indXeqAB);
  
  for (; !second_pre_it->equals(*end_second_pre_it); ++*second_pre_it)
  {
    Variable l, g, c;
    bool l_sign, g_sign, c_sign;
    (**second_pre_it)->getXeqAB(c, c_sign, l, l_sign, g, g_sign);
    
    Variable current_var = l;
    for (int i = 1; i <= 2; i++)
    {
      if (i == 1)
        current_var = l;
      if (i == 2)
        current_var = g;

      // iterating all clauses from new_set and old_set 
      // which contain variable l
      PDeductionObjectIterator first_pre_it = new_set->begin(current_var);
      PDeductionObjectIterator new_end = new_set->end(current_var);
    
      while (!first_pre_it->equals(*new_end))
      {
        PDeductionObject new_obj = (*this)(**first_pre_it, **second_pre_it, current_var);
        if (new_obj.get() != 0)
        {
	  PDeductionObject premise = **first_pre_it;
          mySolver->processNewObject(this, new_obj, returned_set, &(*premise), &(***second_pre_it));
        }
	++*first_pre_it;
      }
    }
    
    
    mySolver->simplifyAllObjectsByNewModifiers();
  }
  
  
}

int BackLinearization2Rule::checkRestriction(DeductionObjectSet* myset, Variable indexvar) const
{
  PDeductionObjectIterator it;
  PDeductionObjectIterator itend;
  it=myset->begin(indexvar);
  itend=myset->end(indexvar);
  for (; !(it->equals(*itend)); ++(*it))
  {
    PSAClause myclause=(((boost::shared_dynamic_cast<SAClause,DeductionObject>(**it))));
    PEquality eq=myclause->getEquality();
    switch (eq->getEqType())
    {
      case eqt11m2:	return 0; // occurs in XOR, may be not an input (dangerous)
      case eqtXeqAB:	if (eq->getVar1() == indexvar) return 0; // is an AND
      default: ;
      // there may be more cases; consider them if you would like to
      // strengthen this requirement. eqtSpecial is dangerous; others need
      // a careful look into which variable is bad
    }
  } 
  return 1; // no AND, XOR found
}
