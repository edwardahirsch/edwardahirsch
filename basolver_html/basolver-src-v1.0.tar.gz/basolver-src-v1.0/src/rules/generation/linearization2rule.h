#ifndef __linearization2rule_h__
#define __linearization2rule_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "misc/output.h"

/**
 * @file linearization2rule.h
 * @author sergey
 * @brief Contains implementation of Linearization2Rule class
 */

/**
 * @class Linearization2Rule
 * @brief implements Linearization2Rule
 * (see documentation for details)
 */
class Linearization2Rule: public GenerationRule
{
public:
  /// Constructor
  Linearization2Rule(BooleanAlgebraicSolver *s) : mySolver(s) {};

  /// Destructor
  virtual ~Linearization2Rule() {};
  
  /**
   * Generates an object from two given objects.
   */  
  virtual PDeductionObject operator() (const PDeductionObject&, const PDeductionObject&) const;

  /// Interface receiving two sets - one to check against itself, the other to
  /// put new objects into
  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* dedset) const;

  /**
   * Generates from newset and set, puts into returned_set;
   * if (use_new_only) does not check set vs set
   */
  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* newset, DeductionObjectSet* set, bool use_new_only);
 
  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set, DeductionObjectSet* old_set)
  {
    (*this)(returned_set,old_set,new_set,true);
  }

  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set)
  {
    DeductionObjectSet *objset = 0;
    (*this)(returned_set,objset,new_set,true);
  }
     
  std::string getName() const {return "Linearization2Rule";};

private:
  /// solver
  BooleanAlgebraicSolver *mySolver;

  /**
   * Creates the result caring for literals
   */
  void createResult2(Variable,bool,Variable,bool,Variable,bool,Variable,bool,PDeductionObject,PDeductionObject,DeductionObjectSet*) const;

  /**
   * Returns 0 if indexvar does not occure in myset
   * Returns 2 if indexvar has entrance in nonXOR equality in myset
   * Otherwise returns min(2, number of entrance in XOR equality with variables without occuranse in boolean clauses).
   */  
  
  int checkRestriction(DeductionObjectSet* myset, Variable indexvar, PSAClause it2clause, bool may_be_modifier) const;
};
#endif

