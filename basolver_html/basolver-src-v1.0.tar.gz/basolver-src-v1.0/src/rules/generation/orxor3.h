#ifndef __orxor3_h__
#define __orxor3h__

#include "../abstract/generic.h"

/**
 * @file orxor3.h
 * @brief Contains ORXOR3Rule class.
 * @author sergey
 */

/// This rule proceeds as follows:
///
///    y = wv    s = x+y+w-2xy-2yw-2xw+4xyw
///
///  --------------------------------------
///
///         s = x+w(1-v)-2xw(1-v)
///
/// It is intended to help solve modified_addstep_vs_addstep
class ORXOR3Rule : public GenericTwoPremiseRule
{
  
public:

  /// constructor
  ORXOR3Rule(BooleanAlgebraicSolver* s) { mySolver=s;};
  
  virtual std::string getName() const {return "ORXOR3Rule";};

protected:

  virtual PDeductionObjectIterator getBeginIterator1(DeductionObjectSet *) const;
  virtual PDeductionObjectIterator getEndIterator1(DeductionObjectSet *) const;
  
  virtual bool checkObject1(PDeductionObject) const;
  virtual bool checkObject2(PDeductionObject) const;
  
  virtual Variable getVarForIndex(PEquality);

  virtual bool checkObjectMatch(PEquality,PEquality);

  virtual bool createResult(PDeductionObject, PDeductionObject, DeductionObjectSet *, PEquality, PEquality);
  
  virtual int whichOneToDelete(PEquality, PEquality) const {return 0;};


private:

  /// chooses one of the two given variables from the given three variables
  /// and assigns the other two to the latter parameters; returns false if
  /// something does not match
  bool ORXOR3Rule::assignVariables(Variable var1, Variable var2, Variable var3,bool posSecond);
    
  /// variable V of the output
  Variable varV;
  /// boolean value of the literal V
  bool posV;
  /// variable Y of the output
  Variable varY;
  /// boolean value of the literal Y
  bool posY;
  /// variable W of the output
  Variable varW;
  /// boolean value of the literal W
  bool posW;
  /// variable S of the output
  Variable varS;
  /// boolean value of the literal S
  bool posS;
  /// variable X of the output
  Variable varX;
  /// boolean value of the literal X
  bool posX;

};


#endif
