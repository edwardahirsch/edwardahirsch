#ifndef __or3generationrule_h__
#define __or3generationrule_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../general/solver.h"

/**
 * @file or3generationrule.h
 * @author sergey
 * @brief Contains implementation of Or3GeberationRule class
 */

/**
 * @class OR3GenerationRule
 * @brief implements OR3GenerationRule
 * (see documentation for details)
 */
class OR3GenerationRule: public GenerationRule
{
public:
  /// Constructor
  OR3GenerationRule(BooleanAlgebraicSolver *s) : mySolver(s) {};

  /// Destructor
  virtual ~OR3GenerationRule() {};
  
  /**
   * Generates objects from a given deduction object set.
   */  
  virtual PDeductionObject
  operator() (const PDeductionObject&, const PDeductionObject&) const 
  {
    PDeductionObject obj;
    return obj;
  }

  /**
   * Generates from newset and set, puts into returned_set;
   * if (use_new_only) does not check set vs set
   */
  virtual void
  operator() (DeductionObjectSet* returned_set, DeductionObjectSet* dedset, DeductionObjectSet* newset, bool use_new_obj) const;
 
  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set, DeductionObjectSet* old_set)
  {
    (*this)(returned_set,old_set,new_set,true);
  }

  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set)
  {
    DeductionObjectSet* objset = 0;
    (*this)(returned_set,objset,new_set,true);
  }
     
  /**
   * Returns the name of rule.
   */
  std::string
  getName() const {return "OR3GenerationRule";};

private:
  /// solver
  BooleanAlgebraicSolver *mySolver;
};
#endif

