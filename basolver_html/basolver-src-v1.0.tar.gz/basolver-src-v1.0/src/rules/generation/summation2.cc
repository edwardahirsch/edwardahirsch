#include "summation2.h"
#include "../../general/solver.h"

/**
 * @file summation2.cc
 * @brief implementation for summation2.h
 * @author kulikov
 */



// obj1: x=a+bc-ac
// obj2: b=a+S
PDeductionObject
Summation2Rule::operator()(
Variable x, bool x_sign, 
Variable a, bool a_sign, 
Variable b, bool b_sign, 
Variable c, bool c_sign, 
PDeductionObject obj2)
{
  PSAClause clause2 = boost::shared_dynamic_cast<SAClause, DeductionObject>(obj2);
  Assert(clause2, "Input object is not a clause.");
  
  if (clause2->getNumberOfLiterals() != 1)
  {
    PDeductionObject res;
    return res;
  }
    
  PEquality eq2 = boost::shared_dynamic_cast<Equality, SALiteral>(*(clause2->begin()));
  Assert(eq2, "Input clause contains something strange.");
  
  if (!eq2->isCarryBitEquality())
  {
    PDeductionObject res;
    return res;
  }
    

  
  PPolynomial all_second = eq2->getRHS();
  (*all_second) -= *(eq2->getLHS());
  
  bool a_is_present = false, b_is_present = false;
  bool a_sign_in_second = true, b_sign_in_second = true;
  
  PMonomialIterator mon_it = all_second->getBeginIterator();
  PMonomialIterator mon_it_end = all_second->getEndIterator();
  
  // first check that both a and b are present in an input object
  while (!mon_it->equals(*mon_it_end))
  {
    if (a_is_present && b_is_present)
      break;
    
    PMonomial mon = **mon_it;
    
    if (mon->getSize() == 1 && (**(mon->getBeginIterator())) == a 
    && abs(mon->getCoeff()) == 1)
    {
      a_is_present = true;
      a_sign_in_second = (mon->getCoeff() == 1);
    }

    if (mon->getSize() == 1 && (**(mon->getBeginIterator())) == b 
    && abs(mon->getCoeff()) == 1)
    {
      b_is_present = true;
      b_sign_in_second = (mon->getCoeff() == 1);
    }

    ++*mon_it;
  }
  
  // so, both a and b (as monomials) are present in the second equality
  
  (*all_second) += *(eq2->getLHS());
  
  
  if (a_is_present && b_is_present)
  {

  
    PPolynomial x_lit = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(x));
    if (!x_sign)
    {
      (*x_lit) *= (-1);
      x_lit->addMonomial(AlgebraicGenerator::makeMonomial());
    }

    PPolynomial a_lit = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(a));
    if (!a_sign)
    {
      (*a_lit) *= (-1);
      a_lit->addMonomial(AlgebraicGenerator::makeMonomial());
    }

    PPolynomial b_lit = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(b));
    if (!b_sign)
    {
      (*b_lit) *= (-1);
      b_lit->addMonomial(AlgebraicGenerator::makeMonomial());
    }

    PPolynomial c_lit = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(c));
    if (!c_sign)
    {
      (*c_lit) *= (-1);
      c_lit->addMonomial(AlgebraicGenerator::makeMonomial());
    }
    
    PPolynomial result_poly = eq2->getRHS()->clone();
    (*result_poly) -= *(eq2->getLHS());
    
    // representing the second object as b=...
    PMonomialIterator mon_it = result_poly->getBeginIterator();
    PMonomialIterator mon_it_end = result_poly->getEndIterator();
    while (!mon_it->equals(*mon_it_end))
    {
      PMonomial mon = **mon_it;
      if (mon->getSize() == 1 && (**(mon->getBeginIterator())) == b 
      && abs(mon->getCoeff()) == 1)
      {
        if (mon->getCoeff() == 1)
	{
	  (*result_poly) *= (-1);
	  result_poly->addMonomial(AlgebraicGenerator::makeMonomial(b));
	}
	else
	{
	  result_poly->addMonomial(AlgebraicGenerator::makeMonomial(b));
	}
	
	break;
      }
      
      ++*mon_it;
    }
    
    PPolynomial new_b_lit = result_poly;
    if (!b_sign)
    {
      (*new_b_lit) *= (-1);
      new_b_lit->addMonomial(AlgebraicGenerator::makeMonomial());
    }
    
    (*new_b_lit) *= (*c_lit);
    PPolynomial ac = c_lit; 
    (*ac) *= (*a_lit);
    (*new_b_lit) -= (*ac);
    (*new_b_lit) += (*a_lit);
    (*new_b_lit) -= (*x_lit);
    
    PEquality result_eq = AlgebraicGenerator::createEquality(new_b_lit, AlgebraicGenerator::makePolynomial());
    PSAClause result_clause = LogicalGenerator::makeSAClause();
    result_clause->add(result_eq);
    
    return result_clause;
  }
  
  
  PDeductionObject res;
  return res;
}

void
Summation2Rule::operator()(
DeductionObjectSet* returned_set,
DeductionObjectSet* new_set, 
DeductionObjectSet* old_set)
{
  for (int casenum = 1; casenum <= 2; casenum++)
  {
  PDeductionObjectIterator first_pre_it;
  PDeductionObjectIterator end_first_pre_it;
  
  if (casenum == 1)
  {
    first_pre_it = new_set->getBeginIteratorOnWholeSet();
    end_first_pre_it = new_set->getEndIteratorOnWholeSet();
  }
  else
  {
    first_pre_it = old_set->getBeginIteratorOnWholeSet();
    end_first_pre_it = old_set->getEndIteratorOnWholeSet();
  }
  
  for (; !first_pre_it->equals(*end_first_pre_it); ++*first_pre_it)
  {
    PDeductionObject cur_obj = **first_pre_it;
    PSAClause cur_clause = boost::shared_dynamic_cast<SAClause, DeductionObject>(cur_obj);
    Assert(cur_clause, "Not a clause");
    
    if (cur_clause->getNumberOfLiterals() != 1)
      continue;
    
    PEquality cur_eq = boost::shared_dynamic_cast<Equality, SALiteral>(*(cur_clause->begin()));
    Assert(cur_eq, "Not an equality");
    
    Variable a, b, c, x;
    bool a_sign, b_sign, c_sign, x_sign;
    
    if (cur_eq->getYeqACpnAB(x, x_sign, c, c_sign, b, b_sign, a, a_sign))
    // x = a + bc - ac
    {
      PDeductionObjectIterator second_pre_it;
      PDeductionObjectIterator second_pre_it_end;
      
      if (casenum == 2)
      {
        second_pre_it = new_set->begin(b);
	second_pre_it_end = new_set->end(b);
      }
	
      if (casenum == 1)
      {
        second_pre_it_end = old_set->end(b);
	
	  second_pre_it = new_set->begin(b);
      }
      
      while (!second_pre_it->equals(*second_pre_it_end))
      {
        if (casenum == 1 && second_pre_it->equals(*(new_set->end(b))))
        {
          second_pre_it = old_set->begin(b);
          continue;
        }
      
        PDeductionObject new_obj1 = this->operator()(x, x_sign, a, a_sign, b, b_sign, c, c_sign, **second_pre_it);
	PDeductionObject new_obj2 = this->operator()(x, x_sign, b, b_sign, a, a_sign, c, !c_sign, **second_pre_it);
	
	if (new_obj1.get())
	{
	  mySolver->processNewObject(this, new_obj1, returned_set, &(***first_pre_it), &(***second_pre_it));
	}

	if (new_obj2.get())
	{
	  mySolver->processNewObject(this, new_obj2, returned_set, &(***first_pre_it), &(***second_pre_it));
	}

	  
	++*second_pre_it;
	
	if (casenum == 1 && second_pre_it->equals(*(new_set->end(b))))
	  second_pre_it = old_set->begin(b);
      }
      
      mySolver->simplifyAllObjectsByNewModifiers();
    }
    else
      continue;
    
  }
  }
}
