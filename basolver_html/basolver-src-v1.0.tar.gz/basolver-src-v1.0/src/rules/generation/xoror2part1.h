#ifndef __xoror2part1_h__
#define __xoror2part1_h__

#include "../abstract/gensubrule.h"

/**
 * @file xoror2part1.h
 * @brief Contains XOROR2Part1Rule class.
 * @author sergey
 */

/// This rule proceeds as follows:
///
///    z = xy    y = w xor v
///
///  -----------------------
///
///         z = x(w xor v)
///
/// and remove y = w xor v
class XOROR2Part1Rule : public GenericTwoPremiseRule
{
  
public:

  /// constructor
  XOROR2Part1Rule(BooleanAlgebraicSolver* s) { mySolver = s; mySecondVariable = false;}
  
  virtual std::string getName() const {return "XOROR2Part1Rule";};

protected:

  PDeductionObjectIterator getBeginIterator1(DeductionObjectSet *) const;
  virtual bool checkObject1(PDeductionObject obj) const;
  virtual bool checkObject2(PDeductionObject obj) const;
  PDeductionObjectIterator getEndIterator1(DeductionObjectSet *) const;
  virtual Variable getVarForIndex(PEquality);
  virtual bool checkObjectMatch(PEquality,PEquality) {return true;};
  virtual bool createResult(PDeductionObject, PDeductionObject, DeductionObjectSet *, PEquality, PEquality);
  virtual int whichOneToDelete(PEquality,PEquality) const {return 0;};
  virtual bool swapIterator1();

private:

  /// the variable which should be substituted
  Variable myVariable;

  /// the polynomial which this variable should be substituted for
  PPolynomial myPolynomial;

  /// the type of the result
  TEqualityType myType;

  /// if this is true, we are checking the second variable of the first
  /// premise; otherwise we are in the first variable
  bool mySecondVariable;
};


#endif
