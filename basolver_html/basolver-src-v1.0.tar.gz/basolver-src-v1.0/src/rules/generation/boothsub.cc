#include "boothsub.h"

/**
 * @file boothsub.cc
 * @brief implementation for boothsub.h
 * @author sergey
 */


int 
BoothSubRule::whichOneToDelete(PEquality object1, PEquality object2) const 
{
  return 0;
}

Variable BoothSubRule::getNextVarForIndex(PEquality eq)
{
  if (! wasLeft)
  {
    if (!eq->getLHS()->isVariable()) return 0;
    wasLeft=true;
    this->currentLinear=eq->getRHS()->getBeginIterator();
    this->endLinear=eq->getRHS()->getEndIterator();    
    
    myVariable=eq->getVar1();
    if(myVariable == 0)
      myVariable = eq->getLHS()->getVariable();
    
    return myVariable;
  }
  else
  {
    while (!currentLinear->equals(*endLinear))
    {
      
      if ((**currentLinear)->getSize()>1) 
      {
        wasLeft=false;
        return 0;
      }; 	
      if ((((**currentLinear)->getCoeff() % 2) == 0) || ((**currentLinear)->getSize()==0)
          || ((**currentLinear)->getVariable()) == eq->getVar1())
      {
        ++(*currentLinear);
	      continue;  
      }
      myVariable=((**currentLinear)->getVariable());
      ++(*currentLinear);
      
      return myVariable;
    };
  };
  wasLeft=false;
  return 0; 
};


bool BoothSubRule::createResult(PDeductionObject object1, PDeductionObject object2, DeductionObjectSet *result_set, PEquality obj1, PEquality obj2) 
{

  if(object2->getNumberOfLiterals()>1)
    return false;
    //restriction 1
  if(obj1->getEqType() != eqtBoothSubResult && obj2->getEqType() != eqtBoothSubResult 
      && obj1->getEqType() != Special && obj2->getEqType() != Special
      && obj2->getEqType() != eqt11m2)
    return false;
  
  Coefficient coeff;
  PPolynomial poly, poly2;
  bool perenos = false;
  int occurence = 0;
  
  // we must remove first var in list
  if(obj1->getVar1() != obj2->getVar1() 
      || (obj1->getVar2() == 0) || (obj2->getVar2() == 0)
      || obj2->getEqType() == eqtXeqAB
      )
  {

    PPolynomial poly1odd = obj1->getRHS()->getOddPart();
    PPolynomial poly1even = obj1->getLHS()->getOddPart();
    PPolynomial poly2odd = obj2->getRHS()->getOddPart();
    PPolynomial poly2even = obj2->getLHS()->getOddPart();
     
    if(poly1odd->getSize() != 0 
      && poly2odd->getSize() != 0
      && poly1even->getSize() != 0 
      && poly2even->getSize() != 0
      )
    {
      PMonomialIterator mbeg = poly1odd->getBeginIterator();
      PMonomialIterator mend = poly1odd->getEndIterator();
      for(;!mbeg->equals(*mend);)
      {
        TRACE("boothsub",
            std::cout << "monomial = ";
            (**mbeg)->print(std::cout,mySolver);
            std::cout << "coef = " <<  poly2even->getCoefficient(**mbeg) << "\n";
            );
        if((**mbeg)->getSize()!=0 &&
            (poly2odd->getCoefficient(**mbeg) || poly2even->getCoefficient(**mbeg)))
        {
          occurence++;
        }
        ++(*mbeg);
      }
      mbeg = poly1even->getBeginIterator();
      if(poly2odd->getCoefficient(**mbeg) || poly2even->getCoefficient(**mbeg))
        occurence++;
    }

    if(occurence < 2)
    {
      return false;
    }
    
    if(occurence == 3)
    {
      perenos = true;
      if(obj2->getEqType() == eqt11m2)
        return false;
    }
  }
  
 //restriction 3
  if(obj2->getEqType() == eqt11m2)
  {
    PPolynomial poly1even = obj1->getRHS()->getEvenPart();
    PPolynomial poly2even = obj2->getRHS()->getEvenPart();
     
    if(poly1even->getSize() != 0 
      && poly2even->getSize() != 0
      )
    {
      PMonomialIterator mbeg = poly2even->getBeginIterator();
      if(poly1even->getCoefficient(**mbeg))
      {
        return false;
      }
    }
  }

  //sum eqt11m2 with sum of carry bits
  if(obj2->getEqType() == eqt11m2 && obj1->getEqType() != eqtBoothSubResult2)
  {
    if(obj1->getEqType() != eqtBoothSubResult)
      return false;  
    else if (obj1->getVar2() != 0)
      return false;
  }
  //we don't need uknown equalities
  if((obj1->getEqType() == eqtBoothSubResult && obj1->getVar1() == 0)
      || (obj2->getEqType() == eqtBoothSubResult && obj2->getVar1() == 0))
  {
    return false;
  }
  


  // new:
  if(obj1->getEqType() == eqtBoothSubResult 
      && obj2->getEqType() == eqtBoothSubResult
      && obj1->getVar2() == 0 && obj2->getVar2() == 0)
  {
    return false; 
  }
  //restriction 2
 /* if (needCheck)
  {
    if(obj1->getVar2() == obj2->getVar2())
      return false;
  };*/
        
//restriction 4
  if(((obj1->getEqType() == eqtBoothSubResult &&  obj2->getEqType() == Special) ||
      (obj2->getEqType() == eqtBoothSubResult &&  obj1->getEqType() == Special) || 
      (obj1->getEqType() == eqtBoothSubResult &&  obj2->getEqType() == eqtBoothSubResult))
      && obj1->getVar3() != 0 && obj2->getVar3() != 0
    )
  {
    return false;
  };
  
//restriction 5  
  if (!obj2->isBoothSubSubject(myVariable,coeff,poly)) return false;

  
  Coefficient coeff2;
  if (!obj1->isBoothSubSubject(myVariable,coeff2,poly2)) 
  {
    if(occurence > 3 || (occurence == 2 && obj2->getEqType() == eqt11m2) 
        || (occurence == 3 && obj2->getEqType() == Special))
    {
      if (!obj1->getRHS()->occursLinear(myVariable,coeff2))
        return false;
      poly2 = obj1->getLHS()->clone();
      *poly2 -= *(obj1->getRHS());
      PMonomial mon = AlgebraicGenerator::makeMonomial(myVariable);
      mon->setCoeff(coeff2);
      poly2->addMonomial(mon);
    }
    else
      return false;
  }

    
    *poly2 *= coeff;
    *poly *= coeff2;
  
  PEquality resultEquality = AlgebraicGenerator::createEquality(poly,poly2);
  resultEquality->setEqType(eqtBoothSubResult);


  // new arists types:
  if((obj1->getEqType() == Special || obj2->getEqType() == Special)) 
  {
    if(!perenos) 
    {
      PEquality myEq;
      PEquality myEqNoSpecial;
    
      if(obj1->getEqType() == Special)
      {
        myEq = obj1;
        myEqNoSpecial = obj2;
      }
      else
      {
        myEq = obj2;
        myEqNoSpecial = obj1;
      }
    
      if(myEqNoSpecial->getEqType() != eqtBoothSubResult
        ||(myEqNoSpecial->getEqType() == eqtBoothSubResult 
       && myEqNoSpecial->getVar2() != 0 && myEqNoSpecial->getVar3() == 0)
        )
      {
        resultEquality->setVar1(myEq->getVar2());
        resultEquality->setPos1(myEq->getPos2());
        resultEquality->setVar2(myEq->getVar3());
        resultEquality->setPos2(myEq->getPos3());
        resultEquality->setVar3(myEq->getVar4());
        resultEquality->setPos3(myEq->getPos4());
        resultEquality->setVar4(myEq->getVar5());
        resultEquality->setPos4(myEq->getPos5());
        resultEquality->setVar5(0);
        resultEquality->setPos5(true);
      }
    }
    else
    {
      PEquality myEq;
      PEquality myEqNoSpecial;
    
      if(obj1->getEqType() == Special)
      {
        myEq = obj1;
        myEqNoSpecial = obj2;
      }
      else
      {
        myEq = obj2;
        myEqNoSpecial = obj1;
      }

      myVariable = myEqNoSpecial->getVar1();  
      coeff = 0;
      myEqNoSpecial->getLHS()->occursLinear(myVariable,coeff);
      coeff2 = 0;      
      myEqNoSpecial->getLHS()->occursLinear(myVariable,coeff2);
      if(coeff % 2 && coeff2 % 2)
      {
        resultEquality->setVar1(myEqNoSpecial->getVar1());
        resultEquality->setPos1(myEqNoSpecial->getPos1());
        resultEquality->setVar2(myEqNoSpecial->getVar2());
        resultEquality->setPos2(myEqNoSpecial->getPos2());
        resultEquality->setVar3(myEqNoSpecial->getVar3());
        resultEquality->setPos3(myEqNoSpecial->getPos3());
        resultEquality->setVar4(myEqNoSpecial->getVar4());
        resultEquality->setPos4(myEqNoSpecial->getPos4());
        resultEquality->setVar5(myEqNoSpecial->getVar5());
        resultEquality->setPos5(myEqNoSpecial->getPos5());
      }
      else
      {
        resultEquality->setVar1(myEqNoSpecial->getVar2());
        resultEquality->setPos1(myEqNoSpecial->getPos2());
        resultEquality->setVar2(myEqNoSpecial->getVar3());
        resultEquality->setPos2(myEqNoSpecial->getPos3());
        resultEquality->setVar3(myEqNoSpecial->getVar4());
        resultEquality->setPos3(myEqNoSpecial->getPos4());
        resultEquality->setVar4(myEqNoSpecial->getVar5());
        resultEquality->setPos4(myEqNoSpecial->getPos5());
        resultEquality->setVar5(0);
        resultEquality->setPos5(true);
      }
    }
  }
  else
  {
    PEquality myEq;
    if(obj1->getEqType() == eqtBoothSubResult && obj1->getVar2() != 0)
    {
      myEq = obj1;
    }
    else
    {
      myEq = obj2;
    }
    resultEquality->setVar1(myEq->getVar2());
    resultEquality->setPos1(myEq->getPos2());
    resultEquality->setVar2(myEq->getVar3());
    resultEquality->setPos2(myEq->getPos3());
    resultEquality->setVar3(myEq->getVar4());
    resultEquality->setPos3(myEq->getPos4());
    resultEquality->setVar4(myEq->getVar5());
    resultEquality->setPos4(myEq->getPos5());
    resultEquality->setVar5(0);
    resultEquality->setPos5(true);
  }
 
  // we don't need variables with even coefficient in list
  for(int c=0;c<5 && resultEquality->getVar1() !=0;c++)
  {
    coeff = 0;
    resultEquality->getRHS()->getOddPart()->occursLinear(resultEquality->getVar1(),coeff);
    coeff2 = 0;
    resultEquality->getLHS()->occursLinear(resultEquality->getVar1(),coeff2);
    if(!coeff && !coeff2)
    {
      resultEquality->setVar1(resultEquality->getVar2());
      resultEquality->setPos1(resultEquality->getPos2());
      resultEquality->setVar2(resultEquality->getVar3());
      resultEquality->setPos2(resultEquality->getPos3());
      resultEquality->setVar3(resultEquality->getVar4());
      resultEquality->setPos3(resultEquality->getPos4());
      resultEquality->setVar4(resultEquality->getVar5());
      resultEquality->setPos4(resultEquality->getPos5());
      resultEquality->setVar5(0);
      resultEquality->setPos5(true);
    }
    else
      break;
  }
  TRACE("boothsub", std::cout << "After second lit ass:\n";
      resultEquality->print(std::cout, mySolver); std::cout << "\n";
  );

  // hack
  //restriction 6 -- rassheplyetsya!!!
  
  if(resultEquality->getVar1() == 0)
  {
    if(obj1->getVar2() != 0 && obj2->getVar2() != 0)
      return false;
    else if(obj1->getVar2() == 0)
      resultEquality->setVar1(resultEquality->getLHS()->getVariable());
    else
      return false;
  }

  // carry bits sums is a carry bits sums after sum with xor
  if(obj2->getEqType() == eqt11m2)
  {
    resultEquality->setVar1(resultEquality->getLHS()->getVariable());
    resultEquality->setPos1(true);
    resultEquality->setVar2(0);
    resultEquality->setPos2(true);
    resultEquality->setVar3(0);
    resultEquality->setPos3(true);
    resultEquality->setVar4(0);
    resultEquality->setPos4(true);
    resultEquality->setVar5(0);
    resultEquality->setPos5(true);

  }

  // need equality in special form!
  coeff = 0;
  resultEquality->getRHS()->occursLinear(resultEquality->getVar1(),coeff);
  
  if(std::abs(coeff) == 1)
  {
    *(resultEquality->getRHS()) -= *(resultEquality->getLHS());
    PMonomial myMonomial=AlgebraicGenerator::makeMonomial(-coeff, resultEquality->getVar1());
    resultEquality->getRHS()->addMonomialWithCloning(myMonomial); 
    if(coeff > 0)
    {
      *myMonomial *= -1;
      *(resultEquality->getRHS()) *= -1;
    };
    *resultEquality->getLHS()-=(*(resultEquality->getLHS()->clone()));
    resultEquality->getLHS()->addMonomial(myMonomial);
  }
  PPolynomial poly3 = resultEquality->getRHS()->getOddPart();
  PPolynomial poly1odd = obj1->getRHS()->getOddPart();
  PPolynomial poly1even = obj1->getRHS()->getEvenPart();
  PPolynomial poly2odd = obj2->getRHS()->getOddPart();
  PPolynomial poly2even = obj2->getRHS()->getEvenPart();

  
  // set Special type for sum of carry bits
  if(poly1even->getSize() != 0 && poly2even->getSize() != 0 && resultEquality->getLHS()->getSize() != 0)
  {
    PMonomialIterator mbeg = resultEquality->getLHS()->getBeginIterator();
    if(poly1even->getCoefficient(**mbeg) || poly2even->getCoefficient(**mbeg))
    {
      //but no real need in new index
      resultEquality->setEqType(eqtBoothSubResult2);   
    }
  }
//restriction 7
  
  // restriction (a)
  // if $S$ contains odd monomials then the monomials in even part
  // of $T$ should not contains at the same time in odd parts of $S$;
  if(poly1odd->getSize() != 0 
      && poly2even->getSize() != 0)
  {
    PMonomialIterator mbeg = poly1odd->getBeginIterator();
    PMonomialIterator mend = poly1odd->getEndIterator();
    for(;!mbeg->equals(*mend);)
    {
      if(poly2even->getCoefficient(**mbeg))
      {
        return false;
      }
      ++(*mbeg);
    }
  }
//restriction 8

  // restriction (a)
  // if $T$ contains odd monomials then the monomials in even part
  // of $S$ should not contains at the same time in odd parts of $T$;
  if(poly2odd->getSize() != 0 
      && poly1even->getSize() != 0)
  {
    PMonomialIterator mbeg = poly2odd->getBeginIterator();
    PMonomialIterator mend = poly2odd->getEndIterator();
    for(;!mbeg->equals(*mend);)
    {
      if(poly1even->getCoefficient(**mbeg))
      {
        return false;
      }
      ++(*mbeg);
    }
  }

 
  
  

  if (!resultEquality->isTautology())
  {
  
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);

    mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);
    applied++;
    return true;
  }
  return false;
}

PDeductionObjectIterator BoothSubRule::getBeginIterator1(DeductionObjectSet *set) const
{

  return set->getBegin(myCurIndex);
}
  
PDeductionObjectIterator BoothSubRule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEnd(myCurIndex);
}
  
bool BoothSubRule::swapIterator1()
{

  switch (myCurIndex)
  {
    case indCeqXZmXYpnWYnZp2WXYnZ:
      myCurIndex = indCeqWXYpnWnXY;
      return true;
    case indCeqWXYpnWnXY:
      myCurIndex = indCeqYnWYxorZ;
      return true;
    case indCeqYnWYxorZ:
      myCurIndex = indZeqWXpVXm2WVX;
      return true;
    case indZeqWXpVXm2WVX:
      myCurIndex = indBoothSubResult2;
      return true;
    case indBoothSubResult2:
      myCurIndex = indYeqACpDmACD;
      return true;
    case indYeqACpDmACD:
      myCurIndex = indBoothSubResult;
      return true;
    case indBoothSubResult:
      if (!mySecondVariable) 
      {
        mySecondVariable = true;
        return true;
      }
    default: 
      mySecondVariable = false;
      myCurIndex = indCeqXZmXYpnWYnZp2WXYnZ;
      return false;
  }
}

bool BoothSubRule::checkObject1(PDeductionObject obj) const
{
  return true;
};

