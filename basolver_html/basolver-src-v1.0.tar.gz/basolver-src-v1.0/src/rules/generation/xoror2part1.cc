#include "xoror2part1.h"

/**
 * @file xoror2part1.cc
 * @brief implementation for xoror2part1.h
 * @author sergey
 */



Variable XOROR2Part1Rule::getVarForIndex(PEquality eq)
{
  if (mySecondVariable)
    myVariable = eq->getVar3();
  else
    myVariable = eq->getVar2();
  return myVariable;
}

bool XOROR2Part1Rule::checkObject1(PDeductionObject obj) const
{
  return (obj->getEqType() == eqtXeqAB);
}

bool XOROR2Part1Rule::checkObject2(PDeductionObject obj) const
{
  return (obj->getEqType() == eqt11m2);
}

bool XOROR2Part1Rule::createResult(PDeductionObject object1, PDeductionObject object2, DeductionObjectSet *result_set, PEquality obj1, PEquality obj2)
{

  // a special restriction for the non-Booth case
  if (!mySolver->getOptions()->myUseBooth)
  {
    Variable var = obj2->getVar1();
    bool ok = false;
    PModificationObjectIterator mit = mySolver->getModifiers()->begin(var);
    PModificationObjectIterator mend = mySolver->getModifiers()->end(var);
    while (!mit->equals(*mend))
    {
      if (((**mit)->getEqType() != Special) || (mit->getIE()->getVList()->size() > 2))
      {
        ok = true; 
        break;
      }
      ++*mit;
    }
    if (!ok)
    {
      var = obj2->getVar2();
      mit = mySolver->getModifiers()->begin(var);
      mend = mySolver->getModifiers()->end(var);
      while (!mit->equals(*mend))
      {
        if (((**mit)->getEqType() != Special) || (mit->getIE()->getVList()->size() > 2))
        {
          ok = true; 
          break;
        }
        ++*mit;
      }
    }
    if (!ok)
    {
      var = obj2->getVar3();
      mit = mySolver->getModifiers()->begin(var);
      mend = mySolver->getModifiers()->end(var);
      while (!mit->equals(*mend))
      {
        if (((**mit)->getEqType() != Special) || (mit->getIE()->getVList()->size() > 2))
        {
          ok = true; 
          break;
        }
        ++*mit;
      }
    }
    if (!ok) return false;
  }


  
  PEquality resultEquality;
  Variable varW, varV, varX;
  bool posX, wconst;
  bool special_sign=true;
  Variable var1,var2,var3;
  if (!obj2->getOneOneMinusTwoWConst(var1,var2,var3,wconst)) return false;
  if (myVariable == obj1->getVar2())
  {
    if (obj1->getPos2() == true)
    {
      if (wconst) 
        special_sign=false;
    }
    else
    {
      if (!wconst)
        special_sign=false;
    }
    varX = obj1->getVar3();
    posX = obj1->getPos3();
  }
  else
  {
    if (obj1->getPos3() == true)
    {
      if (wconst) 
        special_sign=false;
    }
    else
    {
      if (!wconst)
        special_sign=false;
    }
    varX = obj1->getVar2();
    posX = obj1->getPos2();
  }
 
  if (myVariable == obj2->getVar1())
  {
    varV = obj2->getVar2(); 
    varW = obj2->getVar3();
  }
  else
  {
    if (obj2->getVar2() == myVariable)
    {
      varV = var1; 
      varW = var3;
    }
    else if (obj2->getVar3() == myVariable)
    {
      varV = var1; 
      varW = var2;
    }
    else
      return false;
  }
 
  if ( (varX == varV) || (varX == varW) || (obj1->getVar1() == varV) || (obj1->getVar1() == varW) || (obj1->getVar1() == varX)) return false;
 

  resultEquality = AlgebraicGenerator::createZeqWXpVXm2WVXEquality(obj1->getVar1(),obj1->getPos1(),varX,posX,varV,special_sign,varW,true);
  
  
  if (!resultEquality->isTautology())
  {
    
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);

    mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);

    return true;
  }
  return false;
}

PDeductionObjectIterator XOROR2Part1Rule::getBeginIterator1(DeductionObjectSet *set) const
{
  return set->getBegin(indXeqAB);
}
  
PDeductionObjectIterator XOROR2Part1Rule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEnd(indXeqAB);
}
  
bool XOROR2Part1Rule::swapIterator1()
{

  if (!mySecondVariable)
  {
    mySecondVariable = true;
    return true;
  }
  mySecondVariable = false;
  return false;
}

