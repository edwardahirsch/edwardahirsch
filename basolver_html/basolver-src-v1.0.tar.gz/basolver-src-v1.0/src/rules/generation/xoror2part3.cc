#include "xoror2part3.h"

/**
 * @file xoror2part3.cc
 * @brief implementation for xoror2part3.h
 * @author sergey 
 */

Variable XOROR2Part3Rule::getVarForIndex(PEquality eq)
{
  if (mySecondVariable)
    myVariable = eq->getVar3();
  else
    myVariable = eq->getVar2();
  return myVariable;
}

bool XOROR2Part3Rule::checkObjectMatch(PEquality,PEquality) 
{
  return true;
}

int XOROR2Part3Rule::whichOneToDelete(PEquality,PEquality) const
{
  return 1;
}

bool XOROR2Part3Rule::createResult(PDeductionObject object1, PDeductionObject object2, DeductionObjectSet *result_set, PEquality obj1, PEquality obj2) 
{

  
  PEquality resultEquality;

  Variable varC,varY,varW,varZ;
  bool posC,posY,posW,posZ;
  
  // c = g(y+z-2yz)           g = y(1-w)
  // -----------------------------------
  //        c = y(1-w)(y+z-2yz)
  if (obj2->getEqType() != eqtXeqAB) return false;
 
  varC = obj1->getVar1(); posC = obj1->getPos1();
  
  if ((obj1->getVar2() == obj2->getVar1()) && (obj1->getPos2() == obj2->getPos1()) && 
      (obj1->getVar3() == obj2->getVar2()) /*&& (obj1->getPos3() == obj2->getPos2())*/ )
  {
    varY = obj1->getVar3(); posY = obj2->getPos2();
    varW = obj2->getVar3(); posW = obj2->getPos3();
    varZ = obj1->getVar4(); posZ = ((!obj1->getPos4())!=(obj1->getPos3() != obj2->getPos2()));

  }
  else if ((obj1->getVar2() == obj2->getVar1()) && (obj1->getPos2() == obj2->getPos1()) && 
      (obj1->getVar3() == obj2->getVar3()) )
  {
    varY = obj1->getVar3(); posY = obj2->getPos3();
    varW = obj2->getVar2(); posW = obj2->getPos2();
    varZ = obj1->getVar4(); posZ = ((!obj1->getPos4())!=(obj1->getPos3() != obj2->getPos3()));

  }
  else if ((obj1->getVar2() == obj2->getVar1()) && (obj1->getPos2() == obj2->getPos1()) && 
      (obj1->getVar4() == obj2->getVar2()) )
  {
    varY = obj1->getVar4(); posY = obj2->getPos2();
    varW = obj2->getVar3(); posW = obj2->getPos3();
    varZ = obj1->getVar3(); posZ = ((!obj1->getPos3())!=(obj1->getPos4() != obj2->getPos2()));

  }
  else if ((obj1->getVar2() == obj2->getVar1()) && (obj1->getPos2() == obj2->getPos1()) && 
      (obj1->getVar4() == obj2->getVar3()) )
  {
    varY = obj1->getVar4(); posY = obj2->getPos3();
    varW = obj2->getVar2(); posW = obj2->getPos2();
    varZ = obj1->getVar3(); posZ = ((!obj1->getPos3())!=(obj1->getPos4() != obj2->getPos3()));

  }
  else return false;

  resultEquality = AlgebraicGenerator::createTypedEquality(eqtXeqABC,varC,posC,varW,posW,varY,posY,varZ,posZ);
  
  if (!resultEquality->isTautology())
  {
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);
    mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);
    return true;
  }
  return false;
}

PDeductionObjectIterator XOROR2Part3Rule::getBeginIterator1(DeductionObjectSet *set) const
{
  return set->getBegin(indZeqWXpVXm2WVX);
}
  
PDeductionObjectIterator XOROR2Part3Rule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEnd(indZeqWXpVXm2WVX);
}

bool XOROR2Part3Rule::swapIterator1()
{
  if (!mySecondVariable)
  {
    mySecondVariable = true;
    return true;
  }
  mySecondVariable = false;
  return false;
}

