#include "or3generationrule2.h"
#include "../../misc/output.h"

/**
 * @file or3generationrule2.cc
 * @brief implementation for or3generationrule2.h
 * @author sergey
 */


void 
OR3GenerationRule2::operator()(
DeductionObjectSet* result_set, 
DeductionObjectSet* ded_obj,
DeductionObjectSet* new_obj,
bool use_new_obj) const
{

 
  bool has_old_obj = false;
  if (ded_obj != 0) has_old_obj = true;

  if (use_new_obj && (!new_obj->getSize())) return;
  PDeductionObjectIterator it1 = new_obj->getBegin(indXeqAB);
  PDeductionObjectIterator newend = new_obj->getEnd(indXeqAB);
  PDeductionObjectIterator it2,end2,newend2;
  PDeductionObjectIterator end1;
  if (has_old_obj) end1= ded_obj->getEnd(indXeqAB);
  else end1 = newend;
  Variable v1,v2,v3, varl, var1, var2, var3, varForIndex;
  bool has_new_premise1, has_new_premise2;
  bool p1,p2,p3;
  bool pol,po1,po2,po3;
  has_new_premise1 = true;
  while(!(it1->equals(*end1)))
  {
    // a standard block of code to switch from the new set to the old one,
    // keeping in mind where we currently are (to determine later
    // whether new objects participate in the derivation)
    if (it1->equals(*newend)) 
    {
      has_new_premise1 = false;
      if (!has_old_obj) break;
      it1 = ded_obj->getBegin(indXeqAB);
      if (it1->equals(*end1)) break;
    }

    if (!(**it1)->getXeqAB(v1,p1,v2,p2,v3,p3)) {++*it1; continue;}
    varForIndex = v1;
    if (varForIndex==0) {++*it1; continue;}
    it2=new_obj->begin(varForIndex);
    newend2 = new_obj->end(varForIndex);
    if (has_old_obj) end2=ded_obj->end(varForIndex);
    else end2 = newend2;
    while (!(it2->equals(*end2)))
    {
      
      if (it2->equals(*newend2)) 
      {       
        has_new_premise2 = false;
        if ( (use_new_obj && !has_new_premise1) || (!has_old_obj) )
          break;
        else
		      it2 = ded_obj->begin(varForIndex);
        if (it2->equals(*end2)) break;
      }      
      if ( ((**it2)->getYeqACpDmACD(varl,pol,var1,po1,var2,po2,var3,po3)) && (var3 == varForIndex) && (p1==po3) && 
          ( ( (var1 == v2) && (po1==!p2) ) || 
            ( (var1 == v3) && (po1==!p3) ) ||
            ( (var2 == v2) && (po2==!p2) ) || 
            ( (var2 == v3) && (po2==!p3) )    )   )
      {
        Variable a,b,c,y;
        bool pa,pb,pc,py;
        y = varl; py = pol;  // set y value
        
        // check which of the rhs variables of the first equality is the
        // variable a
        if ((var1 == v2) && (!p2==po1))
        {

          b  = v3; pb = p3;
          a = var1; pa = po1;  // set a value
          c = var2; pc = po2;  // set c value
        }
        else if ((var1 == v3) && (!p3==po1))
        {

          b  = v2; pb = p2;
          a = var1; pa = po1;  // set a value
          c = var2; pc = po2;  // set c value
        }
        // otherwise it could be variable c
        else if ( (var2 == v2) && (!p2 == po2) )
        {

          b = v3; pb = p3;
          c = var1; pc = po1;  // set a value
          a = var2; pa = po2;  // set c value
        }
        else if ( (var2 == v3) && (!p3 == po2) )
        {

          b = v2; pb = p2;
          a = var2; pa = po2;  // set a value
          c = var1; pc = po1;  // set c value
        } 
	                                         
        else {++*it2; continue;}

        PEquality resultEquality = AlgebraicGenerator::createYeqACpnABEquality(y,py,a,pa,c,pc,b,pb);
        
        if (!resultEquality->isTautology())
        {
          PSAClause clause=LogicalGenerator::makeSAClause();
          clause->add(resultEquality);
          mySolver->processNewObject(this,clause,result_set,&(***it1),&(***it2),NULL,NULL,"part 3");
        }
      }

      ++*it2;

    }
      
      
    
    mySolver->simplifyAllObjectsByNewModifiers();
   
    ++*it1;
  }
}

