#include "xor3generationrule.h"
#include "../../misc/output.h"

/**
 * @file xor3generationrule.cc
 * @brief implementation for Xor3GenerationRule 
 * @author sergey
 */



void 
XOR3GenerationRule::operator()(
DeductionObjectSet* result_set, 
DeductionObjectSet* ded_obj,
DeductionObjectSet* new_obj,
bool use_new_obj) const
{


  if (use_new_obj && (!new_obj->getSize())) return;

  // we might receive NULL as ded_obj
  bool has_old_obj = false;
  if (ded_obj != 0) has_old_obj = true;

 
  PDeductionObjectIterator it1 = new_obj->getBegin(indOneOneMinusTwoWConst);
  PDeductionObjectIterator newend = new_obj->getEnd(indOneOneMinusTwoWConst);
  PDeductionObjectIterator it2,end2,newend2;
  PDeductionObjectIterator end1;
  if (has_old_obj) end1 = ded_obj->getEnd(indOneOneMinusTwoWConst);
  else end1 = newend;

  bool has_new_premise1, has_new_premise2;
  PSAClause clause1, clause2;
  PEquality equality1, equality2;
  Variable varForIndex;
  has_new_premise1 = true;

  
  for (; !(it1->equals(*end1)); ++(*it1))
  {

    // a standard block of code to switch from the new set to the old one,
    // keeping in mind where we currently are (to determine later
    // whether new objects participate in the derivation)
    if (it1->equals(*newend)) 
    {
      has_new_premise1 = false;
      if (!has_old_obj) break;
      it1 = ded_obj->getBegin(indOneOneMinusTwoWConst);
      if (it1->equals(*end1)) break;
    }

    clause1=(boost::shared_dynamic_cast<SAClause, DeductionObject>((**it1)));
    if (!clause1) continue;
    equality1=boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin())); 

    for (int j=0; j<=2; ++j)
    {
    
      switch (j)
      {
        case 0: 
          varForIndex=equality1->getVar1();
          break;
        case 1:
          varForIndex=equality1->getVar2();
          break;
        case 2:
          varForIndex=equality1->getVar3();
          break;
        default:
          varForIndex=0;
      }

    if (varForIndex==0) continue;

    // making new iterators
	  it2=new_obj->begin(varForIndex);
    newend2=new_obj->end(varForIndex);
    if (has_old_obj)  end2=ded_obj->end(varForIndex);
    else end2 = newend2;
    has_new_premise2 = true;

	
    for (; !(it2->equals(*end2)); ++(*it2))
    {
      if (it2->equals(*newend2))
      {
        has_new_premise2 = false;
        // if new objects are already done with,
        // there is no point to continue

        if ( (use_new_obj && !has_new_premise1) || (!has_old_obj) )
          break;
        else 
          it2 = ded_obj->begin(varForIndex);
        if (it2->equals(*end2)) break;
      }

      if ((**it2)->getId() > (**it1)->getId())
      {

        clause2=(boost::shared_dynamic_cast<SAClause, DeductionObject>((**it2)));
        equality2=boost::shared_dynamic_cast<Equality, SALiteral>(*(clause2->begin()));   
        
        Variable a,b,d,var2_left,var2_right1,var2_right2;
        bool wconst1,wconst2;

        if (!(**it1)->getOneOneMinusTwoWConst(d,a,b,wconst1)) continue;
        if (!(**it2)->getOneOneMinusTwoWConst(var2_left,var2_right1,var2_right2,wconst2)) continue;
        
        // we find variables for which to apply the rule; note that
        //   x = a xor b
        // is equivalent to 
        //   a = x xor b       and      b = x xor a,
        // so here we are simply looking for a coinciding variable 
        
        
        Variable y = 0;
        Variable c = 0;  
        if (var2_right2 == varForIndex)
        {
          c = var2_right1;
          y = var2_left;
        }
        else if (var2_right1 == varForIndex)
        {
          c = var2_right2;
          y = var2_left;
        }
        else if (var2_left == varForIndex)
        {
          c = var2_right1;
          y = var2_right2;
        }
        else continue;
        
        createResult(j,a,b,c,d,y,wconst1,wconst2,result_set,**it1,**it2);
          
      } 
    }

    }
    
    mySolver->simplifyAllObjectsByNewModifiers();
  }
}

void XOR3GenerationRule::createResult(int j,Variable a, Variable b, Variable c, Variable d, Variable y, bool wconst1, bool wconst2, DeductionObjectSet* result_set, PDeductionObject premise1, PDeductionObject premise2) const
{

          
  PEquality resultEquality;
  switch (j)
  {
    case 0:
      if ((wconst1 && wconst2) || (!wconst1 && !wconst2)) 
        resultEquality = AlgebraicGenerator::create124Equality(y,true,a,true,b,true,c,true);
      else
        resultEquality = AlgebraicGenerator::create124Equality(y,false,a,true,b,true,c,true);
      break;
    case 1:
      if ((wconst1 && wconst2) || (!wconst1 && !wconst2)) 
        resultEquality = AlgebraicGenerator::create124Equality(y,true,d,true,b,true,c,true);
      else
        resultEquality = AlgebraicGenerator::create124Equality(y,false,d,true,b,true,c,true);
      break;
    case 2:
      if ((wconst1 && wconst2) || (!wconst1 && !wconst2)) 
        resultEquality = AlgebraicGenerator::create124Equality(y,true,d,true,a,true,c,true);
      else
        resultEquality = AlgebraicGenerator::create124Equality(y,false,d,true,a,true,c,true);
      break;
    default:
      return;
  }
   
    
  PSAClause clause = LogicalGenerator::makeSAClause();
  clause->add(resultEquality);
  mySolver->processNewObject(this,clause,result_set,&(*premise1),&(*premise2),NULL,NULL);
    

}

