#include "xoror2part2.h"

/**
 * @file xoror2part2.cc
 * @brief implementation for xoror2part2.h
 * @author sergey
 */


Variable XOROR2Part2Rule::getVarForIndex(PEquality eq)
{
  if (mySecondVariable)
    myVariable = eq->getVar2();
  else
    myVariable = eq->getVar1();
  return myVariable;
}

bool XOROR2Part2Rule::createResult(PDeductionObject object1, PDeductionObject object2, DeductionObjectSet *result_set, PEquality obj1, PEquality obj2) 
{
  if ((obj2->getEqType() != eqtXeqAB) && (obj2->getEqType() != eqtZeqWXpVXm2WVX)) return false;
  
  PEquality resultEquality;
  
  Variable varC,varG,varY,varW,varX,varZ;
  bool posC,posG,posY,posW,posX,posZ;

  
  // g = x + y(1-w) - 2xy(1-w)    c = gy     g = x + y(1-w) - 2xy(1-w)  c = xy
  // -----------------------------------     ---------------------------------
  //         c = y - xy - wy + 2xwy               c = y - xy - wy + 2xwy
  if (obj2->getEqType() == eqtXeqAB)
  {
    
    if (!mySecondVariable)
    {
      if ((obj1->getVar4() == obj2->getVar3()) && (obj1->getPos4() == obj2->getPos3()) &&         
          (obj1->getVar1() == obj2->getVar2()) && (obj1->getPos1() == obj2->getPos2()) )
      {
        obj2->getXeqAB(varC,posC,varG,posG,varY,posY);
        varX = obj1->getVar2();
        posX = obj1->getPos2();
      }
      else if ( (obj1->getVar4() == obj2->getVar2()) && (obj1->getPos4() == obj2->getPos2()) &&
          (obj1->getVar1() == obj2->getVar3()) && (obj1->getPos1() == obj2->getPos3()) )
      {
        obj2->getXeqAB(varC,posC,varY,posY,varG,posG);
        varX = obj1->getVar2();
        posX = obj1->getPos2();
      }
      else if ((obj1->getVar4() == obj2->getVar3()) && (obj1->getPos4() == obj2->getPos3()) &&
          (obj1->getVar1() == obj2->getVar2()) && (obj1->getPos1() == !obj2->getPos2()) )
      {
        obj2->getXeqAB(varC,posC,varG,posG,varY,posY);
        varX = obj1->getVar2();
        posX = !obj1->getPos2();
      }
      else if ( (obj1->getVar4() == obj2->getVar2()) && (obj1->getPos4() == obj2->getPos2()) &&
          (obj1->getVar1() == obj2->getVar3()) && (obj1->getPos1() == !obj2->getPos3()) )
      {
        obj2->getXeqAB(varC,posC,varY,posY,varG,posG);
        varX = obj1->getVar2();
        posX = !obj1->getPos2();
      }

      else
        return false;
      
      varW = obj1->getVar3();
      posW = obj1->getPos3();
      
      
      resultEquality = AlgebraicGenerator::createTypedEquality(eqtCeqWXYpnWnXY,varC,posC,varW,posW,varX,posX,varY,posY); 
    }
    else
    {
      if ((obj1->getVar4() == obj2->getVar3()) && (obj1->getPos4() == obj2->getPos3()) &&         
          (obj1->getVar2() == obj2->getVar2()) && (obj1->getPos2() == obj2->getPos2()) )
      {
        obj2->getXeqAB(varC,posC,varX,posX,varY,posY);
      }
      else if ( (obj1->getVar4() == obj2->getVar2()) && (obj1->getPos4() == obj2->getPos2()) &&
          (obj1->getVar2() == obj2->getVar3()) && (obj1->getPos2() == obj2->getPos3()) )
      {
        obj2->getXeqAB(varC,posC,varY,posY,varX,posX);
      }
      else
        return false;
      
      varW = obj1->getVar3();
      posW = obj1->getPos3();
      
      varG = obj1->getVar1();
      posG = obj1->getPos1();
      
      resultEquality = AlgebraicGenerator::createTypedEquality(eqtCeqWXYpnWnXY,varC,posC,varW,posW,varG,posG,varY,posY);
    }
     
      
  }
  // g = x + y(1-w) - 2xy(1-w)      c = g(y+z-2yz)
  // -----------------------------------------------
  //       c = (y+z-2yz)(x + y(1-w) - 2xy(1-w))
  else if (obj2->getEqType() == eqtZeqWXpVXm2WVX)
  {
    if ( (obj1->getVar1() == obj2->getVar2()) /* && (obj1->getPos1() == obj2->getPos2())*/ &&
         (obj1->getVar4() == obj2->getVar3()) /* && (obj1->getPos4() == obj2->getPos3())*/ )
    {
      varY = obj2->getVar3(); posY = obj1->getPos4();
      varZ = obj2->getVar4(); posZ = obj2->getPos4() != (obj1->getPos4() != obj2->getPos3());
      varX = obj1->getVar2(); posX = obj1->getPos2() != (obj1->getPos1() != obj2->getPos2());
    }
    else  if ( (obj1->getVar1() == obj2->getVar2()) /*&& (obj1->getPos1() == obj2->getPos2())*/ &&
               (obj1->getVar4() == obj2->getVar4()) /*&& (obj1->getPos4() == obj2->getPos4())*/ )
    {
      varY = obj2->getVar4(); posY = obj1->getPos4();
      varZ = obj2->getVar3(); posZ = obj2->getPos3() != (obj1->getPos4() != obj2->getPos4());
      varX = obj1->getVar2(); posX = obj1->getPos2() != (obj1->getPos1() != obj2->getPos2());
    }
    else if ( (obj1->getVar2() == obj2->getVar2()) /*&& (obj1->getPos2() == obj2->getPos2())*/ &&
         (obj1->getVar4() == obj2->getVar3()) /*&& (obj1->getPos4() == obj2->getPos3())*/ )
    {
      varY = obj2->getVar3(); posY = obj1->getPos4();
      varZ = obj2->getVar4(); posZ = obj2->getPos4() != (obj1->getPos4() != obj2->getPos3());
      varX = obj1->getVar1(); posX = obj1->getPos1() != (obj1->getPos2() != obj2->getPos2());
    }
    else  if ( (obj1->getVar2() == obj2->getVar2())/* && (obj1->getPos2() == obj2->getPos2())*/ &&
               (obj1->getVar4() == obj2->getVar4())/* && (obj1->getPos4() == obj2->getPos4())*/ )
    {
      varY = obj2->getVar4(); posY = obj1->getPos4();
      varZ = obj2->getVar3(); posZ = obj2->getPos3() !=(obj1->getPos4() != obj2->getPos4()) ;
      varX = obj1->getVar1(); posX = obj1->getPos1() != (obj1->getPos2() != obj2->getPos2());
    }
    else
      return false;

    varC = obj2->getVar1(); posC = obj2->getPos1();
    varW = obj1->getVar3(); posW = obj1->getPos3();

    resultEquality = AlgebraicGenerator::createTypedEquality(eqtCeqXZmXYpnWYnZp2WXYnZ,varC,posC,varW,posW,varX,posX,varY,posY,varZ,posZ);
  }
  else
    return false;
  
  
  if (!resultEquality->isTautology())
  {
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);
    mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);
    return true;
  }
  return false;
}

PDeductionObjectIterator XOROR2Part2Rule::getBeginIterator1(DeductionObjectSet *set) const
{
  return set->getBegin(indSeqXpVnWm2XWnV);
}
  
PDeductionObjectIterator XOROR2Part2Rule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEnd(indSeqXpVnWm2XWnV);
}

bool XOROR2Part2Rule::swapIterator1()
{
  if (!mySecondVariable)
  {
    mySecondVariable = true;
    return true;
  }
  mySecondVariable = false;
  return false;
}
