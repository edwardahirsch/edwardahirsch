#ifndef __xoror2part3_h__
#define __xoror2part3_h__

#include "../abstract/gensubrule.h"

/**
 * @file xoror2part3.h
 * @brief Contains XOROR2Part3Rule class.
 * @author sergey
 */

/// This rule proceeds as follows:
///
///    z = xy    y = w xor v
///
///  -----------------------
///
///         z = x(w xor v)
///
/// and remove y = w xor v
class XOROR2Part3Rule : public GenericTwoPremiseRule
{
  
public:

  /// constructor
  XOROR2Part3Rule(BooleanAlgebraicSolver* s) { mySolver = s; mySecondVariable = false;}
  
  virtual std::string getName() const {return "XOROR2Part3Rule";};

protected:

  PDeductionObjectIterator getBeginIterator1(DeductionObjectSet *) const;
  virtual bool checkObject1(PDeductionObject obj) const {return (obj->getEqType() == eqtZeqWXpVXm2WVX);};
  virtual bool checkObject2(PDeductionObject obj) const {return (obj->getEqType() == eqtXeqAB);};
  PDeductionObjectIterator getEndIterator1(DeductionObjectSet *) const;
  virtual Variable getVarForIndex(PEquality);
  virtual bool checkObjectMatch(PEquality,PEquality);
  virtual bool createResult(PDeductionObject, PDeductionObject, DeductionObjectSet *, PEquality, PEquality);
  virtual int whichOneToDelete(PEquality,PEquality) const;
  virtual bool swapIterator1();

private:

  /// the variable which should be substituted
  Variable myVariable;

  /// the polynomial which this variable should be substituted for
  PPolynomial myPolynomial;

  /// the type of the result
  TEqualityType myType;

  /// boolean to tell whether we iterate over the first or second variable of
  /// the first premise
  bool mySecondVariable;
};


#endif
