#ifndef __or3generationrule2_h__
#define __or3generationrule2_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../general/solver.h"

/**
 * @file or3generationrule2.h
 * @author sergey
 * @brief Contains implementation of OR3GenerationRule2 class
 */

/**
 * @class OR3GenerationRule2
 * @brief implements OR3GenerationRule2
 * (see documentation for details)
 */
class OR3GenerationRule2: public GenerationRule
{
public:
  /// Constructor
  OR3GenerationRule2(BooleanAlgebraicSolver *s) : mySolver(s) {};

  /// Destructor
  virtual ~OR3GenerationRule2() {};
  
  /**
   * Generates objects from a given deduction object set.
   */  
  virtual PDeductionObject
  operator() (const PDeductionObject&, const PDeductionObject&) const 
  {
    PDeductionObject obj;
    return obj;
  }

  /**
   * main interface: generates from newset and set, puts into returned_set;
   * if (use_new_only) does not check set vs set
   */
  virtual void
  operator() (DeductionObjectSet* returned_set, DeductionObjectSet* dedset, DeductionObjectSet* newset, bool use_new_obj) const;
 
  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set, DeductionObjectSet* old_set)
  {
    (*this)(returned_set,old_set,new_set,true);
  }

  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set)
  {
    DeductionObjectSet* objset = 0;
    (*this)(returned_set,objset,new_set,true);
  }
     
  /**
   * Returns the name of rule.
   */
  std::string
  getName() const {return "OR3GenerationRule2";};

private:
  /// solver
  BooleanAlgebraicSolver *mySolver;
};
#endif

