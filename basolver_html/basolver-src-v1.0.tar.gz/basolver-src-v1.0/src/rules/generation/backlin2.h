#ifndef __backlin2_h__
#define __backlin2_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../general/solver.h"

/**
 * @@file backlin2.h
 * Contains BackLinearization2Rule interface.
 *
 * @author kulikov
 */
 

/**
 * @@class BackLinearization2Rule
 * @@brief implements BackLinearization2Rule
 * (see documentation for details)
 */
class BackLinearization2Rule: public GenerationRule
{
public:
  /// Constructor.
  BackLinearization2Rule(BooleanAlgebraicSolver* s) : mySolver(s) {};

  virtual void 
  operator() (DeductionObjectSet* returned_set, 
              DeductionObjectSet* new_set, 
	      DeductionObjectSet* old_set);

  virtual std::string
  getName() const {return "And Substitution Rule";};
  
private:  
  /// Given an object c=lg as a second premise, 
  /// a variable l, and an object containing l as a first 
  /// premise, produces an object c=gS, if the first premise 
  /// is of the form l=S. See documentation for details.
  PDeductionObject
  operator() (PDeductionObject obj1, PDeductionObject obj2, Variable input_l);
  
  /// Reference to the solver.
  BooleanAlgebraicSolver* mySolver;
  
  /**
   * Returns 0 if indexvar is the result of some gate (including XOR)
   * still appearing in the given set; 1 otherwise.
   */  
  int checkRestriction(DeductionObjectSet* myset, Variable indexvar) const;
};
#endif



