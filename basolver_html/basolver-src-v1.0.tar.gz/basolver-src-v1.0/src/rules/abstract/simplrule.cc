#include "simplrule.h"
#include "general/solver.h"
#include "basicobject/simpleobjectset.h"
#include "basicobject/trivialobjectset.h"

/**
 * @file simplrule.cc
 * @brief Contains implementation of several methods of Simplification Rules classes.
 */
 
/* @author kulikov */

void MetaSimplificationRule::clear()
{
  std::list<SimplificationRule *>::iterator it = myRuleList.begin(); 
  while (it != myRuleList.end()) 
  {
    delete (*it); 
    ++it;
  } 
  myRuleList.clear(); 
}


MetaSimplificationRule::~MetaSimplificationRule()
{
  std::list<SimplificationRule *>::iterator it = myRuleList.begin(); 
  while (it != myRuleList.end()) 
  {
    delete (*it); 
    ++it;
  } 
  myRuleList.clear(); 
}

void 
MetaSimplificationRule::operator()(
  DeductionObjectSet* returned_set,
  DeductionObjectSet* new_set,
  DeductionObjectSet* old_set, bool gen_new_vs_new)
{
  if (!gen_new_vs_new && old_set->getSize() == 0)
    return;
    
  if (new_set->getSize() == 0)
    return;
    
  for (std::list<SimplificationRule*>::iterator it = this->myRuleList.begin();
  it != myRuleList.end(); it++)
  {
    (*it)->beforeApplying(returned_set);
    mySolver->simplifyAllObjectsByNewModifiers();
    (**it)(returned_set, new_set, old_set,gen_new_vs_new);
    mySolver->simplifyAllObjectsByNewModifiers();
    (*it)->afterApplying(returned_set);

  }
}

void 
MetaSimplificationRule::operator()(
  DeductionObjectSet* returned_set,
  ModificationObjectSet* new_set,
  ModificationObjectSet* old_set, bool gen_new_vs_new)
{
  if (!gen_new_vs_new && old_set->getSize() == 0)
    return;

  if (new_set->getSize() == 0)
    return;

  for (std::list<SimplificationRule*>::iterator it = this->myRuleList.begin();
  it != myRuleList.end(); it++)
  {
    (*it)->beforeApplying(returned_set);
    mySolver->simplifyAllObjectsByNewModifiers();
    (**it)(returned_set, new_set, old_set,gen_new_vs_new);
    mySolver->simplifyAllObjectsByNewModifiers();
    (*it)->afterApplying(returned_set);
  }
}



void 
MetaSimplificationRule::operator()(
  DeductionObjectSet* returned_set,
  DeductionObjectSet* new_set,
  ModificationObjectSet* old_set)
{
  if (old_set->getSize() == 0 || new_set->getSize() == 0)
    return;
    
  for (std::list<SimplificationRule*>::iterator it = this->myRuleList.begin();
  it != myRuleList.end(); it++)
  {
    (*it)->beforeApplying(returned_set);
    mySolver->simplifyAllObjectsByNewModifiers();
    (**it)(returned_set, new_set, old_set);
    mySolver->simplifyAllObjectsByNewModifiers();
    (*it)->afterApplying(returned_set);
  }
}


void 
MetaSimplificationRule::operator()(
  DeductionObjectSet* returned_set,
  DeductionObjectSet* new_set)
{
  if (new_set->getSize() == 0)
    return;
    
  for (std::list<SimplificationRule*>::iterator it = this->myRuleList.begin();
  it != myRuleList.end(); it++)
  {
    (*it)->beforeApplying(returned_set);
    mySolver->simplifyAllObjectsByNewModifiers();
    (**it)(returned_set, new_set);
    mySolver->simplifyAllObjectsByNewModifiers();
    (*it)->afterApplying(returned_set);
  }
}



void 
MetaSimplificationRule::operator()(
  DeductionObjectSet* returned_set,
  list<DeductionObjectSet*> *ded_list)
{
  for (std::list<SimplificationRule*>::iterator it = this->myRuleList.begin();
  it != myRuleList.end(); it++)
  {
    (*it)->beforeApplying(returned_set);
    mySolver->simplifyAllObjectsByNewModifiers();
    (**it)(returned_set, *ded_list);
    mySolver->simplifyAllObjectsByNewModifiers();
    (*it)->afterApplying(returned_set);
  }
}
