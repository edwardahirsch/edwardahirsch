#include "gensubrule.h"
#include "logical/abstract/saclause.h"

/**
 * @file gensubrule.cc
 * @brief implementation for gensubrule.h
 */


Variable GenericSubstitutionRule::getVarForIndex(PEquality eq)
{
  if (eq->getEqType() == Special)
    myVariable = eq->getLHS()->getVariable();
  else
    myVariable = eq->getVar1();

  myPolynomial = eq->getRHS();
  
  return myVariable;
}

void GenericSubstitutionRule::createResult(PDeductionObject object1, PDeductionObject object2, DeductionObjectSet *result_set, PEquality obj1, PEquality obj2) const
{
  PEquality resultEquality = obj2->substituteVarWithPoly(myVariable,myPolynomial);
  if (!resultEquality->isTautology())
  {
    if (myType != LastType) resultEquality->setEqType(myType);
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);
    mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);
  }
}

PDeductionObjectIterator GenericSubstitutionRule::getBeginIterator1(DeductionObjectSet *set) const
{
  return set->getBeginIteratorOnWholeSet();
}
  
PDeductionObjectIterator GenericSubstitutionRule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEndIteratorOnWholeSet();
}
  
PModificationObjectIterator GenericSubstitutionRule::getBeginIterator1(ModificationObjectSet *set) const
{
  return set->getBeginIteratorOnWholeSet();
}
  
PModificationObjectIterator GenericSubstitutionRule::getEndIterator1(ModificationObjectSet *set) const
{
  return set->getEndIteratorOnWholeSet();
}

PDeductionObjectIterator GenericSubstitutionRule::getBeginIterator2(DeductionObjectSet *set) const
{
  return set->getBeginIteratorOnWholeSet();
}
  
PDeductionObjectIterator GenericSubstitutionRule::getEndIterator2(DeductionObjectSet *set) const
{
  return set->getEndIteratorOnWholeSet();
}
  
PModificationObjectIterator GenericSubstitutionRule::getBeginIterator2(ModificationObjectSet *set) const
{
  return set->getBeginIteratorOnWholeSet();
}
  
PModificationObjectIterator GenericSubstitutionRule::getEndIterator2(ModificationObjectSet *set) const
{
  return set->getEndIteratorOnWholeSet();
}





