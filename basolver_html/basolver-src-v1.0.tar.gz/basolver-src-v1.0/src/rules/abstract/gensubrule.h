#ifndef __gensubrule_h__
#define __gensubrule_h__

#include "generic.h"

/**
 * @file gensubrule.h
 * @brief Contains GenericSubstitutionRule class.
 * @author sergey
 */

/// This rule proceeds as follows:
///    x = P    0 = S
///  -----------------------
///         0 = S|_{x=P}
/// and remove 0=S
/// The rule has virtual methods that must be implemented before use
class GenericSubstitutionRule : virtual public GenericTwoPremiseRule
{
  
public:

  /// constructor
  GenericSubstitutionRule(BooleanAlgebraicSolver* s) { mySolver=s; };
  
  virtual std::string getName() const {return "GenericSubstitutionRule";};

protected:

  /**
   * should return begin iterator on the first set, that is, on the set that
   * contains elements x=P
   */
  virtual PDeductionObjectIterator getBeginIterator1(DeductionObjectSet *) const;

  /**
   * should return end iterator on the first set
   */
  virtual PDeductionObjectIterator getEndIterator1(DeductionObjectSet *) const;

  /**
   * should return begin iterator on the first set, that is, on the set that
   * contains elements x=P
   */
  virtual PModificationObjectIterator getBeginIterator1(ModificationObjectSet *) const;

  /**
   * should return end iterator on the first set
   */
  virtual PModificationObjectIterator getEndIterator1(ModificationObjectSet *) const;
 
  /**
   * should return begin iterator on the second set, that is, on the set that
   * contains elements 0=S
   * only needed if no index variable is given (if getVarForIndex() returns 0)
   */
  virtual PModificationObjectIterator getBeginIterator2(ModificationObjectSet *) const;

  /**
   * should return end iterator on the second set
   * only needed if no index variable is given (if getVarForIndex() returns 0)
   */
  virtual PModificationObjectIterator getEndIterator2(ModificationObjectSet *) const;
  
  /**
   * should return begin iterator on the second set, that is, on the set that
   * contains elements 0=S
   * only needed if no index variable is given (if getVarForIndex() returns 0)
   */
  virtual PDeductionObjectIterator getBeginIterator2(DeductionObjectSet *) const;

  /**
   * should return end iterator on the second set
   * only needed if no index variable is given (if getVarForIndex() returns 0)
   */
  virtual PDeductionObjectIterator getEndIterator2(DeductionObjectSet *) const;

  
  /// check the first object; returns true by default
  virtual bool checkObject1(PDeductionObject) const {return true;};
  /// check the second object; returns true by default
  virtual bool checkObject2(PDeductionObject) const {return true;};
  
  /**
   * choose the variable for index to look for the second equality
   * the default implementation in \ref GenericSubstitutionRule chooses var1 
   * if the given equality is typed and chooses the left-hand side variable if
   * the equality is of type Special
   * NOTE: this method MUST set \ref myVariable and \ref myPolynomial;
   * otherwise the default implementation of createResult() will not work
   * NOTE: if you wish to assign a given type to the result, set myType here
   */
  virtual Variable getVarForIndex(PEquality);

  /**
   * check that these two objects match with each other
   * the default implementation in \ref GenericSubstitutionRule returns true
   */
  virtual bool checkObjectMatch(PEquality,PEquality) const {return true;};

  /**
   * create the resulting object and add it to the given set
   * the default implementation in \ref GenericSubstitutionRule substitutes
   * set type parameter if you want to assign the result with a type
   */
  virtual void createResult(PDeductionObject, PDeductionObject, DeductionObjectSet *, PEquality, PEquality) const;

  /**
   * choose which object to delete; 
   * the default implementation in \ref GenericSubstitutionRule deletes the
   * second object
   */
  virtual int whichOneToDelete(PDeductionObject, PDeductionObject) {return 2;};

  /// pointer to the \ref BooleanAlgebraicSolver
  BooleanAlgebraicSolver *mySolver;

  /// the variable which should be substituted
  Variable myVariable;

  /// the polynomial which this variable should be substituted for
  PPolynomial myPolynomial;

  /// the type of the result
  TEqualityType myType;
};


#endif
