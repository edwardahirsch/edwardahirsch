#include "genrule.h"
#include "misc/output.h"
#include "basicobject/simpleobjectset.h"
#include "basicobject/trivialobjectset.h"

/**
 * @file genrule.cc
 * @brief Contains implementation of several methods of Generation Rule classes
 */

/* @author kulikov */

void 
MetaGenerationRule::operator()(
  DeductionObjectSet* returned_set,
  DeductionObjectSet* new_set, 
  DeductionObjectSet* old_set)
{
  for (std::list<GenerationRule*>::iterator it = this->myRuleList.begin();
  it != this->myRuleList.end(); it++)
  {
    (*it)->beforeApplying(returned_set);
    mySolver->simplifyAllObjectsByNewModifiers();
    (**it)(returned_set, new_set, old_set);
    mySolver->simplifyAllObjectsByNewModifiers();
    (*it)->afterApplying(returned_set);
  }
}

void
MetaGenerationRule::operator()(
  DeductionObjectSet* returned_set,
  DeductionObjectSet* set)
{
  Assert(0, "\nWe do not use this method.");
}
 
