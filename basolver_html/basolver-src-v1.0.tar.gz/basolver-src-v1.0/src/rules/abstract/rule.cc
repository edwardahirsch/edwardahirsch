#include "rule.h"
#include "basicobject/simpleobjectset.h"
#include "basicobject/trivialobjectset.h"

/**
 * @file rule.cc
 * @brief implementation for rule.h
 * @author kulikov
 */




void Rule::beforeApplying(DeductionObjectSet *set)
{
    TRACE("rulesstat2", 
      {
	begin_time = clock();	
	number_of_objects_before_call = set->getSize();
      };);
      
    TRACE("rulesstat", 
      {
	begin_time = clock();	
	number_of_objects_before_call = set->getSize();
      };);
}

void Rule::afterApplying(DeductionObjectSet *set)
{
    TRACE("rulesstat2", 
      {
	std::cerr << "OK"; 
	double duration = ((double)clock()-begin_time)/((double)CLOCKS_PER_SEC);
	this->incTime(duration);
	std::cerr << "\n Statistics for this rule: ";
	std::cerr << "generated " << set->getSize() - number_of_objects_before_call << " objects";
      };);

    TRACE("rulesstat", 
      {
	double duration = ((double)clock()-begin_time)/((double)CLOCKS_PER_SEC);
	this->incTime(duration);
      };);
}

