#ifndef __genrule_h__
#define __genrule_h__

#include "rule.h"
#include "boost/smart_ptr.hpp"
#include <list>
#include "basicobject/objectset.h"

/**
 * @file genrule.h
 * @brief Contains Generation Rules interfaces.
 */
 
/// Forward declaration.
class BooleanAlgebraicSolver;

/// Interface for generation rule.
/// Generation rule is intended to produce new objects 
/// from existent ones. Usually generation rules 
/// do not remove their premises.
class GenerationRule : virtual public Rule
{
public: 
  /// Generates new objects from groups of objects 
  /// from new_set and old_set where at least one object 
  /// is from new_set. New objects are added to returned_set.
  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set, DeductionObjectSet* old_set) = 0;

  /// Generates new objects from groups of objects 
  /// from new_set. New objects are added to returned_set.
  virtual void operator()(DeductionObjectSet* returned_set, DeductionObjectSet* new_set) {};
  
  virtual std::string getName() const { return std::string("GenerationRule"); };
  
};

/// Smart pointer to GenerationRule.
typedef boost::shared_ptr<GenerationRule> PGenerationRule;

/// Generation metarule is a list of generation rules.
/// By application of such a rule we mean consqutive application 
/// of all its internal rules.
class MetaGenerationRule : public GenerationRule
{
private:
  /// List of generation rules.
  std::list<GenerationRule *> myRuleList;
  /// Reference to the solver.
  BooleanAlgebraicSolver *mySolver;  
public: 

  /// constructor
  MetaGenerationRule(BooleanAlgebraicSolver* s): mySolver(s) {};

  /// Destructor. Cleans the internal list of rules. 
  virtual 
  ~MetaGenerationRule()
  { std::list<GenerationRule *>::iterator it = myRuleList.begin(); while (it!=myRuleList.end()) {delete (*it); ++it;}; this->myRuleList.clear(); };
  
  virtual void 
  operator()(DeductionObjectSet* returned_set,
             DeductionObjectSet* new_set, 
	     DeductionObjectSet* old_set);

  virtual void
  operator()(DeductionObjectSet* returned_set,
             DeductionObjectSet* new_set);
 
  /**
   * Adds a rule to this metarule.
   */
  void addRule(GenerationRule* R)
  {
    myRuleList.push_back(R);
  };
 
  virtual std::string 
  getName() const
  { return std::string("MetaGenerationRule"); };
  
  /// Returns list of internal generation rules.
  std::list<GenerationRule *> 
  getList() { return myRuleList; };

  /// clears the list of rules
  void clear()
  { std::list<GenerationRule *>::iterator it = myRuleList.begin(); while (it!=myRuleList.end()) {delete (*it); ++it;}; this->myRuleList.clear(); };

};

/// Smart pointer to MetaGenerationRule.
typedef boost::shared_ptr<MetaGenerationRule> PMetaGenerationRule;  
#endif 


