#include "transferrule.h"
#include "misc/output.h"

/**
 * @file transferrule.cc
 * @brief Contains implementation of TransferRule methods.
 */
 
/* @author kulikov */

bool TransferRule::operator()(
  DeductionObjectSet* new_obj_set,
  DeductionObjectSet* ded_obj_set,
  ModificationObjectSet* mod_obj_set)
{

  PDeductionObjectIterator cur_obj = new_obj_set->getBeginIteratorOnWholeSet();
  PDeductionObjectIterator cur_end = new_obj_set->getEndIteratorOnWholeSet();
  
  for (; !cur_obj->equals(*cur_end); ++*cur_obj)
  {
    if ((**cur_obj)->isTautology())
    {
      mySolver->getOutput()->printObjectRecognition(&(*((**cur_obj))), std::string("tautology"));
      continue;
    };
      
    if ((**cur_obj)->isContradiction())
    {
      mySolver->getOutput()->printObjectRecognition(&(*((**cur_obj))), std::string("contradiction"));
      throw std::string("contradiction");
      return false;
    }
  
    PSAClause clause = boost::shared_dynamic_cast<SAClause, Object>((**cur_obj));
    if (clause.get() != 0)
    {
      if (clause->getNumberOfLiterals() > 1)
      {
        ded_obj_set->add((**cur_obj));
        mySolver->getOutput()->printObjectRecognition(&(*((**cur_obj))), std::string("clause"));
      }
      
      if (clause->getNumberOfLiterals() == 1)
      {
        SALiteralIterator it = clause->begin();
        PEquality equality = boost::shared_dynamic_cast<Equality, SALiteral>(*it);
	
        if (equality.get() != 0)
        {
          if (equality->isModifier())
	  {

	    Variable v2=equality->getRHS()->getVariable();
            if (v2!=0)
	    {
	      Assert((v2>0),"Negative variable in TransferRule");
	      Variable v1=equality->getLHS()->getVariable();
	      int p1=mySolver->getVarPriority(v1);
	      int p2=mySolver->getVarPriority(v2);
	      if (p1!=0) 
	      // if a variable has some priority, we must attempt to copy it.
	      {
	        int p2=mySolver->getVarPriority(v2);
		if ((p2==0)||(p1 < p2))
		//it is possible that both !=0. Then we take the strongest
		{
		 mySolver->setVarPriority(v2,p1);
		 TRACE("nextlit",std::cerr<<"Priority: set ";
		    mySolver->printVar(std::cerr,v2);
		    std::cerr<<" because of ";
		    mySolver->printVar(std::cerr,v1);
		    std::cerr<<" ("<<p2<<"->"<<p1<<")";
		    std::cerr<<std::endl;
		    );
		}
	      }
	      else //i.e., p1==0
	      {
		if (p2!=0) 
	        {
		  mySolver->setVarPriority(v1,p2);
		  TRACE("nextlit",std::cerr<<"Priority: Set ";
		    mySolver->printVar(std::cerr,v1);
		    std::cerr<<" because of ";
		    mySolver->printVar(std::cerr,v2);
		    std::cerr<<" ("<<p1<<"->"<<p2<<")";
		    std::cerr<<std::endl;
		    );
		}
	      }
	    }

            PModificationObject new_obj = PModificationObject(equality);
            mod_obj_set->add(new_obj);

	    mySolver->getOutput()->printObjectRecognition(&(*((**cur_obj))), std::string("modifier"), true);
	    mySolver->getOutput()->printGenerationRuleApplication(this, &(*new_obj), &(*((**cur_obj))), NULL, NULL, NULL, "", true);
	  }
	  else 
	  {
	    ded_obj_set->add((**cur_obj));
	    mySolver->getOutput()->printObjectRecognition(&(*((**cur_obj))), std::string("clause"));
	  }
        }
        else
          Assert(0, "object of unknown type!");
      };
      
    } 
        
  }
  
  new_obj_set->clear();
  return true;
} 
