#include "generic.h"
#include "../../misc/output.h"

/**
 * @file generic.cc
 * @brief implementation for generic.h
 * @author sergey 
 */


void 
GenericTwoPremiseRule::operator()(
DeductionObjectSet* result_set, 
DeductionObjectSet* new_set,
DeductionObjectSet* ded_set)
{

  bool has_old_obj = false;
  if (ded_set != 0) has_old_obj = true;

  
  // taking iterators; methods for taking iterators (e.g.
  // using an index) should be specified in descendants of this class
  PDeductionObjectIterator it1;
  PDeductionObjectIterator it2, end2,newend2,oldbegin2;
  PDeductionObjectIterator newend;
  PDeductionObjectIterator end1;

  bool has_new_premise1 = true, has_new_premise2 = true;
  Variable indexVar = 0;
  bool first_to_delete = false, second_to_delete = false;
  PSAClause clause1,clause2;
  PEquality eq1, eq2;

  do
  {
 
    has_new_premise1 = true, has_new_premise2 = true;
 
  it1 = this->getBeginIterator1(new_set);
  newend = this->getEndIterator1(new_set);
  if (has_old_obj) 
  {
    end1 = this->getEndIterator1(ded_set);
  }
  else end1 = newend;
  
  while (!(it1->equals(*end1)))
  {
    // a standard block of code to switch from the new set to the old one,
    // keeping in mind where we currently are (to determine later
    // whether new objects participate in the derivation)
    if (it1->equals(*newend)) 
    {
      if (!has_old_obj) break;
      has_new_premise1 = false;
      // if new objects are already done with,
      // there is no point to continue
      if (!has_old_obj)
        break;
      else
        it1 = this->getBeginIterator1(ded_set);
      if (it1->equals(*end1)) break;
    }

    // checkObject1(PDeductionObject) should continue if the object has
    // the wrong form for this rule
    if (!this->checkObject1(**it1)) 
    {
      ++*it1;
      continue;
    }
   
    
    clause1=(boost::shared_dynamic_cast<SAClause, DeductionObject>((**it1)));
    eq1 = (boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin())));

    
    // this should return the index variable; if we should use some
    // other custom index, this should return 0
    if (!this->manyVarsForIndex())
    {
      indexVar = this->getVarForIndex(eq1);
    
      if (!indexVar)
      {
        ++*it1;
        continue;
      }
      else
      {
        
        it2 = new_set->begin(indexVar);
        newend2 = new_set->end(indexVar);
  
        
        if ( (has_old_obj) && (has_new_premise1))
          end2=ded_set->end(indexVar);
        else 
          end2=newend2;
      }
    }
    
    bool repeat=true;
    while (repeat)
    {
      if (!this->manyVarsForIndex()) repeat=false;
      else
      {
        indexVar=this->getNextVarForIndex(eq1);
        if (!indexVar) break;
	else
	{
          it2 = new_set->begin(indexVar);
          newend2 = new_set->end(indexVar);

          if ( (has_old_obj) && (has_new_premise1))
            end2=ded_set->end(indexVar);
          else 
            end2=newend2;	  
	};
      }; 
      while (!(it2->equals(*end2)))
      {
        if (it2->equals(*newend2)) 
        {     
          has_new_premise2 = false;
          // if new objects are already done with,
          // there is no point to continue
          if (!has_old_obj || !has_new_premise1)
            break;
          else
            it2 = ded_set->begin(indexVar);
          if (it2->equals(*end2)) break;
        }

        if (((**it1)->getId() == (**it2)->getId()) || (!this->checkObject2(**it2))) {++*it2; continue;}
 
        clause2=(boost::shared_dynamic_cast<SAClause, DeductionObject>((**it2)));
        eq2 = (boost::shared_dynamic_cast<Equality, SALiteral>(*(clause2->begin())));
     
      
        // here we check whether the two objects match
        // we also assume that an object should not pair with itself
        if (this->checkObjectMatch(eq1,eq2))
        {
          // this should create the result and put it into result_set
          if (createResult(**it1,**it2,result_set,eq1,eq2))
          {
            switch (this->whichOneToDelete(eq1,eq2))
            {
              case 1: first_to_delete = true; break;
              case 2: second_to_delete = true; break;
              case 3:
                      first_to_delete = true; second_to_delete = true; break;
            }
           
            if (first_to_delete) break;
            
            if (second_to_delete)
            {
              if (has_new_premise2)
              { 
                mySolver->getOutput()->printThatRuleDeletedObject(this->getName(),&(***it2),new_set);
                it2 = new_set->remove(it2);
              }
              else
              {
                mySolver->getOutput()->printThatRuleDeletedObject(this->getName(),&(***it2),ded_set);
                it2 = ded_set->remove(it2);
              }
            }
          }
        }
      
        if (second_to_delete)
          second_to_delete = false;
        else
            ++*it2;
     };	  

    };

    if (first_to_delete)
    {
      if (has_new_premise1)
      { 
        mySolver->getOutput()->printThatRuleDeletedObject(this->getName(),&(***it1),new_set);
        it1 = new_set->remove(it1);
      }
      else
      {
        mySolver->getOutput()->printThatRuleDeletedObject(this->getName(),&(***it1),ded_set);
        it1 = ded_set->remove(it1);
      }
      first_to_delete = false;
    }
    else
      ++*it1;
  }

  }
  while (this->swapIterator1());
}

PDeductionObjectIterator GenericTwoPremiseRule::getBeginIterator1(DeductionObjectSet *set) const
{
  return set->getBeginIteratorOnWholeSet();
}
  
PDeductionObjectIterator GenericTwoPremiseRule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEndIteratorOnWholeSet();
}
  
PModificationObjectIterator GenericTwoPremiseRule::getBeginIterator1(ModificationObjectSet *set) const
{
  return set->getBeginIteratorOnWholeSet();
}
  
PModificationObjectIterator GenericTwoPremiseRule::getEndIterator1(ModificationObjectSet *set) const
{
  return set->getEndIteratorOnWholeSet();
}

PDeductionObjectIterator GenericTwoPremiseRule::getBeginIterator2(DeductionObjectSet *set) const
{
  return set->getBeginIteratorOnWholeSet();
}
  
PDeductionObjectIterator GenericTwoPremiseRule::getEndIterator2(DeductionObjectSet *set) const
{
  return set->getEndIteratorOnWholeSet();
}
  
PModificationObjectIterator GenericTwoPremiseRule::getBeginIterator2(ModificationObjectSet *set) const
{
  return set->getBeginIteratorOnWholeSet();
}
  
PModificationObjectIterator GenericTwoPremiseRule::getEndIterator2(ModificationObjectSet *set) const
{
  return set->getEndIteratorOnWholeSet();
}





// GENERICDUMMYRULE methods

PDeductionObjectIterator GenericDummyRule::getBeginIterator1(DeductionObjectSet *set) const
{
  return set->getBegin(indXeqAB);
}
  
PDeductionObjectIterator GenericDummyRule::getEndIterator1(DeductionObjectSet *set) const
{
  return set->getEnd(indXeqAB);
}
  
PDeductionObjectIterator GenericDummyRule::getBeginIterator2(DeductionObjectSet *set) const
{
  return set->getBegin(indXeqAB);
}
 
PDeductionObjectIterator GenericDummyRule::getEndIterator2(DeductionObjectSet *set) const
{
  return set->getEnd(indXeqAB);
}

bool GenericDummyRule::checkObject1(PDeductionObject obj) const
{
  return (obj->getEqType() == eqtXeqAB);
}

bool GenericDummyRule::checkObject2(PDeductionObject obj) const
{
  return (obj->getEqType() == eqtXeqAB);
}

Variable GenericDummyRule::getVarForIndex(PEquality eq)
{
  return eq->getVar1();
}

bool GenericDummyRule::checkObjectMatch(PEquality obj1,PEquality obj2) 
{
  return ( (obj1->getVar1() == obj2->getVar2()) || (obj1->getVar1() == obj2->getVar3()) );
}

bool GenericDummyRule::createResult(PDeductionObject object1, PDeductionObject object2, DeductionObjectSet *result_set, PEquality obj1, PEquality obj2) 
{
  
  PPolynomial resultLHS = AlgebraicGenerator::makePolynomial();
  PPolynomial resultRHS = AlgebraicGenerator::makePolynomial();

  resultRHS->addMonomial(AlgebraicGenerator::makeMonomial(obj1->getVar2()));
  if (!obj1->getPos2()) { *resultRHS *= -1; resultRHS->addMonomial(AlgebraicGenerator::makeMonomial()); }

  PPolynomial temp = AlgebraicGenerator::makePolynomial();
  temp->addMonomial(AlgebraicGenerator::makeMonomial(obj1->getVar3()));
  if (!obj1->getPos3()) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }

  *resultRHS *= *temp;

  temp = AlgebraicGenerator::makePolynomial();
  if (obj1->getVar1() == obj2->getVar2())
  {
    temp->addMonomial(AlgebraicGenerator::makeMonomial(obj2->getVar3()));
    if (!obj1->getPos3()) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }
  }
  else
  {
    temp->addMonomial(AlgebraicGenerator::makeMonomial(obj2->getVar2()));
    if (!obj1->getPos2()) { *temp *= -1; temp->addMonomial(AlgebraicGenerator::makeMonomial()); }
  }

  *resultRHS *= *temp; 
 
  resultLHS->addMonomial(AlgebraicGenerator::makeMonomial(obj2->getVar1()));
  if (!obj2->getPos1()) { *resultLHS *= -1; resultLHS->addMonomial(AlgebraicGenerator::makeMonomial()); }
  
  PEquality resultEquality=AlgebraicGenerator::createEquality(resultLHS,resultRHS);     
  
  if (!resultEquality->isTautology())
  {
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);
    mySolver->processNewObject(this,clause,result_set,&(*object1),&(*object2),NULL,NULL);
    return true;
  }
  return false;
}

