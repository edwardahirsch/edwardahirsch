#ifndef __transferrule_h__
#define __transferrule_h__

#include "boost/smart_ptr.hpp"
#include <string>
#include "rule.h"
#include "../../basicobject/objectset.h"
#include "../../logical/logical.h"

  /**
   * Interface for transfer rule.
   * This rule is intended for distinguishing 
   * clauses and modifiers.
   */
  class TransferRule : public Rule
  {
  public:

    ///constructor
    TransferRule(BooleanAlgebraicSolver *solver) : mySolver(solver) {};
    
    /// Transfers objects. Returns false iff contradiction was recognised.
    /// Each object from new_set is checked for type (deduction or modification)
    /// and transfered to the appropriate set. If some object was recognised 
    /// as a contradiction the rule immediately throws a string "contradiction".
    /// If some object was recognised as a tautology it is simply removed 
    /// from new_set (that is, this object is not transfered anywhere).
    /// If new_set does not contain a contradiction at the beginning 
    /// it will be empty after the execution of this operator. 
    bool 
    operator()(DeductionObjectSet* new_set, DeductionObjectSet*, ModificationObjectSet*);
    
    /// Returns the name of rule.
    virtual std::string
    getName() const
    {
      return std::string("TransferRule");
    };

  private:
    /// solver
    BooleanAlgebraicSolver *mySolver;
  };
  
  /**
   * Save pointer for TransferRule.
   */
  typedef boost::shared_ptr<TransferRule> PTransferRule;
  
#endif 


