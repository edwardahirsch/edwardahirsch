#ifndef __simplrule_h__
#define __simplrule_h__

#include "rule.h"
#include "boost/smart_ptr.hpp"
#include "basicobject/dedobj.h"
#include "basicobject/modobj.h"
#include "basicobject/objectset.h"
#include <list>

using namespace std;

/**
 * @file simplrule.h
 * @brief Contains Simplification Rules interfaces.
 */
 
/// Forward declaration.
class BooleanAlgebraicSolver;

/**
 * Interface for simplification rule.
 * Simplification rule replaces existing objects by new ones or 
 * generates new modification objects. Thus, a simplification rule 
 * never increases the number of deduction objects.
 * See documentation for the descendants of this class 
 * to check what premises are eliminated by a rule.
 */  
class SimplificationRule : virtual public Rule
{
public:
  /// Applies a rule to all possible groups of objects 
  /// from old_set and new_set where at least
  /// one object is from new_set. New objects are added 
  /// to returned_set.
  virtual void
  operator()(DeductionObjectSet *returned_set, 
	     DeductionObjectSet  *new_set, 
	     DeductionObjectSet  *old_set, bool gen_new_vs_new = true)
  { return; };

  /// Applies a rule to all possible groups of objects 
  /// from old_set and new_set where at least
  /// one object is from new_set. New objects are added 
  /// to returned_set.
  virtual void
  operator()( DeductionObjectSet *returned_set, 
	    ModificationObjectSet *new_set, 
	    ModificationObjectSet *old_set, bool gen_new_vs_new = true)
  { return; };
  

  /// Simplifies objects from ded_set by means 
  /// of objects from mod_set.
  /// New objects are added 
  /// to returned_set.
  virtual void
  operator()(DeductionObjectSet *returned_set, 
	     DeductionObjectSet *des_set, 
	     ModificationObjectSet * mod_set)
  { return; };	     

  /// Normalizes objects from new_set.
  /// New objects are added to returned_set.
  virtual void 
  operator() (DeductionObjectSet* returned_set, 
              DeductionObjectSet* new_set) { return; };
	      
  /// Given several deduction object sets
  /// simplifies them. New objects are added to returned_set.
  virtual void 
  operator() (DeductionObjectSet* returned_set, 
  list<DeductionObjectSet*>) 
  { return; };

  virtual std::string
  getName() const
  { return std::string("SimplificationRule"); };

  /// Virtual destructor
  virtual
  ~SimplificationRule() {};
};

/// Smart pointer to SimplificationRule.
typedef boost::shared_ptr<SimplificationRule> PSimplificationRule;

/// Simplification metarule is a list of simplification rules.
/// By application of such a rule we mean consequtive 
/// application of all its internal rules. 
class MetaSimplificationRule : public SimplificationRule
{
private:
  /// List of simplification rules.
  std::list<SimplificationRule *> myRuleList;
  /// Reference to the solver.
  BooleanAlgebraicSolver* mySolver;
public:
  /// Constructor.
  MetaSimplificationRule(BooleanAlgebraicSolver* s): mySolver(s) {};
  /// Destructor. Cleanes the internal list of rules.
  virtual 
  ~MetaSimplificationRule();
  
  virtual void
  operator()(DeductionObjectSet * returned_set, 
	     DeductionObjectSet * new_set, 
	     DeductionObjectSet * old_set, bool gen_new_vs_new = true); 

  virtual void
  operator()(DeductionObjectSet*  returned_set, 
	    ModificationObjectSet*  new_set, 
	    ModificationObjectSet*  old_set, bool gen_new_vs_new = true); 

  virtual void
  operator()(DeductionObjectSet * returned_set, 
	     DeductionObjectSet * des_set, 
	     ModificationObjectSet * mod_set); 
	     
  virtual void 
  operator() (DeductionObjectSet* returned_set, 
              DeductionObjectSet* new_set);
	     
  /// an interface to call simplification rules
  /// first parameter is where the rule should put new objects
  /// second parameter is what you need to simplify
  /// third parameter is what you want to simplify with
  virtual void 
  operator() (DeductionObjectSet* returned_set, 
  list<DeductionObjectSet*>*);

  virtual std::string
  getName() const
  { return std::string("MetaSimplificationRule"); };
  
  /// Adds a simplification rule to this metarule. 
  void 
  addRule(SimplificationRule* SR)
  { this->myRuleList.push_back(SR); };
  
  /// Returns list of internal simplification rules.
  std::list<SimplificationRule*> 
  getList() { return myRuleList; };
  
  /// clears the list of rules
  void clear();
};

/// Smart pointer to MetaSimplificationRule.
typedef boost::shared_ptr<MetaSimplificationRule> PMetaSimplificationRule;
  
#endif 


