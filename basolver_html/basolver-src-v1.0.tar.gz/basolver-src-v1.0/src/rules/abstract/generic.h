#ifndef __genericrule_h__
#define __genericrule_h__

#include "genrule.h"
#include "simplrule.h"
#include "boost/smart_ptr.hpp"
#include <list>
#include "basicobject/simpleobjectset.h"
#include "basicobject/trivialobjectset.h"
#include "../../algebraic/algebraic.h"
#include "../../general/solver.h"

/**
 * @file generic.h
 * @brief Contains GenericTwoPremiseRule class.
 * @author sergey
 */

/// This is a generic template for writing two-premise rules
/// One simply needs to define all undefined methods this rule has
/// and plug in the new rule
class GenericTwoPremiseRule : public GenerationRule, public SimplificationRule
{
public:

  /// constructor
  GenericTwoPremiseRule() {};

  /// method from \ref GenerationRule and \ref SimplificationRule
  /// Generates new objects from groups of objects 
  /// from new_set and old_set where at least one object 
  /// is from new_set. New objects are added to returned_set.
  virtual void 
  operator()(DeductionObjectSet* returned_set,
             DeductionObjectSet* new_set, 
             DeductionObjectSet* old_set);

  /// method from \ref GenerationRule
  /// Generates new objects from groups of objects 
  /// from new_set. New objects are added to returned_set.
  virtual void
  operator()(DeductionObjectSet* returned_set,
             DeductionObjectSet* new_set) {};

  /// method from \ref SimplificationRule
  /// Applies a rule to all possible groups of objects 
  /// from old_set and new_set where at least
  /// one object is from new_set. New objects are added 
  /// to returned_set.
  virtual void
  operator()( DeductionObjectSet *returned_set, 
	    ModificationObjectSet *new_set, 
	    ModificationObjectSet *old_set) {};
  

  /// method from \ref SimplificationRule
  /// Simplifies objects from ded_set by means 
  /// of objects from mod_set.
  /// New objects are added 
  /// to returned_set.
  virtual void
  operator()(DeductionObjectSet *returned_set, 
	     DeductionObjectSet *des_set, 
	     ModificationObjectSet * mod_set) {};

  virtual std::string
  getName() const
  { return std::string("GenericTwoPremiseRule"); };

  /// virtual destructor
  virtual
  ~GenericTwoPremiseRule() {};


protected:
 
  /// returns begin iterator on the first set (if it is a \ref
  /// DeductionObjectSet)
  virtual PDeductionObjectIterator getBeginIterator1(DeductionObjectSet *) const;
 
  /// swaps iterators if one needs to switch to another index
  /// return true if another run of the main cycle is needed
  /// return false if the rule may finish
  virtual bool swapIterator1() {return false;};
  
  /// returns end iterator on the first set (if it is a \ref
  /// DeductionObjectSet)
  virtual PDeductionObjectIterator getEndIterator1(DeductionObjectSet *) const;
  
  /// returns begin iterator on the first set (if it is a \ref
  /// ModificationObjectSet)
  virtual PModificationObjectIterator getBeginIterator1(ModificationObjectSet *) const;
  
  /// returns end iterator on the first set (if it is a \ref
  /// ModificationObjectSet)
  virtual PModificationObjectIterator getEndIterator1(ModificationObjectSet *) const;

  /// returns begin iterator on the second set (if it is a \ref
  /// DeductionObjectSet)
  virtual PDeductionObjectIterator getBeginIterator2(DeductionObjectSet *) const;
  
  /// returns end iterator on the second set (if it is a \ref
  /// DeductionObjectSet)
  virtual PDeductionObjectIterator getEndIterator2(DeductionObjectSet *) const;
  
  /// returns begin iterator on the second set (if it is a \ref
  /// ModificationObjectSet)
  virtual PModificationObjectIterator getBeginIterator2(ModificationObjectSet *) const;
  
  /// returns end iterator on the second set (if it is a \ref
  /// ModificationObjectSet)
  virtual PModificationObjectIterator getEndIterator2(ModificationObjectSet *) const;

  /// checks the first object for having the form necessary for applying
  /// this rule
  virtual bool checkObject1(PDeductionObject) const = 0;

  /// checks the second object for having the form necessary for applying
  /// this rule
  virtual bool checkObject2(PDeductionObject) const = 0;

  /// given the first object, returns variable on which the second index should
  /// run; if the second index should not be an index on a variable, return 0;
  /// methods get[Begin,End]Iterator2 are relevant ONLY if this returns 0
  virtual Variable getVarForIndex(PEquality) = 0;

  /// given two objects (provided that checkObject1() and checkObject2()
  /// returned true), checks whether they match to apply the rule
  virtual bool checkObjectMatch(PEquality,PEquality) = 0;
  
  /// given two objects (provided they match and the rule should be applied)
  /// generates the resulting object and add it to returned_set
  /// this method should also care about the html output
  /// the two arguments of type PEquality are the same premises as
  /// PDeductionObject, only with their equalities extracted from
  /// DeductionObjects
  /// return true if an object was created
  /// return false if no objects were created
  virtual bool createResult(PDeductionObject, PDeductionObject, DeductionObjectSet *, PEquality, PEquality) {return false;};

  /// which premise should we delete when rule applies with these inputs?
  /// 0 - no one, 1 - first, 2 - second
  virtual int whichOneToDelete(PEquality, PEquality) const {return 0;};

  /// override this if you wish to look for two variables from the first
  /// equality
  virtual Variable getSecondVarForIndex(PEquality) const {return 0;};
  
  /// override this if you wish to look for many variables from the first
  /// equality
  virtual bool manyVarsForIndex() const {return false;};
 
  /// returns the next variable on which to index;
  /// by default returns 0; override it if you need to index on >1 variable
  virtual Variable getNextVarForIndex(PEquality) {return 0;};

 
  /// a reference to the solver
  BooleanAlgebraicSolver *mySolver;
   
};


/// Smart pointer to \ref GenericTwoPremiseRule.
typedef boost::shared_ptr<GenericTwoPremiseRule> PGenericTwoPremiseRule;


/// A dummy rule to test the \ref GenericTwoPremiseRule class
class GenericDummyRule : public GenericTwoPremiseRule
{
  
public:

  /// constructor
  GenericDummyRule(BooleanAlgebraicSolver* s) {mySolver = s;};

  /// returns the name
  virtual std::string const getName() {return "GenericDummyRule";};

protected:

  virtual PDeductionObjectIterator getBeginIterator1(DeductionObjectSet *) const;
  virtual PDeductionObjectIterator getEndIterator1(DeductionObjectSet *) const;
  virtual PDeductionObjectIterator getBeginIterator2(DeductionObjectSet *) const;
  virtual PDeductionObjectIterator getEndIterator2(DeductionObjectSet *) const;
  
  virtual bool checkObject1(PDeductionObject) const;
  virtual bool checkObject2(PDeductionObject) const;
  
  virtual Variable getVarForIndex(PEquality);

  virtual bool checkObjectMatch(PEquality,PEquality);

  virtual bool createResult(PDeductionObject, PDeductionObject, DeductionObjectSet *, PEquality, PEquality);
  
};



/// Smart pointer to \ref GenericTwoPremiseRule.
typedef boost::shared_ptr<GenericDummyRule> PGenericDummyRule;





#endif
