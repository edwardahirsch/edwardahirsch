#ifndef __MONOMIALSUBSTITUTIONRULE_H__
#define __MONOMIALSUBSTITUTIONRULE_H__

#include "../abstract/simplrule.h"
#include "../../basicobject/simpleobjectset.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../misc/output.h"

/**
 * @class MonomialSubstitutionRule
 * @brief implements MonomialSubstitutionRule
 * (see documentation for details)
 */
class MonomialSubstitutionRule: public SimplificationRule
{
public:
  /**
   * constructor
   */    
  MonomialSubstitutionRule(BooleanAlgebraicSolver* s): mySolver(s){};
 
  virtual void
  operator()(DeductionObjectSet *returned_set, 
	     DeductionObjectSet  *new_set, 
	     DeductionObjectSet  *old_set, bool gen_new_vs_new = true);
	     
  std::string getName() const   {return "MonomialSubstitutionRule";} ;
  



private:
  /**
   * Substitutes one equality in one clause
   */    
  PDeductionObject substituteOne(PSAClause clause, PPolynomial linear, PMonomial square);
  
  /// Returns linear and square parts of equality
  void getParts(PPolynomial& linear, PMonomial& square, PEquality equality);
  
  /// a reference to the solver
  BooleanAlgebraicSolver *mySolver;         
};




#endif
