#include "gatesequiv2.h"
#include "literalsubstitutionrule.h"
#include "../../misc/output.h"

/**
 * @file gatesequiv2.cc
 * @brief implementation for gatesequiv2.h
 * @author kulikov
 */



GatesEquivalence2Rule::GatesEquivalence2Rule(BooleanAlgebraicSolver* s)
{
  mySolver = s;
  myLitSubstRule = new LiteralSubstitutionRule(s);
}

GatesEquivalence2Rule::~GatesEquivalence2Rule()
{
  delete myLitSubstRule;
}



PDeductionObject
GatesEquivalence2Rule::operator() (
PDeductionObject obj1,
PDeductionObject obj2,
int &which_one_to_delete,
bool &evenequiv)
{
  evenequiv = false;
  num_del_pre = 0;
  which_one_to_delete = 0;
  
  PSAClause clause1 = boost::shared_dynamic_cast<SAClause, DeductionObject>(obj1);
  PSAClause clause2 = boost::shared_dynamic_cast<SAClause, DeductionObject>(obj2);
  Assert((clause1 && clause2), "Input objects are not clauses.");
  
  if (clause1->getNumberOfLiterals() != 1 || clause2->getNumberOfLiterals() != 1)
  {
    PDeductionObject res;
    return res;
  }
    
  PEquality eq1 = boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin()));
  PEquality eq2 = boost::shared_dynamic_cast<Equality, SALiteral>(*(clause2->begin()));
  Assert((eq1 && eq2), "Input clauses contain something strange.");
  
  // --------------------------------------- EVENEQ --------------------------------------------
  
  if (eq1->oddPartEqualsModulo2(eq2))
  {
    PPolynomial resultLHS = AlgebraicGenerator::makePolynomial();
    PPolynomial resultRHS = eq2->getEvenPartDiff(eq1);

    // Degrees of eq1 and eq2 is less then 2. Don't apply when they are both
    // linear. See details in TeX documentation. 
    Assert((resultRHS.get() != 0),"oddpartequalsmodulo2 doesn't work");
    if(    !((resultRHS->getSize()>0 && resultRHS->getDegree() == 3))
        && !((resultRHS->getSize()>0 && resultRHS->getDegree() == 1)) 
        )
    {
      if (eq1->getRHS()->getDegree() < eq2->getRHS()->getDegree())
        which_one_to_delete = 2;
      else if (eq1->getRHS()->getDegree() > eq2->getRHS()->getDegree())
        which_one_to_delete = 1;
      else if (eq1->getRHS()->isLexLess(eq2->getRHS()))
        which_one_to_delete = 2;
      else
        which_one_to_delete = 1;
       
      PEquality resultEquality = AlgebraicGenerator::makeEqualityWithCloning(resultLHS,resultRHS);

      PSAClause clause = LogicalGenerator::makeSAClause();
      clause->add(resultEquality);
     
      // needed for modified add step
      if(resultEquality->getEqType() == eqtXeqAB && eq1->getEqType() == Special && eq2->getEqType() == Special)
      {
        evenequiv = true;
        return clause;
      }

      // Don't apply if the difference of eq1 and eq2 mod 2 has is the second
      // degree. See details in TeX documetation.
      if(resultRHS->getDegree() == 1 && resultRHS->getOddPart()->getSize() == 0)
      {
        evenequiv = true;
        return clause;
      }
      else
      {
        evenequiv = false;
        which_one_to_delete = 0;
      }
    }
    else 
      ;
  }
 
  // ----------------------------------------------- END OF EVENEQ ---------------------------------------------
 
  if (!this->checkRestrictions(eq1, eq2))
  {
    PDeductionObject res;
    return res;
  }
  
  
  *eq1->getRHS()-=*eq1->getLHS();
  *eq2->getRHS()-=*eq2->getLHS();
  Variable var1, var2;
  bool equals;
  bool parse=(eq1->getRHS()->parseTwoLiteralInSum(eq2->getRHS(), var1, var2, equals));
  
  *eq1->getRHS()+=*eq1->getLHS();
  *eq2->getRHS()+=*eq2->getLHS();
  if (!parse)  {PDeductionObject res; return res;}
  if (!var1 && !var2 && equals) //sum gets nothing interesting to us: 2S=0
  {
    PDeductionObject res;
    return res;
  }
  if (!var1 && !var2 && !equals)
  // contradiction was generated,  sum: 2S+1=0
  {
    PPolynomial rhs = AlgebraicGenerator::makePolynomial();
    rhs->operator+=(1);
    PEquality result_eq = AlgebraicGenerator::createEquality(AlgebraicGenerator::makePolynomial(), rhs);
    
    PSAClause result_clause = LogicalGenerator::makeSAClause();
    result_clause->add(result_eq);
    return result_clause;  
  };
  if (var1 && !var2) //sum: x=2S[+1]
  {
    mySolver->setVarPriority(var1,100);
    TRACE("nextlit",std::cerr<<"Priority: Disabled (GatesEquiv)";
                  mySolver->printVar(std::cerr,var1);
		  std::cerr<<std::endl;
    );
    PPolynomial rhs = AlgebraicGenerator::makePolynomial();
    if (!equals) rhs->operator+=(1);
    PEquality result_eq = AlgebraicGenerator::createEquality(AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(var1)), rhs);
    PSAClause result_clause = LogicalGenerator::makeSAClause();
    result_clause->add(result_eq);
    return result_clause;  
  };
  if (!(var1 && var2))// x==0 => y==0
  {
    Assert(0,"bug!");
  }
  mySolver->setVarPriority(var1,100);
  mySolver->setVarPriority(var2,100);
  TRACE("nextlit",std::cerr<<"Priority: Disabled (GatesEquiv)";
                  mySolver->printVar(std::cerr,var1);
		  std::cerr<<" ";
                  mySolver->printVar(std::cerr,var2);
		  std::cerr<<std::endl;
  );
  PPolynomial resultLHS = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(var1));
  PPolynomial resultRHS;
  resultRHS = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(var2));
  if (!equals) //we deduce from sum: x=1-y 
  {
    resultRHS->operator*=(-1);
    resultRHS->operator+=(1);
  };
  PEquality result_eq = AlgebraicGenerator::createEquality(resultLHS,resultRHS);
  PSAClause result_clause = LogicalGenerator::makeSAClause();
  result_clause->add(result_eq);
  return result_clause;   
}

void
GatesEquivalence2Rule::operator()(
DeductionObjectSet* returned_set,
DeductionObjectSet* new_set, 
DeductionObjectSet* old_set,
bool gen_new_vs_new)
{
  int todelete = 0;
  bool secondinoldset = true;
  bool gatesequiv = false;
  PDeductionObjectIterator first_pre_it = new_set->getBeginIteratorOnWholeSet();
  PDeductionObjectIterator first_pre_it_end = new_set->getEndIteratorOnWholeSet();
  
  while (!first_pre_it->equals(*first_pre_it_end))
  {
    gatesequiv = false;
    PSAClause first_clause = boost::shared_dynamic_cast<SAClause, DeductionObject>(**first_pre_it);
    Assert(first_clause, "Input objects are not clauses.");
  
    todelete = 0;
    if (first_clause->getNumberOfLiterals() != 1)
    {
      ++*first_pre_it;
      continue;
    }
      
    PEquality first_eq = boost::shared_dynamic_cast<Equality, SALiteral>(*(first_clause->begin()));
 
  
    PVarList odd_var_list = PVarList(new std::list<Variable>);
    PPolynomial left_odd = first_eq->getLHS()->getOddPart();
    PPolynomial right_odd = first_eq->getRHS()->getOddPart();

    left_odd->getVarList(odd_var_list);
    right_odd->getVarList(odd_var_list);
    
    int number_of_considered_var = 0;
    
    for (std::list<Variable>::iterator var_it = odd_var_list->begin(); var_it != odd_var_list->end(); var_it++)
    {
      number_of_considered_var++;
      if (number_of_considered_var >= 3)
        break;
      
      Variable var_from_monom_with_odd_coeff = *var_it;
    
      
      
      PDeductionObjectIterator second_pre_it = old_set->begin(var_from_monom_with_odd_coeff);
      secondinoldset = true;
      PDeductionObjectIterator old_end = old_set->end(var_from_monom_with_odd_coeff);
      PDeductionObjectIterator new_end = new_set->end(var_from_monom_with_odd_coeff);
    
      while (!second_pre_it->equals(*new_end))
      {

        if (todelete == 1) break;
        todelete = 0;
	gatesequiv = false;
        
        if (second_pre_it->equals(*old_end))  
        {
          secondinoldset = false;
          second_pre_it = new_set->begin(var_from_monom_with_odd_coeff);
          if (!gen_new_vs_new || second_pre_it->equals(*new_end))
            second_pre_it = new_end;
          continue;
        }
        
        if (!secondinoldset && ((**second_pre_it)->getId() > (**first_pre_it)->getId()))
        {
          ++*second_pre_it;
          continue;	  
        }
	
       	// before trying this object we have to check 
        // whether we have already tried it

        bool already_tried = false;

        PDeductionObject obj = **second_pre_it;
        VarList *temp_list = second_pre_it->getIE()->getVList();
        
        for (std::list<Variable>::iterator temp_it = odd_var_list->begin();temp_it != var_it; temp_it++)
        {
          if (already_tried)
            break;
          
          for (std::list<Variable>::iterator temp_it2 = temp_list->begin();temp_it2 != temp_list->end(); temp_it2++)
            if ((*temp_it) == (*temp_it2))
            {
              already_tried = true;
              break;
            }
        }
	
        if ( (!already_tried) && ((**first_pre_it)->getId() != (**second_pre_it)->getId()) )
        {
          bool evenequiv = false;
	  gatesequiv = false;
          PDeductionObject new_obj = this->operator()(**first_pre_it, **second_pre_it,todelete,evenequiv);
          
          if (new_obj.get())
          {
            if (evenequiv)
              mySolver->processNewObject(this,new_obj,returned_set,&(***first_pre_it),&(***second_pre_it),NULL,NULL,"EvenEquivalence");
            else
              mySolver->processNewObject(this,new_obj,returned_set,&(***first_pre_it),&(***second_pre_it),NULL,NULL);
          }
	  
          if (evenequiv && todelete == 1)
          {
	    Assert(new_obj.get(), "Bug.");
            mySolver->getOutput()->printThatRuleDeletedObject(this,&(***first_pre_it),new_set);
            first_pre_it = new_set->remove(first_pre_it);
            break;
          }
          
          if (evenequiv && todelete == 2)
          {
	    Assert(new_obj.get(), "Bug.");
            if (secondinoldset)
            {
              mySolver->getOutput()->printThatRuleDeletedObject(this,&(***second_pre_it),old_set);
              second_pre_it = old_set->remove(second_pre_it);
            }       
            else
            {
              mySolver->getOutput()->printThatRuleDeletedObject(this,&(***second_pre_it),new_set);
              second_pre_it = new_set->remove(second_pre_it);
            }        
          }
	  
	  if (!evenequiv && new_obj.get())
	  // gateseq rule generated something
	  {
	    gatesequiv = true;
	    PSAClause newcl = boost::shared_dynamic_cast<SAClause, DeductionObject>(new_obj);
	    PEquality neweq = boost::shared_dynamic_cast<Equality, SALiteral>(*(newcl->begin()));
	    Variable left_var = neweq->getLHS()->getVariable();
	    // simplifying premises by a new object
	    if ((**second_pre_it)->contains(left_var))
	    {
  	      PDeductionObject second_new = (*myLitSubstRule)(**second_pre_it, neweq);
	      mySolver->processNewObject(myLitSubstRule, second_new,returned_set,&(***second_pre_it),&(*neweq),NULL,NULL);
	    
              if (secondinoldset)
              {
                mySolver->getOutput()->printThatRuleDeletedObject(this,&(***second_pre_it),old_set);
                second_pre_it = old_set->remove(second_pre_it);
              }       
              else
              {
                mySolver->getOutput()->printThatRuleDeletedObject(this,&(***second_pre_it),new_set);
                second_pre_it = new_set->remove(second_pre_it);
              }        
	      todelete = 2;
	    }
	    
	    
	    if ((**first_pre_it)->contains(left_var))
	    {
	      PDeductionObject first_new = (*myLitSubstRule)(**first_pre_it, neweq);
	      mySolver->processNewObject(myLitSubstRule, first_new,returned_set,&(***first_pre_it),&(*neweq),NULL,NULL);
	      mySolver->getOutput()->printThatRuleDeletedObject(this,&(***first_pre_it),new_set);
	      first_pre_it = new_set->remove(first_pre_it);
	      todelete = 1;
	      break;
    	    }
	  }
	  
	  
	  
        }   

        
        if (todelete == 1 || gatesequiv) break;
        if (todelete != 2)
          ++*second_pre_it;
      }

      if (todelete ==1 || gatesequiv) break;
      
    }

      
    mySolver->simplifyAllObjectsByNewModifiers();
            
    
    if (todelete != 1 && !gatesequiv)
      ++*first_pre_it;
  }
}


bool
GatesEquivalence2Rule::checkRestrictions(PEquality eq1, PEquality eq2, bool even_equiv) const
{
  if (!even_equiv)
  {
    if (eq1->getEqType() != eq2->getEqType() && 
    ((eq1->getEqType() != eqtBoothSubResult && eq2->getEqType() != Special)
    && (eq2->getEqType() != eqtBoothSubResult && eq1->getEqType() != Special)))
      return false;
 
  
    if (eq1->getEqType() != eqt11m2 && eq1->getEqType() != eqtXeqAB && 
    eq1->getEqType() != Special 
    && eq1->getEqType() != eqtBoothSubResult && eq1->getEqType()!=eqtXeqABpACpBCm2ABC)
      return false;
  
    if (eq1->getEqType() == Special && (eq1->getRHS()->getDegree() + eq2->getRHS()->getDegree() != 3))
      return false;
      
    return true;
  }
  
  return true;
}

