#include "backt2subst.h"
#include "../../misc/output.h"

/**
 * @file backt2subst.cc
 * @brief implementation for backt2subst.h
 * @author kulikov
 */



PDeductionObject
BackT2SubstitutionRule::operator()(
PDeductionObject obj1,
PDeductionObject obj2)
{
  if (obj1->getId() == obj2->getId())
    return PDeductionObject();

  PSAClause clause1 = boost::shared_dynamic_cast<SAClause, DeductionObject>(obj1);
  PSAClause clause2 = boost::shared_dynamic_cast<SAClause, DeductionObject>(obj2);
  Assert((clause1 && clause2), "Input objects are not clauses.");
  
  if (clause1->getNumberOfLiterals() != 1 || clause2->getNumberOfLiterals() != 1)
  {
    PDeductionObject res;
    return res;
  }
    
  PEquality eq1 = boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin()));
  PEquality eq2 = boost::shared_dynamic_cast<Equality, SALiteral>(*(clause2->begin()));
  Assert((eq1 && eq2), "Input clauses contain something strange.");
  
  // restrictions check
  

  if (!(
        ((eq1->getEqType() == Special) && (eq1->getRHS()->getDegree()==2)) || 
	( eq1->getEqType() == eqtXeqAB) || 
	( eq1->getEqType() == eqtBackT2Result)||
        ( eq1->getEqType() == eqtBoothSubResult && eq1->getVar2() != 0)  ||
        ( eq1->getEqType() == eqtVeqYZnotLS) ||
        ( eq1->getEqType() == eqtVeqYZLS) ||
        ( eq1->getEqType() == eqtBackT2Result) 
        ))
        
  {
    PDeductionObject res;
    return res;
  }
    
  // end of restrictions check
  
  Variable c, l, g;
  bool c_sign, l_sign, g_sign;
  if (!eq2->getXeqAB(c, c_sign, l, l_sign, g, g_sign))
  {
    Assert(0, "Bug");
    PDeductionObject res;
    return res;
  }
  PEquality result_eq;
  bool is_fullsubstitution_trace=false;
  if (is_fullsubstitution_trace)
  {
    PPolynomial linear;
    PMonomial square;
    this->getParts(linear, square, eq2);
    result_eq=this->substituteOne(eq1,linear,square);        
  }
  else   
  {
  // now trying to find a monomial lg in the rhs of the first equality
  PPolynomial RHS1 = eq1->getRHS();
  
  PMonomialIterator mon_it = RHS1->getBeginIterator();
  PMonomialIterator end_mon_it = RHS1->getEndIterator();
  
  for (; !mon_it->equals(*end_mon_it); ++*mon_it)
    if ((**mon_it)->getSize() == 2 && abs((**mon_it)->getCoeff()) == 1)
    {
      if ((**mon_it)->contains(l) && (**mon_it)->contains(g))      
      {
        PPolynomial resultLHS = eq1->getLHS()->clone();
        PPolynomial resultRHS = eq1->getRHS()->clone();  
	
	Coefficient c1 = eq2->getRHS()->getCoefficient(**mon_it);
	Coefficient c2 = (**mon_it)->getCoeff();
	
	if (c1 == c2)
	{
	  resultRHS->operator-=(*(eq2->getRHS()));
	  resultRHS->operator+=(*(eq2->getLHS()));
	}
	else
	{
	  resultRHS->operator+=(*(eq2->getRHS()));
	  resultRHS->operator-=(*(eq2->getLHS()));
        }
	result_eq = AlgebraicGenerator::createEquality(resultLHS, resultRHS);
	break;
      }      
   }         
  
  };
  if (!result_eq)
  {
    PDeductionObject res;
    return res;
  };

  if (mySolver->getOptions()->myUseBooth)
  {
    if (eq1->getEqType() != Special && eq1->getEqType() != eqtXeqAB)
    {
      result_eq->setVar1(eq1->getVar1());
      result_eq->setPos1(eq1->getPos1());
      result_eq->setVar2(eq1->getVar2());
      result_eq->setPos2(eq1->getPos2());
      result_eq->setVar3(eq1->getVar3());
      result_eq->setPos3(eq1->getPos3());
      result_eq->setVar4(eq1->getVar4());
      result_eq->setPos4(eq1->getPos4());
      result_eq->setVar5(eq1->getVar5());
      result_eq->setPos5(eq1->getPos5());
      
      if(eq1->getEqType() == eqtVeqYZnotLS || eq1->getEqType() == eqtBackT2Result)
      {
        result_eq->setEqType(eqtBackT2Result);
      }
      else
      {
        result_eq->setEqType(eqtBoothSubResult);
        
        Coefficient coeff = 0;
        result_eq->getRHS()->occursLinear(result_eq->getVar1(),coeff);
        if(std::abs(coeff) == 1)
        {
          *(result_eq->getRHS()) -= *(result_eq->getLHS());
          PMonomial myMonomial = (**(result_eq->getLHS()->getBeginIterator()))->clone();
          myMonomial->substituteEqual(result_eq->getLHS()->getVariable(),result_eq->getVar1());
          myMonomial->setCoeff(-coeff);
          result_eq->getRHS()->addMonomialWithCloning(myMonomial); 
          if(coeff > 0)
          {
            *myMonomial *= -1;
            *(result_eq->getRHS()) *= -1;
          }
          *result_eq->getLHS()-=(*(result_eq->getLHS()->clone()));
          result_eq->getLHS()->addMonomial(myMonomial);
        }
      }
    }
  }
  
  
  PSAClause result_clause = LogicalGenerator::makeSAClause();
  result_clause->add(result_eq);
	return result_clause;

  PDeductionObject res;
  return res;
}

void
BackT2SubstitutionRule::operator()(
DeductionObjectSet* returned_set,
DeductionObjectSet* new_set, 
DeductionObjectSet* old_set,
bool gen_new_vs_new)
{
  // first process the case when the second premise (o=lg)
  // is from new_set
  PDeductionObjectIterator second_pre_it = new_set->getBegin(indXeqAB);
  PDeductionObjectIterator end_second_pre_it = new_set->getEnd(indXeqAB);
  
  for (; !second_pre_it->equals(*end_second_pre_it); ++*second_pre_it)
  {
    Variable l, g, c;
    bool l_sign, g_sign, c_sign;
    (**second_pre_it)->getXeqAB(c, c_sign, l, l_sign, g, g_sign);
    
    // iterating all clauses from new_set and old_set 
    // which contain variable l
    PDeductionObjectIterator first_pre_it = new_set->begin(l);
    if (old_set && !gen_new_vs_new)
      first_pre_it = old_set->begin(l);
    PDeductionObjectIterator old_end;
    if (old_set)
      old_end = old_set->end(l);
    else
      old_end = new_set->end(l);
    PDeductionObjectIterator new_end = new_set->end(l);
    bool first_pre_it_is_in_old = false;
    
    while (!first_pre_it->equals(*old_end))
    {
      if (gen_new_vs_new && first_pre_it->equals(*new_end))
      {
        if (old_set)
        {
          first_pre_it = old_set->begin(l);
          first_pre_it_is_in_old = true;
          continue;
        }
        else
          break;
      }
      PDeductionObject new_obj = (*this)(**first_pre_it, **second_pre_it);
      if (new_obj.get() != 0)
      {
        PDeductionObject premise = **first_pre_it;
        
	bool remove_premise = true;
  
  if((**first_pre_it)->getEqType() == eqtXeqAB)
    remove_premise = false;

	if (remove_premise)
	{
	  if (first_pre_it_is_in_old)
	  {
	    mySolver->getOutput()->printThatRuleDeletedObject(this, &(***first_pre_it), old_set);
            first_pre_it = old_set->remove(first_pre_it);
	  }
          else
	  {
	    mySolver->getOutput()->printThatRuleDeletedObject(this, &(***first_pre_it), new_set);
            first_pre_it = new_set->remove(first_pre_it);
	  }
	}
  else
    ++*first_pre_it;
        
        mySolver->processNewObject(this, new_obj, returned_set, &(*premise), &(***second_pre_it));
      }
      else
        ++*first_pre_it;
    }
    
    mySolver->simplifyAllObjectsByNewModifiers();
  }
  
  // now process the case when the second premise is from old_set
  // (in this case the first premise has to be from new_set!)

  if (old_set)
  {
  
  second_pre_it = old_set->getBegin(indXeqAB);
  end_second_pre_it = old_set->getEnd(indXeqAB);
  
  for (; !second_pre_it->equals(*end_second_pre_it); ++*second_pre_it)
  {
    Variable l, g, c;
    bool l_sign, g_sign, c_sign;
    (**second_pre_it)->getXeqAB(c, c_sign, l, l_sign, g, g_sign);

    // iterating all clauses from new_set and old_set 
    // which contain variable l
    PDeductionObjectIterator first_pre_it = new_set->begin(l);
    PDeductionObjectIterator new_end = new_set->end(l);

    
    while (!first_pre_it->equals(*new_end))
    {
      PDeductionObject new_obj = (*this)(**first_pre_it, **second_pre_it);
      if (new_obj.get() != 0)
      {
        PDeductionObject premise = **first_pre_it;
        bool remove_premise = true;
        
        if((**first_pre_it)->getEqType() == eqtXeqAB)
              remove_premise = false;
        
	 if (remove_premise)
	 {
	   mySolver->getOutput()->printThatRuleDeletedObject(this, &(***first_pre_it), new_set);
	   first_pre_it = new_set->remove(first_pre_it);
	 }	 
         else
	 {
          ++*first_pre_it;
	 }
	
	 mySolver->processNewObject(this, new_obj, returned_set, &(*premise), &(***second_pre_it));
	
      }
      else
        ++*first_pre_it;
    }

  }
    
    mySolver->simplifyAllObjectsByNewModifiers();
  }
}



PEquality BackT2SubstitutionRule::substituteOne(PEquality equality2, PPolynomial linear, PMonomial square)  
{
  PEquality result;
  PPolynomial poly=equality2->getRHS();
  (*poly)-=*(equality2->getLHS());
  PPolynomial quotient=poly->getQuotient(square);
  if (! quotient->getSize())
  {
    (*poly)+=*(equality2->getLHS());
    return result;  
  };    
  PPolynomial remainder=poly->getRemainder(square);      
  (*quotient)*=(*linear);

  (*remainder)+=(*quotient);
  PEquality answer=AlgebraicGenerator::createEquality(AlgebraicGenerator::makePolynomial(), remainder);
  (*poly)+=*(equality2->getLHS());
  return answer;
};

void BackT2SubstitutionRule::getParts(PPolynomial& linear, PMonomial& square, PEquality equality)
{
  linear=equality->getRHS()->clone();
  (*linear)-=*(equality->getLHS());
  PMonomialIterator mon_it=linear->getEndIterator();
  --(*mon_it);
  square=**(mon_it);
  linear->remove(mon_it);
  
  if (square->getCoeff()==1)
  {
    (*linear)*=(-1);
  }
  else 
    square->setCoeff(1);        
};

