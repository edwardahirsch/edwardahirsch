#ifndef __SUBSUMPTION_H__
#define __SUBSUMPTION_H__
#include "../abstract/simplrule.h"
#include "../../algebraic/algebraic.h"
#include "../../general/solver.h"

/**
 * @file subsumption.h
 * @brief contains Subsumption rule implementation
 * @author dmitrits
 */


/**
 * @class SimpleSubsumption
 * @brief Implements subsumption: removes the clauses
 * that are subsets of other clauses.
 *
 * Current implementation requires that the \ref SALiteral
 * in an object are ordered (and, thus, that they can be
 * compared one by one, not as sets).
 */
class SimpleSubsumption : public SimplificationRule
{
public:
  /**
   *  Constructor
   */    
  SimpleSubsumption(BooleanAlgebraicSolver *s):mySolver(s) {};
  
  /// Destructor
  virtual ~SimpleSubsumption() {};
  
  /**
   * Subsumes objects checking only one set against the other
   * and the SECOND set against itself
   */
  void
  operator() (DeductionObjectSet*, DeductionObjectSet*, DeductionObjectSet*, bool gen_new_vs_new);


  std::string getName() const  {return "Subsumption";};

  
private:
  /// Solver
  BooleanAlgebraicSolver *mySolver;
  /**
   * Determines which of the objects subsumes which
   * returns 1 if obj1 subsumes obj2 (including the case when they are equal)
   * returns -1 if obj2 subsumes obj1
   */
  int subsumes(PDeductionObject obj1, PDeductionObject obj2); 
};

#endif
