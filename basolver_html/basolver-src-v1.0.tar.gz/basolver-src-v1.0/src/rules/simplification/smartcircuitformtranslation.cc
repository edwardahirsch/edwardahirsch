#include "smartcircuitformtranslation.h"

/**
 * @file smartcircuitformtranslation.cc
 * @brief implementation for smartcircuitformtranslation.h
 * @author dmitrits
 */




void SmartCircuitFormTranslationRule::myOperator(DeductionObjectSet* returned_set, DeductionObjectSet* newObjSet, DeductionObjectSet* oldObjSet)
{
  result = returned_set;
  myXorDeleteSet=PIEList(new IEList());
  myAndOrDeleteSet=PIEList(new IEList());
  myXorFromWhichSet=PBoolList(new BoolList());
  myAndOrFromWhichSet=PBoolList(new BoolList());

  myInputDedObjSet=oldObjSet;
  myNewDedObjSet=newObjSet;
  PDeductionObjectIterator it=newObjSet->getBeginIteratorOnWholeSet();

  
  // Go through all objects and try start search from them
  myFirstIsNew=true;
  for(;(!(it->equals(*(newObjSet->getEndIteratorOnWholeSet()))));++(*it))
  {
    PSAClause clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(**it);
    if (clause)
    {
      if (clause->isBoolean() && clause->getNumberOfLiterals()==3)
      {
        bool alive= !this->searchForXor(it);
        if (alive)
        { 
          VarList *varList = it->getIE()->getVList();
          for (VarList::iterator vit=varList->begin(); vit!=varList->end();++vit)
          {
            if (alive) alive=! this->searchForAndOr(it, *vit, false);
            if (!alive) break;
          };
        };
      };
    };
  }
  
  // for AND/OR tranformation we are also to start from old set
  it=oldObjSet->getBeginIteratorOnWholeSet();      
  myFirstIsNew=false;
  for(;(!(it->equals(*(oldObjSet->getEndIteratorOnWholeSet()))));++(*it))
  {
    PSAClause clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(**it);
    if (clause)
    {
      if (clause->isBoolean() && clause->getNumberOfLiterals()==3)
      {
        bool alive=true;
        VarList *varList = it->getIE()->getVList();
        for (VarList::iterator vit=varList->begin(); vit!=varList->end();++vit)
        {
          if (alive) alive=! this->searchForAndOr(it, *vit, true);
          if (!alive) break;
        };
      };    
    };        
  }
};

bool SmartCircuitFormTranslationRule::searchForXor(PDeductionObjectIterator first)
{
  myStartIterator=first;
  PSAClause first_clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(**first);
  PClauseList xorList=PClauseList(new ClauseList());
  // We set list of clauses we search for ->xorList
  this->setXorList(xorList, first_clause);
  VarList *vl=first->getIE()->getVList();
  VarList::iterator vit=vl->begin();
  Variable a=*(vit); ++vit;
  Variable b=*(vit); ++vit;
  Variable c=*(vit);

  
  //We search in sets items from xorList. If we find one, delete it from
  // list 
  for (int i=1; i<=2; i++)
  {
    DeductionObjectSet *curset;
    if (i==1) curset=myNewDedObjSet; else curset=myInputDedObjSet;
    PIE ie=curset->getFirstObjectInVars(a,b,c);
    if (ie.get())
    {
      do
      {
        PIE cur=curset->currentObjectInVars();
        PSAClause clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(cur->getObject());
        ClauseList::iterator clit=xorList->begin();
        for(;clit!=xorList->end(); ++clit)
        {
          if (*(*clit)==(*clause))
          {
            xorList->erase(clit);
            myXorDeleteSet->push_back(cur);     	    
	    myXorFromWhichSet->push_back(i==1);     	    
  	    break;
          };      
        };
        if (xorList->empty())
        {
          this->makeXorTransformation();
          return true;
        };
      }
      while (((curset->isLastObjectInVars())));
    };
  };    
  return false;  
};


//Delete clauses (coding a=(1-b)(1-c) ) and make new equality
void
SmartCircuitFormTranslationRule::makeAndOrTransformation()
{
  
  //la=(not lb)*(not lc)
  
  PEquality equality=AlgebraicGenerator::createXeqABEquality(litA->getLHS()->getVariable(),(litA->getRHS()->getFirstConstant()==1),litB->getLHS()->getVariable(),(litB->getRHS()->getFirstConstant()==0),litC->getLHS()->getVariable(),(litC->getRHS()->getFirstConstant()==0));
  PSAClause clause=LogicalGenerator::makeSAClause();
  clause->add(equality);
  IEList::iterator it=myAndOrDeleteSet->begin();      
  Object* obj1=&(*((*it)->getObject())); ++it; 
  Object* obj2=&(*((*it)->getObject())); 
  // mark objects as deleted
  it=myAndOrDeleteSet->begin();  
  BoolList::iterator bi=myAndOrFromWhichSet->begin();   
  bool tempbool = true;
  mySolver->processNewObject(this,clause, result , &(*myStartSearch), obj1,obj2, NULL);      
  for(;it!=myAndOrDeleteSet->end();++it)  
  {
    tempbool = *bi;
    if ((bi != myAndOrFromWhichSet->end()) && (*bi))
      mySolver->getOutput()->printThatRuleDeletedObject(this,&(*((*it)->getObject())),myNewDedObjSet);
    else
      mySolver->getOutput()->printThatRuleDeletedObject(this,&(*((*it)->getObject())),myInputDedObjSet);
    (*it)->eraseFromSet();
    ++bi;
  };
  if (!myFirstIsNew)
  {
    mySolver->getOutput()->printThatRuleDeletedObject(this,&(***myStartIterator),myInputDedObjSet);
    myInputDedObjSet->remove(myStartIterator);
  }
  else 
  {
    mySolver->getOutput()->printThatRuleDeletedObject(this,&(***myStartIterator),myInputDedObjSet);
    myNewDedObjSet->remove(myStartIterator);
  }
};

//a=(1-b)+(1-c)-2(1-b)(1-c)
void
SmartCircuitFormTranslationRule::makeXorTransformation()
{
  IEList::iterator it=myXorDeleteSet->begin();      
  Object* obj1=&(*((*it)->getObject())); ++it; 
  Object* obj2=&(*((*it)->getObject())); ++it; 
  Object* obj3=&(*((*it)->getObject()));
  //add equalities in the new set
  //not la=(not lb)+(not lc) - 2 (not lb) (not lc)
  //not lb=(not la)+(not lc) - 2 (not la) (not lc)
  //not lc=(not lb)+(not la) - 2 (not lb) (not la)

  
  PEquality notLitA=litA->negation();
  PEquality notLitB=litB->negation();
  PEquality notLitC=litC->negation();

  
  //1)not la=(not lb)+(not lc) - 2 (not lb) (not lc)
  
  
  PPolynomial left=notLitA->getPolynomialRepresentation();
  PPolynomial right=notLitB->getPolynomialRepresentation();

  (*right) += (*(notLitC->getPolynomialRepresentation()));
  PPolynomial temp=notLitB->getPolynomialRepresentation();
  (*temp) *= (*(notLitC->getPolynomialRepresentation()));
  (*temp) *= (-2);
  (*right) += (*temp);

  PEquality equality=AlgebraicGenerator::createEquality(left, right);
  PSAClause clause=LogicalGenerator::makeSAClause();
  clause->add(equality);
  it=myXorDeleteSet->begin();  
  BoolList::iterator bi=myXorFromWhichSet->begin();    
  mySolver->processNewObject(this,clause, result , &(*myStartSearch), obj1,obj2, obj3);      
  for(;it!=myXorDeleteSet->end();++it, ++bi)  
  {

    if (*bi)
      mySolver->getOutput()->printThatRuleDeletedObject(this,&(*((*it)->getObject())),myNewDedObjSet);
    else
      mySolver->getOutput()->printThatRuleDeletedObject(this,&(*((*it)->getObject())),myInputDedObjSet);
    (*it)->eraseFromSet();      
  };
  if (!myFirstIsNew)
  {
    mySolver->getOutput()->printThatRuleDeletedObject(this,&(***myStartIterator),myInputDedObjSet);
    myInputDedObjSet->remove(myStartIterator);
  }
  else
  {
   mySolver->getOutput()->printThatRuleDeletedObject(this,&(***myStartIterator),myNewDedObjSet);
   myNewDedObjSet->remove(myStartIterator);
  }; 
};



//set List of xor clauses
void 
SmartCircuitFormTranslationRule::setXorList(PClauseList xorList, PSAClause clause)
{
  myStartSearch=clause;
  myXorDeleteSet->clear();
  myXorFromWhichSet->clear();
  abc=clause;
  SALiteralIterator lits=clause->begin();
  litA=boost::shared_dynamic_cast<Equality,SALiteral>(*lits);
  ++lits;
  litB=boost::shared_dynamic_cast<Equality,SALiteral>(*lits);
  ++lits;
  litC=boost::shared_dynamic_cast<Equality,SALiteral>(*lits);
  PEquality notLitA=(litA->negation());
  PEquality notLitB=(litB->negation());
  PEquality notLitC=(litC->negation());
  anbnc=LogicalGenerator::makeSAClause();
  anbnc->add(litA);  anbnc->add(notLitB); anbnc->add(notLitC);
  nanbc=LogicalGenerator::makeSAClause();
  nanbc->add(notLitA);  nanbc->add(notLitB);  nanbc->add(litC);
  nabnc=LogicalGenerator::makeSAClause();      
  nabnc->add(notLitA);  nabnc->add(litB); nabnc->add(notLitC);
  xorList->push_back(anbnc);  xorList->push_back(nanbc); xorList->push_back(nabnc); 
};


//For and/or
bool SmartCircuitFormTranslationRule::searchForAndOr(PDeductionObjectIterator first,
                                                Variable x, bool need_new_set)
{
  myStartIterator=first;
  PSAClause first_clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(**first);
  PClauseList andOrList=PClauseList(new ClauseList());
  this->setAndOrList(andOrList, first_clause, x);
  VarList *vl = first->getIE()->getVList();
  VarList::iterator vit=vl->begin();
  Variable a=*(vit); ++vit;
  Variable b=*(vit); ++vit;
  Variable c=*(vit);
  bool found=false;
  bool found_first = false;
  bool found_second = false;
  for (int i=1; i<=2; i++)
  {
    DeductionObjectSet *curset;
    if (i==1) curset=myNewDedObjSet; 
    else 
    {
      if (need_new_set && !found) return false;
      curset=myInputDedObjSet;
    };   
    
    PIE ie=curset->getFirstObjectInVars(a,b,c);
    if (ie)
    {
      do
      {
        PIE cur=curset->currentObjectInVars();
        PSAClause clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(cur->getObject());
        if (!found_first && clause->isEqualToNegations(litA,litB))
        {
          myAndOrDeleteSet->push_back(cur);
	  myAndOrFromWhichSet->push_back(i==1);
          found_first = true;
        }

        if (!found_second && clause->isEqualToNegations(litA,litC))
        {
          myAndOrDeleteSet->push_back(cur);
  	  myAndOrFromWhichSet->push_back(i==1);
          found_second = true;
        }
        

        if (found_first && found_second)
        {
          this->makeAndOrTransformation();
          return true;
        };
      }
      while (((curset->isLastObjectInVars())));
    };
  };    
  return false;    
};


//Set and/or list clauses
void 
SmartCircuitFormTranslationRule::setAndOrList(PClauseList andOrList, PSAClause clause, Variable a)
{
  myStartSearch=clause;
  myAndOrDeleteSet->clear();
  myAndOrFromWhichSet->clear();
  abc=clause;
  bool wasB=false;
  SALiteralIterator lits=clause->begin();
  for(;lits!=clause->end();++lits)
  {
    PEquality eq=boost::shared_dynamic_cast<Equality,SALiteral>(*lits); 
    if ((eq->getBooleanVariable())==(a))
    {
      litA=eq;
    }
    else 
    {
      if (!wasB)
      {
        litB=eq; wasB=true;
      }
      else
       litC=eq;    
    };    
  };


  
  

};
