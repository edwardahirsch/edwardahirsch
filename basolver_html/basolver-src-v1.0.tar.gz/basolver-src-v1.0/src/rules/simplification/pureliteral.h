#ifndef __pureliteral_h__
#define __pureliteral_h__
#include "../abstract/simplrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../general/solver.h"

/**
 * @file pureliteral.h
 * Contains PureLiteralRule interface.
 */

/**
 * @class PureLiteralRule
 * @brief Assigns a value True
 * to a pure literal
 * (see documentation for details).
 */
class PureLiteralRule : public SimplificationRule
{
public:
  /// Constructor.
  PureLiteralRule(BooleanAlgebraicSolver* s) : mySolver(s) {};

  virtual void 
  operator() (DeductionObjectSet* returned_set, 
              list<DeductionObjectSet*> ded_list);


  virtual std::string getName() const {return "Pure Literal Rule";};

private:  
  /// Reference to the solver.
  BooleanAlgebraicSolver* mySolver;
  
  /// Checks whether an input variable occurs
  /// only in Boolean clauses and always with the same sign.
  /// Notation:
  ///  0 -- var appears only in Boolean clauses and only negatively
  ///  1 --                                              positively
  /// -1 -- var either appears in a non-Boolean clause or appears with different signs
  /// -2 -- var does not appear in a set
  int
  getSign(DeductionObjectSet* set, Variable var);
};

#endif



