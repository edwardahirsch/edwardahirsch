#include "monomialsubstitutionrule.h"

/**
 * @file monomialsubstitutionrule.cc
 * @brief implementation for monomialsubstitutionrule.h
 * @author dmitrits
 */



void
MonomialSubstitutionRule::operator()(DeductionObjectSet *returned_set, 
	     DeductionObjectSet  *new_set, 
	     DeductionObjectSet  *old_set, bool gen_new_vs_new)
{
  PDeductionObjectIterator it_new=new_set->getBegin(indABeq0);
  PDeductionObjectIterator end_new=new_set->getEnd(indABeq0);
  for (;!it_new->equals(*end_new);++(*it_new))
  {
    PSAClause clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(**it_new);
    if (!clause || clause->getNumberOfLiterals()!=1)
      continue;
    PEquality equality=clause->getEquality();
    if ((equality)->getEqType()==eqtABeq0)
    {  
      Variable index_var=equality->getVar1();
      PPolynomial linear;
      PMonomial square;
      //find square monomial and linear part
      this->getParts(linear, square, equality);
      for (int i=0; i<2;i++)
      {
        if ((i==0) && (!gen_new_vs_new)) continue;
        DeductionObjectSet* cur_set=((i==0)? new_set : old_set);
        PDeductionObjectIterator it2=cur_set->begin(index_var); //AB=0 index expected
        PDeductionObjectIterator end2=cur_set->end(index_var); //AB=0 index expected
        while (!it2->equals(*end2))
        {
          if ((**it2)->getId()!=(**it_new)->getId())
          { 
            PDeductionObject ded_obj2=(**it2);
            PDeductionObject obj=substituteOne(boost::shared_dynamic_cast<SAClause, DeductionObject>(ded_obj2), linear, square);
            if (obj.get()!=0)
            {
              mySolver->getOutput()->printThatRuleDeletedObject(this, &(*ded_obj2), cur_set);	      
              mySolver->processNewObject(this, obj, returned_set, &(***it_new), &(*ded_obj2),NULL, NULL);      
              it2=cur_set->remove(it2);
            }
            else
              ++(*it2);
          }
          else
            ++(*it2);
        };
      };  
    };
    mySolver->simplifyAllObjectsByNewModifiers();
  };
}	     


//Substitute in clause linear instead of square 
PDeductionObject MonomialSubstitutionRule::substituteOne(PSAClause clause, PPolynomial linear, PMonomial square)  
{
  PSAClause result;
  PEquality equality2=clause->getEquality();      
  PPolynomial poly=equality2->getRHS();
  (*poly)-=*(equality2->getLHS());
  PPolynomial quotient=poly->getQuotient(square);
  if (! quotient->getSize())
  {
    (*poly)+=*(equality2->getLHS());
    return result;  
  };    
  PPolynomial remainder=poly->getRemainder(square);      
  (*quotient)*=(*linear);

  (*remainder)+=(*quotient);
  PEquality answer=AlgebraicGenerator::createEquality(AlgebraicGenerator::makePolynomial(), remainder);
  result=LogicalGenerator::makeSAClause();
  result->add(answer);
  (*poly)+=*(equality2->getLHS());
  return result;
};

void MonomialSubstitutionRule::getParts(PPolynomial& linear, PMonomial& square, PEquality equality)
{
  linear=equality->getRHS()->clone();
  (*linear)-=*(equality->getLHS());
  PMonomialIterator mon_it=linear->getEndIterator();
  --(*mon_it);
  square=**(mon_it);
  linear->remove(mon_it);
  
  if (square->getCoeff()==1)
  {
    (*linear)*=(-1);
  }
  else 
    square->setCoeff(1);        
};




