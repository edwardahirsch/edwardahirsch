#ifndef __backt2subst_h__
#define __backt2subst_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../general/solver.h"

/**
 * @@file backt2subst.h
 * Contains BackT2SubstitutionRule interface.
 */

/**
 * @@class BackT2SubstitutionRule
 * @@brief Implements Back T2 Substitution Rule
 * (see documentation for details)
 */
class BackT2SubstitutionRule: public SimplificationRule
{
public:
  /// Constructor.
  BackT2SubstitutionRule(BooleanAlgebraicSolver* s) : mySolver(s) {};

  virtual void 
  operator() (DeductionObjectSet* returned_set, 
              DeductionObjectSet* new_set, 
	      DeductionObjectSet* old_set,
        bool gen_new_vs_new);

  virtual std::string
  getName() const {return "Back And Substitution Rule";};
  
private:  
  /// Given a clause c=lg as a second parameter,
  /// returns a clause o=c+S if 
  /// the first parameter is of the form 
  /// o=lg+S, c=lg, where l, g are literals.
  /// Otherwise returns an empty pointer.
  PDeductionObject
  operator() (PDeductionObject obj1, PDeductionObject obj2);

  /**
   * Substitute one equality in one clause
   */    
  PEquality substituteOne(PEquality equality, PPolynomial linear, PMonomial square);
  
  /// Returns linear and square parts of equality
  void getParts(PPolynomial& linear, PMonomial& square, PEquality equality);

  
  /// Reference to the solver.
  BooleanAlgebraicSolver* mySolver;
};
#endif



