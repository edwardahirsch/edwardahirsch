#ifndef __lin3rule_h__
#define __lin3rule_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../general/solver.h"

/**
 * @file lin3rule.h
 * @author sergey
 * @brief Contains implementation of Lin3Rule class
 */

/**
 * @class Lin3Rule
 * @brief implements Linearization3Rule
 * (see documentation for details)
 */
class Lin3Rule: public SimplificationRule
{
public:
  /// Constructor.
  Lin3Rule(BooleanAlgebraicSolver* s) : mySolver(s) {};

  /**
   * Generates an object from two given objects.
   * Currently returns an empty object.
   */  
  virtual PDeductionObject
  operator() (const PDeductionObject&, const PDeductionObject&) const
  {
    PDeductionObject obj;
    return obj;
  };

  /**
   * Generates from newset and set, puts into returned_set;
   * if (use_new_only) does not check set vs set
   * if (gen_new_vs_new) checks newset vs newset
   */
  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* dedset, DeductionObjectSet* newset, bool use_new_obj, bool gen_new_vs_new) const;
  virtual void operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set, DeductionObjectSet* old_set, bool gen_new_vs_new)
  {
    (*this)(returned_set,old_set,new_set,true,gen_new_vs_new);
  }
  
  std::string getName() const {return "Lin3Rule";};

private:
  /**
   * Creates the resulting equality with given variables
   * and adds it to the given set
   */
  void createResult(Variable a,bool pa,Variable b, bool pb, Variable c, bool pc, Variable x, bool px, Variable y, bool wc2, DeductionObjectSet* result_set, PDeductionObject premise1, PDeductionObject premise2) const;
  
  /// Link to the solver.
  BooleanAlgebraicSolver* mySolver; 
};
#endif

