#include "binclproc4.h"
#include "backtrack/simplelogentry.h"

/**
 * @file binclproc4.cc
 * @brief implementation for binclproc4.h
 * @author kulikov
 */
 

BinaryClausesProcessing4Rule::BinaryClausesProcessing4Rule(BooleanAlgebraicSolver* s)
{
  mySolver = s;
  myAddBinaryResolvents = false;
}

BinaryClausesProcessing4Rule::~BinaryClausesProcessing4Rule()
{
  myTempAssignment.clear();
}


void
BinaryClausesProcessing4Rule::operator() (
  DeductionObjectSet* returned_set,
  DeductionObjectSet* new_set,
  DeductionObjectSet* old_set,
  bool gen_new_vs_new)
{
  if (new_set->getSize() == 0)
    return;
    
  // first we deduce all unit resolvents of binary clauses    
  // in case a unit resolvent is created both premises are eliminated
  
  bool new_obj_generated;
  
  // old vs new
  PDeductionObjectIterator first_pre_it = new_set->getBegin(indTwoClauses);
  PDeductionObjectIterator first_end = new_set->getEnd(indTwoClauses);
  
  while (!first_pre_it->equals(*first_end))
  {
    new_obj_generated = false;
    PDeductionObjectIterator second_pre_it = old_set->getBegin(indTwoClauses);
    PDeductionObjectIterator second_end = old_set->getEnd(indTwoClauses);
    
    while (!second_pre_it->equals(*second_end))
    {
      PDeductionObject obj = this->createUnitResolvent(**first_pre_it, **second_pre_it);
      if (obj.get())
      {
        PDeductionObject first_pre = **first_pre_it;
	PDeductionObject second_pre = **second_pre_it;
	if (this->myNewClauseLength == 1)
	{
          mySolver->getOutput()->printThatRuleDeletedObject(this, &(***first_pre_it), new_set);
	  mySolver->getOutput()->printThatRuleDeletedObject(this, &(***second_pre_it), old_set);
          old_set->remove(second_pre_it);
	  first_pre_it = new_set->remove(first_pre_it);
	  new_obj_generated = true;
	}
        
	mySolver->processNewObject(this, obj, returned_set, &(*first_pre), &(*second_pre), NULL, NULL);
	
	if (new_obj_generated)
	  break;
      }
      ++*second_pre_it;
    }
    
    mySolver->simplifyAllObjectsByNewModifiers();
    
    if (!new_obj_generated)
      ++*first_pre_it;
  }
  
  // new vs new
  if (gen_new_vs_new)
  {
  PDeductionObjectIterator first_pre_it = new_set->getBegin(indTwoClauses);
  PDeductionObjectIterator first_end = new_set->getEnd(indTwoClauses);
  
  while (!first_pre_it->equals(*first_end))
  {
    PDeductionObjectIterator second_pre_it = first_pre_it->clone();
    ++*second_pre_it;
    PDeductionObjectIterator second_end = new_set->getEnd(indTwoClauses);
    new_obj_generated = false;
    
    while (!second_pre_it->equals(*second_end))
    {
      PDeductionObject obj = this->createUnitResolvent(**first_pre_it, **second_pre_it);
      if (obj.get())
      {
        PDeductionObject first_pre = **first_pre_it;
	PDeductionObject second_pre = **second_pre_it;
	if (this->myNewClauseLength == 1)
	{
          mySolver->getOutput()->printThatRuleDeletedObject(this, &(***first_pre_it), new_set);
	  mySolver->getOutput()->printThatRuleDeletedObject(this, &(***second_pre_it), new_set);
          new_set->remove(second_pre_it);
	  first_pre_it = new_set->remove(first_pre_it);
	  new_obj_generated = true;
	}
        
	mySolver->processNewObject(this, obj, returned_set, &(*first_pre), &(*second_pre), NULL, NULL);
	
	if (new_obj_generated)
	  break;
      }
      ++*second_pre_it;
    }
    
    mySolver->simplifyAllObjectsByNewModifiers();
    
    if (!new_obj_generated)
      ++*first_pre_it;
  }
  }
  
  // now we try to deduce something by assigning values 
  // to one of the literals of a new clause
  bool smart_deduce = true;
  
  if (!smart_deduce)
    return;
    
  // initializing structures
  myCurrentTime = 0;
  myTempAssignment.clear();
  
  PDeductionObjectIterator new_bin_clause_it = new_set->getBegin(indTwoClauses);
  PDeductionObjectIterator new_bin_end = new_set->getEnd(indTwoClauses);
  
  while (!new_bin_clause_it->equals(*new_bin_end))
  {
    myCurrentTime++;
    
    int lit1, lit2;
    (**new_bin_clause_it)->getBinaryClauseLiterals(lit1, lit2);
    
    map<long, pair<bool, long> >::iterator it1 = myTempAssignment.find(abs(lit1));
    map<long, pair<bool, long> >::iterator it2 = myTempAssignment.find(abs(lit2));
    
    if (!((it1 != myTempAssignment.end() && (*it1).second.first == (lit1 > 0)) ||
          (it2 != myTempAssignment.end() && (*it2).second.first == (lit2 > 0))))
    {
      this->myNewObjectWasGenerated = false;
      this->tempAddNewUnitClause(returned_set, new_set, old_set, lit1);
      if (this->myNewObjectWasGenerated)
        mySolver->simplifyAllObjectsByNewModifiers();
    }
	  
    ++*new_bin_clause_it;
  }
  
  return;
}; // operator()

void
BinaryClausesProcessing4Rule::tempAddNewUnitClause(
  DeductionObjectSet* returned_set,
  DeductionObjectSet* new_set,
  DeductionObjectSet* old_set,
  int lit)
{
  if (myNewObjectWasGenerated)
    return;
    

  map<long, pair<bool, long> >::iterator it = myTempAssignment.find(abs(lit));
  
  if (it != myTempAssignment.end() && (*it).second.first != (lit > 0) && (*it).second.second == this->myCurrentTime)
  // conflict deduced
  {

    //std::cout << "\nNon-trivial conflict deduced!";
    PSAClause cl = LogicalGenerator::makeSAClause();
    cl->add(LogicalGenerator::makeBoolLiteral(abs(lit), lit > 0));
    mySolver->processNewObject(this, cl, returned_set, NULL, NULL, NULL, NULL);
    this->myNewObjectWasGenerated = true;
    return;
  }
  
  pair<bool, long> sign_and_time = make_pair((lit > 0), this->myCurrentTime);
  if (it != myTempAssignment.end())
    (*it).second = sign_and_time;
  else
    myTempAssignment.insert(make_pair(abs(lit), sign_and_time));
  
  
  PDeductionObjectIterator d_it = old_set->getBegin(indTwoClauses);;
  PDeductionObjectIterator new_end = new_set->getEnd(indTwoClauses);;
  PDeductionObjectIterator old_end = old_set->getEnd(indTwoClauses);;
  
  
  while (!d_it->equals(*new_end))
  {
    if (d_it->equals(*old_end))
    {
      d_it = new_set->getBegin(indTwoClauses);
      continue;  
    }
    
    int lit1, lit2;
    (**d_it)->getBinaryClauseLiterals(lit1, lit2);
    Assert(lit1 != lit2, "Bug");
    if (lit1 == -lit || lit2 == -lit)
    {
      if (lit2 == -lit)
      {
        int temp = lit2;
	lit2 = lit1;
	lit1 = temp;
      }
      // now lit1 = -lit
      
      map<long, pair<bool, long> >::iterator it1 = myTempAssignment.find(abs(lit2));
      if (it1 == myTempAssignment.end() || (*it1).second.first != (lit2 > 0))
        this->tempAddNewUnitClause(returned_set, new_set, old_set, lit2);
    }

    ++*d_it;    
  }
  
  return;
}

void BinaryClausesProcessing4Rule::debugPrint() const
{
  std::cerr << "\n\n-------------------------------------------";
  std::cerr << "\ntime = " << this->myCurrentTime;
  std::cerr << "\nTempAssignment: ";
  map<long, pair<bool, long> >::const_iterator it = myTempAssignment.begin(); 
  for (; it != myTempAssignment.end(); it++)
    std::cerr << "\n\t var = " << ((*it).first)*((*it).second.first ? 1 : -1) << " time = " << (*it).second.second;
  std::cerr << "\nNewBinClauses: ";
  std::cerr << "\n--------------------------------------------\n\n";
}

PDeductionObject
BinaryClausesProcessing4Rule::createUnitResolvent(
  PDeductionObject obj1, 
  PDeductionObject obj2)
{
    this->myNewClauseLength = 0;
    
    int lit1, lit2;
    int x, y;
    obj1->getBinaryClauseLiterals(lit1, lit2);
    obj2->getBinaryClauseLiterals(x, y);

    Assert(lit1 != lit2, "Bug");
    Assert(x != y, "Bug");
    if (lit1 == x && lit2 == y)
      return PDeductionObject();
      
    if (lit1 == y && lit2 == x)
      return PDeductionObject();
    
    // (x y) (-y w) -> (x w)
    if (lit1 == -y || lit2 == -y)
    {
      int w = (lit1 == -y) ? lit2 : lit1;

      
      if ((!this->myAddBinaryResolvents && w == x) || (this->myAddBinaryResolvents && w != -x))
      {
      if (w == x)
        this->myNewClauseLength = 1;
      else
        this->myNewClauseLength = 2;
      
      PSAClause cl = LogicalGenerator::makeSAClause();
      cl->add(LogicalGenerator::makeBoolLiteral(abs(x), x > 0));
      cl->add(LogicalGenerator::makeBoolLiteral(abs(w), w > 0));
      return cl;
      }
    }

    // (x y) (-x w) -> (y w)
    if (lit1 == -x || lit2 == -x)
    {
      int w = (lit1 == -x) ? lit2 : lit1;
      if ((!this->myAddBinaryResolvents && w == y) || (this->myAddBinaryResolvents && w != -y))
      {
      if (w == y)
        this->myNewClauseLength = 1;
      else
        this->myNewClauseLength = 2;
      PSAClause cl = LogicalGenerator::makeSAClause();
      cl->add(LogicalGenerator::makeBoolLiteral(abs(y), y > 0));
      cl->add(LogicalGenerator::makeBoolLiteral(abs(w), w > 0));
      return cl;
      }
    }
    
    // (x y) (-x -y) -> x+y=1
    if ((lit1 == -x && lit2 == -y) || (lit1 == -y && lit2 == -x))
    {
      this->myNewClauseLength = 1;
      PSAClause cl = LogicalGenerator::makeSAClause();
      PPolynomial lhs = AlgebraicGenerator::makePolynomial();
      PMonomial x_mon = AlgebraicGenerator::makeMonomial(abs(x));
      PMonomial y_mon = AlgebraicGenerator::makeMonomial(abs(y));
      if (x < 0)
      {
        x_mon->setCoeff(-1);
	lhs->addMonomial(x_mon);
	lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
      {
        lhs->addMonomial(x_mon);
      }

      if (y < 0)
      {
        y_mon->setCoeff(-1);
	lhs->addMonomial(y_mon);
	lhs->addMonomial(AlgebraicGenerator::makeMonomial());
      }
      else
      {
        lhs->addMonomial(y_mon);
      }

      PPolynomial rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial());
      PEquality eq = AlgebraicGenerator::makeEqualityWithCloning(lhs, rhs);
      cl->add(eq);
      return cl;
    }
    
    return PDeductionObject();
}



