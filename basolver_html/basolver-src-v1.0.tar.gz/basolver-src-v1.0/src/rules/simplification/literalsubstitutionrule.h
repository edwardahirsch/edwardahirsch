#ifndef __LITERALSUBSTITUTIONRULT_H__
#define __LITERALSUBSTITUTIONRULT_H__

#include "../abstract/simplrule.h"
#include "../../basicobject/simpleobjectset.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../misc/output.h"

/**
 * @class LiteralSubstitutionRule
 * @brief implements the LiteralSubstitutionRule
 * (see documentation for details)
 */
class LiteralSubstitutionRule: public SimplificationRule
{
public:
  /**
   *  Constructor
   */    
  LiteralSubstitutionRule(BooleanAlgebraicSolver* s): mySolver(s){};
  
  /**
   * This interface tries to simplify a deduction object by a modification object
   */
  PDeductionObject
  operator() (PDeductionObject dedObj,   PModificationObject modObj)  ; 

  /**
   * This interface tries to simplify a modification object by a modification object
   */
  PDeductionObject
  operator() (  PModificationObject underModification,   PModificationObject modifier)  ;
  
  std::string getName() const {return "LiteralSubstitutionRule";};

  void operator() (
  DeductionObjectSet* returned_set,
  DeductionObjectSet* input_ded_obj_set, 
    ModificationObjectSet* input_mod_obj_set)  ;

  void
  operator() (
  DeductionObjectSet* returned_set,
  ModificationObjectSet* under_mod_obj_set, 
      ModificationObjectSet* input_mod_obj_set, bool gen_new_vs_new)  ;
  
private:
  /**
   * Simplifys one clause by meens of one equality
   */    
  
  void substituteOne(PSAClause clause,   PEquality equality)  ;
  
  /// Reference to the solver.
  BooleanAlgebraicSolver *mySolver;         
};




#endif
