#include "strongnormalizerule.h"
#include "literalsubstitutionrule.h"
#include "logical/implementation/simpleassignment.h"

/**
 * @file strongnormalizerule.cc
 * @brief implementation for strongnormalizerule.h
 * @author dmitrits
 */



StrongNormalizeRule::StrongNormalizeRule(BooleanAlgebraicSolver* s)
{
  mySolver = s;
  myLitSubstRule = new LiteralSubstitutionRule(s);
}

StrongNormalizeRule::~StrongNormalizeRule()
{
  delete myLitSubstRule;
}

void 
StrongNormalizeRule::operator() 
(DeductionObjectSet* returned_set, DeductionObjectSet* new_set)
{
  PDeductionObjectIterator it=new_set->getBeginIteratorOnWholeSet();
  PDeductionObjectIterator end=new_set->getEndIteratorOnWholeSet();
  while (! it->equals(*end))
  {
    PSAClause clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(**it);
    if (!clause || clause->getNumberOfLiterals()!=1)
    {
      ++(*it);
      continue;
    };    
    PEquality equality=clause->getEquality();
    
    PPolynomial even;
    PPolynomial poly;

    poly=equality->getRHS();
    
    *poly-=(*equality->getLHS());
    Variable a, b;
    bool posa, posb;
    long ub=poly->getUpperBound();
    long lb=poly->getLowerBound();
    // Rule 1.
    // if poly=0 and poly>=lb>0 --> contradiction
    // if poly=0 and poly<=ub<0 --> contradiction
    if ((ub<0) || (lb>0))
    {
      PEquality eq=AlgebraicGenerator::makeEqualityWithCloning(
               AlgebraicGenerator::makePolynomial(),
	       AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial()));
      PSAClause clause=LogicalGenerator::makeSAClause();	       
      clause->add(eq);
      PDeductionObject premise = **it;
      it = new_set->remove(it);
      mySolver->processNewObject(this, clause, returned_set, &(*premise), 0, 0, 0, "part1");	
      (*poly)+=*(equality->getLHS());
      mySolver->getOutput()->printThatRuleDeletedObject(this,&(*premise),new_set);
      continue;
    };
    // Rule 2.
    // if poly=0 and poly>=lb=0 => All monomials should be minimal
    if (((poly->getSize()>2) || (poly->getSize()==2 && 
       !(**(poly->getBeginIterator()))->isConstant())) &&
    ((ub==0) || (lb==0)))
    {
      bool is_lower=(lb==0);
      PDeductionObject premise = **it;
      mySolver->getOutput()->printThatRuleDeletedObject(this,&(*premise),new_set);
      it = new_set->remove(it);
      PMonomialIterator mon_it=poly->getBeginIterator();
      PMonomialIterator mon_end=poly->getEndIterator();
      for (;!mon_it->equals(*mon_end);++(*mon_it))
      {
        PEquality eq;
	if (!(**mon_it)->isConstant())
	{
   	  if ((is_lower && ((**mon_it)->getCoeff()>0)) ||
	     (!is_lower && ((**mon_it)->getCoeff()<0)))                    
	  {
	    eq=AlgebraicGenerator::makeEqualityWithCloning(
              AlgebraicGenerator::makePolynomial(),
              AlgebraicGenerator::makePolynomial(**mon_it));
	  }  
	  else  
	  {
	    PMonomial left=AlgebraicGenerator::makeMonomial();
	    left->setCoeff((**mon_it)->getCoeff());
	    eq=AlgebraicGenerator::makeEqualityWithCloning(
              AlgebraicGenerator::makePolynomial(left),
              AlgebraicGenerator::makePolynomial(**mon_it));	    
          };
          PSAClause clause=LogicalGenerator::makeSAClause();	       
          clause->add(eq);
	   mySolver->getNewNewObjects()->add(clause);     
	}
      };
      (*poly)+=*(equality->getLHS());
      mySolver->processNewObjects(this, returned_set, &(*premise), 0, 0, 0, "part2");
      continue;
    };
    //Rule 3.
    // if poly=A+B-2S --->  A=B, A=S
    if (poly->parseAplusB(a, posa, b, posb, even))
    {
      PEquality first;
      PEquality second;
      if (posa==posb)
      {
        first=AlgebraicGenerator::createEquality(
  	 AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(a)),
	 AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(b)));
	PMonomial left=AlgebraicGenerator::makeMonomial(a); left->setCoeff(2);
	second=AlgebraicGenerator::createEquality(AlgebraicGenerator::makePolynomial(left), even);
      }
      else
      {
        PPolynomial right=AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(b));
	*right*=(-1);
	right->addMonomial(AlgebraicGenerator::makeMonomial());
	first=AlgebraicGenerator::createEquality(
  	 AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(a)),
	 right);
	 PMonomial left; 
	if (posa)
	  {left=AlgebraicGenerator::makeMonomial(a); left->setCoeff(2);}	  
	else   
	  {left=AlgebraicGenerator::makeMonomial(b); left->setCoeff(2);}
	second=AlgebraicGenerator::createEquality(AlgebraicGenerator::makePolynomial(left), even);
      };
      PSAClause firstClause=LogicalGenerator::makeSAClause();
      PSAClause secondClause=LogicalGenerator::makeSAClause();
      firstClause->add(first);
      secondClause->add(second);
      PDeductionObject premise = **it;
      mySolver->getOutput()->printThatRuleDeletedObject(this,&(*premise),new_set);
      it = new_set->remove(it);
      (*poly)+=*(equality->getLHS());
      mySolver->getNewNewObjects()->add(firstClause);
      mySolver->getNewNewObjects()->add(secondClause);
      mySolver->processNewObjects(this, returned_set, &(*premise), 0, 0, 0, "part3");
      continue;
    };

    (*poly)+=*(equality->getLHS());        
    {
      if ((!equality) || (! equality->getLHS()->isVariable()))
      {
        ++(*it);
        continue;
      };
    
      PPolynomial odd=equality->getRHS()->getOddPart();
      if (odd->getSize()==equality->getRHS()->getSize())
      {
        ++(*it);
        continue;
      };
      if((**equality->getLHS()->getBeginIterator())->getCoeff()!=1)
      {
        ++(*it);
        continue;
      }
      //Rule 4.
      //a=b+2S --> a=b
      //a=2S -->   a=0
      //a=2S+1 --> a=1
      if ((odd->getSize()==0) || (odd->isLiteral()) || ((odd->isConstant())))
      {
        PSAClause firstClause=LogicalGenerator::makeSAClause();
        PPolynomial even=equality->getRHS()->getEvenPart();
        if (odd->getSize()==0)
        {
          firstClause->add(LogicalGenerator::makeBoolLiteral(equality->getLHS()->getVariable(),0));
        }
        else if ((odd->isConstant()))
        {
          firstClause->add(LogicalGenerator::makeBoolLiteral(equality->getLHS()->getVariable(),1));        
    	  (*even)+=(odd->getFirstConstant()-1);
        }
        else
        {
            firstClause->add(AlgebraicGenerator::createEquality(equality->getLHS(),odd));
        };
        PSAClause secondClause=LogicalGenerator::makeSAClause();
        secondClause->add(AlgebraicGenerator::createEquality(AlgebraicGenerator::makePolynomial(), even));
        
        PDeductionObject premise = **it;
	mySolver->getOutput()->printThatRuleDeletedObject(this,&(*premise),new_set);
        it = new_set->remove(it);
        mySolver->getNewNewObjects()->add(firstClause);
        mySolver->getNewNewObjects()->add(secondClause);
        mySolver->processNewObjects(this, returned_set, &(*premise), 0, 0, 0, "part4");
      }
      else
        ++(*it);
    }  
  };
  
  bool use_part5 = false;
  bool use_part6 = true;
  
  //Rule 5.
  // now process objects of type xy=1 and 1-x=xy
  if (use_part5)
  {
  PDeductionObjectIterator d2eit = new_set->getBeginIteratorOnWholeSet();
  PDeductionObjectIterator d2eit_end = new_set->getEndIteratorOnWholeSet();
  
  while (!d2eit->equals(*d2eit_end))
  {
    PSAClause clause = boost::shared_dynamic_cast<SAClause, DeductionObject>(**d2eit);    
    Assert(clause, "");
    
    if (clause->getNumberOfLiterals() > 1)
    {
      ++*d2eit;
      continue;
    }
    
    PEquality equality = clause->getEquality();
    
    Variable x, y, z;
    bool x_sign, y_sign, z_sign;
    
    if (equality->getEqType() == Special &&
      equality->isXYeq1(x, x_sign, y, y_sign))
      {
        PDeductionObject pre = **d2eit;
	 mySolver->getOutput()->printThatRuleDeletedObject(this,&(*pre),new_set);
        d2eit = new_set->remove(d2eit);
    
        PSAClause xcl = LogicalGenerator::makeSAClause();
        xcl->add(LogicalGenerator::makeBoolLiteral(x, x_sign));

        PSAClause ycl = LogicalGenerator::makeSAClause();
        ycl->add(LogicalGenerator::makeBoolLiteral(y, y_sign));
	
        mySolver->getNewNewObjects()->add(xcl);
        mySolver->getNewNewObjects()->add(ycl);
        mySolver->processNewObjects(this, returned_set, &(*pre), 0, 0, 0, "part5");	
//        mySolver->simplifyAllObjectsByNewModifiers();
      }
      else
      {
        if (equality->getXeqAB(x, x_sign, y, y_sign, z, z_sign) && 
	((x==y && x_sign!=y_sign) || (x==z && x_sign!=z_sign)))
	{
          PDeductionObject pre = **d2eit;
	  mySolver->getOutput()->printThatRuleDeletedObject(this,&(*pre),new_set);
          d2eit = new_set->remove(d2eit);
	  
	  if (x == z)
	  {
	    Variable temp = y;
	    bool temp_sign = y_sign;
	    y = z;
	    y_sign = z_sign;
	    z = temp;
	    z_sign = temp_sign;
	  }
	  
	  // so, now x==y
	  
          PSAClause xcl = LogicalGenerator::makeSAClause();
          xcl->add(LogicalGenerator::makeBoolLiteral(x, !x_sign));
          PSAClause zcl = LogicalGenerator::makeSAClause();
          zcl->add(LogicalGenerator::makeBoolLiteral(z, !z_sign));
	  mySolver->getNewNewObjects()->add(xcl);	  
	  mySolver->getNewNewObjects()->add(zcl);
          mySolver->processNewObjects(this, returned_set, &(*pre), 0, 0, 0, "part5");	
	}
        else
          ++*d2eit;
      }
  } //part 5
  } // if (use_part5)
  
  
  
  // Part 6.   
  // Check whether we can deduce 
  // something from an equality 
  // just by assigning values to its variables.
  if (use_part6)
  {
  PDeductionObjectIterator myit = new_set->getBeginIteratorOnWholeSet();
  PDeductionObjectIterator myend = new_set->getEndIteratorOnWholeSet();
  while (!myit->equals(*myend))
  {
    PSAClause clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(**myit);
    if (!clause || clause->getNumberOfLiterals()!=1)
    {
      ++*myit;
      continue;
    }
    PEquality equality=clause->getEquality();
    
    
    bool can_be_simplified = false;
    
    PVarList var_list = equality->getVariableList();
    
    // check restrictions
    bool all_restrictions_satisfied = true;
    
    // do not process equality if it has more than 3 variables
    if (var_list->size() > 3 || var_list->size() < 2)
      all_restrictions_satisfied = false;
      
    // do not process equality if it is of the form x=1-y
    if (var_list->size() == 2 && equality->getLHS()->isVariable() && equality->getRHS()->getFreeCoefficient() == 1 && equality->getRHS()->getDegree() == 1)
      all_restrictions_satisfied = false;
      
    // do not process equality if it contains only one variable
    if (var_list->size() == 1)
      all_restrictions_satisfied = false;
      
    // do not process equality if it is of the form x=y
    if (var_list->size() == 2 && equality->getLHS()->isVariable() && equality->getRHS()->isVariable())
      all_restrictions_satisfied = false;
    
    if (all_restrictions_satisfied)
    {
      std::list<Variable>::iterator varit = var_list->begin();
      std::list<Variable>::iterator varitend = var_list->end();
      
      Assignment* A = new SimpleAssignment();
      std::list<Assignment*> sat_assignments;
      for (; varit != varitend; varit++)
        A->addLiteral(*varit, false);
	
      A->setToFirst();
      
      // finding all satisfying assignments for this equality
      do
      {
        if (equality->isSatisfiedBy(A))
          sat_assignments.push_back(A->clone());
        A->setToNext();
      }
      while (!A->isEndAssignment());
      
      delete A;
      
      if (sat_assignments.size() == 0)
      // this equality is contradictory
      {
        PSAClause cl = LogicalGenerator::makeSAClause();
        PPolynomial rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial());
        PPolynomial lhs = AlgebraicGenerator::makePolynomial();
        cl->add(AlgebraicGenerator::createEquality(rhs, lhs));
        mySolver->processNewObject(this, cl, returned_set, &(***myit), 0, 0, 0, "part6");	
        return;
      }
      
      PEquality result_eq;
      
      // if all satisfying assignments assign the same value to a variable
      // we create a corresponding equality
      varit = var_list->begin();
      varitend = var_list->end();
      
      for (; varit != varitend; varit++)
      {
        int first_value = -1;
	bool same_value = true;
	
	std::list<Assignment*>::iterator a_it = sat_assignments.begin();
	std::list<Assignment*>::iterator a_end = sat_assignments.end();
	
	for (; a_it != a_end; a_it++)
	{
	  int cur_value = (*a_it)->getValue(*varit);
	  if (first_value == -1)
	  {   first_value = cur_value; }
	  else
	  {
	    if (first_value != cur_value)
	    {
	      same_value = false;
	      break;
	    }
	  }
	}
	
	if (same_value)
	{
	  can_be_simplified = true;
	  PPolynomial lhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(*varit));
	  PPolynomial rhs;
	  if (!first_value)
	    rhs = AlgebraicGenerator::makePolynomial();
	  else
	    rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial());
	  result_eq = AlgebraicGenerator::createEquality(lhs, rhs);
	  break;
	}
      }
      
      // if literals x and y are always assigned the same values 
      // in an assignment we create an equality x=y
      if (!can_be_simplified)
      {
        std::list<Variable>::iterator varit1 = var_list->begin();
        std::list<Variable>::iterator varitend = var_list->end();
	
	for (; varit1 != varitend && !can_be_simplified; varit1++)
	{
          std::list<Variable>::iterator varit2 = varit1;
          varit2++;
	  
	  for (; varit2 != varitend && !can_be_simplified; varit2++)
	  {
            int first_value = -1;
    	    bool same_value = true;
	
	    std::list<Assignment*>::iterator a_it = sat_assignments.begin();
	    std::list<Assignment*>::iterator a_end = sat_assignments.end();
	
	    for (; a_it != a_end; a_it++)
	    {
	      int var1val = (*a_it)->getValue(*varit1);
	      int var2val = (*a_it)->getValue(*varit2);
	      int cur_val = (var1val == var2val);
	      
	      if (first_value == -1)
	      {   first_value = cur_val; }
	      else
	      {
	        if (first_value != cur_val)
	        {
	          same_value = false;
	          break;
	        }
	      }
	    }

 	    if (same_value)
	    {
	      can_be_simplified = true;
	      if (first_value)
	      {
        	PPolynomial lhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(*varit1));
          PPolynomial rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(*varit2));
          result_eq = AlgebraicGenerator::createEquality(lhs, rhs);
	      }
	      else
	      {
          PMonomial mon1 = AlgebraicGenerator::makeMonomial(*varit1);
	        PMonomial mon2 = AlgebraicGenerator::makeMonomial(*varit2);
        	PPolynomial lhs = AlgebraicGenerator::makePolynomial();
        	lhs->addMonomial(mon1);
        	lhs->addMonomial(mon2);
        	PPolynomial rhs = AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial());
		result_eq = AlgebraicGenerator::createEquality(lhs, rhs);
	      }
	      break;
	    }
	  } // iterating on var2
	} // iterating on var1
      } // searching for x=y
      

      // destructing the set of satisfying assignments
      std::list<Assignment*>::iterator a1_it = sat_assignments.begin();
      std::list<Assignment*>::iterator a1_end = sat_assignments.end();
      for (; a1_it != a1_end; a1_it++)
        delete (*a1_it);
      sat_assignments.clear();
      
      
  
      if (can_be_simplified)
      {
        PDeductionObject premise = **myit;
	myit = new_set->remove(myit);
	PDeductionObject simplified_obj = (*myLitSubstRule)(premise, result_eq);
	PSAClause mod_clause = LogicalGenerator::makeSAClause();
	mod_clause->add(result_eq);
	mySolver->getNewNewObjects()->add(mod_clause);     
	mySolver->getNewNewObjects()->add(simplified_obj);     
	mySolver->processNewObjects(this, returned_set, &(*premise), 0, 0, 0, "part6");	
      }
	
    } // check restrictions
    
    if (!can_be_simplified)
      ++*myit;
  } //rule6  iterating on all objects of the given set 
  } // if (use_part6)
  
  
};	    



