#ifndef __SMARTCIRCUITFORMTRANSLATION_H__
#define __SMARTCIRCUITFORMTRANSLATION_H__

#include "../abstract/simplrule.h"
#include "../../basicobject/simpleobjectset.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../misc/output.h"

typedef std::list<PSAClause> ClauseList;
typedef boost::shared_ptr<ClauseList> PClauseList;

typedef IndexElement<DeductionObject> IE;
typedef boost::shared_ptr<IE> PIE;

typedef std::list<PIE> IEList;
typedef boost::shared_ptr<IEList> PIEList;

typedef std::list<bool> BoolList;
typedef boost::shared_ptr<BoolList> PBoolList;

/**
 * @class SmartCircuitFormTranslationRule
 * @brief implements circuit form translation rule
 * (see documentation for details)
 */
class SmartCircuitFormTranslationRule: public SimplificationRule
{
public:
  /**
   * Constructor
   */    
  SmartCircuitFormTranslationRule(BooleanAlgebraicSolver *s): mySolver(s) {};
  
  virtual void 
  operator()(DeductionObjectSet* returned_set, 
	     DeductionObjectSet* new_set, 
	     DeductionObjectSet* old_set, bool gen_new_vs_new)
  { 
    this->myOperator(returned_set, new_set, old_set); 
  };
  
  std::string getName() const {return "SmartCircuitFormTranslationRule";};
  
private:
  /**
   * Finds among boolean clause representation of boolean circuit in the form 
   * o=f(...), there f is polynomial of degree almost  2.
   * see documentation for details
   */ 
  virtual void
  myOperator(DeductionObjectSet* returned_set, DeductionObjectSet* set, DeductionObjectSet* set2);
  

public: 

  virtual 
  ~SmartCircuitFormTranslationRule() {};  
  
private:

  
  /**
   * We already find gate. Makes and/or transformation
   */    
   
  void
  makeAndOrTransformation();
  
  /**
   * We already find gate. Makes xor transformation
   */    
  
  void
  makeXorTransformation();

   /**
    * Literal A in first clause
    */
    
  PEquality litA;

   /**
    * Literal B in first clause
    */
  
  PEquality litB;
  
   /**
    * Literal C in first clause
    */

  PEquality litC;
  
   /**
    * First clause
    */

  PSAClause abc;

   /**
    * New clause letter n denotes negation 
    */
  
  PSAClause nanb;
   /**
    * New clause letter n denotes negation 
    */

  PSAClause nanc;
  
   /**
    * New clause letter n denotes negation 
    */

  PSAClause anbnc;
   /**
    * New clause letter n denotes negation 
    */

  PSAClause nanbc;
   /**
    * New clause letter n denotes negation 
    */

  PSAClause nabnc;      
   /**
    * First deduction object
    */

  PDeductionObject myStartSearch;
  
   /**
    * First deduction object iterator
    */
  
  PDeductionObjectIterator myStartIterator;
  
   /**
    * Already found and/or gates to delete in the future
    */

  PIEList myAndOrDeleteSet;
  
   /**
    * Is Already found and/or gate to delete in the future from new set
    */
  
  PBoolList myAndOrFromWhichSet;
  
   /**
    * Already found xor gates to delete in the future
    */

  PIEList myXorDeleteSet;

   /**
    * Is Already found and/or gate to delete in the future from new set
    */
  
  PBoolList myXorFromWhichSet;
  
   /**
    * Just result set
    */
  DeductionObjectSet *result;
   /**
    * Input sets
    */
  DeductionObjectSet *myInputDedObjSet, *myNewDedObjSet;
  
  /**
   * New separate method for searching only XOR part of circuit
   */
  
  bool searchForXor(PDeductionObjectIterator first);
  

  /**
   * New separate method for searching only AND/OR part of circuit
   */
  
  bool searchForAndOr(PDeductionObjectIterator first,
                      Variable a, bool need_new_set);

  /**
   * Sets needed values and searching list (for appropriate xor gate)
   */    

  void 
  setXorList(PClauseList xorList, PSAClause clause);

  /**
   * Sets needed values and searching list (for appropriate and/or gate)
   */    

  void 
  setAndOrList(PClauseList andOrList, PSAClause clause, Variable a);

  /**
   * If first premise from new set
   */
   
  bool myFirstIsNew;
  /// Reference to the solver
  BooleanAlgebraicSolver *mySolver;
};



#endif

