#include "lin3rule.h"
#include "../../misc/output.h"

/**
 * @file lin3rule.cc
 * @brief implementation for lin3rule.h
 * @author sergey 
 */



void 
Lin3Rule::operator()(
DeductionObjectSet* result_set, 
DeductionObjectSet* ded_obj,
DeductionObjectSet* new_obj,
bool use_new_obj,
bool gen_new_vs_new) const
{

  bool has_old_obj = false;
  if (ded_obj != 0) has_old_obj = true;
  if (use_new_obj && (!new_obj->getSize())) return;
  
  PDeductionObjectIterator it1 = new_obj->getBegin(indXeqABpACpBCm2ABC);
  PDeductionObjectIterator it2, end2,newend2;
  PDeductionObjectIterator newend = new_obj->getEnd(indXeqABpACpBCm2ABC);
  PDeductionObjectIterator end1;
  if (has_old_obj) end1 = ded_obj->getEnd(indXeqABpACpBCm2ABC);
  else end1 = newend;
  it1 = new_obj->getBegin(indXeqABpACpBCm2ABC);

  bool withconstant, has_new_premise1 = true, has_new_premise2=true;
  Variable x,a,b,c,aa,bb,cc,y,yy;
  bool px,pa,pb,pc,withconstant2;

  for (; !(it1->equals(*end1)); ++(*it1))
  {
    // a standard block of code to switch from the new set to the old one,
    // keeping in mind where we currently are (to determine later
    // whether new objects participate in the derivation)
    if (it1->equals(*newend)) 
    {
      if (!has_old_obj) break;
      has_new_premise1 = false;
      it1=ded_obj->getBegin(indXeqABpACpBCm2ABC);
      if (it1->equals(*end1)) break;
    }
    
    if (!(**it1)->getXeqABpACpBCm2ABC(x,px,a,pa,b,pb,c,pc)) continue;
    if (a == 0) continue;
    it2=ded_obj->begin(a);
    newend2=new_obj->end(a);
    if (has_old_obj)
      end2=ded_obj->end(a);
    else 
      end2=newend2;
    
    
    while (!(it2->equals(*end2)))
    {
      if (it2->equals(*newend2)) 
      {     
        has_new_premise2 = false;
        // if new objects are already done with,
        // there is no point to continue
        if ( (use_new_obj && !has_new_premise1) || (!has_old_obj) )
          break;
        else
          it2 = ded_obj->begin(a);
        if (it2->equals(*end2)) break;
      }

      if (!(**it2)->get124(yy,aa,bb,cc,withconstant2)) {++*it2; continue;}
   
        // we should find matching variables
        if (  (a == aa ) && (b == bb) && (c == cc) )
        {
          y = yy;
        }
        else if (  (a == aa ) && (b == cc) && (c == yy) )
        {
          y = bb;
        }
        else if (  (a == yy ) && (b == bb) && (c == cc) )
        {
          y = aa;
        }      
        else if (  (a == yy ) && (b == aa) && (c == cc) )
        {
          y = bb;
        }       
        else if (  (a == yy ) && (b == aa) && (c == bb) )
        {
          y = cc;
        }    
        else if (  (b == yy ) && (a == bb) && (c == cc) )
        {
          y = aa;
        }      
        else if (  (b == yy ) && (a == aa) && (c == cc) )
        {
          y = bb;
        }
        else if (  (b == yy ) && (a == aa) && (c == bb) )
        {
          y = cc;
        }
        else if (  (c == yy ) && (a == bb) && (b == cc) )
        {
          y = aa;
        }
        else if (  (c == yy ) && (a == aa) && (c == cc) )
        {
          y = bb;
        }
        else if (  (c == yy ) && (a == aa) && (b == bb) )
        {
          y = cc;
        } 
        else if (  (c == yy ) && (a == bb) && (b == aa) )
        {
          y = cc;
        } 
        else
        {
          ++*it2;
          continue;
        }
       
        
        PSAClause clause1=(boost::shared_dynamic_cast<SAClause, DeductionObject>((**it1)));
        if (!clause1) {++*it2; continue;}
        if (clause1->getNumberOfLiterals()==8) withconstant = true;
        else withconstant = false;     
        createResult(a,pa,b,pb,c,pc,x,px,y,withconstant2,result_set,**it1,**it2);

        if (has_new_premise2)
        { 
          mySolver->getOutput()->printThatRuleDeletedObject(this,&(***it2),new_obj);
          it2 = new_obj->remove(it2);
        }
        else
        {
          mySolver->getOutput()->printThatRuleDeletedObject(this,&(***it2),ded_obj);
          it2 = ded_obj->remove(it2);
        } 
    }
    mySolver->simplifyAllObjectsByNewModifiers();
  }
}


  
void Lin3Rule::createResult(Variable a, bool pa, Variable b, bool pb, Variable c, bool pc, Variable x, bool px, Variable y, bool wc2, DeductionObjectSet* result_set, PDeductionObject premise1, PDeductionObject premise2) const
{
  bool wwc2 = wc2;
  int constantrhs = 0;
  PPolynomial resultLHS = AlgebraicGenerator::makePolynomial();
  PPolynomial resultRHS = AlgebraicGenerator::makePolynomial();
  PMonomial mona = AlgebraicGenerator::makeMonomial(a); 
  if (!pa) {mona->setCoeff(-1); ++constantrhs;};
  PMonomial monb = AlgebraicGenerator::makeMonomial(b); 
  if (!pb) {monb->setCoeff(-1); ++constantrhs;};
  PMonomial monc = AlgebraicGenerator::makeMonomial(c); 
  if (!pc) {monc->setCoeff(-1); ++constantrhs;};
  if (constantrhs % 2) wwc2 = !wwc2;
  PMonomial monx = AlgebraicGenerator::makeMonomial(x); 
  if (!px) {monx->setCoeff(2); constantrhs-=2;}
  else monx->setCoeff(-2);

  
  PMonomial mony = AlgebraicGenerator::makeMonomial(y);
  if (wwc2)
  {
    mony->setCoeff(-1);
    resultLHS->addMonomial(AlgebraicGenerator::makeMonomial());
  }
  resultLHS->addMonomial(mony);

  resultRHS->addMonomial(mona); 
  resultRHS->addMonomial(monb); 
  resultRHS->addMonomial(monc);
  resultRHS->addMonomial(monx); 
  
  *resultRHS += constantrhs;

  PEquality resultEquality=AlgebraicGenerator::createEquality(resultLHS,resultRHS);    

  resultEquality->setVar1(a);
  resultEquality->setPos1(true);
  resultEquality->setVar2(b);
  resultEquality->setPos2(true);
  resultEquality->setVar3(c);
  resultEquality->setPos3(true);
  resultEquality->setVar4(y);
  resultEquality->setPos4(true);
  resultEquality->setVar5(x);
  resultEquality->setPos5(true);
                  
  
  
  if (!resultEquality->isTautology())
  {
    PSAClause clause=LogicalGenerator::makeSAClause();
    clause->add(resultEquality);
    clause->setGeneratedByLinearization();
    mySolver->processNewObject(this,clause,result_set,&(*premise1),&(*premise2),NULL,NULL);
  }

}

