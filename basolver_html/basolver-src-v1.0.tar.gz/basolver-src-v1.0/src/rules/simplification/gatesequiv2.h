#ifndef __gatesequivalence2_h__
#define __gatesequivalence2_h__
#include "../abstract/genrule.h"
#include "../abstract/simplrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../general/solver.h"

/**
 * @file gatesequiv2.h
 * Contains GatesEquivalence2Rule interface.
 */
 
class LiteralSubstitutionRule;

/**
 * @class GatesEquivalence2Rule
 * @brief implements GatesEquivalence2Rule
 * (see documentation for details)
 *
 * This class also implements EvenEquivalenceRule
 * (see documentation for details)
 */
class GatesEquivalence2Rule: public SimplificationRule
{
public:
  /// Constructor.
  GatesEquivalence2Rule(BooleanAlgebraicSolver* s);
  /// Destructor
  virtual ~GatesEquivalence2Rule();

  virtual void 
  operator() (DeductionObjectSet* returned_set, 
              DeductionObjectSet* new_set, 
	      DeductionObjectSet* old_set,
        bool gen_new_vs_new);

  virtual std::string
  getName() const {return "GatesEquivalence2Rule";};

private:  
  /// Applies a rule to an input pair of deduction objects.
  /// If nothing was deduced returns an empty pointer. Otherwise,
  /// returns a deduced object. The last two flags show
  /// which premises have to be removed and also what rule 
  /// was applied (GatesEquivalence or EvenEquivalence).
  PDeductionObject
  operator() (PDeductionObject obj1, PDeductionObject obj2,int &todelete,bool &evenequiv);
  
  /// The number of premise that need 
  /// to be deleted (0 if none). Set in 
  /// operator(obj, obj). 
  bool num_del_pre;
  
  
  /// number of generated objects (during one call)
  int number_of_generated_objects;
  /// number of tried pairs (during one call)
  int number_of_pairs_tried;
  
  /// Link to the solver.
  BooleanAlgebraicSolver* mySolver;
  
  /// Rule needed for simplifying premises by a new modifier.
  LiteralSubstitutionRule* myLitSubstRule;
  
  /// Checks whether two input equalities satisfy the restrictions of the rule.
  bool
  checkRestrictions(PEquality eq1, PEquality eq2, bool even_equiv = false) const;
};
#endif


