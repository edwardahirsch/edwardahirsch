#include "pureliteral.h"
#include "misc/output.h"

/* @author kulikov */


/**
 * @file pureliteral.cc
 * @brief Contains implementation of PureLiteralRule methods.
 */

void
PureLiteralRule::operator()(
  DeductionObjectSet* returned_set,
  list<DeductionObjectSet*> ded_list)
{

  if (ded_list.size() == 0)
    return;

  bool happened = true; // whether some literal was assigned a sign

  std::list<Variable>::iterator var_it; 
  std::list<Variable>::iterator var_end;
  
  do 
  { 
    happened=false;
    var_it = mySolver->getVarList()->begin();
    var_end = mySolver->getVarList()->end();
  
    for (; var_it != var_end; ++var_it)
    {
      bool same_sign = true;
      int sign = -2;
	
      list<DeductionObjectSet*>::iterator ded_set_it = ded_list.begin();
      list<DeductionObjectSet*>::iterator ded_set_end = ded_list.end();
      while (same_sign && ded_set_it != ded_set_end)
      {
        int current_sign = this->getSign(*ded_set_it, *var_it);
	
        if (current_sign == -1)
	{
	  same_sign = false;
	  break;
	}
	
	if (current_sign != -2 && sign == -2)
	  sign = current_sign;
	  
	if (current_sign != -2 && sign != -2 && current_sign != sign)
	{
	  same_sign = false;
	  break;
	}  
        ded_set_it++;
      }
      
      if (same_sign && (sign == 0 || sign == 1))
      // so, now var has the same sign in all sets
      { 
        happened = true;
	PSAClause cl = LogicalGenerator::makeSAClause();
	cl->add(LogicalGenerator::makeBoolLiteral(*var_it, sign));
	mySolver->processNewObject(this, cl, returned_set);
	mySolver->simplifyAllObjectsByNewModifiers();
	break;
      }
    } // end of iterating on variables
    
  } while (happened);   
 
}

int
PureLiteralRule::getSign(DeductionObjectSet* set, Variable var)
{

  // sergey: this code uses new index counters
  if (!set->getNumberOfOccurrences(var))
    return -2;
  if (set->getUnitOccurrences(var))
    return -1;
  if (set->getPositiveOccurrences(var))
  {
    if (set->getNegativeOccurrences(var))
      return -1;
    else
      return 1;
  }
  else
  {
    if (set->getNegativeOccurrences(var))
      return 0;
    else
      return -2;
  }
  
  if (set->getSize() == 0)
    return -2;

  int sign = -2; 
  
  // the following cycle to be replaced by 
  // simple call to counters
  
  PDeductionObjectIterator it = set->begin(var);
  PDeductionObjectIterator end = set->end(var);
  
  while (!it->equals(*end))
  {
    Assert((**it)->contains(var), "Bug.");
    
    if (!(**it)->isBoolean())
      return -1;
      
    // now (**it) is a Boolean clause containing the variable var
    PSAClause clause = boost::shared_dynamic_cast<SAClause, DeductionObject>(**it);
    
    for (SALiteralIterator lit_it = clause->begin(); lit_it != clause->end(); ++lit_it)
    {
      Assert((*lit_it)->isBoolean(), "Bug.");
      PEquality eq = boost::shared_dynamic_cast<Equality, SALiteral>(*lit_it);
      
      if (!eq->getLHS()->containsVariable(var))
        continue;
      
      int current_sign = eq->getRHS()->getFreeCoefficient();
      
      Assert(current_sign == 0 || current_sign == 1, "Bug.");
      
      if (sign == -2)
      {
        sign = current_sign;
      }
      else
      {
        if (sign != current_sign)
	  return -1;
      }	
    }
    
    ++*it;
  }
  
  return sign;
}


