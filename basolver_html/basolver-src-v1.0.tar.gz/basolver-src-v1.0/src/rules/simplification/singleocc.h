#ifndef __singleocc_h__
#define __singleocc_h__
#include "../abstract/simplrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../general/solver.h"

/**
 * @file singleocc.h
 * Contains SingleOccurrenceRule interface.
 */

/**
 * @class SingleOccurrenceRule
 * @brief Assigns an appropriate Boolean value 
 * to a variable if it occurs only once.
 *
 * Namely, if a variable occurs in only one clause,
 * we may throw this clause away (more precisely, we
 * move it to Modifiers and calculate the single
 * occurring variable from the other variables of this
 * clause if a satisfying assignment is to be calculated.
 */
class SingleOccurrenceRule : public SimplificationRule
{
public:
  /// Constructor.
  SingleOccurrenceRule(BooleanAlgebraicSolver* s) : mySolver(s) {};

  virtual void 
  operator() (DeductionObjectSet* returned_set, 
              list<DeductionObjectSet*> ded_list);

  virtual std::string getName() const {return "Single Occurrence Rule";};

private:  
  /// Reference to the solver.
  BooleanAlgebraicSolver* mySolver;
  
  /// Returns the number of non-unit occurrences of variable var
  /// in all input sets.
  int getTotalNumberOfNonUnitOccurrences(
    list<DeductionObjectSet*> ded_list,  
    Variable var);

  /// Returns the number of occurrences of variable var
  /// in all input sets.
  long
  getTotalNumberOfOccurrences(
    list<DeductionObjectSet*> ded_list, 
    Variable var);
    
  /// Removes single occurrences of variables which appears in XORs
  /// and left-hand sides of ANDs. Returns true iff an occurrence is removed. 
  bool
  checkAndRemoveSingleOccurrence(
    DeductionObjectSet*,
    Variable var, 
    DeductionObjectSet* returned_set);

};

#endif



