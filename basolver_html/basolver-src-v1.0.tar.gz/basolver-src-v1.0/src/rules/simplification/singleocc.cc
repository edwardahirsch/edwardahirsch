#include "singleocc.h"
#include "misc/output.h"

/* @author kulikov */


/**
 * @file singleocc.cc
 * @brief Contains implementation of SingleOccurrenceRule methods.
 */
 
int SingleOccurrenceRule::getTotalNumberOfNonUnitOccurrences(
  list<DeductionObjectSet*> ded_list,
  Variable var)
{

  long total = 0;
  
  for (list<DeductionObjectSet*>::iterator d_it = ded_list.begin();
  d_it != ded_list.end(); d_it++)
    total += (*d_it)->getNumberOfNonUnitOccurrences(var);

  return total;

};

long 
SingleOccurrenceRule::getTotalNumberOfOccurrences(
  list<DeductionObjectSet*> ded_list,
  Variable var)
{
  long total = 0;

  for (list<DeductionObjectSet*>::iterator d_it = ded_list.begin();
  d_it != ded_list.end(); d_it++)
    total += (*d_it)->getNumberOfOccurrences(var);

    
  return total;

};


void
SingleOccurrenceRule::operator()(
  DeductionObjectSet* returned_set,
  list<DeductionObjectSet*> ded_list
  )
{
  bool happened;
  std::list<Variable>::iterator it; 
  std::list<Variable>::iterator end;
  do {
    happened=false;
    it = mySolver->getVarList()->begin();
    end = mySolver->getVarList()->end();
  
    for (;it != end; ++it)
    {
      if (this->getTotalNumberOfOccurrences(ded_list, *it) == 1)
      {
	for (list<DeductionObjectSet*>::iterator d_it = ded_list.begin(); d_it != ded_list.end(); d_it++)
	  if ((*d_it)->isPresent(*it))
	    happened = (happened || this->checkAndRemoveSingleOccurrence(*d_it, *it, returned_set));
      }
    }
 } while (happened);   
}

bool 
SingleOccurrenceRule::checkAndRemoveSingleOccurrence(DeductionObjectSet *set, Variable var, DeductionObjectSet* returned_set)
{
  Assert((set->getNumberOfOccurrences(var) == 1), "Non-single occurrence in ...SingleOccurrence!" );
  PDeductionObjectIterator it = set->begin(var);
  Assert(it!=0,"Empty PDeductionObjectIterator in SingleOccurrences");
  Assert(it.get()!=0,"Null PDeductionObjectIterator in SingleOccurrences");
  Assert(!(it->equals(*(set->end(var)))),"Empty index in SingleOccurrences");
  if (!(**it)->hasOneEquality()) // Boolean case: trivial
  {
    mySolver->getOutput()->printObjectDeletion(NULL,&(***it),NULL,NULL,NULL,NULL);
    PSAClause clause=boost::shared_dynamic_cast<SAClause, DeductionObject>(**it);
    // find var=? in ***it
    std::list<PSALiteral>::iterator lbeg = clause->begin();
    std::list<PSALiteral>::iterator lend = clause->end();
    
    while (lbeg!=lend)
    {
      PEquality equality=boost::shared_dynamic_cast<Equality, SALiteral>(*lbeg);
      if (equality->getBooleanVariable() == var)
      {
	
	PModificationObject new_obj = PModificationObject(equality);
	mySolver->getOutput()->printObjectRecognition(&(*new_obj),std::string("pure literal"));
	mySolver->getModifiers()->add(new_obj);
	
        break;
      }
      ++lbeg;
    }
    set->remove(it); // drop it, the procedure will return
    return true;
  }
  
  PSAClause clause1=(boost::shared_dynamic_cast<SAClause, DeductionObject>((**it)));
  PEquality eq1 = (boost::shared_dynamic_cast<Equality, SALiteral>(*(clause1->begin())));
  TEqualityType eqt = eq1->getEqType();
  if ( (eqt == eqtXeqAB) || (eqt == eqt11m2) )
  {
    if (eqt == eqtXeqAB)
    {
      if (eq1->getVar1() != var) {
        return false;
      }
    }    
    mySolver->getOutput()->printObjectDeletion(NULL,&(***it),NULL,NULL,NULL,NULL);
    eq1->setMainVar(var);
    
    mySolver->getModifiers()->add(PModificationObject(eq1));
    it = set->remove(it); 
    return true; // anyway, we will repeat the whole process
  }
  else
  {

    return false;
  }
  return false; // for sure
}




