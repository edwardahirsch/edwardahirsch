#include "literalsubstitutionrule.h"

/**
 * @file literalsubstitutionrule.cc
 * @brief implementation for literalsubstitutionrule.h
 * @author dmitrits
 */


PDeductionObject
LiteralSubstitutionRule::operator() (  PDeductionObject dedObj,   PModificationObject modObj)  
{
  PSAClause oldclause=(boost::shared_dynamic_cast<SAClause, DeductionObject>(dedObj));
  PSAClause clause=oldclause->clone();
  PEquality equality=boost::shared_dynamic_cast<Equality, ModificationObject>(modObj);
  this->substituteOne(clause, equality);
  return clause;
}; 
 
void LiteralSubstitutionRule::substituteOne(PSAClause clause,   PEquality equality)  
{
  if (equality->isBoolean())
  {
    clause->assign(equality->getLHS()->getVariable(),(int) (equality->getRHS()->getFirstConstant()));
  }
  else if (equality->isFirstType())
  {
    if (equality->getRHS()->isVariable())
    {
      clause->substituteEqual(equality->getLHS()->getVariable(),equality->getRHS()->getVariable());
    }
    else
    {
      clause->substituteNonEqual(equality->getLHS()->getVariable(),equality->getRHS()->getVariable());
    };
  }; 
};
  

PDeductionObject
LiteralSubstitutionRule:: operator() (  PModificationObject underModification,   PModificationObject modifier)  
{
   PEquality oldEqualityUnderModification=boost::shared_dynamic_cast<Equality, ModificationObject>(underModification);
   PEquality equalityUnderModification=boost::shared_dynamic_cast<Equality, ModificationObject>(oldEqualityUnderModification->cloneObject());
   PEquality equalityModifier=boost::shared_dynamic_cast<Equality, ModificationObject>(modifier);  
   if (equalityModifier->isBoolean())
   {
     equalityUnderModification->assign(equalityModifier->getLHS()->getVariable(),(int) (equalityModifier->getRHS()->getFirstConstant()));
   }
   else if (equalityModifier->isFirstType())
   {
     if (equalityModifier->getRHS()->isVariable())
     {
       equalityUnderModification->substituteEqual(equalityModifier->getLHS()->getVariable(),equalityModifier->getRHS()->getVariable());
     }
     else
     {
       equalityUnderModification->substituteNonEqual(equalityModifier->getLHS()->getVariable(),equalityModifier->getRHS()->getVariable());
     };
   };  
   if ((*equalityUnderModification)==(*oldEqualityUnderModification))
   {
     PDeductionObject null;
     return null;
   }
   
   PSAClause clause = LogicalGenerator::makeSAClause(); 
   clause->add(PSALiteral(equalityUnderModification));
   return clause;   
};
 
void 
LiteralSubstitutionRule::operator() (
DeductionObjectSet* returned_set,
DeductionObjectSet* input_ded_obj_set, 
  ModificationObjectSet* input_mod_obj_set)  
{
  PModificationObjectIterator cur_mod_obj = input_mod_obj_set->getBeginIteratorOnWholeSet();
  PModificationObjectIterator mod_end = input_mod_obj_set->getEndIteratorOnWholeSet();
  PDeductionObjectIterator cur_ded, ded_end;
  PDeductionObject obj;
  
  for (;!cur_mod_obj->equals(*mod_end);++*cur_mod_obj)
  {
    if ((**cur_mod_obj)->getLHS()->isVariable())
    {
      Variable var = (**cur_mod_obj)->getLHS()->getVariable();
      cur_ded = input_ded_obj_set->begin(var);
      ded_end = input_ded_obj_set->end(var);
      while (!cur_ded->equals(*ded_end))
      {
        obj = (*this)(**cur_ded,**cur_mod_obj);
        if (obj.get() != 0)
        {
          PDeductionObject premise = **cur_ded;
          mySolver->getOutput()->printThatRuleDeletedObject(this, &(*premise), input_ded_obj_set);
          cur_ded = input_ded_obj_set->remove(cur_ded);
          mySolver->processNewObject(this, obj, returned_set, &(*premise),&(***cur_mod_obj),NULL,NULL);
        }
        else
          ++*cur_ded;
      }
      mySolver->simplifyAllObjectsByNewModifiers();
    }
  }

};



void
LiteralSubstitutionRule::operator() (
DeductionObjectSet* returned_set,
ModificationObjectSet* new_set, 
ModificationObjectSet* old_set, bool gen_new_vs_new)  
{
  

for (int i = 1; i <= 2; i++)
{
  ModificationObjectSet *simplified_set = 0;
  // we first simplify new_set by means of itself, and then old_set by new_set
  if (i == 1)
    simplified_set = new_set;
  if (i == 2)
    simplified_set = old_set;

  // declare iterators; always try to simplify it2 by means of it1
  PModificationObjectIterator it1, it2;

  for (it1 = new_set->getBeginIteratorOnWholeSet(); 
  !it1->equals(*(new_set->getEndIteratorOnWholeSet())); ++*it1)
    if ((**it1)->getLHS()->isVariable())
    {
      Variable var = (**it1)->getLHS()->getVariable();
      it2 = simplified_set->begin(var);
      
      while (!it2->equals(*(simplified_set->end(var))))
      {
        // skip if iterators point the same object;
	// however compare iterators only in case they are both from new_set
        if ((i==1) && (&(***it1) == &(***it2)))
	{
	  ++*it2;
          continue;
	}
	
        PDeductionObject new_ded_obj = (*this)(**it2, **it1);
      
        if (new_ded_obj.get() != 0)
        // it2 was simplified with non-trivial result
        {
	  PModificationObject premise = **it2;
	  it2 = simplified_set->remove(it2);
	  
	  mySolver->processNewObject(this, new_ded_obj, returned_set,  &(*premise),&(***it1),NULL,NULL);
        }
        else 
          ++*it2;
      }
      mySolver->simplifyAllObjectsByNewModifiers();
    }
} // for
 
    

};

