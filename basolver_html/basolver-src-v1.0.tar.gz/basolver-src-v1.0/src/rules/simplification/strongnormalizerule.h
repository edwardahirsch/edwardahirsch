#ifndef __strongnormalizerule_h__
#define __strongnormalizerule_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../misc/output.h"
/**
 * @file strongnormalizerule.h
 * @brief normalize equalities
 * @author dmitrits
 */

/**
 * @class StrongNormalizeRule
 * @brief Implements strong normalization 
 * (see documentation for details)
 */
class StrongNormalizeRule: public SimplificationRule
{
public:
  /// Constructor. 
  StrongNormalizeRule(BooleanAlgebraicSolver* s);

  /// Destructor. 
  ~StrongNormalizeRule();

  
  virtual void 
  operator() (DeductionObjectSet* returned_set, DeductionObjectSet* new_set);
  
  std::string 
  getName() const 
  {return "StrongNormalizeRule";};
      
  /// Reference to the solver.
  BooleanAlgebraicSolver *mySolver;        

private:
  /// Rule needed for simplifying new objects.
  LiteralSubstitutionRule*
  myLitSubstRule;      
};
#endif
