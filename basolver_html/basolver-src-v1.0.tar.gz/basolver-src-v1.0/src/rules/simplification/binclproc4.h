#ifndef __binclproc4_h__
#define __binclproc4_h__
#include "../abstract/genrule.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../misc/output.h"

using namespace std;


/**
 * @file binclproc4.h
 * Contains interface for BinaryClausesProcessing4Rule.
 */
 


/**
 * @class BinaryClausesProcessing4Rule
 * @brief Implements the binary clauses processing algorithm
 * (see documentation for details). 
 */
class BinaryClausesProcessing4Rule : public SimplificationRule
{
public:
  /// Constructor.
  BinaryClausesProcessing4Rule(BooleanAlgebraicSolver* s);
  
  virtual 
  ~BinaryClausesProcessing4Rule();

  virtual void 
  operator()(DeductionObjectSet* returned_set,
             DeductionObjectSet* new_set,
	     DeductionObjectSet* old_set,
	     bool gen_new_vs_new = true); 

  virtual std::string 
  getName() const 
  { return std::string("BinaryClausesProcessingRule"); };
  
private:
  /// Link to the solver.
  BooleanAlgebraicSolver* mySolver;

  /// Temporal assignment storing also the time when 
  /// a variable was assigned a value.
  map<long, pair<bool, long> > 
  myTempAssignment;
  
  /// Variable storing the current time
  /// (needed for myTempAssignment);
  long myCurrentTime;
  
  /// Tries to deduce something by adding the unit clause (lit1).
  void 
  tempAddNewUnitClause(
    DeductionObjectSet*, 
    DeductionObjectSet*, 
    DeductionObjectSet*, 
    int lit1);
  
  /// Debug printing (to std::cerr) of internal structures.
  void
  debugPrint() const;
  
  /// Given two binary clauses creates a unit resolvent if possible.
  /// More precisely, does the following:
  /// (x y) (-y w)  -> (x w)
  /// (x y) (-x -y) -> x=-y
  PDeductionObject 
  createUnitResolvent(PDeductionObject obj1, PDeductionObject obj2);
  
  /// A flag indicating that a new object was generated.
  bool
  myNewObjectWasGenerated;
  
  /// Stores the length of a newly generated clause
  /// (if equals to 1, premises are removed).
  int 
  myNewClauseLength;
  
  /// Only if this flag is set to true,
  /// this rule will add binary resolvents.
  int 
  myAddBinaryResolvents;
};
#endif
