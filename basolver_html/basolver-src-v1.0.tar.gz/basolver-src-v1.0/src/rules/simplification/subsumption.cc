#include "subsumption.h"
#include "../../algebraic/algebraic.h"
#include "../../logical/logical.h"
#include "../../misc/output.h"


/**
 * @file subsumption.cc
 * @brief implementation for subsumption.h
 * @author sergey 
 */




void 
SimpleSubsumption::operator () (DeductionObjectSet* res, DeductionObjectSet* set2, DeductionObjectSet* set, bool gen_new_vs_new)
{  
  PDeductionObjectIterator iter1 = set2->getBeginIteratorOnWholeSet();
  PDeductionObjectIterator iter2, enditer2, enditer3;
  PDeductionObjectIterator enditer = set2->getEndIteratorOnWholeSet();
  VarList *varlist;
  PSAClause clause;
  std::list<Variable>::iterator vbeg,vend;

  bool it1deleted = false, useset2forit2 = true;
  while (*iter1 != *enditer)
  {
    varlist = iter1->getIE()->getVList();
    vbeg = varlist->begin();
    vend = varlist->end();
    
    while (vbeg != vend)
    {
     
      // standard dancing around with iterators
      if (gen_new_vs_new)
        iter2 = set2->begin(*vbeg);
      else
        iter2 = set->begin(*vbeg);
      enditer2 = set->end(*vbeg);
      enditer3 = set2->end(*vbeg);
      useset2forit2 = true;


      
      while (*iter2 != *enditer2)
      {

        // iterators again
        if (gen_new_vs_new && (iter2->equals(*enditer3)))
        {
          iter2 = set->begin(*vbeg);
          useset2forit2 = false;
          if (iter2->equals(*enditer2)) break;
        }

        
        if ((**iter2)->getId() != (**iter1)->getId())
          switch (subsumes(**iter1, **iter2))
          {
            case 1:
              mySolver->getOutput()->printObjectDeletion(this,&(***iter2),&(***iter1),NULL,NULL,NULL);
              if (useset2forit2)
              {
                mySolver->getOutput()->printThatRuleDeletedObject(this,&(***iter2),set2);
                iter2 = set2->remove(iter2);
		this->incNumberOfGeneratedObjects();
              }
              else
              {
                mySolver->getOutput()->printThatRuleDeletedObject(this,&(***iter2),set);
                iter2 = set->remove(iter2);
		this->incNumberOfGeneratedObjects();
              }
              break;
            case -1:
              mySolver->getOutput()->printObjectDeletion(this,&(***iter1),&(***iter2),NULL,NULL,NULL);
	      this->incNumberOfGeneratedObjects();
              it1deleted = true;
              break;
            default:
              ++*iter2;
          }
        else
          ++*iter2;
        if (it1deleted) break;
      }
      if (it1deleted) break;
      ++vbeg;
    }
    if (it1deleted)
    {
      mySolver->getOutput()->printThatRuleDeletedObject(this,&(***iter1),set2);
      iter1 = set2->remove(iter1);
      it1deleted = false;
    }
    else
    {
      mySolver->simplifyAllObjectsByNewModifiers();
      ++*iter1;
    }
  }
}


// returns 1, if obj1 subsumes obj2 (including the case when they're equal)
// returns -1, if obj2 subsumes obj1
int SimpleSubsumption::subsumes(PDeductionObject obj1, PDeductionObject obj2)
{
  
  PSAClause cl1 = boost::shared_dynamic_cast<SAClause,DeductionObject>(obj1);
  PSAClause cl2 = boost::shared_dynamic_cast<SAClause,DeductionObject>(obj2);
  

  // this is designed to cover the case xy=0 vs (-x -y)
  if ((obj1->getEqType() == eqtABeq0) && (obj2->getNumberOfLiterals() == 2))    
  {
    SALiteralIterator it1 = cl1->begin();
    SALiteralIterator it2 = cl2->begin();

    if ( ((*it2)->getBooleanVariable() == (*it1)->getVar1()) && ((*it2)->getBooleanSign() == !(*it1)->getPos1()) )
    {
      ++it2;
      if ( ((*it2)->getBooleanVariable() == (*it1)->getVar2()) && ((*it2)->getBooleanSign() == !(*it1)->getPos2()) )
      {
        return 1;
      }
      else return 0;
    }
    else if ( ((*it2)->getBooleanVariable() == (*it1)->getVar2()) && ((*it2)->getBooleanSign() == !(*it1)->getPos2()) )
    {
      ++it2;
      if ( ((*it2)->getBooleanVariable() == (*it1)->getVar1()) && ((*it2)->getBooleanSign() == !(*it1)->getPos1()) )
      {
        return 1;
      }
      else return 0;
    }
    else
      return 0;
  }

  if ((obj2->getEqType() == eqtABeq0) && (obj1->getNumberOfLiterals() == 2))
  {
    SALiteralIterator it1 = cl1->begin();
    SALiteralIterator it2 = cl2->begin();

    if ( ((*it1)->getBooleanVariable() == (*it2)->getVar1()) && ((*it1)->getBooleanSign() == !(*it2)->getPos1()) )
    {
      ++it1;
      if ( ((*it1)->getBooleanVariable() == (*it2)->getVar2()) && ((*it1)->getBooleanSign() == !(*it2)->getPos2()) )
      {
        return -1;
      }
      else return 0;
    }
    else if ( ((*it1)->getBooleanVariable() == (*it2)->getVar2()) && ((*it1)->getBooleanSign() == !(*it2)->getPos2()) )
    {
      ++it1;
      if ( ((*it1)->getBooleanVariable() == (*it2)->getVar1()) && ((*it1)->getBooleanSign() == !(*it2)->getPos1()) )
      {
        return -1;
      }
      else return 0;
    }
    else
      return 0;
  }

  if (cl1->getNumberOfLiterals()<cl2->getNumberOfLiterals())
  {
    if (cl1->isSubsetOf(*cl2)) return 1;
    return 0;
  }
  else
  {
    if (cl2->isSubsetOf(*cl1)) return -1;
  }
  return 0;
  
}
