#ifndef __OBJECTINDEX_H__
#define __OBJECTINDEX_H__

/**
 * @file objectindex.h
 * @brief Contains a simple implementation
 * of the ObjectIndex template
 * @author sergey
 */

#include "../../algebraic/abstract/variable.h"
#include "objectiterator.h"
#include <vector>
#include <map>
#include <stdio.h>
#include <iostream>
#include "../../misc/tracer.h"

/**
 * a triple of long ints
 */
typedef std::pair<std::pair<long, long>,long> TLongTriple;

/**
 * a pair of long ints
 */
typedef std::pair<long,long> TLongPair;


    
/**
 * @class SimpleObjectIndex
 * @brief Object index template that allows
 * to include indexing into different types of sets.
 * It is currently used by \ref SimpleObjectSet.
 * Please refer to the descriptions of specific methods
 * for descriptions of different types of indices kept
 * in this entity.
 */
template <class T>
class SimpleObjectIndex
{
public:

  /// smart pointer to \ref SimpleObjectIterator on base class
  typedef boost::shared_ptr<SimpleObjectIterator<T> > PSimpleObjectIterator;
  /// smart pointer on the base class
  typedef boost::shared_ptr<T> PT;
  /// \ref IndexElement on the base class
  typedef IndexElement<T> IE;
  /// \ref TinyIndexElement on the base class
  typedef TinyIndexElement<T> TIE;
  /// smart pointer for \ref IE
  typedef boost::shared_ptr<IE> PIE;
  /// smart pointer for \ref TIE
  typedef boost::shared_ptr<TIE> PTIE;
  /// list of \ref PT
  typedef std::list<boost::shared_ptr<T> > TList;
  /// list of \ref PTIE
  typedef std::list<PTIE> IEList;
  /// iterator on \ref TList
  typedef typename TList::iterator TIterator;
  /// iterator on \ref IEList
  typedef typename IEList::iterator IEIterator;

  /// vector of \ref IEList
  typedef std::vector<IEList *> TVector;
  /// vector of \ref IEIterator
  typedef std::vector<IEIterator> TIterVector;
  /// map that indexes \ref IEList by triples of longs
  typedef std::map<TLongTriple,IEList *> TMap3;
  /// map that indexes \ref IEList by pairs of longs
  typedef std::map<TLongPair,IEList *> TMap2;
  /// vector of long counters
  typedef std::vector<long > TCounterVector;
  
  /**
   * Constructs the index on num variables
   */
  SimpleObjectIndex(long int num);

  /**
   * clears the index
   */
  void clear()
  {
 
    TRACE("clearing",std::cout << "clearing\n";);
    
    typename TVector::iterator i1=myVector->begin();
    typename TIterVector::iterator i2=myDelVector->begin();
    typename TVector::iterator i3=myLHSVector->begin();
    typename TCounterVector::iterator c1=myCounters->begin();
    typename TCounterVector::iterator c2=myGeneralCounters->begin();    
    typename TCounterVector::iterator c3=myPositiveCounters->begin();
    typename TCounterVector::iterator c4=myNegativeCounters->begin();
    for(;i1!=myVector->end();i1++,i2++,i3++,c1++,c2++,c3++,c4++)
    {
      (*i1)->clear();
      (*i2)=(*i1)->begin();
      (*i3)->clear();
      (*c1)=0;
      (*c2)=0;
      (*c3)=0;
      (*c4)=0;
    };
    for (int i=0; i<INDICES_NUM; ++i)
    {
      TRACE("newindicesclear", std::cout << "   clearing index " << i << "\n"; flush(std::cout););
      ind[i]->clear();
      iter[i] = ind[i]->begin();
    }
    typename TMap2::iterator it2 = myMap2->begin();
    while (it2 != myMap2->end())
    {
      (*it2).second->clear();
      delete (*it2).second;
      ++it2;
    }
    typename TMap3::iterator it3 = myMap3->begin();
    while (it3 != myMap3->end())
    {
      (*it3).second->clear();
      delete (*it3).second;
      ++it3;
    }
    myMap3->clear();
    myMap2->clear();
 
 }

  /**
   * returns the number of occurrences of a given variable in the clauses
   */
  long getNumberOfOccurrences(long num)
  {
    return this->getOccurrenceCounter(num);
  }
  
  /**
   * adds an entry to the map of three variables
   */
  void add2Map(PIE p, TLongPair pa)
  {
    typename TMap2::iterator it = myMap2->find(pa);
    if (it == myMap2->end())
    {
      TRACE("index3",std::cout << "creating list for " << pa.first << " and " << pa.second << "\n";);
      myMap2->insert(std::make_pair(pa,new IEList));
      it = myMap2->find(pa);
    }
    PTIE newtie(new TIE(p));
    (*it).second->push_back(newtie);
  }

  /**
   * adds an entry to the map of three variables
   */
  void add3Map(PIE p, TLongTriple trip)
  {
    typename TMap3::iterator it = myMap3->find(trip);
    if (it == myMap3->end())
    {
      TRACE("index3",std::cout << "creating list for " << trip.first.first << " and " << trip.first.second << " and " << trip.second << "\n";);
      myMap3->insert(std::make_pair(trip, new IEList));
      it = myMap3->find(trip);
    }
    PTIE newtie(new TIE(p));
    (*it).second->push_back(newtie);
  }


  /**
   * returns the first value of a set consisting of
   * objects with their varlists included in this one
   */
  PIE firstObjectInVars(long x, long y, long z)
  {
    long max=x, min=x, mid=x;
    if (y>x) {
      if (z>y) {max=z; mid=y;}
      else {
        if (z>x) {mid = z; max=y;}
        else {min = z; max = y;};
      }
    }
    else {
      if (z<y) {min=z; mid=y;}
      else if (z<x) {mid=z; min=y;}
      else {max=z;min=y;};
    }
    curTriple.first.first = max; 
    curTriple.first.second = mid; 
    curTriple.second = min;
    typename TMap3::iterator it3 = myMap3->find(curTriple);
    if (it3 != myMap3->end())
    {
      curList = (*it3).second;
      if (setCurIter(curList)) {mySetNumber = 1; return ((*curIterator)->getIE());};
    }
    TLongPair pair; pair.first = max; pair.second = mid;
   typename TMap2::iterator it2 = myMap2->find(pair);
    if (it2 != myMap2->end())
    {
      curList = (*it2).second;
      if (setCurIter(curList)) {mySetNumber = 2; return ((*curIterator)->getIE());};
    }
    pair.second = min;
    it2 = myMap2->find(pair);
    if (it2 != myMap2->end())
    {
      curList = (*it2).second;
      if (setCurIter(curList)) {mySetNumber = 3; return ((*curIterator)->getIE());};
    }
    pair.first = mid;
   it2 = myMap2->find(pair);
    if (it2 != myMap2->end())
    {
      curList = (*it2).second;
      if (setCurIter(curList)) {mySetNumber = 4; return ((*curIterator)->getIE());}; 
    }
    PIE result; return result; 
  }
  

  /**
   * returns the current object with varlist contained
   * in the given variables;
   * if \ref firstObjectInVars was not called, this 
   * function may return garbage
   */
  PIE currentObjectInVars()
  {
    return ((*curIterator)->getIE());
  }

  /**
   * return the next object with varlist contained in the given variables
   */
  PIE nextObjectInVars()
  {
    do
    {
      ++curIterator;
      if (curIterator == curList->end()) break;
    }
    while ((*curIterator)->isDeleted());
    if (curIterator != curList->end()) 
    {
      return ((*curIterator)->getIE());
    }    
    TLongPair pair; typename TMap2::iterator it2;  
    if (mySetNumber <=1)
    {    
      pair.first = curTriple.first.first; pair.second = curTriple.first.second;
      it2 = myMap2->find(pair);
      if (it2 != myMap2->end())
      {
        curList = (*it2).second;
        if (setCurIter(curList)) {mySetNumber = 2; return ((*curIterator)->getIE());};
      }
    }
    if (mySetNumber <= 2)
    {
      pair.first = curTriple.first.first; pair.second = curTriple.second; 
      it2 = myMap2->find(pair);
      if (it2 != myMap2->end())
      {
        curList = (*it2).second;
        if (setCurIter(curList)) {mySetNumber = 3; return ((*curIterator)->getIE());};
      }
    }
    if (mySetNumber <= 3)
    {
      pair.first = curTriple.first.second; pair.second = curTriple.second; 
      
      it2 = myMap2->find(pair);
      if (it2 != myMap2->end())
      {
        curList = (*it2).second;
        if (setCurIter(curList)) {mySetNumber = 4; return ((*curIterator)->getIE());}; 
      }
    }
    PIE result; return result;        
  }

  /**
   * check whether this is the last object
   */
  bool isLastObjectInVars()
  {
    return (curIterator == curList->end());
  }

  /**
   * increase counters of boolean clauses depending on the input clause
   */
  void incCounters(PIE ie)
  {
      VarList *vlist = ie->getVList();
      VarList::iterator viter = vlist->begin();
      VarList::iterator vend = vlist->end();
 
      while (viter != vend)
      {
        ++myGeneralCounters->at((*viter));
        if (!ie->getObject()->hasOneEquality())
        {
          ++myCounters->at((*viter));
        }
        if (ie->getObject()->isPositive(*viter))
          ++myPositiveCounters->at((*viter));
        if (ie->getObject()->isNegative(*viter))
          ++myNegativeCounters->at((*viter));
        ++viter;
      }
  }

  /**
   * increase counters of boolean clauses depending on the input clause
   * alternative interface
   */
  void incCounters(IE *ie)
  {
      VarList *vlist = ie->getVList();
      VarList::iterator viter = vlist->begin();
      VarList::iterator vend = vlist->end();
 
      while (viter != vend)
      {
        ++myGeneralCounters->at((*viter));
        if (!ie->getObject()->hasOneEquality())
        {
          ++myCounters->at((*viter));
        }
        if (ie->getObject()->isPositive(*viter))
          ++myPositiveCounters->at((*viter));
        if (ie->getObject()->isNegative(*viter))
          ++myNegativeCounters->at((*viter));
        ++viter;
      }
  }

  /**
   * check whether the variable with this number is contained in a non-unit
   * clause
   */
  bool isVariableInNonUnitClause(long num)
  {
    return (myCounters->at(num) > 0);
  }

  /**
   * check whether the given variable is contained in a unit clause
   */
  bool isVariableInUnitClause(long num)
  {
    return (myGeneralCounters->at(num) > myCounters->at(num));
  }

  /// return the number of positive occurrences for the given variable
  long getPositiveOccurrences(long num)
  {
    return myPositiveCounters->at(num);
  }

  /// return the number of negative occurrences for the given variable
  long getNegativeOccurrences(long num)
  {
    return myNegativeCounters->at(num);
  }

  /**
   * return the number of non-unit-clause occurrences for a given variable
   */
  bool getNumberOfNonUnitOccurrences(Variable num)
  {
    return myCounters->at(num);
  }
  
  /**
   * return the number of unit-clause occurrences for a given variable
   */
  bool getUnitOccurrences(Variable num)
  {
    return (myGeneralCounters->at(num) - myCounters->at(num));
  }

  /**
   * return the number of occurrences for a given variable
   */
  long int getOccurrenceCounter(long num)
  {
    return (myGeneralCounters->at(num));
  }

 
  /**
   * return the number of variables
   */
  long int getVarNum() {return myVarNum;};

  /**
   * get begin iterator for a variable by number
   */
  PSimpleObjectIterator begin(long int num);

  /**
   * set current iterator for a given IEList
   */
  bool setCurIter(IEList *list);
  
  /**
   * get an end iterator for a given variable number
   */
  PSimpleObjectIterator end(long int num);
  
  /**
   * Adds a clause to the index
   */
  void addElement(PIE ie);

  /**
   * removes the element from the index
   * currently this is needed only to decrease counters of non-unit clauses
   */
  void remove(PT obj)
  {
    {
      PVarList vlist = obj->getVariableList();
      VarList::iterator viter = vlist->begin();
      VarList::iterator vend = vlist->end();
      while (viter != vend)
      { 
        --myGeneralCounters->at((*viter));
        if (!obj->hasOneEquality())
          --myCounters->at((*viter));
        if (obj->isPositive(*viter))
          --myPositiveCounters->at((*viter));
        if (obj->isNegative(*viter))
          --myNegativeCounters->at((*viter));
        ++viter;
      }
    }
  }

  /**
   * Push back a new index element (variable).
   */
  void addVariable();
  
  /**
   * return whether a variable is present in the current index
   */
  bool isPresent(long num) 
  {
    return myGeneralCounters->at(num);
  };

  /**
   * call this function to stop supporting the index that organizes all
   * boolean equalities with <=3 variables by those variables
   */  
  void forgetThreeVarIndex() {supportThreeVarIndex = false;};
  
  /**
   * get begin iterator on index given by parameter
   */
  PSimpleObjectIterator getBegin(TIndexType index) const {
    PSimpleObjectIterator res(new SimpleObjectIterator<T>(ind[index]->begin(),ind[index]));
    return res;
  };

 
  /**
   * get end iterator on index given by parameter
   */
  PSimpleObjectIterator getEnd(TIndexType index) const {
    PSimpleObjectIterator res(new SimpleObjectIterator<T>(ind[index]->end(),ind[index]));
    return res;
  };

  /// test print for debug
  void testPrint(Variable var,BooleanAlgebraicSolver *slv)
  {
    IEIterator it = myVector->at(var)->begin();
    IEIterator end = myVector->at(var)->end();
    std::cout << "Test print for index on var p" << var << "\n";
    std::cout << "Deleted iterator is pointing to ";
    if (myDelVector->at(var) == end) std::cout << "END\n";
    else 
    {
      (*(myDelVector->at(var)))->getObject()->print(std::cout, slv);
      std::cout << "\n";
    }

    std::cout << "Test print for index number " << var << "\n";
    while (it != end)
    {
      if ((*it)->isUnadded()) std::cout << "  UNADDED";
      else
      {
        ((*it)->getObject())->print(std::cout, slv);
        if ((*it)->isDeleted()) std::cout << "  DELETED";
        if ((*it)->isDeletedAtEnd()) std::cout << "  AT END";
      }
      std::cout << "\n";
      ++it;
    }
  }
 
  /// test print for debug
  void testPrint(TIndexType t,BooleanAlgebraicSolver *slv)
  {
    IEIterator it = ind[t]->begin();
    IEIterator end = ind[t]->end();
    std::cout << "Test print for index number " << t << "\n";
    std::cout << "Deleted iterator is pointing to ";
    if (iter[t] == end) std::cout << "END\n";
    else 
    {
      (*(iter[t]))->getObject()->print(std::cout, slv);
      std::cout << "\n";
    }

    std::cout << "Test print for index on type " << t << "\n";
    while (it != end)
    {
      if ((*it)->isUnadded()) std::cout << "  UNADDED";
      else
      {
        ((*it)->getObject())->print(std::cout, slv);
        if ((*it)->isDeleted()) std::cout << "  DELETED";
        if ((*it)->isDeletedAtEnd()) std::cout << "  AT END";
      }
      std::cout << "\n";
      ++it;
    }
  }
 

 /**
   * dumps the lists to the output stream
   * implemented for debug only
   */
  std::ostream& print(std::ostream& os);
 
  /**
   *  returns an iterator for a given left-hand side variable number
   */
  boost::shared_ptr<SimpleObjectIterator<T> > SimpleObjectIndex<T>::getLHSbegin(long int num) const
  {
    IEIterator citer = (myLHSVector->at(num))->begin();
    if (citer != (myLHSVector->at(num))->end())
    {
      while ((*citer)->isDeleted())
      {
        ++citer;
        if (citer == (myLHSVector->at(num))->end()) break;
      }
    }
    PSimpleObjectIterator res(new SimpleObjectIterator<T>(citer,myLHSVector->at(num)));
    return res;
  }


  /**
   * returns an end iterator for a given left-hand side variable number
   */
  boost::shared_ptr<SimpleObjectIterator<T> > SimpleObjectIndex<T>::getLHSend(long int num) const
  {
    IEIterator citer = (myLHSVector->at(num))->end();
    PSimpleObjectIterator res(new SimpleObjectIterator<T>(citer,myLHSVector->at(num)));
    return res;
  } 


  /**
   * Destructor
   */
  ~SimpleObjectIndex();

  /// a garbage collector
  void collectGarbage()
  {
    PSimpleObjectIterator it, end;
    for (int i=1; i<=myVarNum; ++i)
    {
      it = this->begin(i);
      end = this->end(i);
      while (!it->equals(*end))
        ++*it;
    }

    TIndexType j = indGeneral;
    
    while (j<INDICES_NUM)
    {
      it = this->getBegin(j);
      end = this->getEnd(j);
      while (!it->equals(*end))
        ++*it;
      j = TIndexType(j+1);
    }
  }
  
  /**
   * Unadds the given \ref IndexElement from indices
   */
  void unAddFromIndices(IE *ie)
  {
  
    for (typename std::list<Variable>::iterator it = ie->getVList()->begin();it!=ie->getVList()->end();++it)
    {
      if (myDelVector->at(*it) == myVector->at(*it)->end()) continue;
      TRACE("unaddfromindices",std::cout << "  index on var p" << *it << " ";
          flush(std::cout);
          std::cout << (*(myDelVector->at(*it)))->getObject()->getId() << "\n";);
      if (((*myDelVector->at(*it))->getObject()->getId()) == ie->getObject()->getId())
      {
        TRACE("unaddromindices", std::cout << *it << " ";);
        ++(myDelVector->at(*it));
      }
    }
    
    for (typename std::list<TIndexType>::iterator it = ie->getIndexList()->begin();it!=ie->getIndexList()->end();++it)
    {
      if (iter[*it] == ind[*it]->end()) continue;
      TRACE("unaddfromindices",std::cout << "  index " << *it << " ";
          flush(std::cout);
          std::cout << (*iter[*it])->getObject()->getId() << "\n";);
      if (((*iter[*it])->getObject()->getId()) == ie->getObject()->getId())
      {
        TRACE("unaddromindices", std::cout << *it << " ";);
        ++(iter[*it]);
      }
    }
   TRACE("unaddfromindices", std::cout << "Done.\n"; flush(std::cout););
  }
  

  /**
   * checks that the AT END iterator is good in all indices
   */
  void checkInvariants()
  {
    typename std::list<PTIE>::iterator it, end;
    for (unsigned int i=1; i<myDelVector->size(); ++i)
    {
      it = myDelVector->at(i);
      end = myVector->at(i)->end();
      while (it != end)
      {
        if (!(*it)->isDeletedAtEnd())
          std::cout << "BAD in index on variable p" << i << "\n";
        ++it;
      }
    }
    for (int i=indEqualities; i<indLast; ++i)
    {
      it = iter[i];
      end = ind[i]->end();
      while (it != end)
      {
        if (!(*it)->isDeletedAtEnd())
          std::cout << "BAD in index number " << i << "\n";
        ++it;
      }
    }
  }
  
  /**
   * Unerases the given \ref IndexElement from indices
   */
  void unEraseFromIndices(IE *ie)
  {
    long id1,id2; 
    IEIterator tempit;

    for (typename std::list<Variable>::iterator it = ie->getVList()->begin();it!=ie->getVList()->end();++it)
    {
      if (myDelVector->at(*it) == myVector->at(*it)->end()) continue;
      
      if (!((*myDelVector->at(*it)).get())) continue;
      if (!((*myDelVector->at(*it))->getObject().get())) continue;
 
      id1 = ((*myDelVector->at(*it))->getObject()->getId());
      id2 = ie->getObject()->getId();
      
      tempit = myDelVector->at(*it);
      while (  (tempit != myVector->at(*it)->end()) )
      {
        if ((*tempit)->isUnadded())
          tempit = myVector->at(*it)->erase(tempit);
        else if (id2 == (*tempit)->getObject()->getId())
        {
          break;
        }
        else
          ++tempit;
      }

      if (tempit != myVector->at(*it)->end())
      {
        (*myDelVector->at(*it))->unDeleteAtEnd();
        while (  (myDelVector->at(*it) != myVector->at(*it)->end()) &&  ((*myDelVector->at(*it))->getObject()->getId() != id2)   )
        {
          if ((*myDelVector->at(*it))->isUnadded())
            myDelVector->at(*it) = myVector->at(*it)->erase(myDelVector->at(*it));
          else
          {
            (*myDelVector->at(*it))->unDeleteAtEnd();
            ++(myDelVector->at(*it));
          }
        }
        if (myDelVector->at(*it) != myVector->at(*it)->end())
        {
          (*myDelVector->at(*it))->unDeleteAtEnd();
          ++(myDelVector->at(*it));
        }
      }
    }
    
    for (typename std::list<TIndexType>::iterator it = ie->getIndexList()->begin();it!=ie->getIndexList()->end();++it)
    {
           
      if (iter[*it] == ind[*it]->end()) continue;
      if (!((*iter[*it]).get())) continue;
      if (!((*iter[*it])->getObject().get())) continue;
      id1 = ((*iter[*it])->getObject()->getId());
      id2 = ie->getObject()->getId();

      tempit = iter[*it];
      while (  (tempit != ind[*it]->end()) )
      {
        if ((*tempit)->isUnadded())
          tempit = ind[*it]->erase(tempit);
        else if (id2 == (*tempit)->getObject()->getId())
        {
          break;
        }
        else
          ++tempit;
      }

      if (tempit != ind[*it]->end())
      {
        (*iter[*it])->unDeleteAtEnd();
        while (  (iter[*it] != ind[*it]->end()) &&  ((*iter[*it])->getObject()->getId() != id2)   )
        {
          if ((*iter[*it])->isUnadded())
            iter[*it] = ind[*it]->erase(iter[*it]);
          else
          {
            (*iter[*it])->unDeleteAtEnd();
            ++(iter[*it]);
          }
        }
        if (iter[*it] != ind[*it]->end())
        {
          (*iter[*it])->unDeleteAtEnd();
          ++(iter[*it]);
        }
      }
    }
  }

  /// return the iterator for deletion
  IEIterator *getDeletedIterator(TIndexType type) const
  {
    return &(iter[type]);
  }

private:

  /**
   * number of variables
   */	
  long int myVarNum;

  /**
   * index by one variable
   */
  TVector *myVector;

  /**
   * index by the left-hand side variable
   */
  TVector *myLHSVector;

  /**
   * index for boolean clauses with three variables
   */
  TMap3 *myMap3;

  /**
   * index for boolean clauses with two variables
   */
  TMap2 *myMap2;
  
  /**
   * current iterator (for the "subset of three vars" index)
   */
  typename IEList::iterator curIterator;
  /**
   * current set number (for the "subset of three vars" index)
   */  
  int mySetNumber;
  
  /**
   * current triple of variable numbers (for the "subset of three vars" index)
   */
  TLongTriple curTriple;
  
  /**
   * current list (for the "subset of three vars" index)
   */
  IEList *curList;
  
  /**
   * if this is on, the "subset of three vars" index is supported; otherwise,
   * newly added objects are not dispatched into that index
   */
  bool supportThreeVarIndex;

  /**
   * vector of counters of non-unit clauses
   */
  TCounterVector *myCounters;

  /// vector of counters of positive occurrences
  TCounterVector *myPositiveCounters;

  /// vector of counters of negative occurrences
  TCounterVector *myNegativeCounters;

  /**
   * vector of counters for all clauses
   */
  TCounterVector *myGeneralCounters;

  /**
   * array of indices
   */
  IEList* ind[INDICES_NUM];

  /**
   * array of iterators to the last not deleted object
   */
  IEIterator iter[INDICES_NUM];

  /// iterators
  TIterVector *myDelVector;
  
};

/**
 * Destructor
 */
template <class T> SimpleObjectIndex<T>::~SimpleObjectIndex()
{
  this->clear();
  for (int i=0; i<myVarNum+1; i++)
  {
    delete myVector->at(i);
    delete myLHSVector->at(i);
  }
  delete myVector;
  delete myDelVector;
  delete myLHSVector;
  delete myCounters;
  delete myPositiveCounters;
  delete myNegativeCounters;
  delete myGeneralCounters;
  delete myMap3;
  delete myMap2;
  for (int i=0; i<INDICES_NUM; ++i)
  {
    delete ind[i];
  }
}

/**
 *  Constructs the index
 */
template <class T> SimpleObjectIndex<T>::SimpleObjectIndex(long int num)
{
    myVarNum = num;
    myVector = new TVector(num+1);
    myDelVector = new TIterVector(num+1);
    myLHSVector = new TVector(num+1);
    myMap3 = new TMap3();
    myMap2 = new TMap2();
    supportThreeVarIndex = true;
    for (int i=0; i<INDICES_NUM; ++i)
    {
      ind[i] = new IEList();
      iter[i] = ind[i]->begin();
    }
   
    myCounters = new TCounterVector(num+1);
    myPositiveCounters = new TCounterVector(num+1);
    myNegativeCounters = new TCounterVector(num+1);
    myGeneralCounters = new TCounterVector(num+1);
    for (int i=0; i< num+1; i++)
    {
      myVector->at(i) = new std::list<boost::shared_ptr<TinyIndexElement<T> > >;
      myDelVector->at(i) = myVector->at(i)->begin();
      myLHSVector->at(i) = new std::list<boost::shared_ptr<TinyIndexElement<T> > >;
      myCounters->at(i) = 0;
      myPositiveCounters->at(i) = 0;
      myNegativeCounters->at(i) = 0;
      myGeneralCounters->at(i) = 0;
    }
}


/**
 * Push back a new index element (variable).
 */
template <class T> void SimpleObjectIndex<T>::addVariable()
{
  myVarNum++;
  myVector->push_back(new std::list<boost::shared_ptr<TinyIndexElement<T> > >);
  myDelVector->push_back(myVector->at(myVarNum)->begin());
  myLHSVector->push_back(new std::list<boost::shared_ptr<TinyIndexElement<T> > >);
  myCounters->push_back(0);
  myPositiveCounters->push_back(0);
  myNegativeCounters->push_back(0);
  myGeneralCounters->push_back(0);
}

/**
 * Adds a clause to the index
 */
template <class T> void SimpleObjectIndex<T>::addElement(PIE ie)
{
  TRACE("toindex",std::cout << "trying to add "; ie->getObject()->print(std::cout,0); std::cout << "\n";);
  PVarList pvl = ie->getObject()->getVariableList();
  Variable x;
  VarList::iterator viter = pvl->begin();
  while (viter!=pvl->end())
  {
    
    PTIE tie(new TIE(ie,&(myDelVector->at(*viter))));
    myVector->at((*viter))->push_front(tie);
    ie->getVList()->push_back(*viter);
    ++viter;
  }

  if (ie->getObject()->hasOneEquality())
  {
    PTIE tie2(new TIE(ie,&iter[indEqualities]));
    ind[indEqualities]->push_front(tie2);
    ie->getIndexList()->push_back(indEqualities);
    switch (ie->getObject()->getEqType())
    {
      case eqt11m1:
        {
          PTIE tie(new TIE(ie,&iter[indOneOneMinusOne]));
          ind[indOneOneMinusOne]->push_front(tie);
          ie->getIndexList()->push_back(indOneOneMinusOne); 
          break;
        }
        
      case eqt11m2:
        {
          PTIE tie(new TIE(ie,&iter[indOneOneMinusTwoWConst]));
          ind[indOneOneMinusTwoWConst]->push_front(tie);
          ie->getIndexList()->push_back(indOneOneMinusTwoWConst);

          PTIE tie2(new TIE(ie,&iter[indOneOneMinusTwo]));
          ind[indOneOneMinusTwo]->push_front(tie2);
          ie->getIndexList()->push_back(indOneOneMinusTwo);
          break;
        }
      
      case eqtXeqAB:
        {
          PTIE tie(new TIE(ie,&iter[indXeqAB]));
          ind[indXeqAB]->push_front(tie);
          ie->getIndexList()->push_back(indXeqAB);
          break;
        }

      case eqtXeqABpACpBCm2ABC:
        {
          PTIE tie(new TIE(ie,&iter[indXeqABpACpBCm2ABC]));
          ind[indXeqABpACpBCm2ABC]->push_front(tie);
          ie->getIndexList()->push_back(indXeqABpACpBCm2ABC);
          break;
        }
   
      case eqtDeqABpACmABC:
        {
          PTIE tie(new TIE(ie,&iter[indDeqABpACmABC]));
          ind[indDeqABpACmABC]->push_front(tie);
          ie->getIndexList()->push_back(indDeqABpACmABC);
          break;
        }
   
      case eqt124:
        {
          PTIE tie(new TIE(ie,&iter[ind124]));
          ind[ind124]->push_front(tie);
          ie->getIndexList()->push_back(ind124);
          break;
        }
    
      case eqtABeq0:
        {
          PTIE tie(new TIE(ie,&iter[indABeq0]));
          ind[indABeq0]->push_front(tie);
          ie->getIndexList()->push_back(indABeq0);
          
          PTIE tie2(new TIE(ie,&iter[indTwoClauses]));
          ind[indTwoClauses]->push_front(tie2);
          ie->getIndexList()->push_back(indTwoClauses);
          break;
        }
   
      case eqtWeqXmXYZ:
        {
          PTIE tie(new TIE(ie,&iter[indWeqXmXYZ]));
          ind[indWeqXmXYZ]->push_front(tie);
          ie->getIndexList()->push_back(indWeqXmXYZ);
          break;
        }
        
      case eqtXeqABC:
        {
          PTIE tie(new TIE(ie,&iter[indXeqABC]));
          ind[indXeqABC]->push_front(tie);
          ie->getIndexList()->push_back(indXeqABC);
          break;
        }
        
      case eqtZeqWXpVXm2WVX:
        {
          PTIE tie(new TIE(ie,&iter[indZeqWXpVXm2WVX]));
          ind[indZeqWXpVXm2WVX]->push_front(tie);
          ie->getIndexList()->push_back(indZeqWXpVXm2WVX);
          break;
        }
        
      case eqtSeqXpVnWm2XWnV:
        {
          PTIE tie(new TIE(ie,&iter[indSeqXpVnWm2XWnV]));
          ind[indSeqXpVnWm2XWnV]->push_front(tie);
          ie->getIndexList()->push_back(indSeqXpVnWm2XWnV);
          break;
        }

      case eqtCeqWXYpnWnXY:
        {
          PTIE tie(new TIE(ie,&iter[indCeqWXYpnWnXY]));
          ind[indCeqWXYpnWnXY]->push_front(tie);
          ie->getIndexList()->push_back(indCeqWXYpnWnXY);
          break;
        }
      
      case eqtCeqXZmXYpnWYnZp2WXYnZ:
        {
          PTIE tie(new TIE(ie,&iter[indCeqXZmXYpnWYnZp2WXYnZ]));
          ind[indCeqXZmXYpnWYnZp2WXYnZ]->push_front(tie);
          ie->getIndexList()->push_back(indCeqXZmXYpnWYnZp2WXYnZ);
          break;
        }
        
      case eqtCeqYnWYxorZ:
        {
          PTIE tie(new TIE(ie,&iter[indCeqYnWYxorZ]));
          ind[indCeqYnWYxorZ]->push_front(tie);
          ie->getIndexList()->push_back(indCeqYnWYxorZ);
          break;
        }

      case eqtBoothSubResult2:
        {
          PTIE tie(new TIE(ie,&iter[indBoothSubResult2]));
          ind[indBoothSubResult2]->push_front(tie);
          ie->getIndexList()->push_back(indBoothSubResult2);
          break;
        }
    
      case eqtBoothSubResult:
        {
          PTIE tie(new TIE(ie,&iter[indBoothSubResult]));
          ind[indBoothSubResult]->push_front(tie);
          ie->getIndexList()->push_back(indBoothSubResult);
          break;
        }
        
      case eqtYeqACpDmACD:
        {
          PTIE tie(new TIE(ie,&iter[indYeqACpDmACD]));
          ind[indYeqACpDmACD]->push_front(tie);
          ie->getIndexList()->push_back(indYeqACpDmACD);
          break;
        }

      case eqtVeqYZLS:
      case eqtVeqYZnotLS:
        {
          PTIE tie(new TIE(ie,&iter[indVeqYZLS]));
          ind[indVeqYZLS]->push_front(tie);
          ie->getIndexList()->push_back(indVeqYZLS);
          break;
        }
        
      default:
        break;
    }

   
   if (ie->getObject()->isDeg2Even())
   {
     PTIE tie(new TIE(ie,&iter[indDeg2Even]));
     ind[indDeg2Even]->push_front(tie);
     ie->getIndexList()->push_back(indDeg2Even);
   }
   if (ie->getObject()->isLin2Subject())
   {
     PTIE tie(new TIE(ie,&iter[indLin2]));
     ind[indLin2]->push_front(tie);
     ie->getIndexList()->push_back(indLin2);     
   }
   if (ie->getObject()->getLHSVariable(x))
   {
     PTIE tie(new TIE(ie));
     myLHSVector->at(x)->push_back(tie);
   }

  }

  if (ie->getObject()->getNumberOfLiterals() == 2) 
  {   
    
    TRACE("ind2clauses",std::cout << "adding "; ie->getObject()->print(std::cout,0););
    PTIE tie(new TIE(ie,&iter[indTwoClauses]));
    ind[indTwoClauses]->push_front(tie);
    ie->getIndexList()->push_back(indTwoClauses);   
  }


  
  this->incCounters(ie);
      
  if (supportThreeVarIndex)
  {
    TLongTriple trip;
    if (ie->getObject()->isBooleanThreeVariables(trip.first.first,trip.first.second,trip.second))
    {
      add3Map(ie,trip);
    }
    else  
    {
      TLongPair pair;
      if (ie->getObject()->isBooleanTwoVariables(pair.first,pair.second))
      {
        add2Map(ie,pair);
      }
    }
  }
}

/**
 *  returns an iterator for a given IEList
 */
template <class T> bool SimpleObjectIndex<T>::setCurIter(IEList *list)
{
  curIterator = list->begin();
  if (curIterator != list->end())
  {
    while ((*curIterator)->isDeleted())
    {
      ++curIterator;
      if (curIterator == list->end()) break;
    }
  }
  return (!(curIterator == list->end()));
}




/**
 *  returns an iterator for a given variable number
 */
template <class T> boost::shared_ptr<SimpleObjectIterator<T> > SimpleObjectIndex<T>::begin(long int num)
{
  PSimpleObjectIterator res(new SimpleObjectIterator<T>(myVector->at(num)->begin(),myVector->at(num)));
  return res;
}


/**
 * returns an end iterator for a given variable number
 */
template <class T> boost::shared_ptr<SimpleObjectIterator<T> > SimpleObjectIndex<T>::end(long int num)
{
  PSimpleObjectIterator res(new SimpleObjectIterator<T>(myVector->at(num)->end(),myVector->at(num)));
  return res;
}

/**
 * localization of \ref SimpleObjectIndex for \ref DeductionObject
 */
typedef SimpleObjectIndex<DeductionObject> DeductionObjectIndex;
/**
 * smart pointer for \ref DeductionObjectIndex
 */
typedef boost::shared_ptr<DeductionObjectIndex> PDeductionObjectIndex;

/**
 * localization of \ref SimpleObjectIndex for \ref ModificationObject
 */
typedef SimpleObjectIndex<ModificationObject> ModificationObjectIndex;
/**
 * smart pointer for \ref ModificationObjectIndex
 */
typedef boost::shared_ptr<ModificationObjectIndex> PModificationObjectIndex;

#endif
