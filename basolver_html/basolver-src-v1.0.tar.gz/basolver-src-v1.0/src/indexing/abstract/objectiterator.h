#ifndef __OBJECTITERATOR_H__
#define __OBJECTITERATOR_H__

/**
 * @file indexing/abstract/objectiterator.h
 * @brief The header for the DeductionObjectIterator class
 * @author sergey
 */

#include "../../basicobject/dedobj.h"
#include "../../basicobject/modobj.h"

/**
 * @class SimpleObjectIterator
 * @brief A template class that allows to
 * iterate over different types of objects.
 */
template <class T>
class SimpleObjectIterator
{
 
public:
 
  /// smart pointer on the base class
  typedef boost::shared_ptr<T> PT;
  /// \ref IndexElement on the base class
  typedef IndexElement<T> IE;
  /// smart pointer for \ref IE
  typedef boost::shared_ptr<IE> PIE;
  /// \ref TinyIndexElement on the base class
  typedef TinyIndexElement<T> TIE;
  /// smart pointer for \ref TIE
  typedef boost::shared_ptr<TIE> PTIE;
  /// list of \ref PT
  typedef std::list<boost::shared_ptr<T> > TList;
  /// list of \ref PIE
  typedef std::list<PTIE> IEList;
  /// iterator on \ref TList
  typedef typename TList::iterator TIterator;
  /// iterator on \ref IEList
  typedef typename IEList::iterator IEIterator;
  /// const iterator on \ref IEList
  typedef typename IEList::const_iterator IEConstIterator;
  /// smart pointer for \ref SimpleObjectIterator on the base class
  typedef boost::shared_ptr<SimpleObjectIterator<T> > PSimpleObjectIterator;
 
  /// constructor
  SimpleObjectIterator()
  {
  }
  
  /**
   * A constructor
   */
  SimpleObjectIterator(const IEConstIterator iter, IEList *listRef) : myIterator(iter), myListRef(listRef)
  {
    if (myIterator!=myListRef->end())
    {
      if (!(*myIterator)->getDeletedIterator())
      {
        while ((*myIterator)->isDeleted())
        {
          ++myIterator;
          if (myIterator == myListRef->end()) break;
        }
      }
      else
      {

        
        bool removed = false;
        
        while ((*myIterator)->isDeleted())
        {
          if ((*myIterator)->isUnadded())
          {
            myIterator = myListRef->erase(myIterator);
            if (myIterator == myListRef->end())
              break;
            continue;
          }
          
          if ((*myIterator)->isDeletedAtEnd())
          {
            myIterator = myListRef->end();
            break;
          }
          else
          { 
            PTIE tempPTIE(*myIterator);
            if (tempPTIE->getDeletedIterator())
            {
              tempPTIE->setDeletedAtEnd();
              *(tempPTIE->getDeletedIterator()) = myListRef->insert(*(tempPTIE->getDeletedIterator()),tempPTIE);
              myIterator = myListRef->erase(myIterator);
              removed = true;
            }
          }
          if (!removed)
            ++myIterator;
          else
            removed = false;
          if (myIterator == myListRef->end()) break;
        }
      }
    }

  }
  
  /**
   * A constructor
   */
  SimpleObjectIterator(const IEIterator iter, IEList *listRef) : myIterator(iter), myListRef(listRef)
  {
    if (myIterator!=myListRef->end())
    {
      if (!(*myIterator)->getDeletedIterator())
      {
        while ((*myIterator)->isDeleted())
        {
          ++myIterator;
          if (myIterator == myListRef->end()) break;
        }
      }
      else
      {

      bool removed = false;
      while ((*myIterator)->isDeleted())
      {
        if ((*myIterator)->isUnadded())
        {
          myIterator = myListRef->erase(myIterator);
          if (myIterator == myListRef->end())
            break;
          continue;
        }

        if ((*myIterator)->isDeletedAtEnd())
        {
          myIterator = myListRef->end();
          break;
        }
        else
        { 
          PTIE tempPTIE(*myIterator);
          if (tempPTIE->getDeletedIterator())
          {
            tempPTIE->setDeletedAtEnd();
            *(tempPTIE->getDeletedIterator()) = myListRef->insert(*(tempPTIE->getDeletedIterator()),tempPTIE);
            myIterator = myListRef->erase(myIterator);
            removed = true;
          }
        }
        if (!removed)
          ++myIterator;
        else
          removed = false;
        if (myIterator == myListRef->end()) break;
      }
      
      }
    }
  }
 
  /**
   * dereference the iterator
   * to get what it's pointing to
   */
  PT operator *() {return (*myIterator)->getObject();};
 
  /**
   * update iterator without incrementing it
   */
  void update()
  {
    if (myIterator == myListRef->end()) return;
    if ( (*myIterator)->isDeleted() || (*myIterator)->isUnadded())
      this->plusplus();
  }

 
  /**
   * move iterator to the next object
   */
  void operator ++ () {this->plusplus();};

  /// increment the iterator
  void plusplus();
  
  /// equality test
  bool operator ==(const SimpleObjectIterator<T> &it) {return equals(it);};
  /// inequality test
  bool operator !=(const SimpleObjectIterator<T> &it) {return !equals(it);};

  /**
   * cloning
   */ 
  PSimpleObjectIterator clone() {
    PSimpleObjectIterator res(new SimpleObjectIterator<T>(myIterator,myListRef));
    return res;
  };
  
  /**
   * the inequality operator
   */
  bool equals(const SimpleObjectIterator<T> &);

  /**
   * test whether we are at end of list
   */
  bool isAtEnd() const {return (myIterator == myListRef->end());};

  /**
   * returns the index element
   */
  PIE getIE() {return ((*myIterator)->getIE());};

  /**
   * virtual destructor
   */
  ~SimpleObjectIterator() {};

  /**
   * return the iterator itself;
   * this is needed only for \ref TrivialObjectSet::remove()
   */
  IEIterator getIterator() {return myIterator;};
  
private:
  /// the iterator itself
  IEIterator myIterator;
  /// a reference to the list
  IEList *myListRef;

};

template <class T>
void SimpleObjectIterator<T>::plusplus()
{
 
//  IEIterator tit = myListRef->begin();
  if (myIterator == myListRef->end()) return;
  
  if (!(*myIterator)->getDeletedIterator())
  {
    do
    {
      ++myIterator;
      if (myIterator == myListRef->end()) break;
    }
    while ((*myIterator)->isDeleted());
 
    return;
  }
      
  

  bool removed = false;
  do
  {
    if (!removed)
      ++myIterator;
    else
      removed = false;
    
    if (myIterator == myListRef->end()) break;
 
    if ((*myIterator)->isUnadded())
    {
      myIterator = myListRef->erase(myIterator);
      if (myIterator == myListRef->end()) break;
      removed = true;
      continue;
    }
 
    if (!(*myIterator)->isDeleted()) return;
    
    if ((*myIterator)->isDeletedAtEnd())
    {
      myIterator = myListRef->end();
      break;
    }
    else
    { 
      if ((*myIterator)->getDeletedIterator())
      { 
        (*myIterator)->setDeletedAtEnd();
        *((*myIterator)->getDeletedIterator()) = myListRef->insert(*((*myIterator)->getDeletedIterator()),*myIterator);
        myIterator = myListRef->erase(myIterator);
        removed = true;
        if (myIterator == myListRef->end()) 
        {
          return;
        }
        
      }
    }
    
  }
  while ((*myIterator)->isDeleted());
}

template <class T>
bool SimpleObjectIterator<T>::equals(const SimpleObjectIterator<T> &iter)
{
  this->update();
  return (myIterator == iter.myIterator);
}

/**
 * localization of \ref SimpleObjectIterator for \ref DeductionObject
 */
typedef SimpleObjectIterator<DeductionObject> DeductionObjectIterator;
/**
 * smart pointer for \ref DeductionObjectIterator
 */
typedef boost::shared_ptr<DeductionObjectIterator> PDeductionObjectIterator;

/**
 * localization of \ref SimpleObjectIterator for \ref ModificationObject
 */
typedef SimpleObjectIterator<ModificationObject> ModificationObjectIterator;
/**
 * smart pointer for \ref ModificationObjectIterator
 */
typedef boost::shared_ptr<ModificationObjectIterator> PModificationObjectIterator;


#endif
