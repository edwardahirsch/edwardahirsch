#ifndef __MONOMIALITERATOR_H__
#define __MONOMIALITERATOR_H__

/**
 * @file indexing/monomialiterator.h
 * @brief The header for the MonomialIterator class
 * @author dmitrits
 */

#include "../algebraic/abstract/monomial.h"


/**
 * Forward declarations
 */
class MonomialIterator;
/**
 * smart pointer for \ref MonomialIterator
 */
typedef boost::shared_ptr<MonomialIterator> PMonomialIterator;


/**
 * @class MonomialIterator
 * @brief iterates over lists of monomials
 */
class MonomialIterator
{
  
public:
  
  /**
   * dereference the iterator
   * to get what it's pointing to
   */
  virtual PMonomial operator * () = 0;
  
  /**
   * move iterator to the next object
   */
  virtual void operator ++ () = 0;

  /**
   * move iterator to the previous object
   */
  virtual void operator -- () = 0;

  /**
   * comaprison iterator
   */
  virtual bool equals(const MonomialIterator &) const = 0;

  /**
   * virtual destructor
   */
  virtual ~MonomialIterator() {};
    
};

#endif
