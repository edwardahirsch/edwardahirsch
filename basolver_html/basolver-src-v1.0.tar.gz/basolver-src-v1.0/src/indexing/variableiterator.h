#ifndef __VARIABLEITERATOR_H__
#define __VARIABLEITERATOR_H__

/**
 * @file variableiterator.h
 * @brief The header for the VariableIterator class
 * @author dmitrits
 */

#include "../algebraic/abstract/variable.h"


/**
 * Forward declarations
 */
class VariableIterator;
/**
 * smart pointer for \ref VariableIterator
 */
typedef boost::shared_ptr<VariableIterator> PVariableIterator;

/**
 * @class VariableIterator
 * @brief iterates over variables
 */
class VariableIterator
{
  
public:
  
  /**
   * dereference the iterator
   * to get what it's pointing to
   */
  virtual Variable operator * () = 0;
  
  /**
   * move iterator to the next object
   */
  virtual void operator ++ () = 0;

  /**
   * the inequality operator
   */
  virtual bool equals(const VariableIterator &) const = 0;

  /**
   * virtual destructor
   */
  virtual ~VariableIterator() {};
    
};

#endif
