#include "variableiterator.h" 

/* @author sergey */
