#include "simplemonomialiterator.h"

/**
 * @author sergey 
 * @brief implementation for simplemonomialiterator.h
 **/

PMonomial SimpleMonomialIterator::operator *()
{
   return *myIterator;
}

bool SimpleMonomialIterator::equals(const MonomialIterator &iter) const
{
  const SimpleMonomialIterator& tmp = dynamic_cast<const SimpleMonomialIterator& >(iter);
  bool result = (myIterator == tmp.myIterator);
  return result;
 return true; 
}
