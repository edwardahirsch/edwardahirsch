#ifndef __SIMPLEMONOMIALITERATOR_H__
#define __SIMPLEMONOMIALITERATOR_H__

/**
 * @file indexing/simplemonomialiterator.h
 * @brief contains a simple implementation
 * for the MonomialIterator interface
 * @author dmitrits
 */

#include "monomialiterator.h"
#include "../misc/tracer.h"
#include <list>

/**
 * @class SimpleMonomialIterator
 * @brief implementation of the MonomialIterator class
 */
class SimpleMonomialIterator : public MonomialIterator
{
  
private:
  /// the iterator itself
  std::list<PMonomial>::iterator myIterator;
  
public:
  /**
   * Constructor
   */
  SimpleMonomialIterator(std::list<PMonomial>::iterator iter): myIterator(iter){};

  /**
   * dereference the iterator
   * to get what it's pointing to
   */
  PMonomial operator * ();

  /**
   * move iterator to the next object
   */
  void operator++ () {++myIterator;} ;

  virtual void operator -- () {--myIterator;};

  /**
   * equality test
   */
  bool equals(const MonomialIterator& saci) const;
  
  /**
   * return private implementation iterator (used for optimization)
   */
  std::list<PMonomial>::iterator getListIterator() {return myIterator;};
};

/**
 * smart pointer for \ref SimpleMonomialIterator
 */
typedef boost::shared_ptr<SimpleMonomialIterator> PSimpleMonomialIterator;

#endif
