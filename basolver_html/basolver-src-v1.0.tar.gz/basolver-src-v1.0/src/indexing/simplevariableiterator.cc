#include "simplevariableiterator.h"

/**
 * @author sergey 
 * @brief simplevariableiterator.h
 **/

Variable SimpleVariableIterator::operator *()
{
  std::pair<long int, Variable> pair=*myIterator;
  return pair.second;
}

bool SimpleVariableIterator::equals(const VariableIterator &iter) const
{
  const SimpleVariableIterator& tmp = dynamic_cast<const SimpleVariableIterator& >(iter);
  bool result = (myIterator == tmp.myIterator);
  return result;
 return true; 
}

