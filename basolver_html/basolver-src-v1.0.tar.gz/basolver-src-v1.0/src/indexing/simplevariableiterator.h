#ifndef __SIMPLEVARIABLEITERATOR_H__
#define __SIMPLEVARIABLEITERATOR_H__

/**
 * @file indexing/simplevariableiterator.h
 * @brief contains a simple implementation
 * for the VariableIterator interface
 * @author sergey
 */

#include "variableiterator.h"
#include "../misc/tracer.h"
#include <map>

/**
 * a map on \ref Variable
 */
typedef std::map<long int, Variable> VarMap; 
/**
 * smart pointer for \ref VarMap
 */
typedef boost::shared_ptr<VarMap> PVarMap;

/**
 * @class SimpleVariableIterator
 * @brief iterates over variable maps;
 * used for implementing monomials
 */
class SimpleVariableIterator : public VariableIterator
{
  
private:
  /// the iterator itself
  VarMap::iterator myIterator;
  
public:
  /// constructs from a standard map iterator
  SimpleVariableIterator(VarMap::iterator iter): myIterator(iter){};

  /**
   * dereference the iterator
   * to get what it's pointing to
   */
  Variable operator * ();

  /**
   * move iterator to the next object
   */
  void operator++ () {++myIterator;} ;

  /**
   * equality test
   */
  bool equals(const VariableIterator& saci) const;

};

#endif
