#include "genoptions.h"
#include "options.h"
#include "boost/tokenizer.hpp"
#include "config.h"
#include "misc/tracer.h"
#include <limits>
#include <sstream>
#include "misc/i2s.h"

/**
 * @file options.cc
 * @brief Contains implementation of Options methods.
 */
 
/* @author sergey */


bool
Options::parseOnOff(std::string name, bool given, char* value, bool defaultValue)
{
    if(given)
    {
        if(std::string(value) == "on")
        {
            return true;
        }
        else if (std::string(value) == "off")
        {
            return false;
        }
        else
        {
            reportFailure(std::string("Illegal value for the") + name + " option: " + value);
            return defaultValue;
        }
    }
    else
    {
        return defaultValue;
    }
}

bool
Options::readOptions(int argc, char** argv)
{
    //for (int i = 0; i < argc; i++) std::cerr << "\n" << argv[i];
    gengetopt_args_info args_info; 

    if(cmdline_parser(argc, argv, &args_info) != 0)
    {
        reportFailure("Failed to parse the command line\n");
    }

    if(args_info.inputs_num != 1 && args_info.inputs_num != 2)
    {
        reportFailure("Accepts one or two file names.");
    }

    if(args_info.nosets_given)
    {
      myNoSets = 1;
    }
    else
    {
      myNoSets = 0;
    }
    
    myFileName = string(args_info.inputs[0]);
    myFileName2 = "";
    if (args_info.inputs_num == 2)
    {
      myFileName2 = string(args_info.inputs[1]);
    }

    if (args_info.html_given)
    {
      myHtmlOutput = 1;
    }
    else
    {
      myHtmlOutput = 0;
    }
    
    if (args_info.booth_given)
    {
      myUseRulesForBooth = 1;
    }
    else
    {
      myUseRulesForBooth = 0;
    }
    
    
    if (args_info.equiv_given)
      myEquivChecking = true;
    else
      myEquivChecking = false;

#ifdef USE_TRACING
    if(args_info.trace_given)
    {
      std::string argString(args_info.trace_arg);
      boost::tokenizer<> tok(argString);
      
      for(boost::tokenizer<>::iterator beg=tok.begin(); beg!=tok.end();++beg)
      {
        std::cerr << "Trace set to " << *beg << std::endl;
        setTrace(*beg);  
      }
    }
#endif

    if (args_info.inputs_num != 2 && myEquivChecking)
    {
      this->reportFailure("--equiv option should be given together with two files");
    }
    
    
   
    myOptionsRead=true;
    return true;
}

void
Options::checkInternalState() const
{
    if(!myOptionsRead)
    {
        reportFailure("An attempt to access options before they are read");
    }
}

void
Options::reportFailure(std::string s ) const
{
    cmdline_parser_print_help();
    std::cerr << "\nCommand line parser error: " << s << "\n";
    exit(-1);
}

