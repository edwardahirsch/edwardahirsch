#ifndef __OPTIONS_H__
#define __OPTIONS_H__

#include <iostream>
#include <string>

#include "misc/exception.h"
#include "general/solveroptions.h"

/**
 * @file options.h
 * @brief Contains Options interface.
 */

    /** Exceptions in program options.
     */
    class OptionException : public Exception
    {
    public:
        virtual void 
        module(std::ostream& os) const
        {
            os << "Program options: ";
        }
    };

    /** The exception is raised when a wrong program option is given.
     */
    class WrongOption : public OptionException
    {
    private:
      /// option that is wrong
        const std::string myOption;
    public:
        /// A constructor.
        WrongOption(const std::string& option)
        : myOption (option)
        { }

        virtual void 
        what (std::ostream& os) const
        {
            os << myOption << std::endl;
        }
    };

/** This class is intended to be used as a flag store + a command line
 *  parser. See also the class \ref SolverOptions.
 */
class
Options
{
public:      
    /// Read the options from the command line
    bool
    readOptions(int argc, char** argv);

    /// The name of file to process
    const std::string&
    getFileName() const   { checkInternalState(); return myFileName; }

    /// The name of the second file (if any) to process.
    const std::string&
    getFileName2() const   { checkInternalState(); return myFileName2; }

    /// Returns whether we should create html output
    bool
    getHtmlOutput() const { checkInternalState(); return myHtmlOutput; }

    /// should we output the sets in html?
    bool
    getNoSets() const { checkInternalState(); return myNoSets; }

    /// should we check two input circuits for equivalence 
    bool
    getEquivChecking() const { checkInternalState(); return myEquivChecking; }


    /// should we use special rules for Booth multipliers?
    bool 
    getUseRulesForBooth() const { checkInternalState(); return myUseRulesForBooth; }
    
private:
    /// checks the internal state of the options machinery
    void
    checkInternalState() const;
    /// report a failure
    void
    reportFailure(std::string s ) const;

    /// name of the first file
    std::string
    myFileName;

    /// name of the second file
    std::string
    myFileName2;

    /// parse
    bool
    parseOnOff(std::string, bool, char*, bool);

    /// have we read the options?
    bool myOptionsRead;

    /// is html output on?
    bool myHtmlOutput;

    /// should we output the sets in html?
    bool myNoSets;

    /// should we use special rules for Booth multipliers?
    bool myUseRulesForBooth;
    
    /// should we check two input circuits for equivalence 
    bool myEquivChecking;
};

#endif //  __OPTIONS_H__
