#include "logical.h"

#include "../algebraic/implementation/booleanequality.h"
#include "implementation/simplesaclause.h"


/**
 * @file logical.cc
 * @brief Implementing LogicalGenerator class
 * @author sergey
 */


/**
 * Creating an empty clause
 */
PSAClause LogicalGenerator::makeSAClause()
{
  PSAClause pcla(new SimpleSAClause());
  return pcla;
}

/**
 * Creating a new deduction object
 */
PDeductionObject LogicalGenerator::makeDeductionObject()
{
  PDeductionObject res(new SimpleSAClause());
  return res;
}

/**
 * Creating a boolean literal
 */
PSALiteral LogicalGenerator::makeBoolLiteral(Variable var, bool pos)
{
  Assert(var>0, "Only a positive number is accepted as a variable number.");
  PSALiteral res(new BooleanEquality(var, pos));
  return res;
}


PModificationObject LogicalGenerator::makeUnitClause(Variable var, bool value)
{
  return AlgebraicGenerator::createBooleanEquality(var, value);
  /*PPolynomial left=AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial(var));
  PPolynomial right;
  if (value)
    right=AlgebraicGenerator::makePolynomial(AlgebraicGenerator::makeMonomial());
  else    
    right=AlgebraicGenerator::makePolynomial();
  PModificationObject res = boost::shared_dynamic_cast<ModificationObject,Equality>(AlgebraicGenerator::createEquality(left, right));
  return res;*/
}

