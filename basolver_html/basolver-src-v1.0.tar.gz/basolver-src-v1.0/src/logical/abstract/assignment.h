#ifndef __ASSIGNMENT_H__
#define __ASSIGNMENT_H__

/**
 * @file assignment.h
 * @author kulikov
 * @brief Contains an interface to Assignment class.
 */

#include <stdio.h>
#include "boost/smart_ptr.hpp"
#include "../../algebraic/abstract/variable.h"
#include "../../algebraic/abstract/coefficient.h"
#include "../../misc/statistics.h"
#include "../../basicobject/object.h"
#include <string>



/**
 * Forward declaration.
 */
class Assignment;
/**
 * Smart pointer to \ref Assignment.
 */
typedef boost::shared_ptr<Assignment> PAssignment;

/**
 * @class Assignment
 * @brief Contains Boolean values to variables. 
 */
class Assignment
{
public:
  /// Constructor.
  Assignment() {};
  
  /// Returns a value assigned to an input variable
  /// by this assignment (-1 if none assigned).
  virtual int  
  getValue(Variable var) const = 0;
  
  /// Adds a literal to this assignment.
  virtual void
  addLiteral(Variable var, bool sign) = 0; 
  
  /// The following three methods are needed 
  /// for iterating on all possible assignments 
  /// of Boolean values to variables of this assignment.
  
  /// Replaces all literals of this assignment by negative literals,
  /// that is, replaces values of the variables by {0, 0, ..., 0}.
  virtual void
  setToFirst() = 0;
  
  /// Sets to the next assignment in the standard order.
  /// E.g., replaces an assignment {0, 1, 0, 1} by {0, 1, 1, 0}.
  virtual void 
  setToNext() = 0;
  
  /// Checks whether this assignment is the last in the standard order
  /// (that is, whether it assigns 1 to all variables).
  virtual bool
  isEndAssignment() const = 0;
  
  /// Prints this assignment to a given stream.
  virtual std::ostream&
  print(std::ostream&) const = 0;
  
  /// Creates a copy of this assignment.
  virtual Assignment*
  clone() const = 0;
};

/**
 * Overloading the standard << operator
 */
extern std::ostream& operator<< (std::ostream& os, const Assignment& a);

#endif
