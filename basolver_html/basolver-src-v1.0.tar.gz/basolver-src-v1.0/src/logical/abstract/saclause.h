#ifndef __SACLAUSE_H__
#define __SACLAUSE_H__

#include "boost/smart_ptr.hpp"
#include "saliteral.h"
#include "basicobject/dedobj.h"
#include "algebraic/abstract/equality.h"

/**
 * @file saclause.h
 * @brief Declares the SAClause class.
 * @author sergey
 */

/**
 * Forward declarations
 */
class SAClause;
/**
 * smart pointer for \ref SAClause
 */
typedef boost::shared_ptr<SAClause> PSAClause;
/**
n* iterator for a list of \ref PSALiteral
 */
typedef std::list<PSALiteral>::iterator SALiteralIterator;

/**
 * @class SAClause
 * @brief A set of SALiterals linked with an OR.
 * \invariant
 *  - A clause does not contain a pair of equal saliterals, that is, 
 * literals of the same type (Equality, NonEquality, BoolLiteral)
 * for which the <tt>operator==</tt> of the corresponding class
 * returns the value <tt>True</tt>.   
 *  - A clause is not obviously satisfied.
 *  - A clause is not obviously unsatisfied.
 *  - A clause does not contain simultaneously a Boolean literal and a 
 * literal in the form of equality.
 * @see SALiteral
 */


class SAClause : public DeductionObject
{
public:
  
  /**
   * constructor with statistics
   */
  SAClause() {
  };
  
  /**
   * Deletes all literals
   */
  virtual void empty() = 0;
  
  /**
   * Returns true if clause has only one literal -- equality
   */

  virtual bool hasOneEquality() const = 0;
  
  /**
   * Assigns value val (zero-nonzero) to variable var
   * Returns:
   * ART_Active - clause still active
   * ART_Satisfiable - clause reduced to TRUE (should delete clause)
   * ART_Unsatisfiable - clause reduced to FALSE (whole formula is false)
   */
  virtual AssignReturnType assign(Variable var, int val) = 0;
  
  /**
   * Substitute one variable instead other (x:=y)
   * Returns:
   * ART_Active - clause still active
   * ART_Satisfiable - clause reduced to TRUE (should delete clause)
   * ART_Unsatisfiable - clause reduced to FALSE (whole formula is false)
   */
  virtual AssignReturnType substituteEqual(Variable x, Variable y) = 0;

  /**
   * Substitute negation of one variable instead other (x:=1-y)
   * Returns:
   * ART_Active - clause still active
   * ART_Satisfiable - clause reduced to TRUE (should delete clause)
   * ART_Unsatisfiable - clause reduced to FALSE (whole formula is false)
   */
  virtual AssignReturnType substituteNonEqual(Variable x, Variable y) = 0;

  virtual bool isPositive(long num) const = 0;
  virtual bool isNegative(long num) const = 0;
  

  /**
   * Prints the clause
   */
  virtual std::ostream& print(std::ostream&, BooleanAlgebraicSolver*,bool print_as_dedobj = false) = 0;
  
/**
   * Adds a literal to the clause
   * Parameter clone shows to clone literal or not
   */

  virtual void add(PSALiteral literal, bool clone)=0;


  /**
   * Adds a literal to the clause without cloning
   */
  virtual void add(PSALiteral) = 0;



  /**
   * Returns the list of variables occurring in the clause
   */
   virtual PVarList getVariableList() const = 0;

 /**
   * Returns the list of variables with respect to the
   * given option
   * @param rettype return type
   * @see TGetVar
   */
  virtual PVarList getVariableList(TGetVar rettype) const = 0;

  /// cloning
  virtual PSAClause clone() const = 0;

  /// clone as an ordinary pointer, not a smart one
  virtual SAClause *cloneAsPointer() const = 0;
 
  /**
   * Get begin iterator for literals
   */
  virtual SALiteralIterator begin() = 0;

  /**
   * Get end iterator for literals
   */
  virtual SALiteralIterator end() = 0;

  /**
   * delete a literal from the clause
   */
  virtual void deleteLiteral(SALiteralIterator) = 0;
  
  /**
   * Cloning method
   */
  virtual PDeductionObject cloneObject() const = 0;
  /// clone as an ordinary pointer to a \ref DeductionObject
  virtual DeductionObject *cloneAsObjPointer() const = 0;
  
  /**
   * Virtual destructor
   */
  virtual ~SAClause() {};
  
  /**
   * returns whether this clause consist of only boolean literals
   */
  virtual bool isBoolean()=0; 
  
  /**
   * returns the number of literals in this clause
   */
  virtual int getNumberOfLiterals() const = 0; 
  
  /**
   * Check if two clauses are boolean and conflict on exactly one literal
   */
  
  virtual bool canPerformResolution(SAClause& secondClause)=0; 
  
  /**
   * Returns resolvent of two clauses if it is possible. Otherwise returns 
   * empty clause.
   */
  
  virtual PSAClause getResolvent(SAClause& secondClause)=0; 
  
  /**
   * Compare two clauses
   */    
  
  virtual bool operator == (SAClause& secondClause) const =0; 
  
  /**
   * Check if this clause is subset of secondClause
   */    
  
  virtual bool isSubsetOf (SAClause& secondClause) const =0; 
  
  /**
   * Check if this clause is already satisfied.
   */    
  
  virtual bool isAlreadySatisfied() const=0;

  /**
   * Check if this clause is already unsatisfiable.
   */    
  
  virtual bool isUnsatisfiable() const=0;

  /**
   * checks whether this is one equality of degree 2 with even
   * coefficients of its degree 2 monomials
   */
  virtual bool isDeg2Even() const = 0;
  /**
   * Checks whether this is an equality of the form x=y+z-yz
   * assigns x,y,z to params
   */
  virtual bool getOneOneMinusOne(long &,long&,long&) const = 0;
  
  /**
   * Checks whether this is an equality of the form x=y+z-2yz
   * assigns x,y,z to params and checks whether the rhs has a 
   * constant and returns it
   */
  virtual bool getOneOneMinusTwoWConst(long &,long &,long &,bool &) const = 0;
 
  /**
   * Checks whether this is an equality of the form x=y+z-2yz
   * assigns x,y,z to params
   */
  virtual bool getOneOneMinusTwo(long &,long &,long &) const = 0;
  /**
   * Checks whether this is an equality of the form x=ab
   * assigns x,a,b to params
   */
  virtual bool getXeqAB(long &,long &,long &) const = 0;
  /**
   * Checks whether this is an equality of the form x=ab
   * assigns x,a,b to params; x,a,b may be literals
   */
  virtual bool getXeqAB(Variable &,bool &,Variable &,bool &,Variable &,bool &) const = 0;
  
  /**
   * Checks whether this is an equality of the given type
   */
  virtual bool isType(TEqualityType type) const = 0;

  /**
   * Returns first Equality, if first literal can be cast to Equality;
   * Otherwise returns empty pointer.
   */
  virtual PEquality getEquality() const=0;

  /**
   * returns true if this clause consists of two literals, each of which is
   * the negation of the given equality (that is, the given equalities are
   * \ref BooleanEquality
   */
  virtual bool isEqualToNegations(PEquality eq1, PEquality eq2) const = 0;

  virtual TEqualityType getEqType() const = 0;
  
  virtual bool getXeqABpACpBCm2ABC(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const = 0;
  virtual bool get124(Variable&,Variable&,Variable&,Variable&,bool&) const = 0;
  virtual bool getDeqABpACmABC(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const = 0;
  virtual bool getYeqACpDmACD(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const= 0;
  virtual bool isLin2Subject() const = 0;
  virtual bool getLin2Subject(Variable&,Variable&) const = 0;
  virtual bool getLin2Subject(Variable&,Variable&,Variable&,Coefficient&,Coefficient&,Coefficient&) const = 0;
  virtual bool getLHSVariable(Variable &) const = 0;
  virtual bool getYeqACpnAB(Variable &x, bool &px, Variable &a, bool &pa, Variable &c, bool &pc, Variable &b, bool &pb) const = 0;
 
  virtual bool isVarPresentAndNonAssigned(Variable x);
  
  virtual bool
  isSatisfiedBy(Assignment*) const = 0;
  
  virtual bool
  getBinaryClauseLiterals(int& lit1, int& lit2);
};

#endif
