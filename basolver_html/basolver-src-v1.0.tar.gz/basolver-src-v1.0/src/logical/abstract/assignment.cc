#include "assignment.h"

/**
 * @file assignment.cc
 * @author kulikov
 * @brief Contains implementation of several methods of the Assignment class.
 */


/**
 * Overloading the standard << operator
 */
extern std::ostream& operator<< (std::ostream& os, const Assignment& a)
{
  return (a.print(os));
}


