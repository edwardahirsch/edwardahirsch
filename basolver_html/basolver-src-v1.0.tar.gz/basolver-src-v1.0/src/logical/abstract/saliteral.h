#ifndef __SALITERAL_H__
#define __SALITERAL_H__

/**
 * @file saliteral.h
 * @author sergey
 * @brief Contains class description for the abstract SALiteral class (container for equalities)
 */

#include <stdio.h>
#include "boost/smart_ptr.hpp"
#include "../../algebraic/abstract/variable.h"
#include "../../algebraic/abstract/coefficient.h"
#include "../../misc/statistics.h"
#include "../../basicobject/object.h"
#include "logical/abstract/assignment.h"
#include "misc/assert.h"
#include <string>

class BooleanAlgebraicSolver;

/**
 * Forward declarations
 */
class SALiteral;
/**
 * smart pointer for \ref SALiteral
 */
typedef boost::shared_ptr<SALiteral> PSALiteral;

/**
 * @class SALiteral
 * @brief This class is a wrapper for objects that occur in \ref SAClause.
 * The only implementation currently supported for this class is \ref
 * Equality.
 * @see Equality
 */
class SALiteral
{

public:
 
  SALiteral() {
  };
  
  /**
   * assigns a value to a variable
   * input val as 0 or 1
   * returns:
   * ART_Active - the literal is still active
   * ART_Satisfiable - the literal is satisfied (should delete clause)
   * ART_Unsatisfiable - the literal is unsatisfied (should delete literal)
   */
  virtual AssignReturnType assign(Variable var, int val) = 0;
  
  /**
   * prints saliteral
   */
  virtual std::ostream& print(std::ostream& os,BooleanAlgebraicSolver *,bool print_as_dedobj = false) = 0;

  /**
   * clones saliteral
   */
  virtual PSALiteral clone() const = 0;

  /**
   * returns true if:
   * - it is a positive boolean literal
   * - it is an equality and its rhs equals to 1
   */
  virtual bool isPositive() const = 0;

  /// is this a boolean literal?
  virtual bool isBoolean() const = 0;
 
  /// returns the boolean variable of this literal
  /// if the literal is not boolean (by default) returns 0
  virtual long getBooleanVariable() const {return 0;};
 
  /// returns the boolean sign of this literal
  /// if the literal is not boolean (by default) returns false
  /// please check getBooleanVariable() before asking for boolean sign to
  /// assure that the literal is boolean
  virtual bool getBooleanSign() const {return false;};

  /**
   * returns the list of variables occurring
   * in the literal
   */
  virtual PVarList getVariableList() const = 0;

  /// get variable 1; applicable only for \ref TypedEquality
  /// returns 0 if there is no such variable
  virtual Variable getVar1() const 
  {
    Assert(0,"tried to get var not from typed equality");
    return 0;
  }; 
  
  /// get variable 2; applicable only for \ref TypedEquality
  /// returns 0 if there is no such variable
  virtual Variable getVar2() const 
  {
    Assert(0,"tried to get var not from typed equality");
    return 0;
  }; 
  
  /// get variable 3; applicable only for \ref TypedEquality
  /// returns 0 if there is no such variable
  virtual Variable getVar3() const 
  {
    Assert(0,"tried to get var not from typed equality");
    return 0;
  }; 
  
  /// get variable 4; applicable only for \ref TypedEquality
  /// returns 0 if there is no such variable
  virtual Variable getVar4() const 
  {
    Assert(0,"tried to get var not from typed equality");
    return 0;
  };
 
  /// get variable 5; applicable only for \ref TypedEquality
  /// returns 0 if there is no such variable
  virtual Variable getVar5() const 
  {
    Assert(0,"tried to get var not from typed equality");
    return 0;
  };

  /// get sign of variable 1 in the corresponding literal; applicable only for \ref TypedEquality
  /// please check whether the variable exists (getVar1() != 0); in the
  /// opposite case the output of this function is meaningless
  virtual bool getPos1() const 
  {
    Assert(0,"tried to get pos value not from typed equality");
    return true;
  };
 
  /// get sign of variable 2 in the corresponding literal; applicable only for \ref TypedEquality
  /// please check whether the variable exists (getVar2() != 0); in the
  /// opposite case the output of this function is meaningless
  virtual bool getPos2() const 
  {
    Assert(0,"tried to get pos value not from typed equality");
    return true;
  };
  
  /// get sign of variable 3 in the corresponding literal; applicable only for \ref TypedEquality
  /// please check whether the variable exists (getVar3() != 0); in the
  /// opposite case the output of this function is meaningless
  virtual bool getPos3() const 
  {
    Assert(0,"tried to get pos value not from typed equality");
    return true;
  };
  
  /// get sign of variable 4 in the corresponding literal; applicable only for \ref TypedEquality
  /// please check whether the variable exists (getVar4() != 0); in the
  /// opposite case the output of this function is meaningless
  virtual bool getPos4() const 
  {
    Assert(0,"tried to get pos value not from typed equality");
    return true;
  };

  /// get sign of variable 5 in the corresponding literal; applicable only for \ref TypedEquality
  /// please check whether the variable exists (getVar5() != 0); in the
  /// opposite case the output of this function is meaningless
  virtual bool getPos5() const 
  {
    Assert(0,"tried to get pos value not from typed equality");
    return true;
  };

  
  /**
   * virtual destructor
   */
  virtual ~SALiteral() {};
  
  /**
<<<<<<< saliteral.h
   * compares two literals.
   * We may have literals of differnet types therefore it is important
   * to change this method then we add new literal type.
   * Recently we operate only with equalities and boolean literals.
   */    
  
/*  bool  operator==(SALiteral& literal) const;
  bool  operator<(SALiteral& literal) const;     */
  
  /// compares two literals
  virtual bool operator == (SALiteral& literal) const=0;
  /// compares two literals
  bool operator!=(SALiteral& literal) const {return ! ((*this)==literal);};
  /// compares two literals
  virtual bool operator < (SALiteral& literal) const=0;


 

  /**
   * checks whether this has degree 2 and even coefficients of
   * its degree 2 monomials
   */
  virtual bool isDeg2Even() const {return false;};
  /**
   * checks whether this is one equality looking like x=a+b-2ab;
   * assigns x,a,b to params; checks whether the rhs has a
   * constant and returns this
   */
  virtual bool getOneOneMinusTwoWConst(long &x, long &a, long &b, bool &withconstant) const {return false;};
 
  /**
   * checks whether this is one equality looking like x=a+b-2ab;
   * assigns x,a,b to params
   */
  virtual bool getOneOneMinusTwo(long &x, long &a, long &b) const {return false;};

  /**
   * checks whether this is one equality looking like x=a+b-ab;
   * assigns x,a,b to params
   */
  virtual bool getOneOneMinusOne(long &x, long &a, long &b) const {return false;};
 
  /**
   * checks whether this is one equality looking like x=ab;
   * assigns x,a,b to params
   */
  virtual bool getXeqAB(long &,long &,long &) const {return false;};
 
  /**
   * checks whether this might be subject to Linearization2Rule,
   * namely, whether this has form of x = c1*a+c2*b+c3*ab,
   * where c1 and c2 might be zero; assigns a,b to params
   */ 
  virtual bool getLin2Subject(Variable&,Variable&) const {return false;};
  
  /**
   * checks whether this is one equality looking like
   * y = ac+d-acd; assigns the variables y,a,c,d to params
   */
  virtual bool getYeqACpnAB(Variable& y,bool&,Variable& a,bool&,Variable& c,bool&,Variable& b,bool&) const {return false;};
 
  
  /**
   * checks whether this is one equality looking like
   * y = ac+d-acd; assigns the variables y,a,c,d to params
   */
  virtual bool getYeqACpDmACD(Variable& a,bool&,Variable& b,bool&,Variable& c,bool&,Variable& d,bool&) const {return false;};
 
  /**
   * checks whether this is one equality looking like
   * d = ab + ac - abc; assigns the variables d,a,b,c to params
   */
  virtual bool getDeqABpACmABC(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const {return false;};

  /**
   * checks whether this is one equality looking like
   * y = a+b+c-2ab-2ac-2bc+4abc; assigns y,a,b,c to params
   */
  virtual bool get124(Variable&,Variable&,Variable&,Variable&,bool&) const {return false;};

  /**
   * checks whether this might be subject to Linearization2Rule,
   * namely, whether this has form of x = c1*a+c2*b+c3*ab,
   * where c1 and c2 might be zero
   */ 
  virtual bool isLin2Subject() const {return false;};
  
  /**
   * checks whether this might be subject to Linearization2Rule,
   * namely, whether this has form of x = c1*a+c2*b+c12*ab,
   * where c1 and c2 might be zero, assigns x,a,b,c1,c2,c12 to params
   */ 
  virtual bool getLin2Subject(Variable&,Variable&,Variable&,Coefficient&,Coefficient&,Coefficient&) const {return false;};
 
  /**
   * checks whether this is one equality looking like
   * x = ab+ac+bc-2abc; assigns x,a,b,c to params
   */
  virtual bool getXeqABpACpBCm2ABC(Variable&,bool&,Variable&,bool&,Variable&,bool&,Variable&,bool&) const {return false;};
 
  /**
   * checks whether this is one equality looking like x=ac+(1-a)b;
   * assigns x,a,c,b to params
   */
  virtual bool getXeqACpnAB(Variable &x, bool &px, Variable &a, bool &pa, Variable &c, bool &pc, Variable &b, bool &pb) const {return false;};
  
  /**
   * returns the number of the first variable occurring here
   */
  virtual long getFirstVariableNumber() const = 0;
  /**
   * checks whether lhs of this literal consists of one variable
   * and assigns this variable to parameter
   */
  virtual bool getLHSVariable(Variable &) const = 0;
  
  
  /// checks whether this 
  /// object contains a variable x.
  virtual bool 
  containsVar(Variable x) const;
 
  /// returns equality type of the literal
  virtual TEqualityType getEqType() const = 0;
  
  
  
  /**
   * checks whether this is one equality looking like x=ab;
   * assigns x,a,b to params;
   * new version for \ref TypedEquality
   */
  virtual bool getXeqAB(Variable &,bool &,Variable &,bool &, Variable &, bool &) const {return false;};
 
  // experimenting with TypedEquality
 
  /**
   * checks whether this is one equality looking like x=ab;
   * assigns x,a,b to params;
   * new version for \ref TypedEquality
   */
  virtual bool getXeqABnew(Variable &,bool &,Variable &,bool &, Variable &, bool &) const {return false;};
   
  /**
   * checks whether this is one equality looking like x=ab
   * new version for \ref TypedEquality
   */
  virtual bool isXeqABnew() const {return false;};
  
  /// checks whether an input variable is present 
  /// and non-assigned in this object (we say that 
  /// a variable x is assigned if this object is of the form
  /// either x=1 or x=y).
  virtual bool
  isVarPresentAndNonAssigned(Variable x) = 0;
  
  /// checks whether this literals is satisfied by a given assignment.
  virtual bool
  isSatisfiedBy(Assignment* a) const = 0;
 
};


#endif
