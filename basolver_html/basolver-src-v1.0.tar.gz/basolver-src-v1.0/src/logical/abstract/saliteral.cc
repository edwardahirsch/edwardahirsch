/**
 * @file saliteral.cc
 * @brief implementation for saliteral.h
 * @author sergey
 */

#include "saliteral.h"
#include "../../algebraic/abstract/equality.h"

bool
SALiteral::containsVar(Variable x) const
{
  std::list<Variable> var_list = *(this->getVariableList());
  std::list<Variable>::iterator it = var_list.begin();
  for (; it != var_list.end(); it++)
    if ((*it) == x)
      return true;
  return false;

}


