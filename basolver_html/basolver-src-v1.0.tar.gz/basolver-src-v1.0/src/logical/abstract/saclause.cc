/**
 * @file saclause.cc
 * @brief Implements the SAClause class (general stuff; for low-level
 * implementation see /logical/implementation folder)
 * @author sergey
 */

#include "saclause.h"

bool
SAClause::isVarPresentAndNonAssigned(Variable x)
{
  if (this->getNumberOfLiterals() == 1)
  {
    if ((*(this->begin()))->isVarPresentAndNonAssigned(x))
      return true;
    
    return false;
  }

  std::list<PSALiteral>::iterator lit_it = (this->begin());
    
  while (lit_it != this->end())
  {
    if (!(*lit_it)->containsVar(x))
      return true;
      
    lit_it++;
  }
  
  return true;
}

bool
SAClause::getBinaryClauseLiterals(int& lit1, int& lit2)
{
  if (this->getNumberOfLiterals() == 1)
  {
    PSALiteral lit = *(this->begin());
    PEquality eq = boost::shared_dynamic_cast<Equality, SALiteral>(lit);
    
    if (eq->getEqType() != eqtABeq0)
      return false;
    
    bool pos1 = eq->getPos1();  
    bool pos2 = eq->getPos2();  
    
    lit1 = eq->getVar1();
    lit2 = eq->getVar2();
    
    lit1 *= ((pos1) ? -1 : 1);
    lit2 *= ((pos2) ? -1 : 1);
    
    
    return true;
  }
  
  if (this->getNumberOfLiterals() == 2)
  {
    std::list<PSALiteral>::iterator lit_it = (this->begin());
    PEquality eq1 = boost::shared_dynamic_cast<Equality, SALiteral>((*lit_it));
   
    bool pos1 = eq1->isPositive();
    lit1 = eq1->getBooleanVariable();
    lit1 *= ((pos1) ? 1 : -1);
    
    lit_it++;
    
    PEquality eq2 = boost::shared_dynamic_cast<Equality, SALiteral>((*lit_it));
    int pos2 = eq2->isPositive();
    lit2 = eq2->getBooleanVariable();
    lit2 *= ((pos2) ? 1 : -1);
    
    return true;
  }
  
  return false;
}


