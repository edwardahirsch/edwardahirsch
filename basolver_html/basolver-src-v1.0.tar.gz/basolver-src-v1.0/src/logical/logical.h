#ifndef __LOGICAL_H__
#define __LOGICAL_H__

#include "boost/smart_ptr.hpp"

#include "../algebraic/abstract/equality.h"

// Abstract logical classes
#include "abstract/saliteral.h"
#include "abstract/saclause.h"

// Implementing logical classes
#include <stdio.h>
#include "../misc/tracer.h"
#include "../misc/assert.h"

/**
 * @file logical.h
 * @brief  A class for generating logical stuff
 * @author sergey
 */


// forward declaration
class BooleanAlgebraicSolver; 

/**
 * @class LogicalGenerator
 * @brief A class for generating clauses, literals, and objects
 * @author sergey
 */
class LogicalGenerator
{
public:


  /**
   * Creates a clause
   */
  static PSAClause makeSAClause();

  /**
   * Creates a deduction object
   */
  static PDeductionObject makeDeductionObject();

  /**
   * Creates a boolean literal.
   */
  static PSALiteral makeBoolLiteral(Variable var, bool pos);
 
  /**
   * Creates a unit clause
   */
  static PModificationObject makeUnitClause(Variable var, bool value);

};

/**
 * smart pointer for \ref LogicalGenerator
 */
typedef boost::shared_ptr<LogicalGenerator> PLogicalGenerator;

#endif
