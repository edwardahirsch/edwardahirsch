#include "simpleassignment.h"

/**
 * @file simpleassignment.cc
 * @brief Contains implementation of the SimpleAssignment methods.
 */
 
/* @author kulikov */

void
SimpleAssignment::addLiteral(Variable var, bool sign)
{
  myLiterals.insert(make_pair(var, sign));
};


int 
SimpleAssignment::getValue(Variable var) const
{
  map<Variable, bool>::const_iterator it = myLiterals.find(var);
  
  if (it == myLiterals.end())
    return -1;
    
  if ((*it).second)
    return 1;
    
  return 0;
}

void
SimpleAssignment::setToFirst()
{
  myIsEnd = false;  

  map<Variable, bool>::iterator it = myLiterals.begin();
  map<Variable, bool>::iterator it_end = myLiterals.end();
  
  for (; it != it_end; it++)
    (*it).second = false;
    
  return;
}

void
SimpleAssignment::setToNext()
{
  map<Variable, bool>::iterator it = myLiterals.begin();
  map<Variable, bool>::iterator it_end = myLiterals.end();

  while (it != it_end && (*it).second)
  {
    (*it).second = false;
    it++;
  }  
  
  if (it != it_end)
    ((*it).second) = true;
  else
    myIsEnd = true;

    
  return;
}

bool 
SimpleAssignment::isEndAssignment() const
{
  return myIsEnd;
}

ostream&
SimpleAssignment::print(ostream& os) const
{
  map<Variable, bool>::const_iterator it = myLiterals.begin();
  map<Variable, bool>::const_iterator it_end = myLiterals.end();
  
  for (; it != it_end; it++)
  {
    os << "p" << (*it).first;
    os << "=" << (*it).second << " ";
  }  
  
  return os;
}

Assignment*
SimpleAssignment::clone() const
{
  Assignment* clone = new SimpleAssignment();
  
  map<Variable, bool>::const_iterator it = myLiterals.begin();
  map<Variable, bool>::const_iterator it_end = myLiterals.end();

  for (; it != it_end; it++)
    clone->addLiteral((*it).first, (*it).second);
    
  return clone;
}

