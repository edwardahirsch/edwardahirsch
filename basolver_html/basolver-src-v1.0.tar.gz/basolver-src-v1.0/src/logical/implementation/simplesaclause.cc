#include "simplesaclause.h"
/**
 * @file simplesaclause.cc
 * @brief Implements the SimpleSAClause class
 */
 
/* @author sergey */

/**
 * A constructor
 */
SimpleSAClause::SimpleSAClause() 
{
  myLitList = new std::list<PSALiteral>;
  mySize=0;
  myVarListMayBeChanged = true;
}

SimpleSAClause::SimpleSAClause(const SimpleSAClause& clause)
{
  myLitList = new std::list<PSALiteral>;
  mySize=0;
  std::list<PSALiteral>::const_iterator lbeg = clause.myLitList->begin();
  while (lbeg!=clause.myLitList->end())
  {
    add(*lbeg, true);
    ++lbeg;
  }
  myVarListMayBeChanged = true;
}

bool SimpleSAClause::isNegative(long var) const
{
  std::list<PSALiteral>::const_iterator lbeg = myLitList->begin();
  std::list<PSALiteral>::const_iterator lend = myLitList->end();
  while (lbeg != lend)
  {
    if ((*lbeg)->getBooleanVariable() == var)
      return (!(*lbeg)->isPositive());
    ++lbeg;
  }
  return false;
}

bool SimpleSAClause::isPositive(long var) const
{
  std::list<PSALiteral>::const_iterator lbeg = myLitList->begin();
  std::list<PSALiteral>::const_iterator lend = myLitList->end();
  while (lbeg != lend)
  {
    if ((*lbeg)->getBooleanVariable() == var)
      return (*lbeg)->isPositive();
    ++lbeg;
  }
  return false;
}

/**
 * Another constructor
 */
SimpleSAClause::SimpleSAClause(PSALiteral lit) 
{
  myLitList = new std::list<PSALiteral>;
  myLitList->push_back(lit);
  mySize=1;
  myVarListMayBeChanged = true;
}

/**
 * Empties the list of literals
 */
void SimpleSAClause::empty()
{
  myLitList->clear();
  mySize=0;
  myVarListMayBeChanged = true;
}


 
AssignReturnType SimpleSAClause::assign(Variable var, int val)
{
  std::list<PSALiteral>::iterator lbeg = myLitList->begin();
  std::list<PSALiteral>::iterator lend = myLitList->end();
  
  while (lbeg!=lend)
  {
    switch((*lbeg)->assign(var,val))
    {
      case ART_Satisfiable:
        return ART_Satisfiable;
        break;
      case ART_Unsatisfiable:
        lbeg = myLitList->erase(lbeg);
	mySize--;
      default:
        ++lbeg;
    }
  }
  
  myVarListMayBeChanged = true;
  return ART_Active;
}

AssignReturnType SimpleSAClause::substituteEqual(Variable x, Variable y)
{
  myVarListMayBeChanged = true;
  std::list<PSALiteral>::iterator lbeg = myLitList->begin();
  std::list<PSALiteral>* newList = new std::list<PSALiteral>;
  while (lbeg!=myLitList->end())
  {
    PEquality equality=boost::shared_dynamic_cast<Equality, SALiteral>(*lbeg);
    if (equality!=0)
    {
      switch (equality->substituteEqual(x, y))
      {
        case ART_Satisfiable:
          {
            delete newList;
            return ART_Satisfiable;
          }
        case ART_Unsatisfiable:
          break;
        default:
          newList->push_back(equality);
      }
    }
    ++lbeg;
  }      
  if (!newList->size()) 
  {
    delete newList;
    return ART_Unsatisfiable;
  }
  myLitList->clear();
  mySize=0;
  for (std::list<PSALiteral>::iterator lnew = newList->begin();lnew!=newList->end(); ++lnew)
  {
    this->add(*lnew);
  };
  newList->clear();
  delete newList;
  return ART_Active;
}

bool SimpleSAClause::isType(TEqualityType type) const
{
  return (((myLitList->size() == 1) && ((*(myLitList->begin()))->getEqType() == type)) ||
         ( (myLitList->size() > 1) && (type == Boolean) ) );
}

AssignReturnType SimpleSAClause::substituteNonEqual(Variable x, Variable y)
{
  myVarListMayBeChanged = true;
  std::list<PSALiteral>::iterator lbeg = myLitList->begin();
  std::list<PSALiteral>* newList = new std::list<PSALiteral>;
  while (lbeg!=myLitList->end())
  {
    PEquality equality=boost::shared_dynamic_cast<Equality, SALiteral>(*lbeg);
    if (equality!=0)
    {
      switch (equality->substituteNonEqual(x, y))
      {
        case ART_Satisfiable:
          {
            delete newList;
            return ART_Satisfiable;
          }
        case ART_Unsatisfiable:
          break;
        default:
          newList->push_back(equality);
      }
    }
    ++lbeg;
  }      
  if (!newList->size()) 
  {
    delete newList;
    return ART_Unsatisfiable;
  }
  myLitList->clear();
  mySize=0;
  for (std::list<PSALiteral>::iterator lnew = newList->begin();lnew!=newList->end(); ++lnew)
  {
    this->add(*lnew);
  };
  newList->clear();
  delete newList;
  return ART_Active;
}
 

/**
 * Printing
 */
std::ostream& SimpleSAClause::print(std::ostream& os,BooleanAlgebraicSolver *slv,bool print_as_dedobj) 
{

  if (myLitList->size() && !print_as_dedobj)
  {
    PEquality firstobj = boost::shared_dynamic_cast<Equality, SALiteral>(*myLitList->begin());
  
    if (!( (myLitList->size() == 1) && (firstobj->getId()) ) )
      os << this->getId() << ": ";
  }
  else
    os << this->getId() << ": ";
  
  std::list<PSALiteral>::const_iterator lbeg = myLitList->begin();
  bool booleantype = false;
  if ((myLitList->size() == 1) && ((*lbeg)->getEqType() == Boolean)) booleantype = true;
  while (lbeg!=myLitList->end())
  {
    (*lbeg)->print(os,slv,print_as_dedobj);
    os << " ";
    ++lbeg;
  }
  if (booleantype) os << "[type Boolean]";

  return os;
}

/**
 * returns the list of variables
 */
PVarList SimpleSAClause::getVariableList(TGetVar rettype) const
{
  if (rettype==ReturnAll && this->getNumberOfLiterals()==1)
  {
    return (*(myLitList->begin()))->getVariableList();
  };
      
  PVarList pvl(new VarList());
  PVarList pvl2;
  std::list<PSALiteral>::const_iterator lbeg = myLitList->begin();
  std::list<Variable>::iterator vbeg, vend, vbeg2, vend2;
  switch(rettype)
  {
    case ReturnAll:
      while (lbeg!=myLitList->end())
      {
        pvl2 = (*lbeg)->getVariableList();
        vbeg2 = pvl2->begin();
        vend2 = pvl2->end();
        while (vbeg2 != vend2)
        {
          vbeg = pvl->begin();
          vend = pvl->end();
          while (vbeg != vend)
          {
            if ((*vbeg) == (*vbeg2)) break;
            if ((*vbeg) > (*vbeg2))
            {
              pvl->insert(vbeg,*vbeg2);
              break;
            }
            ++vbeg;            
          }
          if (vbeg == vend)
            pvl->push_back(*vbeg2);
          ++vbeg2;
        }
        ++lbeg;
      } 
      break;
    case ReturnTopTwo:
      break;
  }
  
  return pvl;
}

/**
 * Cloning
 */
PDeductionObject SimpleSAClause::cloneObject() const
{
  PDeductionObject res(new SimpleSAClause(*this));
  return res;
}

DeductionObject *SimpleSAClause::cloneAsObjPointer() const
{
  return (new SimpleSAClause(*this));
}

PSAClause SimpleSAClause::clone() const
{
  PSAClause res(new SimpleSAClause(*this));
  return res;
}

SAClause *SimpleSAClause::cloneAsPointer() const
{
  return (new SimpleSAClause(*this));
}

bool SimpleSAClause::isBoolean()
{
  return processBoolean();
}

bool SimpleSAClause::isEqualToNegations(PEquality eq1, PEquality eq2) const
{
  if (myLitList->size() != 2) return false;
  std::list<PSALiteral>::iterator lbeg = myLitList->begin();
  PEquality eq = boost::shared_dynamic_cast<Equality,SALiteral>(*lbeg);
  if ( eq->isNegation(eq1) )
  {
    ++lbeg;
    eq = boost::shared_dynamic_cast<Equality,SALiteral>(*lbeg); 
    return (eq->isNegation(eq2));
  }
  else if (eq->isNegation(eq2))
  {
    ++lbeg;
    eq = boost::shared_dynamic_cast<Equality,SALiteral>(*lbeg); 
    return (eq->isNegation(eq1));
  }
  else return false;
}


bool SimpleSAClause::processBoolean()
{
  std::list<PSALiteral>::iterator lbeg = myLitList->begin();
  while (lbeg!=myLitList->end())
  {
    PEquality equality=boost::shared_dynamic_cast<Equality, SALiteral>(*lbeg);
    if (equality!=0)
    {
      if (!equality->isBoolean())
        return false;
    }
    else
    {
      return false;
    };
    ++lbeg;
  };    
  return true;
}; 

/**
 * Destructor
 */
SimpleSAClause::~SimpleSAClause()
{
  
  myLitList->clear();
  delete myLitList;
}

bool SimpleSAClause::canPerformResolution(SAClause& secondClause)
{
  if (!this->isBoolean() || !secondClause.isBoolean()) return false;
  int contrars=0;
  for (SALiteralIterator first=this->begin();first!=this->end(); ++first)
  {
    for (SALiteralIterator second=secondClause.begin();second!=secondClause.end(); ++second)
    {
      PEquality eq1=boost::shared_dynamic_cast<Equality, SALiteral>(*first);
      PEquality eq2=boost::shared_dynamic_cast<Equality, SALiteral>(*second);
      if (eq1==0 || eq2==0)
        return false;
      if (((eq1->getBooleanVariable())==(eq2->getBooleanVariable())) 
          && ((eq1->getBooleanSign())!=(eq2->getBooleanSign())))
      {	  
	 contrars++;
	 if (contrars>1) return false;
      };	  	
    };
  };
  return true;      
}; 
  
  
PSAClause SimpleSAClause::getResolvent(SAClause& secondClause)
{
  PSAClause result(new SimpleSAClause());
  if (!this->canPerformResolution(secondClause))  
    return result;
  for (SALiteralIterator first=this->begin();first!=this->end(); ++first)
  {
    int myContrar=0;
    for (SALiteralIterator second=secondClause.begin();second!=secondClause.end(); ++second)
    {
      PEquality eq1=boost::shared_dynamic_cast<Equality, SALiteral>(*first);
      PEquality eq2=boost::shared_dynamic_cast<Equality, SALiteral>(*second);
      if ((eq1->getBooleanVariable()==eq2->getBooleanVariable()) 
          && (eq1->getBooleanSign()!=eq2->getBooleanSign()))
	 myContrar++;
    };
    if (myContrar==0)
      result->add(*first,true);
  };
  for (SALiteralIterator second=secondClause.begin();second!=secondClause.end(); ++second)
  {
    int myContrar=0;
    for (SALiteralIterator first=this->begin();first!=this->end(); ++first)
    {
      PEquality eq1=boost::shared_dynamic_cast<Equality, SALiteral>(*first);
      PEquality eq2=boost::shared_dynamic_cast<Equality, SALiteral>(*second);
      if (((eq1->getBooleanVariable())==(eq2->getBooleanVariable())) 
          && (eq1->getBooleanSign()!=eq2->getBooleanSign()))
	 myContrar++;
    };
    if (myContrar==0)
      result->add(*second,true);
  };
  return result;      
};


void SimpleSAClause::add(PSALiteral lit)
{
  myVarListMayBeChanged = true;
  this->add(lit, false);
};


void SimpleSAClause::add(PSALiteral lit, bool clone)
{
  myVarListMayBeChanged = true;
  SALiteralIterator iter=myLitList->begin();
  while ((iter!=myLitList->end()) && (**iter < (*lit))) ++iter;
  PSALiteral litToAdd=clone ? lit->clone() : lit;
  if (iter == myLitList->end())
  {
    myLitList->push_back(litToAdd);
    mySize++;
    return;
  }
  if (**iter == (*lit))
  {
    return;
  }
  myLitList->insert(iter,litToAdd);
  mySize++;
  return;  
};

bool SimpleSAClause::operator == (SAClause& secondClause) const
{
  try
  {
    SimpleSAClause& simpleClause=dynamic_cast<SimpleSAClause&>(secondClause);
    SALiteralIterator myIter=myLitList->begin();
    SALiteralIterator hisIter=simpleClause.myLitList->begin();
    while (myIter!=myLitList->end() && hisIter!=simpleClause.myLitList->end())
    {
      if (!((**myIter)==(**hisIter))) return false;
      ++myIter;
      ++hisIter;
    };
    if (myIter!=myLitList->end() || hisIter!=simpleClause.myLitList->end())
      return false;
    return true;  
  }
  catch (std::bad_cast &bc)  
  {
    return false;
  };    
}; 

bool SimpleSAClause::isSubsetOf (SAClause& secondClause) const 
{
  try
  {
    SimpleSAClause& simpleClause=dynamic_cast<SimpleSAClause&>(secondClause);
    SALiteralIterator myIter=myLitList->begin();
    SALiteralIterator myEnd=myLitList->end();
    SALiteralIterator hisEnd=simpleClause.myLitList->end();
    SALiteralIterator hisIter=simpleClause.myLitList->begin();
    bool equal_size=(this->getNumberOfLiterals()==secondClause.getNumberOfLiterals());
    while (myIter!=myEnd && hisIter!=hisEnd)
    {
      if ((**myIter)==(**hisIter))
      {
        ++myIter;
        ++hisIter;
      }
      else
      {
        if (equal_size) return false;
        if ((**myIter)<(**hisIter)) return false;
        ++hisIter;
      }        	
    };
    if ((! equal_size) && myIter!=myEnd)
      return false;
    return true;  
  }
  catch (std::bad_cast &bc)  
  {
    Assert(0, "Only SimpleClause is supperted by this method");
    return false;
  };    

};

bool
SimpleSAClause::isAlreadySatisfied() const
{
  std::list<PSALiteral>::iterator lbeg = myLitList->begin();
  bool has_old=false;
  PEquality old;
  while (lbeg!=myLitList->end())
  {
    PEquality equality=boost::shared_dynamic_cast<Equality, SALiteral>(*lbeg);
    if (equality!=0)
    {
      if (equality->isTautology())
        return true;
      if (equality->isBoolean())
      {
        if (has_old)
	{
	  if ((old->getBooleanVariable()==equality->getBooleanVariable()) && old->getBooleanSign()!=equality->getBooleanSign())
	  {
	    return true;
	  };	  
	}
	has_old=true;
	old=equality;
      };	
    }
    ++lbeg;
  }
  return false;
}; 

bool SimpleSAClause::isBooleanInVars(long &x, long &y, long &z) const
{
  if (myLitList->size() > 3) return false;
  std::list<PSALiteral>::iterator lbeg = myLitList->begin();
  if (!(*lbeg)->isBoolean()) return false;
  x = (*lbeg)->getFirstVariableNumber();
  ++lbeg;
  if (lbeg == myLitList->end()) return false;
  if (!(*lbeg)->isBoolean()) return false;
  y = (*lbeg)->getFirstVariableNumber();
  ++lbeg;
  if (lbeg == myLitList->end()) {z=0; return true;}
  if (!(*lbeg)->isBoolean()) return false;
  z = (*lbeg)->getFirstVariableNumber();
  return true;
}

bool SimpleSAClause::isBooleanThreeVariables(long&x, long&y, long&z) const
{
  long tmp;
  if (myLitList->size() != 3) return false;
  std::list<PSALiteral>::iterator lbeg = myLitList->begin();
  if (!(*lbeg)->isBoolean()) return false;
  x = (*lbeg)->getFirstVariableNumber();
  ++lbeg;
  if (lbeg == myLitList->end()) return false;
  if (!(*lbeg)->isBoolean()) return false;
  tmp = (*lbeg)->getFirstVariableNumber();
  if (tmp > x) {y = x; x = tmp;} else y = tmp;
  ++lbeg;
  if (lbeg == myLitList->end()) {z=0; return true;}
  if (!(*lbeg)->isBoolean()) return false;
  tmp = (*lbeg)->getFirstVariableNumber();
  if (tmp > x) {z = y; y = x; x = tmp;}
  else if (tmp > y) {z = y; y = tmp;}
  else z = tmp;
  return true;
} 

bool SimpleSAClause::isBooleanTwoVariables(long&x, long&y) const
{
  long tmp;
  if (myLitList->size() != 2) return false;
  std::list<PSALiteral>::iterator lbeg = myLitList->begin();
  if (!(*lbeg)->isBoolean()) return false;
  x = (*lbeg)->getFirstVariableNumber();
  ++lbeg;
  if (lbeg == myLitList->end()) return false;
  if (!(*lbeg)->isBoolean()) return false;
  tmp = (*lbeg)->getFirstVariableNumber();
  if (tmp > x) {y = x; x = tmp;} else y = tmp;
  return true;
} 
 
TEqualityType SimpleSAClause::getEqType() const
{
  if (myLitList->size() > 1) return Boolean;
  else return (*(myLitList->begin()))->getEqType();
}

bool
SimpleSAClause::isUnsatisfiable() const
{
  std::list<PSALiteral>::iterator lbeg = myLitList->begin();
  while (lbeg!=myLitList->end())
  {
    PEquality equality=boost::shared_dynamic_cast<Equality, SALiteral>(*lbeg);
    if (equality!=0)
    {
      if (!equality->isUnsatisfiable())
        return false;
    }
    else return false;
    ++lbeg;
  };
  return true;
};


bool
SimpleSAClause::isSatisfiedBy(Assignment* a) const
{
  std::list<PSALiteral>::const_iterator it = myLitList->begin();
  std::list<PSALiteral>::const_iterator it_end = myLitList->end();
  
  for (; it != it_end; it++)
    if ((*it)->isSatisfiedBy(a))
      return true;
      
  return false;

}

