#ifndef __SIMPLESACLAUSE_H__
#define __SIMPLESACLAUSE_H__

/**
 * @file simplesaclause.h
 * @brief Contains implementation for the abstract
 * class SAClause
 * @author sergey
 */

#include "../abstract/saclause.h"
#include <list>
#include "../../misc/tracer.h"

class SimpleSAClause;
/**
 * smart pointer for \ref SimpleSAClause
 */
typedef boost::shared_ptr<SimpleSAClause> PSimpleSAClause;

/**
 * An implementation for the SAClause class
 */
class SimpleSAClause : public SAClause
{

private:
  /// list of literals
  std::list<PSALiteral>* myLitList;

  /// reprocess the answer to the question whether this is boolean
  bool processBoolean();
  
  /// this flag allows not to recalculate var list 
  /// in case a clause was not changed
  mutable bool myVarListMayBeChanged;
  /// list of variables of this clause
  mutable PVarList myVarList;
  /// size of the list of literals 
  int mySize;
public:
  
  /**
   * Empty constructor
   */
  SimpleSAClause();
  
  /**
   * Constructs from another clause
   */
  SimpleSAClause(const SimpleSAClause&);
  
  /**
   * Constructs from literal
   */
  SimpleSAClause(PSALiteral lit);

  /**
   * Empties the list of literals
   */
  void empty();

  /**
   * Assigns a value to a variable
   */
  AssignReturnType assign(Variable var, int val);
  
  /**
   * Substitute one variable instead other (x:=y)
   */
  AssignReturnType substituteEqual(Variable x, Variable y);

  virtual bool hasOneEquality() const  {return (myLitList->size() == 1);};
  
  /**
   * Substitute negation of one variable instead other (x:=1-y)
   */
   
   AssignReturnType substituteNonEqual(Variable x, Variable y);

  /**
   * Returns variable list
   */
  virtual PVarList getVariableList() const {return this->getVariableList(ReturnAll);};

  /**
   * returns varlist with respect to the option;
   * currently works with ReturnAll option *only*
   */
  PVarList getVariableList(TGetVar rettype) const;

  bool isPositive(long num) const;
  bool isNegative(long num) const;
  
  /**
   * Printing
   */
  std::ostream& print(std::ostream&,BooleanAlgebraicSolver *,bool print_as_dedobj=false);

  /**
   * Cloning as a smart pointer to \ref DeductionObject
   */
  PDeductionObject cloneObject() const;
  /**
   * clones as an ordinary pointer to \ref DeductionObject
   */
  DeductionObject *cloneAsObjPointer() const;

  /// clone
  PSAClause clone() const;
  /// clone as an ordinary pointer
  SAClause *cloneAsPointer() const;
 
  /**
   * begin iterator
   */
  SALiteralIterator begin() {return myLitList->begin();};
  
  /**
   * end iterator
   */
  SALiteralIterator end() {return myLitList->end();};

  /**
   * delete a literal from the clause
   */
  void deleteLiteral(SALiteralIterator iter) {myLitList->erase(iter);};
  
  /**
   * Adds a literal to the clause without cloning
   */
  virtual void add(PSALiteral lit);

  /**
   * Adds a literal to the clause
   * Parameter clone shows to clone literal or not
   */

  void add(PSALiteral literal, bool clone);
  /**
   * Destructor
   */
  ~SimpleSAClause();
  
   /**
   * returns whether this clause consist of obly boolean literals
   */
   bool isBoolean(); 
   /// return the number of literals (size of \ref myLitList)
   virtual int getNumberOfLiterals() const
   {
     return mySize;     
   };
     
  /**
   * Check if two clauses are boolean and conflict on exactly one literal
   */
  
  bool canPerformResolution(SAClause& secondClause); 
 
  bool isType(TEqualityType type) const;
  
  /**
   * Returns resolvent of two clauses if it is possible. Otherwise returns 
   * empty clause.
   */
  
  PSAClause getResolvent(SAClause& secondClause); 

  /**
   * Compare two clauses
   */    
  
  bool operator == (SAClause& secondClause) const; 

  /**
   * Checkif this clause is subset of secondClause
   */    
  
  bool isSubsetOf (SAClause& secondClause) const; 
  
  /**
   * Check if this clause is already satisfied    
   */    
   
  bool isAlreadySatisfied() const;  

  /**
   * Check if this clause is already unsatisfiable    
   */    
 
  bool isUnsatisfiable() const;  

  virtual bool isDeg2Even() const
  {
    return ((myLitList->size() == 1) && ((*(myLitList->begin()))->isDeg2Even()));   
  };

  virtual TEqualityType getEqType() const;
  
  virtual bool getOneOneMinusOne(long &x, long &a, long &b) const {
    return ((myLitList->size() == 1) && ((*(myLitList->begin()))->getOneOneMinusOne(x,a,b)));
  }
 
  virtual bool getOneOneMinusTwoWConst(long &x, long &a, long &b, bool &withconstant) const {
    return ((myLitList->size() == 1) && ((*(myLitList->begin()))->getOneOneMinusTwoWConst(x,a,b,withconstant)));
  }
 
  virtual bool getOneOneMinusTwo(long &x, long &a, long &b) const {
    return ((myLitList->size() == 1) && ((*(myLitList->begin()))->getOneOneMinusTwo(x,a,b)));
  }

  virtual bool getXeqAB(Variable &x,bool &posx, Variable &a,bool &posa,Variable &b, bool &posb) const {
    return ((myLitList->size() == 1) && ((*(myLitList->begin()))->getXeqAB(x,posx,a,posa,b,posb)));
  }
  virtual bool getXeqAB(long &x, long &a, long &b) const {
    return ((myLitList->size() == 1) && ((*(myLitList->begin()))->getXeqAB(x,a,b)));
  }

  virtual bool getYeqACpnAB(Variable &x, bool &px, Variable &a, bool &pa, Variable &c, bool &pc, Variable &b, bool &pb) const {
    return ((myLitList->size() == 1) && ((*(myLitList->begin()))->getXeqACpnAB(x,px,a,pa,c,pc,b,pb)));
  }


  /**
   * checks whether this is boolean and contains no more than 3 vars
   * assigns values of the vars to parameters
   */
  bool isBooleanInVars(long &,long &, long &) const;

  bool isBooleanTwoVariables(long&,long&) const;
  bool isBooleanThreeVariables(long&,long&,long&) const;
  
  PEquality getEquality() const
  {
    return boost::shared_dynamic_cast<Equality, SALiteral>(*(myLitList->begin()));
  };

  virtual bool getXeqABpACpBCm2ABC(Variable& x,bool& px,Variable& a,bool &pa,Variable& b,bool &pb,Variable& c,bool &pc) const {
    return ((myLitList->size() == 1) && (*myLitList->begin())->getXeqABpACpBCm2ABC(x,px,a,pa,b,pb,c,pc));
  };

  virtual bool get124(Variable& x,Variable& a,Variable& b,Variable& c,bool&pc) const {
    return ((myLitList->size() == 1) && (*myLitList->begin())->get124(x,a,b,c,pc));
  };
  
  virtual bool getDeqABpACmABC(Variable& d,bool&pd,Variable& a,bool&pa,Variable& b,bool&pb,Variable& c,bool&pc) const {
    return ((myLitList->size() == 1) && (*myLitList->begin())->getDeqABpACmABC(d,pd,a,pa,b,pb,c,pc));
  };
  
  virtual bool getYeqACpDmACD(Variable& y,bool& py,Variable& a,bool &pa, Variable& c, bool &pc, Variable& d, bool &pd) const {
    return ((myLitList->size() == 1) && (*myLitList->begin())->getYeqACpDmACD(y,py,a,pa,c,pc,d,pd));
  };

  virtual bool getLin2Subject(Variable &a, Variable &b) const {
    return ((myLitList->size() == 1) && (*myLitList->begin())->getLin2Subject(a,b));
  } 
  
  virtual bool isLin2Subject() const {
    return ((myLitList->size() == 1) && (*myLitList->begin())->isLin2Subject());
  } 
  
  virtual bool getLin2Subject(Variable &x,Variable &a, Variable &b,Coefficient&c1,Coefficient&c2,Coefficient&c12) const {
    return ((myLitList->size() == 1) && (*myLitList->begin())->getLin2Subject(x,a,b,c1,c2,c12));
  }

  virtual bool getLHSVariable(Variable &x) const
   {
    return ((myLitList->size() == 1) && (*myLitList->begin())->getLHSVariable(x));
  }
  
  virtual bool isEqualToNegations(PEquality eq1, PEquality eq2) const;



  // experimenting with TypedEquality
 
  virtual bool getXeqABnew(Variable &v1,bool &p1,Variable &v2,bool &p2, Variable &v3, bool &p3) const 
  {
    return ((myLitList->size() == 1) && (*myLitList->begin())->getXeqABnew(v1,p1,v2,p2,v3,p3));
  }
  
  virtual bool
  isSatisfiedBy(Assignment* ) const;
 
};

#endif
