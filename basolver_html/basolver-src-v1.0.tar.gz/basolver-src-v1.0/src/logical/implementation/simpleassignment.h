#ifndef __SIMPLEASSIGNMENT_H__
#define __SIMPLEASSIGNMENT_H__

/**
 * @file simpleassignment.h
 * @author kulikov
 * @brief Contains an interface of the SimpleAssignment class.
 */

#include "logical/abstract/assignment.h"
#include <string>

using namespace std;

/**
 * Forward declaration.
 */
class SimpleAssignment;
/**
 * Smart pointer to \ref Assignment.
 */
typedef boost::shared_ptr<SimpleAssignment> PSimpleAssignment;

/**
 * @class SimpleAssignment
 * @brief Implements the \ref Assignment interface.
 * Literals are stored as a standard map.
 */
class SimpleAssignment : public Assignment
{
public:
  /// Constructor.
  SimpleAssignment() { myIsEnd = false; };
  
  /// Destructor. Clears the internal map of literals.
  virtual
  ~SimpleAssignment()
  { myLiterals.clear(); };
  
  /// Returns a value assigned to an input variable
  /// by this assignment (-1 if none assigned).
  virtual int  
  getValue(Variable var) const;
  
  /// Adds a literal to this assignment.
  virtual void
  addLiteral(Variable var, bool sign); 
  
  virtual void 
  setToFirst();
  
  virtual void
  setToNext();
  
  virtual bool
  isEndAssignment() const;
  
  /// Prints this assignment to a given stream.
  virtual ostream&
  print(ostream&) const;
 
  virtual Assignment*
  clone() const;
  
private:
  /// Map of literals.
  map<Variable, bool> myLiterals;
  
  /// This flag is set when all assignments were already considered.
  bool myIsEnd;
};

#endif
