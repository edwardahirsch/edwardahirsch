#ifndef __CONFIG_H__
#define __CONFIG_H__

//#define DEBUG

/**
 * @file config.h
 * @brief Configuration file. 
 */

#ifdef DEBUG
 #define USE_ASSERTEXCEPTION 1
 #define USE_TRACING  
#else
 #undef USE_ASSERTEXCEPTION 
 #undef USE_TRACING  
#endif // DEBUG

#define COLLECT_STAT

#endif // __CONFIG_H__
