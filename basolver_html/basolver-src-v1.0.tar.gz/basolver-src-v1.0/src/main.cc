 /** @file main.cc
  * @brief Main file. 
  */
  
/* @author kulikov */

/**
 * \mainpage
 * \section compilation Compilation
 *
 * To (re)build basolver, type \n
 * <tt>make [version]</tt>\n 
 * in the top-level directory of the solver distribution (<i>not</i> in <tt>src/</tt> subdirectory),
 * where version can be either debug, profile, release (default), or static.
 * It creates an executable file <tt>./bin/basolver[.version]</tt>
 * (however, there is no ".release" suffix for the release version).
 *
 * To make a library, type\n
 * <tt>make solverlib</tt>\n
 * It creates a file <tt>./bin/basolver.a</tt>. Use it together 
 * with the header \ref solve.h (follow the link to see the main solver interfaces).
 * 
 *
 * \section using Using the program
 *
 * To use basolver binary, type \n
 * <tt>./bin/basolver[.version] [options] file1 [file2]</tt>
 *
 * If only one file is given, it has to be in DIMACS cnf format.
 * If two files are given, they both have to be in either ISCAS or RTL format
 * (see format description below) and have to contain equal number of
 * inputs and outputs. These two formats allow to encode conveniently
 * boolean and arithmetic circuits.
 *
 * \subsection cmdlineopts Command line options
 *
 * Command line options are the following:
 * - --equiv (flag, default=off) - may be given only with two input files;\n
 * if this flag is set,
 * the solver checks the equivalence of the two input circuits: it produces a formula which is unsatisfiable 
 * if and only if the two input circuits are equivalent and solves it;\n
 * if this flag is unset the solver just adds the equalities stating that all corresponding inputs and outputs
 * of two input circuits are equal and solves the resulting set;
 * - --booth (flag, default=off) - use special rules for for Booth multipliers (under development, currently does not really help)
 * - --html (flag, default=off) - write html output
 * - --nosets (flag, default=off) - do not write the sets in html output
 *
 * \subsection format Format description
 * 
 * <b>DIMACS cnf format</b>
 *
 * This format is parsed by \ref CNFParser.
 * 
 * An input file starts with comments (each line starts with c).
 * The number of variables and the number of clauses is defined by the line
 * 
 * <tt>p cnf variables clauses</tt>
 * 
 * Each of the next lines specifies a clause: a positive literal
 * is denoted by the corresponding number, and a negative literal
 * is denoted by the corresponding negative number. The last number
 * in a line should be zero. For example,
 * 
 * <tt>
 \verbatim
  c A sample .cnf file.
  p cnf 3 2
  1 -3 0
  2 3 -1 0 
 \endverbatim
 * </tt>  
 * 
 * <b>ISCAS and RTL formats</b>
 *
 * ISCAS and RTL formats are parsed by \ref RTLParser.
 *
 * These two formats allow to conveniently encode 
 * arithmetic circuits.
 * The RTL format is designed as an extension of the ISCAS format. Its difference from the ISCAS format is in 
 * the possibility to work with multi-bit variables (thus, ISCAS format does not 
 * allow NUM, SUM, MULT gates) and with CLAUSE operator. Below we provide 
 * the description of the RTL format. (The subdirectory ./examples/
 * contains examples of benchmarks in RTL format).
 *
 * Each string of a file in RTL format should match one of the following types:
 * - x = GATE(y1, ..., yk)
 * - OPERATOR(y1, ..., yk)
 * where GATE can be BUFF, NOT, AND, NAND, OR, NOR, XOR, XNOR, MULT, SUM, NUM, and
 * OPERATOR can be INPUT, OUTPUT, CLAUSE.
 * 
 * 
 * MULT, SUM, and NUM gates accept multi-bit variables,
 * while all other gates work with bit variables only.
 * Restrictions on variable names are the following: 
 * a variable name should not start with '_' or a digit or contain 
 * one of the characters ',', ')', '(', '='; gate name 
 * cannot be used as a variable name.
 * A multi-bit variable can appear in the right hand side
 * of a gate description iff it appears in the left hand side of some 
 * previous gate (this condition is needed for calculating
 * the number of bits in resulting multi-bit variable).
 * The number of bits in the sum of two multi-bit variables
 * is equal to the maximum number of bits in these variables
 * plus 1, the number of bits in the product is just a sum of
 * these numbers. A variable cannot appear in the left hand side
 * of a not-NUM gate more than once.
 * Empty lines in an input file are not allowed. 
 * Comments start with '#' (comments may start only at 
 * the beginning of a string). 
 *
 * Semantics:
 * 
 * <table border=0>
 * <tr width=200><td>
 * INPUT(x)</td><td> x is an input bit of a circuit</td></tr>
 * <tr><td>OUTPUT(x)</td><td> x is an output bit of a circuit</td></tr>
 * <tr><td>CLAUSE(x1, ..., xk)</td><td>at least one of the variables x1, ..., xk has value True</td></tr>
 * <tr><td>x = BUFF(y)</td><td> x = y, where x and y are bits</td></tr>
 * <tr><td>x = NOT(y)</td><td> x = 1 - y, where x and y are bits</td></tr>
 * <tr><td>x = AND(y, z)</td><td> x = (y and z), where x, y, and z are bits</td></tr>
 * <tr><td>x = OR(y, z)</td><td> x = (y or z), where x, y, and z are bits</td></tr>
 * <tr><td>x = XOR(y, z)</td><td> x = (y xor z), where x, y, and z are bits</td></tr>
 * <tr><td>x = NUM(y1, ..., yk)</td><td> x is a k-bit variable consisting of
 * bits y1, ..., yk, where y1 is the parity bit</td></tr>
 * <tr><td>x = SUM(y, z)</td><td> x = y + z, where x, y, and z are 
 * such multi-bit variables that the number
 * of bits in y and z are known (that is,
 * y and z have to appear in the left
 * hand side of some previous equality
 * with gate SUM, MULT, or NUM)</td></tr>
 * <tr><td>x = MULT(y, z)</td><td> x = yz, where x, y, and z are multi-bit
 * variables, such that the number
 * of bits in y and z are known (that is,
 * y and z have to appear in the left
 * hand side of some previous equality
 * with gate SUM, MULT, or NUM) </td></tr></table>
 *
 *
 * ISCAS sample file:
 * <tt>
 * \verbatim
  #
  # A circuit representing the standard full adder
  # 
  INPUT(a)
  INPUT(b)
  INPUT(c)
  n = AND(b, c)
  m = AND(a, c)
  l = AND(a, b)
  k = XOR(a, b)
  e = OR(l, m)
  sum = XOR(k, c)
  CARRY = OR(e, n)
  OUTPUT(sum)
  OUTPUT(carry) 
  \endverbatim  
 * </tt> 
 *  
 * 
 * RTL sample file:
 * <tt>
 * \verbatim
  #
  # An RTL specification for (x+y)*z for two-bit numbers x, y, z. 
  #
  INPUT(x0)
  INPUT(x1)
  INPUT(y0)
  INPUT(y1)
  INPUT(z0)
  INPUT(z1)
  #
  x = NUM(x0,x1)
  y = NUM(y0,y1)
  z = NUM(z0,z1)
  #
  s = SUM(x, y)
  #
  m = MULT(s, z)
  m = NUM(m0, m1, m2, m3, m4)
  #
  OUTPUT(m0)
  OUTPUT(m1)
  OUTPUT(m2)
  OUTPUT(m3)
  OUTPUT(m4)
   \endverbatim
 * </tt> 
 *  
 * \section src Source
 * The difference of basolver (mixed boolean-algebraic solver) from a typical 
 * SAT solver is that it works with clauses that are disjunctions 
 * of <em>polynomial equalities</em> consisting of boolean variables.
 * In the present version a clause is either an ordinary clause of
 * boolean literals (for example, x=0 or y=1 or z=1), or a clause
 * consisting of a single polynomial equality (for example, z=x+y-2xy).
 *
 * Below we describe the main classes of the 
 * basolver (we give descriptions mostly to 
 * abstract classes; each page devoted to a class
 * contains links to all its descendants).
 * Note that most classes have several invariants that need to be
 * satisfied for basolver to work correctly. So, whenever you are 
 * modifying a method of a class do not forget to check that your modification
 * preserves all invariants of this class. 
 * To see invariants of a class go to the definition of this class and click 'More...'.
 *
 * For most classes we have abstract interfaces. This is done for 
 * easy substitution of implementations of an interface. Thus, 
 * instantiations are made inside generators of basolver objects of specific implementations. 
 * Usually interfaces
 * are implemented in a class whose name is obtained by adding prefix
 * 'Simple' to the name of an interface (a notable exception is \ref
 * TypedEquality and \ref BooleanEquality that are currently the only
 * implementations of \ref Equality).
 * 
 * \subsection algclasses Algebraic Classes
 *
 * Algebraic classes are used to construct mixed boolean-algebraic extensions 
 * of logical classes.
 * - \ref Coefficient is just an integer coefficient.
 * - \ref Variable is what a typical Boolean variable is.
 * - \ref Monomial is a product of Coefficient and several variables
 * (note that since we work with Boolean variables this product contains 
 * each variable at most once).
 * - \ref Polynomial is a sum of monomials.
 * - \ref Equality is an entity of the form poly1=poly2, where poly1 and poly2 are polynomials.
 * - \ref AlgebraicGenerator is a generator of algebraic objects of specific implementations.  
 *
 * \subsection logclasses Logical Classes
 *
 * Logical classes represent mixed boolean-algebraic extensions of typical logical 
 * objects, such as Boolean literal or Boolean clause.
 * - \ref SALiteral is a mixed boolean-algebraic extension of a Boolean literal.
 * Currently, only an equality (of type \ref Equality)
 * may be used as a \ref SALiteral. 
 * - \ref SAClause is a mixed boolean-algebraic extension of a Boolean clause. Thus, \ref SAClause is a 
 * disjunction of several SALiterals. For example, a Boolean clause 
 * \f$ (x_1 \lor x_2 \lor \bar{x_3})\f$ has the following representation in basolver:
 * \f$ (x_1=1 \lor x_2=1 \lor x_3=0)\f$.
 * - LogicalGenerator is a generator of logical objects of specific implementations.
 *
 * Note that we do not have a class corresponding to the notion of a CNF formula.
 * Instead of it we use sets of objects (of template type \ref ObjectSet,
 * instantiating it to consist either of deduction objects or of modification
 * objects).
 *  
 * \subsection objs Basic Objects of the Search Space
 *
 * Any object of the search space is considered either as a deduction object 
 * (of type DeductionObject) or a modification object (of type \ref ModificationObject). 
 * Modification objects are those by means of which we simplify another objects. 
 * Currently, as modification objects we consider only equalities of the form \f$ l=0 \f$
 * and \f$l_1=l_2\f$, where \f$l, l_1, l_2\f$ are literals.
 * These objects are stored in sets which are
 * respective localizations of the \ref ObjectSet template. The standard implementation
 * we use is \ref SimpleObjectSet which has several internal indices (such as, for 
 * example, adjacency lists). These indices are kept in a special structure
 * (\ref SimpleObjectIndex). However, for certain sets which do not
 * require indices at all we use \ref TrivialObjectSet --- the simplest set
 * possible with cheap basic operations). Both sets allow all typical set operations
 * (such as getSize(), add(), clear()) and also operations on iterators with sets
 * (begin(), end(), remove()). Note that all operations with iterators 
 * are in fact implemented in indexing classes (\ref SimpleObjectIndex).
 *
 * The \ref SimpleObjectSet on \ref DeductionObject is called \ref
 * AdjDedObjSet. The \ref SimpleObjectSet on \ref ModificationObject is called
 * \ref AdjModObjSet.
 * 
 * 
 * \subsection indclasses Indexing Classes
 *
 * These classes represent indices and iterators of basolver. 
 * Index is a structure for storing objects of a set intended to quicker
 * perform the operation of extracting objects that satisfy 
 * some predefined condition. For example, when we want to assign 
 * the value 1 to a variable x in a formula, we only have to change 
 * clauses that contain x. The corresponding index (adjacency list) returns
 * the necessary set of clauses, and we do not need to traverse all clauses in
 * the set.
 *
 * An iterator is an entity allowing to iterate conveniently on all selected objects.
 * 
 * We have indices and iterators for several objects of the program 
 * (we use our own indices and iterators for easier substitution
 * of implementations; however, our structures are often just wrappers 
 * for standard <tt>C++</tt> libraries indices and iterators).
 * 
 * The \ref SimpleObjectSet class allows to take the following iterators:
 * - SimpleObjectSet::getBeginIteratorOnWholeSet() returns an iterator on the whole set;
 * 
 * - SimpleObjectSet::begin() returns an iterator on all objects of the set
 *   containing the variable given as parameter;
 * 
 * - SimpleObjectSet::getLHSbegin() returns the begin iterator on all equalities
 *   of the set whose left-hand side contains the given variable.
 * 
 * - SimpleObjectSet::getBegin() returns the begin iterator on all equalities
 *   of the set that have the type given as parameter. See object types
 *   description for further information on the objects this index contains.
 *
 * 
 * To create an iterator for the end of the corresponding list, use ...End...
 * instead of ...Begin... in each of the cases described above.
 * 
 * - SimpleObjectSet::getFirstObjectInVars(). This index is supported somewhat
 * differently; its current iterator is kept inside the indexing system. Use
 * this method for getting the first object whose variables are contained in
 * the given three. Use SimpleObjectSet::nextObjectInVars() for traversing 
 * the set of such objects, SimpleObjectSet::currentObjectInVars() for peeking
 * at the current object, and SimpleObjectSet::isLastObjectInVars() for
 * testing whether you are at the end of the list.
 *
 * 
 * All these indices are supported in \ref SimpleObjectSet and are not
 * supported in \ref TrivialObjectSet (\ref ObjectSet has an assertion against
 * their use in the trivial implementation).
 *
 * 
 * \subsection backclasses Backtracking Classes
 *
 * These classes are intended to undo modifications made 
 * during the proof search process. This is also known 
 * as backtracking and used in all DPLL-like algorithms. 
 * The program has the class Log and BooleanAlgebraicSolver has a feature Log* myLog.
 * This feature contains all necessary 
 * information needed to undo modifications. 
 *
 * To undo all modifications made after some moment of time 
 * one has to remember this moment of time (this is implemented in the class Bookmark)
 * and then (after applying modifications) take this moment
 * to the solver's \ref Log. 
 * However there are sets that do not require 
 * to be returned to the state of this moment (for example, 
 * temporary sets). To indicate whether or not all modifications 
 * of a set have to be remembered in the \ref Log use the procedure writeLog().
 * See sample code below.
 * 
 * \code // remember the current state of sets
 * PBookmark bookmark = mySolver->getBookmark();
 * // somehow modify sets
 * mySolver->mySet1->add(myObject);
 * mySolver->mySet2->clear();
 * // undo all modifications that was made
 * mySolver->myLog->getBackTo(bookmark); 
 * \endcode
 *
 * \subsection ruleclasses Rules Classes
 *
 * These classes implement simplification and generation rules 
 * of basolver. A simplification rule replaces deduction objects 
 * with new ones or generates new modification objects. A generation rule produces new objects 
 * from existing objects. Thus, simplification rule never increase the number of 
 * deduction objects, while a generation rule usually does.
 * Simplification rules are called from the main algorithm more often.
 * Follow the links (SimplificationRule, GenerationRule) 
 * to see all specific rules. We also have a specific rule (\ref TransferRule)
 * which is intended to distinguish deduction and modification objects.
 * 
 * 
 *
 * \subsection mainalg Main Algorithm
 *
 * The main algorithm is implemented as a BooleanAlgebraicSolver::solve() method
 * (see documentation for detailed description
 * of the main algorithm).
 * Rules can be added to meta-rules of the algorithm 
 * in the constructor BooleanAlgebraicSolver::BooleanAlgebraicSolver() in file 
 * <tt>./src/general/solver.cc</tt>.
 * If you want to use another algorithm just 
 * create a new child-class of BooleanAlgebraicSolver and implement 
 * this algorithm in its solve() method.
 * 
 * To solve (i.e. find a satisfying assignment if it exists) a set of clauses
 * give this set to the method solve(). Example: 
 *     
 * \code // creating object of the class Solver
 * BooleanAlgebraicSolver* mySolver = new BooleanAlgebraicSolver();
 * // creating parser for an input set of clauses
 * Parser* myParser = new Parser();
 * // reading a set of clauses from the given file
 * PDeductionObjectSet mySet = myParser->parseCNF("file.cnf");
 * // solving the input set of clauses
 * mySolver->solve(mySet);
 * \endcode
 *
 * This calls the algorithm of the BooleanAlgebraicSolver class for the input set of clauses.
 * The algorithm uses the rules given to it in its constructor BooleanAlgebraicSolver::BooleanAlgebraicSolver().
 * The set of used rules can be easily changed there (however, do not forget 
 * to recompile basolver after changing this set). 
 */

// tracing
#include "misc/tracer.h"
// command line options
#include "getopt/options.h"
// parsers
#include "parse/parser.h"
// solver
#include "general/solver.h"
// ouput
#include "misc/output.h"
// solve
#include "solve.h"

/**
 * the executed method
 */
int main(int argc, char **argv)
{
  try
  {
    // reading command line options; in case of a wrong option
    // the program is terminated
    Options cmdLineOptions;
    cmdLineOptions.readOptions(argc,argv);
    
    
    
    // creating a solver
    BooleanAlgebraicSolver* solver = new BooleanAlgebraicSolver();
    solver->setOptions(cmdLineOptions);    
    
    
    
    // reading an input formula
    Parser *parser= new Parser();
    DeductionObjectSet* formula = 0;
    
    if (solver->getOptions()->myFileName2.size() == 0)
      formula = parser->parseCNF(solver,solver->getOptions()->myFileName);
    else
      formula = parser->parseTwo(solver, solver->getOptions()->myFileName, solver->getOptions()->myFileName2, solver->getOptions()->myEquivChecking);
      
    // solving the formula
    bool satisfiable = solver->solve(formula);
    
    // printing results and statistics
    if (satisfiable)
    {
      solver->printSatAssignment();
      solver->getOutput()->printSatisfyingAssignmentPage(true);
    }
    else
      std::cout << "s UNSATISFIABLE\n";
    
    solver->getStats()->print(std::cout);
    
    // destructing all initilaized structures
    delete formula;
    delete parser;
    delete solver;
   
    #ifdef USE_TRACING
    delete traceSet();
    #endif
    
    // returning
    if (satisfiable)
      return 10;
    else
      return 20;
  }
  catch(Exception &e)
  {
    std::cout << "Exception in " << e.module() << ": " << e.what() << '\n';
    exit(-9);
  }

  return 0;
}

