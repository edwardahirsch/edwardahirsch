#ifndef __SOLVE_H__
#define __SOLVE_H__
 /** 
  * @file solve.h
  * @brief Contains the main solving interfaces. 
  * Each method parses a formula (from an array or a file(s))
  * and solves it.
  * 
  */
  
/* @author kulikov */


/// @brief Solves a CNF formula from a given array.
///
/// Solves an input CNF formula 
/// given as array of clauses (a null-terminated 
/// array of null-terminated arrays of literals). 
/// If the formula is satisfiable, returns a
/// satisfying assignment (as a null-terminated array of literals).
/// Otherwise, returns NULL.
int*
solveCNF(const int* const* const array);

/// @brief Solves a CNF formula from a given file.
///
/// Reads a CNF formula given in DIMACS format from a given file
/// and solves it.
/// If the formula is satisfiable, returns a
/// satisfying assignment (as a null-terminated array of literals).
/// Otherwise, returns NULL.
int* 
solveCNF(const char* filename);

/// @brief Checks either two circuits or a circuit and a specification 
/// from given files for equivalence.
///
/// Reads either two input circuits or a circuit and a specification 
/// given in either ISCAS or RTL format
/// and checks whether they are equivalent (creates a formula 
/// stating that on some input two input circuits have different outputs).
/// Returns true, iff they 
/// are equivalent (note however that they are equivalent 
/// iff the resulting formula is unsatisfiable!).
bool
checkEquivalence(const char* filename1, const char* filename2);


/// @brief Solves a formula resulting from "merging" either 
/// two circuits or a circuit and a specification given in either 
/// ISCAS or RTL format.
///
/// Reads two input circuits given in either ISCAS or RTL format,
/// adds equalities stating that their inputs and outputs are equal,
/// and solves the resulting formula. Returns true iff the resulting 
/// formula is satisfiable.
bool
solve(const char* filename1, const char* filename2);


#endif


