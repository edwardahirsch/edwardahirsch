/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2001.
This file contains the implementation of the algorithm itself.
*********************************************************************/

#include "framework.h"
#include<string.h>

#define MaxRuns (I)
#define MaxAssigns (A)
#define MaxTime (T)

//GWSat
number Noise = 50;
number cutoff;
number breakTime;


number *UnitClauses;
number NumberOfUnitClauses;
/*
UnitClauses is a list of all literals appearing in unit clauses.
NumberOfUnitClauses is the size of UnitClauses.
*/

////////////////////////////////////////////////////////////////////////
int compare(const void*a,const void*b)
{
	return ((*((number*)a)) < (*((number*)b)));
}


////////////////////////////////////////////////////////////////////////
/*
void SetEqual(struct NumberWithLink *A, number *B)
// restores sizes of clauses from array B
{
  number Counter;
  
  for(Counter=0;Counter<NumberOfClauses;Counter++)
    A[Counter].Number = B[Counter]; 
}
*/
////////////////////////////////////////////////////////////////////////
void SetNewValue(struct NumberWithLink *Formula, number Variable, 
		number Value, number *y)
// Assign a value to a variable and update the formula accordingly.
{
  number Counter, Counter1, Counter2, NumberToChange, C1;
  number NumberOfVarsInClause;
  number *Clause;
  struct MyList *ThisClause;
#ifdef _BIN_
  struct MyList *ThisBinClause;
  struct MyList *NewDualClauses = NULL; 
#endif

#ifndef _SAT_COMP_
  Assign++;
#endif

  /* VariablesInClauses[Variable-1] is list of clauses with  
   * Variable 
   */
  
  ThisClause = VariablesInClauses[Variable-1];
  while(ThisClause!=NULL)
  {
    Counter1 = ThisClause->Number;
    
    /* Counter1 - number of current clause, 
     * Clause - current clause it self, 
     * NumberOfVarsInClause - size of current clause */
    
    Clause = Formula[Counter1].link;
    NumberOfVarsInClause = SavedSOC[Counter1];
    for(Counter2=0;Counter2<NumberOfVarsInClause;Counter2++) //search for +-Var
    {
      if(Clause[Counter2]==Variable) // +Variable \in Clause
      {
        if(Value==1) { SavedSOC[Counter1] = 0; break; } // remove Clause
        else
          {
	  /* Delete only this variable */
          SavedSOC[Counter1]--;
          NumberToChange = Clause[Counter2];
          Clause[Counter2] = Clause[SavedSOC[Counter1]];      
          Clause[SavedSOC[Counter1]] = NumberToChange;
          
          if(NumberOfVarsInClause==1)
	  {
	          Satisfied = 0; // now it's empty clause
          }
    	  else if(NumberOfVarsInClause==2) // now it's unit clause
	        {
	          UnitClauses[NumberOfUnitClauses]=Clause[0];
	          NumberOfUnitClauses++;
#ifdef _BIN_
                  tempAssign[abs(Clause[0]) - 1] = 0; 
#endif
	        }
#ifdef _BIN_
          // now the clause is 2-clause, we put it to the list
          // and after we call incBinSat for all new bin clauses   
          else if(NumberOfVarsInClause==3)
	  {
            ThisBinClause         = (struct MyList *) malloc(sizeof(struct MyList));
            ThisBinClause->link   = NewDualClauses;
            ThisBinClause->Number = Counter1;
            NewDualClauses        = ThisBinClause;
          }
#endif    
          break; // we are hoping there was only one occurrence of Variable
	      }
      }
      else
      {
        if(Clause[Counter2]==-Variable) // -Variable \in Clause
        {
          if(Value==0) { SavedSOC[Counter1]=0; break; } // remove Clause
          else
	    {
	    /* Delete only this variable */
            SavedSOC[Counter1]--;
            NumberToChange = Clause[Counter2];
            Clause[Counter2] = Clause[SavedSOC[Counter1]];      
            Clause[SavedSOC[Counter1]] = NumberToChange;
       
            if(NumberOfVarsInClause==1){
	            Satisfied = 0; // it's empty now
            } else if(NumberOfVarsInClause==2) // it's unit now
	          {
	            UnitClauses[NumberOfUnitClauses]=Clause[0];
	            NumberOfUnitClauses++;
#ifdef _BIN_
                    tempAssign[abs(Clause[0]) - 1] = 0;
#endif
	          }
#ifdef _BIN_
            // now the clause is 2-clause, we put it to the list
            // and after we call incBinSat for all new bin clauses   
            else if(NumberOfVarsInClause==3){
              ThisBinClause         = (struct MyList *) malloc(sizeof(struct MyList));
              ThisBinClause->link   = NewDualClauses;
              ThisBinClause->Number = Counter1;          
              NewDualClauses        = ThisBinClause;
            }
#endif		    
            break; // we are hoping there was only one occurrence of Variable
          }
        }
      }
    }
    
    ThisClause = ThisClause->link;
  }
#ifdef _BIN_
// for all new clauses of size 2 call incBinSat
  ThisClause = NewDualClauses;

  while(ThisClause!=NULL){
    ThisBinClause = ThisClause->link;
    Clause = Formula[ThisClause->Number].link;
    incBinSat(Clause[0], Clause[1],Formula,y);
    free(ThisClause);
    ThisClause = ThisBinClause;
  }
#endif
}

////////////////////////////////////////////////////////////////////////////
// Unit Propagation: if there is a unit clause,
// we assign to the corresponding variable a value that satisfies this clause.
number Conflicts=0, OldConflicts;
void PropUnit(struct NumberWithLink *Gi, number *y) 
{
  number Opposite,Number,Unit,C1;

  if(NumberOfUnitClauses!=0)
  {
    Opposite=0;

    // Take a unit clause from their list at random.
    // Therefore, the set of these clauses is treated as a MULTIset.
    Unit=UnitClauses[Number=random()%NumberOfUnitClauses];
    UnitClauses[Number]=UnitClauses[--NumberOfUnitClauses];
    
    // Looking for other occurrences of this variable in unit clauses...
    // SHOULD not waste time here, but determine this instead at the time of
    // generation of unit clauses 
    // (e.g., make an array HasUnit[variable] = 
    // +1 (positive), -1 (negative), 0 (no), 2 (both)).
    for(C1=NumberOfUnitClauses-1; C1>=0; C1--)
      if(UnitClauses[C1]==-Unit)
      { 
        Opposite=1; 
        UnitClauses[C1]=UnitClauses[--NumberOfUnitClauses];       
      }
      else if(UnitClauses[C1]==Unit)
        UnitClauses[C1]=UnitClauses[--NumberOfUnitClauses];       

      if(Opposite==0)
      {
        if(Unit>0){
          United[Unit-1]=1;
          // set current value in variable and put it into formula
      	  if (y[Unit-1]==0) Flip++;
#ifndef _SAT_COMP_
          if((Flip>p)&&(p!=-1))
            return;  
#endif
          y[Unit-1] = 1;
          SetNewValue(Gi, Unit, 1, y);
        }
        else //Unit<0
	{
          United[-Unit-1]=1;
          // set current value in variable and put it into formula
      	  if (y[-Unit-1]==1) Flip++;
#ifndef _SAT_COMP_
          if((Flip>p)&&(p!=-1))
            return;
#endif
          y[-Unit-1] = 0;
          SetNewValue(Gi, -Unit, 0, y);  
        }
      }
      // (Opposite == 1) ==> set the old value to this variable
      // COULD try to repair conflicts at this point
      else
      {
        Conflicts++;   
        SetNewValue(Gi, abs(Unit), y[abs(Unit)-1],y);
        United[abs(Unit)-1]=1;
      }
    return; // 1;
  }

  return; // 0;
}

#ifdef _BIN_
////////////////////////////////////////////////////////////////////////////
// this is temporary Unit Propagation of literal Lit 
void incTempPropUnit(number Lit,struct NumberWithLink *Formula,
		number *PermanentAssignment)
{
  number Counter;
  struct MyList *ThisClause;
  number *Clause;
  
  // If we have a conflict in temporarily assigned variables
  // (we already have -Lit in tempAssign with time of assignment == current):
  if(((tempAssign[abs(Lit)-1]==-curTime)&&(Lit>0))||
     ((tempAssign[abs(Lit)-1]==curTime)&&(Lit<0)))
  {
    UnitClauses[NumberOfUnitClauses++] = Lit; //???: 
                                              //1) UnitClauses are therefore
                                              //TEMPORARY Unit Clauses?
                                              //Otherwise, I do not understand
                                              //why Lit should be assigned
                                              //the positive value.
    
    while(NumberOfUnitClauses!=0)
    {
      PropUnit(Formula,PermanentAssignment);
#ifndef _SAT_COMP_
      if((Flip>p)&&(p!=-1))
        return;
#endif
    }
    return;
  }
  
  // No conflict: add Lit to temporary assignment
  tempAssign[abs(Lit)-1] = ((Lit>0)?curTime:-curTime);
   
  // Propagate further: for all clauses like (-Lit | y ) in Formula
  // recursively call incTempPropUnit(y,Formula,PermanentAssignment):
  ThisClause = VariablesInClauses[abs(Lit)-1];

  while(ThisClause!=NULL)
  {
    Clause = Formula[Counter=ThisClause->Number].link;
    
    if(SavedSOC[Counter]==2) // 2-clause
    {

      if(Clause[0]==-Lit) // found; 1st literal is "removed"
      {
        if(Clause[1]>0)
	{
          if(!(tempAssign[Clause[1]-1]>0)) // didn't have it=>haven't processed
            incTempPropUnit(Clause[1],Formula,PermanentAssignment);
#ifndef _SAT_COMP_
          if((Flip>p)&&(p!=-1))
            return;
#endif
        }
        else
	{
          if(!(tempAssign[-Clause[1]-1]<0))
            incTempPropUnit(Clause[1],Formula,PermanentAssignment);
#ifndef _SAT_COMP_
          if((Flip>p)&&(p!=-1))
            return;
#endif
        }  
      }
      else if(Clause[1]==-Lit) // the same for the second literal
      {
        if(Clause[0]>0)
	{
          if(!(tempAssign[Clause[0]-1]>0))
            incTempPropUnit(Clause[0],Formula,PermanentAssignment);
#ifndef _SAT_COMP_
          if((Flip>p)&&(p!=-1))
            return;
#endif
        }
        else
	{
          if(!(tempAssign[-Clause[0]-1]<0))
            incTempPropUnit(Clause[0],Formula,PermanentAssignment);
#ifndef _SAT_COMP_
          if((Flip>p)&&(p!=-1))
            return;
#endif
        }  
      }
    }
    
    ThisClause = ThisClause->link;
  }
}

////////////////////////////////////////////////////////////////////////////
// incremental algorithm for 2SAT: to Formula add new binary clause (Lit1 | Lit2) 
void incBinSat(number Lit1, number Lit2,struct NumberWithLink *Formula, 
		number *PermanentAssignment)
{
  curTime++; // increase current time
  
  while(NumberOfUnitClauses)
  {
    PropUnit(Formula,PermanentAssignment);
#ifndef _SAT_COMP_
    if((Flip>p)&&(p!=-1))
      return;
#endif
  }
// If one of literals in new clause is set temporarily to TRUE,
// or permanently to anything,
// do nothing:
  if((United[abs(Lit1)-1])||(United[abs(Lit2)-1]))
    return;
  
  if((tempAssign[abs(Lit1)-1]>0)&&(Lit1>0))
    return;
  if((tempAssign[abs(Lit1)-1]<0)&&(Lit1<0))
    return;

  if((tempAssign[abs(Lit2)-1]>0)&&(Lit2>0))
    return;
  if((tempAssign[abs(Lit2)-1]<0)&&(Lit2<0))
    return;
  
// Otherwise, temporarily set true value to Lit1 
  incTempPropUnit(Lit1,Formula,PermanentAssignment);  
#ifndef _SAT_COMP_
  if((Flip>p)&&(p!=-1))
    return;
#endif
}
#endif

//////////////////////////////////////////////////////////////////////////////
void flipbest(struct NumberWithLink *Gi, number *y,number *breakcount,number *UnSatClauses){
  number *clause,*Clause;
  number BestVars[NumberOfVars];
  number sizeOfBestVars = 0;
  struct MyList *ThisClause;
 
  number Counter,Counter3,Number,Counter1,Counter2, SizeOfClause,NumberOfVarsInClause;
  number isUnsat, Best = NumberOfClauses + 1, curBest; 

  Number =random()%NumberOfClauses;

  isUnsat = 0;
  for(Counter=Number;Counter<NumberOfClauses;Counter++){
    if(UnSatClauses[Counter]){
      isUnsat = 1;
      Number = Counter;
      break;
    }
  }
  if(!isUnsat)
  for(Counter=0;Counter<Number;Counter++){
    if(UnSatClauses[Counter]){
      isUnsat = 1;
      Number = Counter;
      break;
    }
  }
  if(!isUnsat){//there are no unsat clauses
    Satisfied=1;
    return;
  }
  
  // take random unsat clause 
  clause = Gi[Number].link;
  SizeOfClause = SavedSOC[Number];

  
  // clause is unsat 
  for(Counter=0;Counter<SizeOfClause;Counter++){
    curBest=breakcount[abs(clause[Counter])-1];  
      
    if(curBest<=Best){
      if(curBest<Best){
        sizeOfBestVars = 0;
        Best = curBest;
      }
      BestVars[sizeOfBestVars] = Counter;
      sizeOfBestVars++;
    }
  }
  if(Best>0)
  if((random()%100)< Noise){
    Number =abs(clause[random()%SizeOfClause])-1;
  }
  else  
    Number = abs(clause[BestVars[random()%sizeOfBestVars]])-1;
  else
    Number = abs(clause[BestVars[random()%sizeOfBestVars]])-1;
  
  y[Number] = 1- y[Number];

  ThisClause = VariablesInClauses[Number];
  while(ThisClause!=NULL){
    Counter1 = ThisClause->Number;

    Clause = Gi[Counter1].link;
    NumberOfVarsInClause = SavedSOC[Counter1];
    isUnsat = 1;
    
    for(Counter=0;Counter<NumberOfVarsInClause;Counter++){
      
      if(((y[abs(Clause[Counter])-1]==1)&&(Clause[Counter]>0))||
      ((y[abs(Clause[Counter])-1]==0)&&(Clause[Counter]<0))){
         if(isUnsat==1){
           isUnsat=0;
           Counter2=abs(Clause[Counter])-1;
         }
         else if(isUnsat==0){// it may be critical clause before flip
           isUnsat=-1;
           Counter3=abs(Clause[Counter])-1;
         }
         else{// it's not critical clause
           isUnsat=-2;
           break;
         }
      }
    }
    if(isUnsat==0){
      breakcount[Counter2]++;
      if(Counter2==Number){//this clause become sat after flip 
        UnSatClauses[Counter1]=0;
      }
    }
    else if(isUnsat==1){//unsat
      breakcount[Number]--;
      UnSatClauses[Counter1]=1;
    }
    else if(isUnsat==-1){
      if(Counter3==Number)
        breakcount[Counter2]--;
      else if(Counter2==Number)
        breakcount[Counter3]--;
    }
    
    ThisClause = ThisClause->link;
  }

}

//////////////////////////////////////////////////////////////////////////////
void GWSat(struct NumberWithLink *Gi, number *y){
  number C1=0,C2=0,Counter,NumberOfVarsInClause,*Clause;        
  number breakcount[NumberOfVars],isUnsat;
  number UnSatClauses[NumberOfClauses];
  
  for(C1=0;C1<NumberOfVars;C1++) breakcount[C1]=0;

  for(Counter=0;Counter<NumberOfClauses;Counter++){
    UnSatClauses[Counter]=0;
    Clause = Gi[Counter].link;
    NumberOfVarsInClause = SavedSOC[Counter];
    isUnsat = 1;


    for(C2=0;C2<NumberOfVarsInClause;C2++){
      if(((y[abs(Clause[C2])-1]==1)&&(Clause[C2]>0))||
      ((y[abs(Clause[C2])-1]==0)&&(Clause[C2]<0))){
         if(isUnsat==1){
           isUnsat=0;
           C1=abs(Clause[C2])-1;
         }
         else{// not critical clause
           isUnsat=-1;
           break;
         }
      }
    }
    if(isUnsat==0)
      breakcount[C1]++;
    else if(isUnsat==1){//unsat
      UnSatClauses[Counter]=1;
    }
  }

  Satisfied=0;

  C1=0;
  do{  
    if(C1==cutoff){
      break;
    }
#ifndef _SAT_COMP_
    Flip++;  
    if((Flip>p)&&(p!=-1))
      return;
#endif
    C1++;
    flipbest(Gi,y,breakcount,UnSatClauses);
  }while(Satisfied==0);
}


///////////////////////////////////////////////////////////////////////////////
void Modify(struct NumberWithLink *Gi, number *pi, number *y) 
// one pass of a modified Paturi-Pudlak-Zane algorithm
{
  number Counter,Number,Counter1,C1;
  number Variable;
  number Unit;
  number StartFlip=Flip;
  number Opposite; // do we have the unit clause opposite to the chosen one?
#ifdef _BIN_
  struct MyList *ThisClause;
  number *Clause;
#endif
  
  // PreUnitClauses is list of unit clauses that are premordialy in formula, 
  // UnitClauses is list of all unit clauses,
  // PreNumberOfUnitClauses and NumberOfUnitClauses - sizes of these lists
  NumberOfUnitClauses=PreNumberOfUnitClauses;
  for(Counter=0;Counter<PreNumberOfUnitClauses;Counter++)
    UnitClauses[Counter] = PreUnitClauses[Counter];

  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    United[Counter]=0; // United contains all variables that already have values
#ifdef _BIN_
    tempAssign[Counter]=0; // No variables have even temporary values yet
#endif
  }
  
#ifdef _BIN_
  // call incBinSat for all binary clauses of the input formula
  ThisClause = PreDualClauses;

  curTime = 1;

  while(ThisClause!=NULL){
    Counter = ThisClause->Number;
    Clause  = Gi[Counter].link;
    incBinSat(Clause[0],Clause[1],Gi,y);
#ifndef _SAT_COMP_
    if((Flip>p)&&(p!=-1))
      return;
#endif
    ThisClause = ThisClause->link;
  }
#endif

OldConflicts=Conflicts;
Conflicts=0;

// main cycle when all variables are assigning
  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    while(NumberOfUnitClauses)
    {
      PropUnit(Gi,y);
#ifndef _SAT_COMP_
      if((Flip>p)&&(p!=-1))
        return;
#endif
		      
    }
//h6-debug   printf("%ld:%ld ",Counter,Conflicts);

    // take variable accordingly to permutation pi
    Variable=pi[Counter];
              
    // if we already work with this variable then we skip it 
    if(United[Variable-1]!=1)
    {
#ifdef _BIN_
      // before set variable some permanent value try to set it temporally
      // in hope to create during this conflict in temporary assignment
      if(y[Variable-1])
        incTempPropUnit(Variable,Gi,y);
      else
        incTempPropUnit(-Variable,Gi,y);
  
#ifndef _SAT_COMP_
      if((Flip>p)&&(p!=-1))
        return;
#endif
		      
      while(NumberOfUnitClauses)
      {
        PropUnit(Gi,y);
#ifndef _SAT_COMP_
        if((Flip>p)&&(p!=-1))
          return;
#endif
      }
      
      if(United[Variable-1]!=1)
#endif
      {
        SetNewValue(Gi, Variable, y[Variable-1],y);
        United[Variable-1]=1;
      }

#ifdef ___MYVAR_DEBUG___      
     if(Flip>100) 
     {
       FormulaOut(Gi);
       printf("\nUnit clauses:");
       for(C1=0; C1<NumberOfUnitClauses; C1++) printf("%lld,",UnitClauses[C1]);
       printf("\n");
     }
#endif

    }
  }
  if (!Satisfied)
  if (StartFlip==Flip) 
  // then flip at random
  {
    number randvar;

    randvar=random()%NumberOfVars;
    y[randvar]=1-y[randvar];

 
#ifdef ___MYVAR_DEBUG___      
    if (NextOpposite!=0)
    {
      randvar=random()%NumberOfVars;
      y[randvar]=1-y[randvar];
    }
    else
    {
       printf("\n\nBUG%lld\n\n",Flip);
       exit(-1);
    }			  
#endif

  }
}

//////////////////////////////////////////////////////////////////////////////
number Search(struct NumberWithLink *Gi) // search for a satisfying assignment
{
number SizeOfNumber = sizeof(number);
number *SizesOfClauses = malloc(NumberOfClauses*SizeOfNumber);
number C, C1, C2, Number, Run, Period;
number pi[NumberOfVars];
number y[NumberOfVars];
number z[NumberOfVars];
number *zh = malloc(NumberOfClauses*SizeOfNumber);
time_t initime;
number ThisTry = 0;  
number AverageRun=0, AveragePeriod=0, AverageAssign=0, AverageFlip=0;

#ifndef _SAT_COMP_
long microsec;  

struct timeval tv;
struct timezone tz;

//new time
struct tms buf;
struct tms bbuf;
times(&bbuf);

//fix initial moment of time
gettimeofday(&tv,&tz);
microsec = tv.tv_usec;
initime=time(NULL);
#endif  
// SizesOfClauses is list of current clauses (arrays) sizes, 
// we quickly restore them from Gi[C].Number's after each iteration.  
//for(C=0;C<NumberOfClauses;C++) SizesOfClauses[C] = Gi[C].Number;
memcpy(SizesOfClauses,SavedSOC,NumberOfClauses*SizeOfNumber);     

FAILS=0;
UnitClauses=zh;
Conflicts=NumberOfVars;

SetPermutation(pi);  
GetRandomVector(y);
cutoff =(NumberOfVars*NumberOfVars)>>1;//*NumberOfClauses/5;
if(!cutoff)
  cutoff = 10*NumberOfVars;

breakTime = NumberOfVars;
  
#ifndef _SAT_COMP_

if((MaxPeriods=(NumberOfVars*p)/100)==0)
  MaxPeriods=NumberOfVars; 
  
if (!Quiet) printf("\n");

//--- Main Cycle ---
for (ThisTry=0; ThisTry<MaxTry; ThisTry++)
{ 
  if (MaxTry>0) if (!Quiet) printf("Try %lld/%lld...\n",ThisTry+1,MaxTry);
	
  for(Run=0, Assign=0, Flip=0; (Run<MaxRuns) && 
		  (time(NULL)<initime+MaxTime) && 
		  (Assign < MaxAssigns) && ((Flip<p)||(p==-1)); Run++)
  {
    if (!Quiet) 
    { 
      printf("\x00d[%lld:",Run); fflush(stdout); 
    }

    if (Run%2==0) 
    // get random vector or the reverse for the previous one
    {
      GetRandomVector(y);
      for(C1=0; C1<NumberOfVars; C1++) z[C1]=y[C1];
    }
    else 
      for(C1=0; C1<NumberOfVars; C1++) y[C1]=1-z[C1];

    for(Period=0; ((Period<MaxPeriods)||(p==-1))&&(time(NULL)<initime+MaxTime) 
        && ((Flip < p)||(p==-1)); Period++)
    {
      if (!Quiet) if (Period%25==0) 
      {
        printf("%c\x008",(Period%50==0)?'/':'\\'); 
        fflush(stdout);
      }

      if (aGiven) 
      { 
        printf("%lld,",dist(SatAssignment,y)); 
        fflush(stdout); 
      }
#endif
#ifdef _SAT_COMP_
    for(Period=0;;Period++){
#endif

      GetRandomPermutation(pi);
      Satisfied=1;
      //suppose that the current assignment can be made satisfying
      //until we prove the opposite

#ifdef ___MYVAR_DEBUG___      
      printf("\n Current vector transformed to:\n");
    
      for(C1=0; C1<NumberOfVars; C1++)
        printf("%lld, ",y[C1]);
#endif

      
      Modify(Gi,pi,y); 
#ifdef _SAT_COMP_
      if(Satisfied==0)
#endif
        memcpy(SavedSOC,SizesOfClauses,NumberOfClauses*SizeOfNumber);     
      
      if((Satisfied==0))//&&(!((Period+1)%breakTime)))
//      if(Satisfied==0)
      {
/*
        if(Noise == 50)
          Noise = 30;
        else if(Noise == 30)
          Noise = 70;
        else if(Noise == 70)
          Noise = 50;
*/        
//        printf("%lld<?%lld:%lld\n",OldConflicts,Conflicts,NumberOfVars/32);

      if ((Conflicts>=OldConflicts)&&(Conflicts>NumberOfVars/12)) GWSat(Gi,y);
#ifndef _SAT_COMP_
      if((Flip>p)&&(p!=-1))
      {
//        MaxTime = 0;
      }
#endif
      }
      //one pass of PPSZ

#ifndef _SAT_COMP_
      if(p==-1) if (!Quiet) 
      { 
        printf("\x00d[%lld:",Period); 
        fflush(stdout); 
      }
#endif

      if (Satisfied==1) 
      //found satisfying assignment
      {
#ifdef _SAT_COMP_
        printf("s SATISFIABLE");
        for(C1=0; C1<NumberOfVars; C1++){
        if(!(C1%5))
          printf("\nv ");        
        if(y[C1])
          printf("%lld ",C1+1);
        else
          printf("-%lld ",C1+1);
        }
        printf("0\n");       
        exit(10);
#endif          
#ifndef _SAT_COMP_

        gettimeofday(&tv,&tz);
        times(&buf);
/*   
        if(!Satisfy(Gi,y)){
          printf("!!!!!!!!!!!!BUG!!!!!!!!!!!");
          exit(-2);
        }
*/          
        
        if (aGiven) 
        { 
          printf("%lld",dist(SatAssignment,y)); 
          fflush(stdout); 
        }
    
        if (!Quiet) printf(" OK (Run=%lld,Period=%lld,Assigns=%lld,Flips=%lld,Time=%f,UserTime=%f,SysTime=%f)\n",
          Run+1,Period+1,Assign,Flip,
          (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
          ((float)buf.tms_utime+buf.tms_cutime - bbuf.tms_utime - bbuf.tms_cutime)/100,
          ((float)buf.tms_stime+buf.tms_cstime - bbuf.tms_stime - bbuf.tms_cstime)/100);

	
	      if (MaxTry==1) 
        //then also fprintf the assignment and this data
  	    {
          fprintf(outFile," v "); 
	        for(C1=0; C1<NumberOfVars; C1++) fprintf(outFile,"%lld",y[C1]);
	  
          fprintf(outFile,
	          "\n Run=%lld\n Period=%lld\n Assigns=%lld\n Flips=%lld\n Time=%f\n UserTime=%f\n SysTime=%f\n FAILS=%lld\n",
	          Run+1,Period+1,Assign,Flip,
	          (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
            ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/100,
            ((float)buf.tms_stime+buf.tms_cstime - bbuf.tms_stime - bbuf.tms_cstime)/100,
	        FAILS);
	      }

        AverageRun    += (Run+1);
        AveragePeriod += (Period+1);
        AverageAssign += Assign;
        AverageFlip   += Flip;
        MedianAssign[ThisTry] = Assign;
        MedianFlip[ThisTry] = Flip;

        Period=MaxPeriods+1; 
        Run=MaxRuns+1; 
        break; 
        //out of Period, Run cycles
#endif 
      }

    } //(Period)

#ifndef _SAT_COMP_

    if (aGiven) 
    { 
      printf("%lld\n",dist(SatAssignment,y)); 
      fflush(stdout); 
    }

  } //(Run)
 
  if (!Satisfied)
  {
    FAILS++;
    gettimeofday(&tv,&tz);
    times(&buf);
    if (!Quiet) printf(" FAIL (Run=%lld,Period=%lld,Assigns=%lld,Flips=%lld,Time=%f,UserTime=%f,SysTime=%f)\n",
          Run,Period,Assign,Flip,
          (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
          ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/100,
          ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/100);
    if (MaxTry==1) //then also fprintf the assignment and this data
    {
      fprintf(outFile," v ");
      for(C1=0; C1<NumberOfVars; C1++) fprintf(outFile,"%lld",y[C1]);

      fprintf(outFile,
	    "\n Run=%lld\n Period=%lld\n Assigns=%lld\n Flips=%lld\n Time=%f\n UserTime=%f\n SysTime=%f\n FAILS=%lld\n",
	    Run,Period,Assign,Flip,
	    (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
      ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/100,
      ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/100,
      FAILS);
    }
  }

} //(ThisTry)

//--- End Of Main Cycle ---

if (MaxTry>1) //printf and fprintf average data
{ 
  //fprintf the last satisfying assignment
  fprintf(outFile," v ");
  for(C1=0; C1<NumberOfVars; C1++) fprintf(outFile,"%lld",y[C1]);

  ThisTry -= FAILS;
    
  qsort(MedianAssign,MaxTry,SizeOfNumber,&compare);
  qsort(MedianFlip,MaxTry,SizeOfNumber,&compare);
  
  if(ThisTry!=0)
  {
    fprintf(outFile,"\n AverageRun=%f\n AveragePeriod=%f\n AverageAssigns=%lld\n AverageFlips=%lld\n MedianAssigns=%lld\n MedianFlips=%lld\n AverageTime=%f\n UserTime=%f\n SysTime=%f\n FAILS=%lld\n",
       (float)AverageRun/ThisTry, 
       (float)AveragePeriod/ThisTry, 
       AverageAssign/ThisTry, 
       AverageFlip/ThisTry,
       MedianAssign[MaxTry/2],
       MedianFlip[MaxTry/2],
       (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000)/ThisTry,
       ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/(ThisTry*100),
       ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/(ThisTry*100),
       FAILS);
  }
  else
  {
    fprintf(outFile,"\n MedianAssigns=%lld\n MedianFlips=%lld\n AverageTime=%f\n UserTime=%f\n SysTime=%f\n FAILS=%lld\n",
       Assign,
       Flip,
       (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
       ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/100,
       ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/100,
       FAILS);
  }                                                            

  if (!Quiet) 
    if(ThisTry!=0)
    {
      printf("AVERAGES: Run=%.2f,Period=%.2f,Assigns=%lld/%lld,Flips=%lld/%lld,Time=%f,UserTime=%f,SysTime=%f. FAILS=%lld)\n",
       (float)AverageRun/ThisTry, 
       (float)AveragePeriod/ThisTry,
       AverageAssign/ThisTry, 
       MedianAssign[MaxTry/2],
       AverageFlip/ThisTry,
       MedianFlip[MaxTry/2],
       (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000)/ThisTry, 
       ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/(ThisTry*100),
       ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/(ThisTry*100),
       FAILS);
    }
    else
    {
     printf("MEDIAN: Assigns=%lld,Flips=%lld,Time=%f,UserTime=%f,SysTime=%f. FAILS=%lld)\n",
      Assign,
      Flip,
      (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
      ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/100,
      ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/100,
      FAILS);
    }                                          
}
      
FreeVariablesInClauses();
for(C=0;C<NumberOfClauses;C++) free(Gi[C].link);
    
return FAILS; 
#endif
}

