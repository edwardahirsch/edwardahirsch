/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2001.
This is a header file. 
*********************************************************************/
#ifdef _MPI_
#include "mpi.h"
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/time.h> 
#include <sys/times.h> 
#include <dirent.h>
#include <libgen.h>
#include <errno.h>

#ifdef _BIN_
#define VERSION ("V0.981")
#else
#define VERSION ("V0.981-nobin")
#endif

#ifndef __VariablesOFProgram__
#define __VariablesOFProgram__

typedef long long int number;

//--- Data structures :

struct NumberWithLink // a clause: its size and array of literals
{	              
//  number Number;
  number *link;
};

struct MyList // list of clause numbers
{ 
  number Number;
  struct MyList *link;
};

struct MyList **VariablesInClauses; 
// Array of lists. VariablesInClauses[k-1] is a list of numbers of clauses 
// containing variable x_k. Used for quick search for a clause containing x_k.

struct MyList *PreDualClauses; // list of numbers of 2-clauses 
                               // in the input formula

number *SavedSOC; // saved sizes of clauses of formula

number *United; // array of permanent assigned variables 

number *PreUnitClauses; // PreUnitClauses is a list of numbers of unit clauses
                        // in the input formula.
number PreNumberOfUnitClauses; //size of PreUnitClauses 

#ifdef _BIN_
number *tempAssign;
// Temporary "assignment" for variables at time of incBinSat.
// Size of this array is NumberOfVars and if tempAssign[i] is non zero,
// then x_i has a temporary value ("true" if tempAssign[i]>0 or 
// "false" of tempAssign[i]<0); abs(tempAssign[i]) 
// is the time when the variable was set
number curTime;
// current time, increase by 1 with every call of incBinSat function
#endif

int Satisfied; // 1, if found a satisfying assignment; 0 otherwise.  

number *SatAssignment; // satisfying assignment, if supplied by the user
number NumberOfVars; // maximal number of a variable in the current formula
number NumberOfClauses; // number of clauses in the current formula

//--- Statistics: 
number FAILS; // number of failures
number Flip; // number of flips made so far for one try
number Assign ; // number of assignments made so far for one try

#ifndef _SAT_COMP_
number *MedianFlip; // total number of flips for for all tries
number *MedianAssign; // total number of assignments for for all tries
#endif

//--- The result of processing command-line parameters:
number I; // runs limit
number T; // time limit
number A; // assignments limit
number MaxPeriods; // max periods per run
number p; // MaxPeriods = NumberOfVariables * p / 100 
int Quiet; // be quiet
int aGiven; // -a given in command line
number MaxTry; // tries limit 
FILE *outFile; // output file
FILE *inFile;  // input file

//--- Functions:
// Random generators:
#ifndef __SetPermutation__
#define __SetPermutation__
void SetPermutation(number *Permutation); // fill the trivial permutation 
#endif
void GetRandomPermutation(number *Permutation); // random permutation of 1..n
void GetRandomVector(number *Vector); // random vector from {0,1}^NumberOfVars 

// I/O:
void OutVariablesInClauses(void); // debug info: prints VariablesInClauses[]
void FreeVariablesInClauses(); // frees memory from VariablesInClauses[]

number WorkWithCNF(); // Read formula from file (1) 
void WorkWithFile(char *InputFile); // Read formula from file (2)
int listdir(char *dirname); // runs WorkWithFile for dirname/*.cnf 

// Main:
int main(int argc,char *argv[]); // main program
number Search(struct NumberWithLink *Gi); // algorithm itself
void incBinSat(number Lit1, number Lit2,struct NumberWithLink *Gi, number *y);

#endif

