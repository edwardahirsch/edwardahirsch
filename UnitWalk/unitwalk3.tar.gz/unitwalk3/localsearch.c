#include "base.h"
#include <sys/time.h>
#include <sys/times.h>
#include <sys/types.h>

/**
 * Dummy modify function.
 * @@date 21.07.03
 */
void modify(LocalSearch *ls)
{
  ls->status = SATISFIABLE;
}
/**
 * Make typical local search. 
 * @date 21.07.03
 */ 
int makeLocalSearch(LocalSearch *localSearch)
{
  number MaxTry, MaxRuns;
#ifdef STATISTICS
  number MaxFlip, MaxTime, MaxAssignments, MaxConflicts, initTime;
#endif
  number MaxPeriods, OldConflicts;
  Statistics *myStatistics;
  number NumberOfVariables = localSearch->formula->number_of_variables;
  static struct tms prog_tms;
  myStatistics = localSearch->statistics;

#ifdef STATISTICS
  MaxFlip          = localSearch->constraints->max_flips;
  MaxTime          = localSearch->constraints->max_time;
  MaxAssignments   = localSearch->constraints->max_assignments;
  MaxConflicts     = localSearch->constraints->max_conflicts;
  initTime         = myStatistics->init_time;
#endif
  MaxRuns          = localSearch->constraints->max_runs;
  MaxTry           = localSearch->constraints->max_tries;
  MaxPeriods       = localSearch->constraints->max_periods;
  
  for (myStatistics->tries=0; myStatistics->tries<MaxTry; myStatistics->tries++)
  { 
#ifdef STATISTICS 
    myStatistics->assignments=0;
    myStatistics->flips=0; 
    myStatistics->conflicts = 0;
#endif
    for(myStatistics->runs=0; (myStatistics->runs<MaxRuns)||(MaxRuns==-1); 
      myStatistics->runs++)
    {
#ifdef STATISTICS
      if((myStatistics->flips < MaxFlip)&&(MaxFlip!=-1))
        break;

      if((time(NULL)<initTime+MaxTime)&&(MaxTime!=-1))
        break;

      if((myStatistics->assignments < MaxAssignments)&&(MaxAssignments!=-1))
        break;    

      if((myStatistics->conflicts < MaxConflicts)&&(MaxConflicts!=-1))
        break;
#endif      
      localSearch->assignment =
        setRandomAssignment(localSearch->assignment,NumberOfVariables);       
 
      for(myStatistics->periods=0; (myStatistics->periods<MaxPeriods)||
        (MaxPeriods==-1); myStatistics->periods++)
      {
#ifdef STATISTICS
      times(&prog_tms);
      localSearch->statistics->final_time = 
        prog_tms.tms_utime + prog_tms.tms_cutime;
#ifndef NDEBUG
      if(!(myStatistics->periods%1000))
        printStatistics(myStatistics);
#endif      
#endif
        localSearch->status = SATISFIABLE;
        
        OldConflicts = myStatistics->conflicts;
        myStatistics->conflicts = 0;
        modifyByUnitWalk(localSearch);
#ifndef NDEBUG        
        printf("%d<?%d:%d\n",OldConflicts,myStatistics->conflicts,NumberOfVariables/10);
#endif        
#ifdef _WALKSAT_
        if ((myStatistics->conflicts>=OldConflicts)
            &&(myStatistics->conflicts>NumberOfVariables/12))
        {
          modifyByWalkSat(localSearch);
        }
#endif
       
        if(localSearch->status == SATISFIABLE)
        {
          times(&prog_tms);
          localSearch->statistics->final_time = 
            prog_tms.tms_utime + prog_tms.tms_cutime;
          return 10;
        }
         
        if(localSearch->status == UNSATISFIABLE)
        {
          times(&prog_tms);
          localSearch->statistics->final_time = 
            prog_tms.tms_utime + prog_tms.tms_cutime;
          return 20;
        }
      } /// myStatistics->periods  
    } /// myStatistics->runs
  } /// myStatistics->tries 

  return -1; ///error: we should not be here 
}
