#include "base.h"
/**
 * Assign value to literal
 * @date 21.07.03
 */
void assignValue(LocalSearch *UnitWalk, number literal)
{
  Variable *myVar;
  Clause **clausesList;
  number sizeOfClausesList;
#ifdef _BIN_
  Clause **binClauseList;
  number sizeOfBinClauseList;
#endif
  ClauseStatus myClauseStatus;
  Clause *myClause;
  number c;
  number *unitClauses = UnitWalk->unit_clauses;

  ///debug

//  printf("Debug posi for %d:\n",literal);
/*
if(literal == 1068 || literal == -1068)
{
  myVar = &(UnitWalk->formula->variables[abs(1068)-1]);
  for(c=0;c<myVar->size_of_positive_list;c++)
    printClause(myVar->positive_list[c]);

  printf("Debug nega for %d:\n",literal);
  for(c=0;c<myVar->size_of_negative_list;c++)
    printClause(myVar->negative_list[c]);

  printf("End Debug\n");
}
*/
//  printFormula(UnitWalk->formula);
/*
  printf("before the %d\n",literal);
  myVar = &(UnitWalk->formula->variables[2389]);
  clausesList = myVar->negative_list;
  sizeOfClausesList = myVar->size_of_negative_list;
  for(c=0;c<sizeOfClausesList;c++)
    printClause((clausesList[c]));

  if(sizeOfClausesList==2)  
    exit(-1);
*/
#ifdef _BIN_
  myVar = &(UnitWalk->formula->variables[abs(literal) - 1]);
  /// debug for bin; in normal case that is impossible!
  if(myVar->period == UnitWalk->statistics->periods)
  {
    if(literal>0)
    {
      if(myVar->status==SET_TO_ZERO)
        UnitWalk->status = UNKNOWN;
    }
    else
    {
      if(myVar->status==SET_TO_ONE)
        UnitWalk->status = UNKNOWN;
    }
    return;
  }
#endif  
  if(literal>0)
  {
    myVar = &(UnitWalk->formula->variables[literal - 1]);
    clausesList       = myVar->negative_list;
    myVar->status     = SET_TO_ONE;
    sizeOfClausesList = myVar->size_of_negative_list; 
    myVar->size_of_negative_list = 0;
  }
  else
  { 
    myVar = &(UnitWalk->formula->variables[-literal - 1]);
    clausesList       = myVar->positive_list;
    myVar->status     = SET_TO_ZERO;
    sizeOfClausesList = myVar->size_of_positive_list;
    myVar->size_of_positive_list = 0;
  }
#ifdef _BIN_
  binClauseList = (Clause **) calloc(sizeOfClausesList, sizeof(Clause *));
  sizeOfBinClauseList = 0;
#endif
  /// unit question
  /// one of the reasons has size 1
  myVar->has_unit = 0;
  myVar->decision_level = UnitWalk->current_decision_level;

  myVar->period         = UnitWalk->statistics->periods;
#ifdef STATISTICS
      UnitWalk->statistics->assignments++;
#endif
  /// add variable to the implication graph
  UnitWalk->implication_graph[UnitWalk->size_of_implication_graph++] = literal; 

/*  
  for(c=0;c<UnitWalk->size_of_implication_graph;c++)
    printf("%d ",UnitWalk->implication_graph[c]);
  printf("\n"); 
*/
/* 
  printf("WLs for %d\n",literal);
  for(c=0;c<sizeOfClausesList;c++)
    printClause(clausesList[c]);
*/
  for(c=0;c<sizeOfClausesList;c++)
  { 
    myClause = clausesList[c];
/*
    printf("working with the clause: ");
    printClause(myClause);
*/
    myClauseStatus = assignClause(UnitWalk, myClause, -literal);
    switch(myClauseStatus)
    {
    case UNIT: 
//      printf("added new unit clause = %d\n",myClause->literals[0]);
      unitClauses[UnitWalk->size_of_unit_clauses++] = myClause->literals[0]; 
      continue;
      break;
    case BIN:
#ifdef _BIN_
      binClauseList[sizeOfBinClauseList++] = myClause;
#endif
      continue;
      break;
    default:
      continue;
      break;
    }  
  }
#ifdef _BIN_
  for(c=0;c<sizeOfBinClauseList;c++)
  {
    incBinSat(UnitWalk,binClauseList[c]);
  }
  free(binClauseList);
#endif
}


