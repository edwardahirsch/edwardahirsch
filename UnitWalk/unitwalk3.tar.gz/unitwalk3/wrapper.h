#ifndef _WRAPPER_H_
#define _WRAPPER_H_
/**
 * \file wrapper.h 
 * \brief C++ wrapper definitions for UnitWalk  
 * 
 * \author Arist Kojevnikov
 * \date 03.07.2003
 * 
 * \include wrapper.h
 */
//#include "../dpsat.h"
#include "base.h"

namespace unitwalk 
{ 
  /** UnitWalk C++ wrapper 
   *  
   * This wrapper is for inclusion to gateprop.
   *
   */
  class UnitWalk : public dpsat::GenericSATSolver
  {
  public:
    /// constructor
    UnitWalk(unsigned varnumber, DpCommObject* c) : NumberOfVars(varnumber), 
      myPreClauses(), mySolution(varnumber)
    {
      result = 28120107;
      srandom(result);
      Formula *myFormula = (Formula *) malloc(sizeof(Formula));
    }
   
    /// constructor with parameters
    UnitWalk(unsigned varnumber, const DpSatParameter& par, DpCommObject* c) : 
      NumberOfVars(varnumber), myPreClauses(), mySolution(varnumber)
    {}
    
    /**
     * In UnitWalk weights of all variable is 1.
     */
    virtual void
    setWeight(unsigned int, float)
    {}
    
    virtual bool 
    getValue(unsigned int x)
    {
    }
    
    /**
     * In this version we don't use any Parameters
     */
    virtual void 
    setParameters(const DpSatParameter & par)
    {}
    
    virtual bool
    enterInputClause(const std::vector<int>& cl);
    
    virtual void
    writeDimacs(std::ostream& out);
    
    virtual SatResult
    search(); 

    virtual std::ostream&
    assignment(std::ostream& out);

    /// destructor
    virtual ~UnitWalk()
    {}
  private:
    LocalSearch *myUnitWalk;
  }; /// class UnitWalk
} /// namespace unitwalk
#endif /// _WRAPPER_H_
