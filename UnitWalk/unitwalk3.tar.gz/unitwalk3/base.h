#ifndef UNITWALK_BASE
#define UNITWALK_BASE
/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2003.
This is a header file contains diffinitions of functions. 
*********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structures.h"
/// constuctors
LocalSearch *newLocalSearch(Formula *formula);
Formula *newFormula(Formula *formula);

/// destructors
void freeLocalSearch(LocalSearch *unitWalk);

/// work with memory
bool enlargeLiterals(Formula *formula);
bool enlargeClauses(Formula *formula);
bool enlargeWLlist(Variable *variable, bool enlargePosi);
#ifdef _WALKSAT_
bool enlargeALLlist(Variable *variable, bool enlargePosi);
#endif
/// work with formula
Clause *putClause(Formula *formula, number *array, number size,number id);

/// work with assignment 
bool testAssignment(Formula *formula, Assignment assignment);

/// work with clause
void initClause(Clause *clause,number *literals, number size);
ClauseStatus
assignClause(LocalSearch *UnitWalk, Clause *clause, number literal);
void heapSortClause(number *numbers, number array_size);
bool addReason(Clause *clause, Variable *myVariable,number myLiteral);
void restoreWLBack(number literal, Variable *variableList, Clause *clause);

/// work with variables
void assignValue(LocalSearch *UnitWalk, number literal);
bool UnitProp(LocalSearch *UnitWalk);
bool processUnitClauses(LocalSearch *UnitWalk);

/// reading formula from the file
Formula *readFormula(char *InputFile);

/// learning
number *resolve(number *first, number *second, number maxSize, number conflict,
  number *sizeOfArray);
bool learn(LocalSearch *UnitWalk, number conflictLit);

/// binary clauses
void incBinSat(LocalSearch *UnitWalk, Clause *clause);

///printing
void printFormula(Formula *formula);
void printClause(Clause *clause);
void printLiterals(number *start, number *end);
void printAssignment(Assignment y, number size);
void printConstraints(Constraints *constraints);
void printStatistics(Statistics *statistics);

/// random
Assignment  setRandomAssignment(Assignment ass, number size);
Permutation setRandomPermutation(Permutation myPermutation, number size);

/// local search algorithms
int makeLocalSearch(LocalSearch *localSearch);//typical local search
void modifyByUnitWalk(LocalSearch *UnitWalk); //unitwalk search
void modifyByWalkSat(LocalSearch *UnitWalk); 
#endif /// UNITWALK_BASE
