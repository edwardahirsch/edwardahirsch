#include "base.h"
/**
 * second part of heapsort algorithm.
 * @date 24.07.03
 */
void siftDown(number *numbers, number root, number bottom)
{
  number temp, i = root, c = root;
  number lastindex = bottom/2;  

  temp = numbers[i];
  while (c <= lastindex)
  {
    c = 2*i;    /* c = 2i is the left-child of i */
    if ((c+1<=bottom)&&(numbers[c + 1] > numbers[c]))
      c++;    /* c is the greatest child of i */
    if (temp >= numbers[c])
      break;
    numbers[i] = numbers[c];
    i = c;
  }
  numbers[i] = temp;
}
/**
 * heap Sort for the vector.
 * It is the most slow O(n log n) algorithm, but it does not use recursive
 * calls --- for small data structures better
 * @date 24.07.03
 */
void heapSortClause(number *numbers, number array_size)
{
  number i, temp;
  number *pas_numbers = numbers - 1;

  for (i = (array_size / 2); i >= 1; i--)
    siftDown(pas_numbers, i, array_size);

  for (i = array_size; i >= 2; i--)
  {
    temp = pas_numbers[1];
    pas_numbers[1] = pas_numbers[i];
    pas_numbers[i] = temp;
    siftDown(pas_numbers, 1, i-1);
  }
}


/**
 * Compute resolvent of two vectors
 * @note end of all vectors should be 0 
 * @note all vectors should be sorted 
 * @date 22.07.03
 */
number *resolve(number *first, number *second, number maxSize, number conflict,
  number *sizeOfArray)
{
  number *array = (number *) calloc(maxSize,sizeof(number));
  number Counter1 = 0, Counter2 = 0, Counter;
  number First, Second;
   
  if(conflict<0) 
    conflict = -conflict;

  for(Counter=0;;)
  {
    First = first[Counter1];
    Second = second[Counter2];
    if((First==0)&&(Second==0))
      break;

    if(First==Second) 
    {
      array[Counter] = First;
      Counter++;
      Counter1++; 
      Counter2++;
    }   
    else
    {
      if(First>Second)
      {  
        if(Second==0)
        { 
          if(conflict!=abs(First))
          {
            array[Counter] = First;
            Counter++;
          }
          Counter1++;
          continue;
        }

        if(conflict!=abs(Second))
        { 
          array[Counter] = Second;
          Counter++;
        }
        Counter2++;
      }
      else /// first[Counter1]<second[Counter2]
      {
        if(First==0)
        {
          if(conflict!=abs(Second))
          {
            array[Counter] = Second;
            Counter++;   
          } 
          Counter2++;
          continue;
        }

        if(conflict!=abs(First))
        { 
          array[Counter] = First;
          Counter++;
        } 
        Counter1++;
      }
    }
  }
  *sizeOfArray = Counter;
  return array;
}

/**
 * Init literal.
 * @date 18.07.03
 */
void initClause(Clause *clause,number *literals, number size)
{
  clause->literals = literals;
  clause->size     = size;
}
/**
 * Add reason
 * return true if conflict 
 * @date 25.07.03
 */
bool addReason(Clause *clause, Variable *myVariable, number myLiteral)
{
  bool returnValue = 0;
  number currentPeriod = clause->period;

  if(myLiteral > 0)
  {
    switch(myVariable->has_unit)
    {
    case -1:
      if(myVariable->negaReason->period==currentPeriod)
      {
        myVariable->has_unit = 2;
        returnValue = 1;
      }
      else
        myVariable->has_unit = 1;

      break;
    case 0:
      myVariable->has_unit = 1;
      break;
    default:/// 2, 1 --- don't change anything
      break;
    }
    myVariable->posiReason = clause;
  }  
  else
  {
    switch(myVariable->has_unit)
    {
    case 1:
      if(myVariable->posiReason->period==currentPeriod)
      {
        myVariable->has_unit = 2;
        returnValue = 1;
      }
      else
        myVariable->has_unit = -1;
      break;
    case 0:
      myVariable->has_unit = -1;
    default:/// 2, -1 --- don't change anything
      break;
    }
    myVariable->negaReason = clause;
  }
  return returnValue;
}

/**
 * restore the WL
 * @date 25.07.03
 */
void restoreWLBack(number literal, Variable *variableList, Clause *clause)
{
  Variable *myVariable = &(variableList[abs(literal)-1]);
  if(literal > 0)
    myVariable->positive_list[myVariable->size_of_positive_list++] = clause;
  else
    myVariable->negative_list[myVariable->size_of_negative_list++] = clause;
}

/**
 * Set literal in the clause
 * @date 21.07.03
 */
ClauseStatus assignClause(LocalSearch *UnitWalk, 
  Clause *clause, number literal)
{
  number *myLiterals    = clause->literals;
  number sizeOfLiterals = clause->size; 
  number Counter, myLiteral;
  Variable *myVariable;
  int WLchanged = 0;
  int isBinary  = 1;
  Variable *variableList = UnitWalk->formula->variables;
  number currentPeriod = UnitWalk->statistics->periods;

  ///debug
/*
  printf("Debug posi for :\n");
  myVariable = &(variableList[1]);
  for(Counter=0;Counter<myVariable->size_of_positive_list;Counter++)
    printClause(myVariable->positive_list[Counter]);
  
  printf("Debug nega:\n");
  for(Counter=0;Counter<myVariable->size_of_negative_list;Counter++)
    printClause(myVariable->negative_list[Counter]);
 
  printf("End Debug\n");
*/
  if(clause->period!=currentPeriod)
  {
    switch(clause->size)
    {
    case 1:
      clause->status = UNIT;
      break;
    case 2:
      clause->status = BIN;
      break;
    default:
      clause->status = NONE;
      break;
    }
    clause->period = currentPeriod;
  }

  switch(clause->status)
  {
  case NONE:
    /// work with WL 
    /// false literal should be at second place
    if(myLiterals[0]==literal)
    {
      myLiterals[0] = myLiterals[1];
      myLiterals[1] = literal;
    }

    /// Check if first literal is true
    myVariable = &(variableList[abs(myLiterals[0])-1]);  
    if(myVariable->period==currentPeriod)
    {
      restoreWLBack(literal, variableList, clause);
      clause->status = SATISFIED;
      return SATISFIED;
    }
    
    /// look for a new literal to watch
    for(Counter=2; Counter < sizeOfLiterals; Counter++)
    {
      myLiteral = myLiterals[Counter];
      myVariable = &(variableList[abs(myLiteral)-1]); 
      if(myVariable->period!=currentPeriod)
      {
        if(!WLchanged)/// not assigned in current period
        {  
          if(myLiteral > 0)
          { 
            /// add new clauseLink
            if(myVariable->size_of_positive_list == 
               myVariable->real_size_of_positive_list)
            {
//              printf("enlarge for literal: %d\n",myLiteral);
              enlargeWLlist(myVariable, 1);
            }

            myVariable->positive_list[myVariable->size_of_positive_list++]
              = clause;
          } 
          else
          {
            /// add new clauseLink
            
            if(myVariable->size_of_negative_list ==
               myVariable->real_size_of_negative_list)
            {
//              printf("enlarge for literal: %d\n",myLiteral);
              enlargeWLlist(myVariable, 0);
            }

            myVariable->negative_list[myVariable->size_of_negative_list++]
              = clause;
          }
          myLiterals[Counter] = myLiterals[1];
          myLiterals[1] = myLiteral;
          WLchanged = 1;
        }
        else /// in clause more then 2 not yet assigned variables
        {
          isBinary = 0; 
        }
      }
      else /// variable already have assignment
      { 
        if(myLiteral>0)
        {
          if(myVariable->status==SET_TO_ONE)
          {
            if(!WLchanged)
              restoreWLBack(literal, variableList, clause);
            clause->status = SATISFIED;
            return SATISFIED;
          }
        }
        else
        { 
          if(myVariable->status==SET_TO_ZERO)
          {
            if(!WLchanged)
              restoreWLBack(literal, variableList, clause);
            clause->status = SATISFIED;
            return SATISFIED;
          }
        }
      }
    }
    /// we have unit clause
    if(!WLchanged)
    {
      /// add reason to the first literal
      myLiteral = myLiterals[0];
      myVariable = &(variableList[abs(myLiteral)-1]);
    
      if(addReason(clause, myVariable, myLiteral))
        UnitWalk->conflict_variable = myLiteral;

      restoreWLBack(literal, variableList, clause);
      clause->status = UNIT;
      return UNIT;
    }
    if(isBinary)
    {
      clause->status = BIN;
      return BIN;
    }
    break;
  case BIN:
    /// create UnitClause
    if(myLiterals[0]==literal)
    {
      myLiterals[0] = myLiterals[1];
      myLiterals[1] = literal;
    }
    /// Check if first literal is true
    myLiteral = myLiterals[0];
    myVariable = &(variableList[abs(myLiteral)-1]);
    if(myVariable->period==currentPeriod)
    {
      clause->status = SATISFIED;
    }
    else /// add reason to literal
    { 
      if(addReason(clause, myVariable, myLiteral))
        UnitWalk->conflict_variable = myLiteral;
    }

    restoreWLBack(literal, variableList, clause);
    
    if(clause->status == SATISFIED)
      return SATISFIED;

    clause->status = UNIT;
    return UNIT;
    break;
  case UNIT:
    restoreWLBack(literal, variableList, clause);
    clause->status = UNSATISFIED;
    return UNSATISFIED;
    break;
  case UNSATISFIED:
    restoreWLBack(literal, variableList, clause);
    return UNSATISFIED;
    break;
  case SATISFIED:
    restoreWLBack(literal, variableList, clause);
    return SATISFIED;
    break;
  default:
    printf("BUG in assignClause, clause.c\n");
    exit(-10);
    break;
  }
  return NONE;
}
