/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2003.
This file contains output procedures. 
*********************************************************************/
#include "structures.h"
/**
 * Print statistics.
 * @date 25.07.03
 */
void printStatistics(Statistics *statistics)
{
  printf("c Runtime statistics:\n");
  printf("c   Number of runs        = %d\n", statistics->runs);
  printf("c   Number of tries       = %d\n", statistics->tries);
  printf("c   Number of flips       = %d\n", statistics->flips);
  printf("c   Overall running time  = %f\n", 
    ((double)statistics->final_time-statistics->init_time)/((double)CLK_TCK));
  printf("c   Number of periods     = %d\n", statistics->periods);
  printf("c   Number of assignments = %d\n", statistics->assignments);
  printf("c   Number of conflicts   = %d\n", statistics->conflicts);
}

/**
 * Print constraints.
 * @date 25.07.03
 */
void printConstraints(Constraints *constraints)
{
  number c;
  printf("c Runtime limits:\n");
  if((c=constraints->max_runs)!=-1)
    printf("c   Runs limit = %d\n", constraints->max_runs);
  else
    printf("c   No limits for runs\n");

  if((c=constraints->max_time)!=-1)
    printf("c   Maximal run time limit = %d sec.\n", c);
  else
    printf("c   Unlimited running time\n");

  if((c=constraints->max_assignments)!=-1)
    printf("c   Assignments limit = %d\n", c);
  else
    printf("c   No limits for number of assignments\n");

  if((c=constraints->max_periods)!=-1)
    printf("c   Limit for periods = %d\n", c);
  else
    printf("c   No limits for periods\n");

  if((c=constraints->max_tries)!=-1)
    printf("c   Limit for tries = %d\n", c);
  else
    printf("c   No limits for tries\n");

  if((c=constraints->max_flips)!=-1)
    printf("c   Limit for flips = %d\n", c);
  else
    printf("c   No limits for flips\n");

  if((c=constraints->max_conflicts)!=-1)
    printf("c   Limit for conflicts = %d\n", c);
  else
    printf("c   No limits for number of conflicts\n");
}

/**
 * Print assignment.
 * @date 24.07.03
 */
void printAssignment(Assignment y, number size)
{
  number C1;
  printf("v ");
  for(C1=0;C1<size;C1++)
  {
/*
    if(!((C1+1)%5))
      printf("\nv ");
*/
    if(y[C1])
      printf("%d ",C1+1);
    else
      printf("-%d ",C1+1);
  }
  printf("0\n");
}

/**
 * Print literals.
 * @todo change not to use size and c
 * @date 18.07.03
 */
void printLiterals(number *start, number *end)
{
  number size = end - start;
  number c;
  for(c=0;c<size;c++)
  {
    printf("%d ",start[c]); 
  }
}
/**
 * Print the clause.
 * @date 18.07.03
 */
void printClause(Clause *clause)
{
  number c, size;
  number *literals;
  
  literals = clause->literals;
  size = clause->size;
  for(c=0;c<size;c++)
  {
    printf("%d ",literals[c]);
  }
  printf("0");
#ifndef NDEBUG
  switch(clause->status)
  {
    case SATISFIED:
      printf("(=SAT) ");
      break;
      
    case UNSATISFIED:
      printf("(=FALSE) ");
      break;
      
    case NONE:
      printf("(= ) ");
      break;
      
    case BIN:
      printf("(=BIN) ");
      break;
      
    case UNIT:
      printf("(=UNIT) ");
      break;
      
    default:
      printf("(=?) ");
      break;
  }
#endif
  printf("\n");
}

/**
 * version of FormulaOut for new data structures:
 * prints the current formula in dimacs format
 */
void printFormula(Formula *formula)
{
  number Counter,Counter1, NumberOfVarsInClause; 
  number NumberOfClauses, NumberOfVars, Literal;
  number *myLiterals;
  Clause *clauseList = formula->clauses;
  
  NumberOfClauses = formula->number_of_clauses;
  NumberOfVars    = formula->number_of_variables;
  
  printf("\np cnf %d %d\n",NumberOfVars,NumberOfClauses);
  
  for(Counter=0;Counter<NumberOfClauses;Counter++)
  {
    myLiterals = clauseList[Counter].literals;
    NumberOfVarsInClause = clauseList[Counter].size;

//    printf("Number of vars = %d\n ", NumberOfVarsInClause);   
 
    for(Counter1=0;Counter1<NumberOfVarsInClause;Counter1++)
    {
//      printf("Counter = %d;", Counter1); 
      Literal = myLiterals[Counter1];
      printf("%d ",Literal);
#ifndef NDEBUG
      switch(formula->variables[abs(Literal)-1].status)
      {
      case SET_TO_ONE: 
        printf("(=1) ");
        break;
      case SET_TO_ZERO:
        printf("(=0) ");
        break;
      case NOT_SET:
        printf("(= ) ");
        break;
      default: 
        printf("BUG! ");
        break; 
      }
#endif
    }

    if(NumberOfVarsInClause!=0)
      printf("0 ");

#ifndef NDEBUG   
    switch(clauseList[Counter].status)
    {
    case SATISFIED:
      printf("(=SAT) ");
      break; 

    case UNSATISFIED:
      printf("(=FALSE) ");
      break;
 
    case NONE:
      printf("(= ) ");
      break;
    
     case BIN:
      printf("(=BIN) ");
      break;

     case UNIT:
      printf("(=UNIT) ");
      break;

    default:
      printf("(=?) ");
      break;
    }
#endif
    printf("\n");
  }
}
