#include "base.h"
/**
 * Unit propopogation 
 * @return 1 if conflict exist
 * @date 22.07.03
 */
bool UnitProp(LocalSearch *UnitWalk)
{
  number Unit, Number, Counter, sizeOfUnitClauses;
  number *UnitClauses = UnitWalk->unit_clauses;
  bool Opposite = 0;
  /// Take a unit clause from their list at random.
  /// Therefore, the set of these clauses is treated as a MULTIset.
  if((Unit = UnitWalk->conflict_variable))
  {
    UnitWalk->conflict_variable = 0;
    /// update the implication_graph
    UnitWalk->implication_graph[UnitWalk->size_of_implication_graph++] = Unit;
    UnitWalk->implication_graph[UnitWalk->size_of_implication_graph++] = -Unit;
    /// remove from unitclauses
    sizeOfUnitClauses = UnitWalk->size_of_unit_clauses;
    for(Counter=0;Counter<sizeOfUnitClauses;Counter++)
    {
      if(Unit<0)
        Unit = -Unit;

      if(abs(UnitClauses[Counter])==Unit)
      {
        UnitClauses[Counter]=UnitClauses[--UnitWalk->size_of_unit_clauses];
        sizeOfUnitClauses--;
      }
    }
    return 1;
  }
  
  Unit = UnitClauses[Number=random()%UnitWalk->size_of_unit_clauses];

  UnitClauses[Number]=UnitClauses[--UnitWalk->size_of_unit_clauses];

  sizeOfUnitClauses = UnitWalk->size_of_unit_clauses;
  /// we SHOULD do this --- we have MULTIset!!!
  for(Counter=0;Counter<sizeOfUnitClauses;Counter++)
  {
    if(UnitClauses[Counter]==Unit)
    {
      UnitClauses[Counter]=UnitClauses[--UnitWalk->size_of_unit_clauses];
      sizeOfUnitClauses--; 
    }
    else if(UnitClauses[Counter]==-Unit)
    {
      UnitClauses[Counter]=UnitClauses[--UnitWalk->size_of_unit_clauses];
      sizeOfUnitClauses--;
      Opposite = 1;
    }
  } 
  
  /// we have conflict
  if(Opposite)
  {
    /// update the implication_graph
    UnitWalk->implication_graph[UnitWalk->size_of_implication_graph++] = Unit;
    UnitWalk->implication_graph[UnitWalk->size_of_implication_graph++] = -Unit;
    return 1; 
  }
  /// flip?
  if(Unit>0)
  {
    if(!UnitWalk->assignment[Unit-1])
    {
      UnitWalk->assignment[Unit-1] = 1;
#ifdef STATISTICS
      UnitWalk->statistics->flips++;
#endif
    }
  }
  else
  {
    if(UnitWalk->assignment[-Unit-1])
    { 
      UnitWalk->assignment[-Unit-1] = 0;
#ifdef STATISTICS
      UnitWalk->statistics->flips++;
#endif
    }
  }
//  printf("Apply to %d by unitclause rule\n",Unit);
  assignValue(UnitWalk,Unit);
  return 0;  
}
