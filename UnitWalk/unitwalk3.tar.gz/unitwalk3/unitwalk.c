#include "base.h"
/**
 * Process unit cluases.
 * @return 1 if find proof of unsatisfiability
 * @date 25.07.03
 */
bool processUnitClauses(LocalSearch *UnitWalk)
{
  number decisionVariable;

  while(UnitWalk->size_of_unit_clauses)
  {
/*
    printf("Unit: ");
    printLiterals(UnitWalk->unit_clauses,
      UnitWalk->unit_clauses+UnitWalk->size_of_unit_clauses);
    printFormula(UnitWalk->formula);
    printf("\n");
*/
    if(UnitProp(UnitWalk))
    {
      /// resolve the conflict
#ifdef STATISTICS
      UnitWalk->statistics->conflicts++;
#endif
      decisionVariable =
        UnitWalk->unit_clauses[UnitWalk->size_of_unit_clauses];
#ifdef LEARNING
      if(learn(UnitWalk,decisionVariable))
        UnitWalk->status = UNSATISFIABLE;
      else
#endif
        UnitWalk->status = UNKNOWN;
#ifdef LEARNING
      return 1;
#endif
    }
  }
  return 0;
}

/**
 * Modify by UnitWalk
 * @date 21.07.03
 */
void modifyByUnitWalk(LocalSearch *UnitWalk)
{
  number c, decisionVariable;
  Formula *formula = UnitWalk->formula;
  number NumberOfVars = formula->number_of_variables;
  Permutation myPermutation = UnitWalk->permutation;
  Assignment  myAssignment  = UnitWalk->assignment;
  number sizeOfNumber  = sizeof(number);
  number currentPeriod = UnitWalk->statistics->periods;  
  Variable *Variables = formula->variables;
 
  myPermutation = setRandomPermutation(myPermutation,NumberOfVars);
  
  UnitWalk->current_decision_level = 0;

  /// init unit clauses with permanent unit clauses
  c = formula->size_of_permanent_unit_clauses;
  memcpy(UnitWalk->unit_clauses,formula->permanent_unit_clauses,
    c*sizeOfNumber);
  UnitWalk->size_of_unit_clauses = c; 

  /// before take a decision remove implication graph
  UnitWalk->size_of_implication_graph = 0;
#ifdef _BIN_
  UnitWalk->current_time = 0;
#endif
/*
  printf("Permutation: ");
  printLiterals(myPermutation, myPermutation+NumberOfVars);
  printf("\nAssignment: ");
  printAssignment(myAssignment,NumberOfVars);
*/
  /// process unit clauses
  if(processUnitClauses(UnitWalk))
    return;

  for(c=0;c<NumberOfVars;c++)
  {
    /// before take a decision remove implication graph
    UnitWalk->size_of_implication_graph = 0;

    decisionVariable = myPermutation[c];

    /// we already substitute this variable
   if(Variables[abs(decisionVariable)-1].period == currentPeriod)
     continue;

    /// and increment decision level
    UnitWalk->current_decision_level++;
    if(myAssignment[decisionVariable-1])
    {
//      printf("Decision Variable = %d\n",decisionVariable); 
      UnitWalk->unit_clauses[UnitWalk->size_of_unit_clauses++] =
        decisionVariable;
    }
    else
    {
//      printf("Decision Variable = -%d\n",decisionVariable);  
      UnitWalk->unit_clauses[UnitWalk->size_of_unit_clauses++] =
        -decisionVariable;
    }
    /// process unit clauses
    if(processUnitClauses(UnitWalk))
      return;
  }
//  UnitWalk->status = SATISFIABLE;
}
