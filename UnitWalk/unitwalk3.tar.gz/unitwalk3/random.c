#include "structures.h"
/**
 * Set random assignment.
 * @date 21.07.03
 */
Assignment setRandomAssignment(Assignment myAssignment,number size)
{
  number Counter;

  for(Counter=0;Counter<size;Counter++)
  {
    myAssignment[Counter] = random()%2;
  }
  return myAssignment;
}

/**
 * Set random permutation.
 * @date 21.07.03
 */
Permutation setRandomPermutation(Permutation myPermutation, number size)
{
  number Counter, Random, Number;

  for(Counter=0;Counter<size;Counter++)
  {
    Random = random()%size;
 
    Number = myPermutation[Counter];
    myPermutation[Counter] = myPermutation[Random];
    myPermutation[Random]  = Number;
  }
  return myPermutation;
}

