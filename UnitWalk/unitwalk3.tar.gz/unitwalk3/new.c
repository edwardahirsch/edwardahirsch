#include "structures.h"
#include <sys/time.h>
#include <sys/times.h>


/**
 * Default constructor for LocalSearch.
 * @date 18.07.03
 */
LocalSearch *newLocalSearch(Formula *myFormula)
{
  number NumberOfVariables = myFormula->number_of_variables;
  number NumberOfClauses   = myFormula->number_of_clauses;
  number Counter;
  static struct tms prog_tms;
  Constraints *myConstraints = (Constraints *) malloc(sizeof(Constraints));
  Statistics  *myStatistics  = (Statistics  *) malloc(sizeof(Statistics));
  LocalSearch *myUnitWalk    = (LocalSearch *) malloc(sizeof(LocalSearch));
  number sizeOfNumber = sizeof(number);  
  Permutation myPermutation;
  /// init the Constraints
  myConstraints->max_runs        = -1; ///infty 
  myConstraints->max_time        = -1; ///infty
  myConstraints->max_assignments = -1; ///infty
  myConstraints->max_periods     = -1; ///infty
  myConstraints->max_tries       = 1; 
  myConstraints->max_flips       = -1;
  myConstraints->max_conflicts   = -1;

#ifdef STATISTICS
  /// init the Statistics
  times(&prog_tms);
  myStatistics->init_time = prog_tms.tms_utime + prog_tms.tms_cutime; 
#endif 
  myUnitWalk->constraints = myConstraints;
  myUnitWalk->statistics  = myStatistics;

  myUnitWalk->status      = UNKNOWN;
  myUnitWalk->formula     = myFormula;
  myUnitWalk->assignment  = (bool *) calloc(NumberOfVariables,sizeof(bool));

  /// work with permutation
  myPermutation = (number *) calloc(NumberOfVariables,sizeOfNumber);
  myUnitWalk->permutation = myPermutation; 
  for(Counter=0;Counter < NumberOfVariables;Counter++)
  {
    myPermutation[Counter]=Counter+1;
  }

  /// init of list of unit clauses
  myUnitWalk->unit_clauses = (number *) calloc(NumberOfClauses, sizeOfNumber);
  myUnitWalk->size_of_unit_clauses = 0; 

  myUnitWalk->implication_graph = 
    (number *) calloc(2*NumberOfVariables, sizeOfNumber);
  
  myUnitWalk->size_of_implication_graph = 0; 

  myUnitWalk->conflict_variable = 0;

#ifdef _BIN_  
  /// init binary info
  myUnitWalk->temp_assignment = 
    (number *) calloc(NumberOfVariables, sizeOfNumber);
#endif
  return myUnitWalk;
}

/**
 * Allocate the formula; number_of_clauses and number_of_variables should 
 * be already diffined
 * @date 18.07.03
 */
Formula *newFormula(Formula *formula)
{
  number c;
  number numberOfClauses   = formula->number_of_clauses;
  number numberOfVariables = formula->number_of_variables; 
  Variable *variableList;
  Variable *myVariable;
  number sizeOfNumber     = sizeof(number);
  number sizeOfClause     = sizeof(Clause);
  number sizeOfClauseLink = sizeof(Clause *);
  number sizeOfVariable   = sizeof(Variable);
  number size;

  /// init clauses
  formula->clauses = (Clause *)
    calloc(numberOfClauses, sizeOfClause);
  formula->real_number_of_clauses = numberOfClauses;
 
  /// init variables
  formula->variables = (Variable *)
    calloc(numberOfVariables, sizeOfVariable);

  variableList = formula->variables;
  /// init variables
  for(c=0;c<numberOfVariables;c++)
  {
    myVariable  = &(formula->variables[c]);

    myVariable->positive_list = (Clause **)
      calloc(1, sizeOfClauseLink);

    myVariable->real_size_of_positive_list = 1;
    myVariable->size_of_positive_list = 0;

    myVariable->negative_list = (Clause **)
      calloc(1, sizeOfClauseLink);

    myVariable->real_size_of_negative_list = 1;
    myVariable->size_of_negative_list = 0;
#ifdef _WALKSAT_
    myVariable->all_positive_list = (Clause **)
      calloc(1, sizeOfClauseLink);

    myVariable->real_size_of_all_positive_list = 1;
    myVariable->size_of_all_positive_list = 0;

    myVariable->all_negative_list = (Clause **)
      calloc(1, sizeOfClauseLink);
    
    myVariable->real_size_of_all_negative_list = 1;
    myVariable->size_of_all_negative_list = 0;
                        
    myVariable->number_of_critical_clauses = 0; 
#endif
    myVariable->period = -1;
    myVariable->status = NOT_SET;
  }
  
  /// permanent unit clauses
  formula->permanent_unit_clauses = (number *) 
    calloc(numberOfClauses, sizeOfNumber);
  formula->size_of_permanent_unit_clauses = 0;

  /// init literals
//  size = 3*numberOfClauses;
  size = numberOfClauses;
  formula->literals_start = (number *)  calloc(size, sizeOfNumber);
  formula->literals_end      = formula->literals_start;
  formula->literals_real_end = formula->literals_start + size;

  return formula;
}
