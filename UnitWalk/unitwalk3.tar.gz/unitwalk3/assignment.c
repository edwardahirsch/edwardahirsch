#include "base.h"
/**
 * Test if assignment satisfy the formula
 * @date 24.07.03
 */
bool testAssignment(Formula *formula, Assignment assignment)
{
  number Counter1, Counter2, VarNumber;
  number NumberOfClauses = formula->number_of_clauses;
  number ValueOfClause = 0;
  number NumberOfVarsInClause;
  number *Literals;
  Clause *myClauses;
  Clause *myClause;

  myClauses = formula->clauses;
  for(Counter1=0;Counter1<NumberOfClauses;Counter1++)
  {
    myClause = &(myClauses[Counter1]);
    NumberOfVarsInClause = myClause->size;
    Literals = myClause->literals;

    for(Counter2=0;Counter2<NumberOfVarsInClause;Counter2++)
    {
      VarNumber=Literals[Counter2];
      if(VarNumber<0)
      {
        if(assignment[-VarNumber - 1]==0)
        {
          ValueOfClause = 1;
          break;
        }
      }
      else if(VarNumber>0)
      {
        if(assignment[VarNumber - 1]==1)
        {
          ValueOfClause = 1;
          break;
        }
      }
    }
    if(ValueOfClause==0 && NumberOfVarsInClause)
    {
      return 0;
    }
    ValueOfClause=0;
  }
  return 1;
}
