#include "base.h"


#ifdef _WALKSAT_
/**
 * Enlarge all clauses list, if exist such need
 * @return 0 if cannot allocate the memory
 * @date 09.08.03
 */
bool enlargeALLlist(Variable *variable, bool enlargePosi)
{
  Clause **list;
  number oldSizeOfList, newSizeOfList;
  Clause **oldList;

  if(enlargePosi)
  {
    oldList = variable->all_positive_list;
    oldSizeOfList = variable->real_size_of_all_positive_list;
  }
  else
  {
    oldList = variable->all_negative_list;
    oldSizeOfList = variable->real_size_of_all_negative_list;
  }

  newSizeOfList = oldSizeOfList*2;
  list = realloc(oldList, newSizeOfList*sizeof(Clause *));
  if(enlargePosi)
  {
    variable->all_positive_list = list;
    variable->real_size_of_all_positive_list = newSizeOfList;
  }
  else
  {
    variable->all_negative_list = list;
    variable->real_size_of_all_negative_list = newSizeOfList;
  }
  return 1;
}
#endif

/**
 * Enlarge WL list, if exist such need
 * @return 0 if cannot allocate the memory
 * @date 25.07.03
 */
bool enlargeWLlist(Variable *variable, bool enlargePosi)
{
  Clause **list;
  number oldSizeOfList, newSizeOfList;
  Clause **oldList;

//  printf("enlargeWLlist\n");
  
  if(enlargePosi)
  {
    oldList = variable->positive_list;
    oldSizeOfList = variable->real_size_of_positive_list;
  }
  else
  {
    oldList = variable->negative_list;
    oldSizeOfList = variable->real_size_of_negative_list;
  }

  newSizeOfList = oldSizeOfList*2;
  list = realloc(oldList, newSizeOfList*sizeof(Clause *));
  if(enlargePosi)
  {
    variable->positive_list = list;
    variable->real_size_of_positive_list = newSizeOfList;
  }
  else
  {
    variable->negative_list = list;
    variable->real_size_of_negative_list = newSizeOfList;
  }
  return 1;
}
/**
 * Enlarge literals space.
 * @return 0 if cannot allocate the memory
 * @date 23.07.03
 */
bool enlargeLiterals(Formula *formula)
{
  /// allocate new memory
  number *old_literals_start = formula->literals_start;
  number old_real_size       = formula->literals_real_end - old_literals_start;
  number old_size            = formula->literals_end - old_literals_start; 
  number new_size            = old_real_size * 2;
  number shift,c;
  number numberOfClauses     = formula->number_of_clauses;
  Clause *clauses            = formula->clauses;

//  printf("enlargeLiterals\n");
 
  formula->literals_start    = 
    realloc(old_literals_start,new_size*sizeof(number));
  formula->literals_end      = formula->literals_start + old_size;
  formula->literals_real_end = formula->literals_start + new_size;

  /// update all the clauses pointers
  shift = formula->literals_start - old_literals_start;
  for(c=0;c<numberOfClauses;c++)
  {
    clauses[c].literals += shift;
  }
  return 1;
}

/**
 * Enlarge clauses space.
 * @return 0 if cannot allocate the memory
 * @date 23.07.03
 */
bool enlargeClauses(Formula *formula)
{
  /// allocate new memory
  Clause *old_clauses_start = formula->clauses;
  number old_size           = formula->number_of_clauses;
  number new_size           = old_size * 2;
  number c;
  number numberOfVariables  = formula->number_of_variables;
  Variable *variables      = formula->variables;
  Clause **list;
  number size, c1, shift;

//  printf("enlargeClauses\n");

  formula->clauses = (Clause *)
    realloc(old_clauses_start,new_size*sizeof(Clause));
  formula->real_number_of_clauses = new_size;

  /// update all the clauses pointers
  shift = formula->clauses - old_clauses_start;
  for(c=0;c<numberOfVariables;c++)
  {
    list = variables[c].positive_list;
    size = variables[c].size_of_positive_list;  
    for(c1=0;c1<size;c1++)
    {
      list[c1] += shift;
    }
    
    list = variables[c].negative_list;
    size = variables[c].size_of_negative_list;
    for(c1=0;c1<size;c1++)
    {
      list[c1] += shift;
    }
#ifdef _WALKSAT_
    list = variables[c].all_positive_list;
    size = variables[c].size_of_all_positive_list;
    for(c1=0;c1<size;c1++)
    {
      list[c1] += shift;
    }
    
    list = variables[c].all_negative_list;
    size = variables[c].size_of_all_negative_list;
    for(c1=0;c1<size;c1++)
    {
      list[c1] += shift;
    }
#endif
  }
  return 1;
}

