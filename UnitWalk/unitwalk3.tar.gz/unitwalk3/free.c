#include "structures.h"

void freeFormula(Formula *formula);
/**
 * Default destructor for UnitWalk.
 * @date 18.07.03
 */
void freeLocalSearch(LocalSearch *ls)
{
  free(ls->constraints);
  free(ls->statistics);
  free(ls->assignment);
  free(ls->permutation);
  freeFormula(ls->formula);
  free(ls->unit_clauses);
  free(ls->implication_graph);
#ifdef _BIN_
  free(ls->temp_assignment);
#endif
  free(ls);
}
/**
 * Default destructor for Formula.
 * @date 18.07.03
 */
void freeFormula(Formula *formula)
{
  number c;
  number NumberOfVariables = formula->number_of_variables;

  /// free clauses
  free(formula->clauses);

  /// free variables
  for(c=0;c<NumberOfVariables;c++)
  { 
    free(formula->variables[c].positive_list);
    free(formula->variables[c].negative_list);
#ifdef _WALKSAT_
    free(formula->variables[c].all_positive_list);
    free(formula->variables[c].all_negative_list);
#endif
  }
  free(formula->variables);

  /// free unit clauses
  free(formula->permanent_unit_clauses);  

  /// free literals
  free(formula->literals_start);

  /// free formula it self
  free(formula);
}
