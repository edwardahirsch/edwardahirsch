#include "base.h"
/**
 * Give an answer if the array is for this decision level.
 * array end with 0
 * @23.07.03
 */
bool isUIParray(LocalSearch *UnitWalk, number *array)
{
  number Counter, Number;
  bool isUIP = 0;
  number curLevel = UnitWalk->current_decision_level;
  Variable *myVars = UnitWalk->formula->variables; 

  for(Counter=0;;Counter++)
  {
    Number = array[Counter];
    if(Number==0)
      break;

    if(myVars[abs(Number)-1].decision_level == curLevel)
    {
     if(!isUIP) /// no vars of curLevel were
       isUIP =1;
     else /// already was some variable of curLevel
       return 0;   
    }          
  }
  return 1;
}

/**
 * Find the best resolvent and add it to formula
 * @return 1 if contradiction
 * @23.07.03
 */
bool learn(LocalSearch *UnitWalk, number conflictLit)
{
  Formula *myFormula = UnitWalk->formula;
  number *myImplicationGraph = UnitWalk->implication_graph;
  number sizeOfImplicationGraph = UnitWalk->size_of_implication_graph;
  number numberOfVariables = myFormula->number_of_variables;
  number sizeOfNumber = sizeof(number);
  Variable *myVariables = myFormula->variables;  
 
  Clause *myReason1;
  number sizeOfReason1;
  number *Literals1 = (number *) malloc(sizeOfNumber*(numberOfVariables+1)); 
  
  Clause *myReason2;
  number sizeOfReason2;
  number *Literals2 = (number *) malloc(sizeOfNumber*(numberOfVariables+1));
 
  number *array;
  number sizeOfArray;
 
  if((conflictLit = myImplicationGraph[--sizeOfImplicationGraph]) > 0)
    myReason1 = myVariables[conflictLit - 1].posiReason;
  else
    myReason1 = myVariables[-conflictLit - 1].negaReason;
/*
  printf("\nreason1:");
  printClause(myReason1);
*/
  sizeOfReason1 = myReason1->size + 1;
  memcpy(Literals1,myReason1->literals,sizeOfNumber*sizeOfReason1);
  heapSortClause(Literals1,sizeOfReason1-1);

  while(sizeOfImplicationGraph>0)
  {
    if((conflictLit = myImplicationGraph[--sizeOfImplicationGraph]) > 0)
      myReason2 = myVariables[conflictLit - 1].posiReason;
    else
      myReason2 = myVariables[-conflictLit - 1].negaReason;
/*    
    printf("next reason:");
    printClause(myReason2);
*/
    sizeOfReason2 = myReason2->size + 1;

    memcpy(Literals2,myReason2->literals,sizeOfNumber*sizeOfReason2);
    heapSortClause(Literals2,sizeOfReason2-1);

    array = resolve(Literals1,Literals2,
      sizeOfReason1 + sizeOfReason2, conflictLit, &sizeOfArray);
/*  
    printf("Resolent: ");
    conflictLit = 0;
    while(array[conflictLit]!=0)
    {
      printf("%d ",array[conflictLit]);
      conflictLit++;
    }
    printf("\n");
*/  
    if(sizeOfArray==0)  /// Great! we derive contradiction!
    {
      free(array);
      free(Literals1);
      free(Literals2);
      return 1;
    }

    if(isUIParray(UnitWalk, array))/// Great! we find FirstUIP!
    {
//      printf("Great! we find FirstUIP!\n");
      /// now add this clause to the formula...
      putClause(myFormula,array,sizeOfArray,myFormula->number_of_clauses++);
      free(array);
      free(Literals1);
      free(Literals2);
      return 0;
    }
    free(Literals1);
    Literals1 = array;
    sizeOfReason1 = sizeOfArray;
  }
//  free(array);
  free(Literals1);
  free(Literals2);
  return 0;
} 

/**
 * Put clause to the formula.
 * It returns the clause.
 * @date 18.07.03
 */
Clause *putClause(Formula *formula, number *array, number size,number id)
{
  number c,literal;
  Variable *myVariable;
  Clause *myClause;
  number *literals; 
 
  if(id==formula->real_number_of_clauses)
  {
//    printf("enlarging clauses\n"); 
    enlargeClauses(formula);
  }
  myClause = &(formula->clauses[id]);

  if(formula->literals_real_end - formula->literals_end < size + 1)
  {
//    printf("enlarging literals\n");
    enlargeLiterals(formula);
  }

  initClause(myClause,formula->literals_end,size);
  literals = myClause->literals;
  /// init WL
  if(size!=0)
  for(c=0;c<2;c++)
  {
    literal = array[c];
    literals[c] = literal;
    
    if(literal>0)
    {
      myVariable = &(formula->variables[literal-1]);
      if(myVariable->size_of_positive_list ==
         myVariable->real_size_of_positive_list)
       enlargeWLlist(myVariable, 1);

      myVariable->positive_list[myVariable->size_of_positive_list++] 
        = myClause;

#ifdef _WALKSAT_
      if(myVariable->size_of_all_positive_list ==
          myVariable->real_size_of_all_positive_list)
        enlargeALLlist(myVariable, 1);
      
      myVariable->all_positive_list[myVariable->size_of_all_positive_list++]
        = myClause;
#endif
    }
    else
    {
      myVariable = &(formula->variables[-literal-1]);
      if(myVariable->size_of_negative_list ==
          myVariable->real_size_of_negative_list)
        enlargeWLlist(myVariable, 0);

      myVariable->negative_list[myVariable->size_of_negative_list++]
        = myClause;
#ifdef _WALKSAT_
      if(myVariable->size_of_all_negative_list ==
          myVariable->real_size_of_all_negative_list)
        enlargeALLlist(myVariable, 0);
      
      myVariable->all_negative_list[myVariable->size_of_all_negative_list++]
        = myClause;
#endif
    }

    if(size==1)/// unit clause!
      break;
  }

  for(c=2;c<size;c++)
  {
    literal = array[c];
    literals[c] = literal;
#ifdef _WALKSAT_
    if(literal>0)
    {
      myVariable = &(formula->variables[literal-1]);
      if(myVariable->size_of_all_positive_list ==
          myVariable->real_size_of_all_positive_list)
        enlargeALLlist(myVariable, 1);
      
      myVariable->all_positive_list[myVariable->size_of_all_positive_list++]
        = myClause;
    }
    else
    {
      myVariable = &(formula->variables[-literal-1]);
      if(myVariable->size_of_all_negative_list ==
          myVariable->real_size_of_all_negative_list)
        enlargeALLlist(myVariable, 0);
      myVariable->all_negative_list[myVariable->size_of_all_negative_list++]
        = myClause;
    }
#endif
  }

  literals[size] = 0;
  formula->literals_end += size + 1;
  myClause->period = -1;
#ifdef _WALKSAT_
  myClause->flip = -1;
#endif
  /// work with unit clause
  if(size==1)
  {
    formula->permanent_unit_clauses[formula->size_of_permanent_unit_clauses++] 
      = literal;
    /// add reason
    addReason(myClause, myVariable, literal);
  }
/*
  printf("new Clause: ");
  printClause(myClause);
*/
  return myClause;
}
