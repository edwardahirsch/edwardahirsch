/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2001.
This file contains main procedure.
*********************************************************************/

#include "base.h"
/* 
 * Main Program :
 */
int main(int argc,char *argv[])
{
  double result;
  char *NameOfFile;
  int mySearchResult;
  LocalSearch *myUnitWalk;
  Formula *myFormula;
  Assignment myAssignment;
  
  if(argc == 2)
  {
    result = 28120107;
  }      
  else if(argc != 3)
  {     
    printf("c Wrong command line format!\n");
    exit(-3);  
  }
  else
    result = atof(argv[2]);

  NameOfFile = argv[1];

  printf("c UnitWalk starting with random seed %.0f on %s\n",
    result, NameOfFile);

  srandom(result);

  myFormula = readFormula(NameOfFile);
  myUnitWalk = newLocalSearch(myFormula);

#ifdef STATISTICS
  printConstraints(myUnitWalk->constraints);
#endif
//  printFormula(myFormula);
//  printLiterals(myUnitWalk->formula->literals_start,
//    myUnitWalk->formula->literals_end);
  mySearchResult = makeLocalSearch(myUnitWalk);
  
//  printFormula(myFormula);
 
  switch (mySearchResult)
  {
    case 10:
#ifdef STATISTICS
      printStatistics(myUnitWalk->statistics);

      if(testAssignment(myFormula, myAssignment = myUnitWalk->assignment))
#endif 
        printf("s SATISFIABLE\n");
#ifdef STATISTICS
      else
        printf("c ERROR\n");
#endif
      printAssignment(myAssignment,myFormula->number_of_variables);
      break;
    case 20:
#ifdef STATISTICS
      printStatistics(myUnitWalk->statistics);
#endif
      printf("s UNSATISFIABLE\n");
      break; 
    default:
      printf("c ERROR\n");
      break;
  }
  fflush(stdout);
  freeLocalSearch(myUnitWalk);
  return(mySearchResult);
}
