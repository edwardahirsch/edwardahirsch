#include "base.h"
void 
addWL(number literal, Variable *Variables,Clause *clause);

/**
 * findStatus
 * @return true if clause unsat
 * @date 11.08.03
 */
bool findStatus(LocalSearch *UnitWalk, Clause *myClause, number literal)
{
  number *myLiterals = myClause->literals;
  number sizeOfLiterals = myClause->size;
  Assignment assignment = UnitWalk->assignment;
  number Counter=2, myLiteral;
  Variable *variableList = UnitWalk->formula->variables;

  if(myClause->size==1)
  {
    myLiteral = myLiterals[0];
    if(myLiteral>0)
    {
      if(!assignment[myLiteral- 1])/// first wl is false
      {
        myClause->status = UNSATISFIED;
        return 1;
      }
    }
    else
    {
      if(assignment[-myLiteral- 1])/// first is false
      {
        myClause->status = UNSATISFIED;
        return 1;
      }
    }
    myClause->status = UNIT;
    return 0;
  }
  
  
  if(myLiterals[0] == literal)
  {
    myLiterals[0] = myLiterals[1];
    myLiterals[1] = literal;
  }
  /// check if first literal is false
  myLiteral = myLiterals[0];
  if(myLiteral>0)
  {
    if(assignment[myLiteral- 1])/// first wl is true
      Counter=0;
  }
  else
  {
    if(!assignment[-myLiteral- 1])/// first is true
      Counter=0;
  }

  if(Counter)/// search for new first wl
  {
    for(; Counter < sizeOfLiterals; Counter++)
    {
      myLiteral = myLiterals[Counter];
      if(myLiteral>0)
      {
        if(assignment[myLiteral- 1])/// find new first wl
        {
          myLiterals[Counter] = myLiterals[0];
          myLiterals[0] = myLiteral;
          break;
        }
      }
      else
      {
        if(!assignment[-myLiteral- 1])/// find new first wl
        {
          myLiterals[Counter] = myLiterals[0];
          myLiterals[0] = myLiteral;
          break;
        }
      }
    }
    if(Counter == sizeOfLiterals)/// we fail to find sat literal
    {
      myClause->status = UNSATISFIED;
      return 1;
    }
    addWL(myLiterals[0], variableList, myClause);
  }
  else
    Counter = 2;

  /// check if second literal is true
  myLiteral = myLiterals[1];
  if(myLiteral>0)
  {
    if(assignment[myLiteral- 1])/// second wl is true
      return 0;
  }
  else
  {
    if(!assignment[-myLiteral- 1])/// second is true
      return 0;
  }

  /// search for new second wl
  for(; Counter < sizeOfLiterals; Counter++)
  {
    myLiteral = myLiterals[Counter];
    if(myLiteral>0)
    {
      if(assignment[myLiteral- 1])/// find new second wl
      {
        myLiterals[Counter] = myLiterals[1];
        myLiterals[1] = myLiteral;
        break;
      }
    }
    else
    {
      if(!assignment[-myLiteral- 1])/// find new second wl
      {
        myLiterals[Counter] = myLiterals[1];
        myLiterals[1] = myLiteral;
        break;
      }
    }
  }

  if(Counter == sizeOfLiterals)/// we fail to find sat literal
  {
    myClause->status = UNIT;
    variableList[abs(myLiterals[0])-1].number_of_critical_clauses++;
  }
  else
  {
    myClause->status = SATISFIED;
    addWL(myLiterals[1], variableList, myClause);
  }
  
  return 0;
}

/**
 * find New WL 
 * @return true if clause unsat
 * @date 07.08.03
 */
bool findNewWL(LocalSearch *UnitWalk, Clause *myClause, number literal)
{
  number *myLiterals = myClause->literals;
  number sizeOfLiterals = myClause->size;
  Variable *variableList = UnitWalk->formula->variables;
  Assignment assignment = UnitWalk->assignment;
  number Counter, myLiteral;

  switch(myClause->status)
  {
  case UNSATISFIED:
    return 1;
  case UNIT:
    myClause->status = UNSATISFIED;
    return 1;
  case NONE: 
  case BIN:
  case SATISFIED:
    /// true literal should be at first place
    if(myLiterals[0] == literal)
    {
      myLiterals[0] = myLiterals[1];
      myLiterals[1] = literal;
    }
    /// find new wl
    for(Counter=2; Counter < sizeOfLiterals; Counter++)
    {
      myLiteral = myLiterals[Counter];
      if(myLiteral>0)
      {
        if(assignment[myLiteral- 1])/// find new first wl
        {
          myLiterals[Counter] = myLiterals[1];
          myLiterals[1] = myLiteral;
          break;
        }
      }
      else
      {
        if(!assignment[-myLiteral- 1])/// find new first wl
        {
          myLiterals[Counter] = myLiterals[1];
          myLiterals[1] = myLiteral;
          break;
        }
      }
    }
    if(Counter == sizeOfLiterals)/// we fail to find sat 
    /// literal
    {
      myClause->status = UNIT;
      variableList[abs(myLiterals[0])-1].number_of_critical_clauses++;
      break;
    }
    addWL(myLiterals[1], variableList, myClause);
    break;
  default:
    printClause(myClause);
    printf("ERROR in walksat module!\n");
    exit(-30);
    break;
  }
  return 0;
}

/**
 * Update clause status
 * @date 17.08.03 
 */
void updateNewWL(LocalSearch *UnitWalk, Clause *myClause, number literal)
{
  number *literals;
  number sizeOfLiterals,C2;
  Variable *Variables = UnitWalk->formula->variables;
  Variable *myVariable = &Variables[abs(literal)-1];
    
  switch(myClause->status)
  {
    case UNIT:
      literals = myClause->literals;
      sizeOfLiterals = myClause->size;
      
      if(literals[0] == literal)
        return;
      
      for(C2=1;C2<sizeOfLiterals;C2++)
      {
        if(literals[C2] == literal)
        {
          if(C2!=1)
          {
            literals[C2] = literals[1];
            literals[1] = literal;
          }
          addWL(literals[1], Variables, myClause);
          Variables[abs(literals[0])-1].number_of_critical_clauses--;
          myClause->status = SATISFIED;
          break;
        }
      }
      break;
    case UNSATISFIED:
      literals = myClause->literals;
      sizeOfLiterals = myClause->size;
      for(C2=0;C2<sizeOfLiterals;C2++)
      {
        if(literals[C2] == literal)
        {
          literals[C2] = literals[0];
          literals[0] = literal;
          myVariable->number_of_critical_clauses++;
          addWL(literals[0], Variables, myClause);
          myClause->status = UNIT;
          break;
        }
      }
    default:
      return;
    break;
  }
}

/**
 * Flip best variable
 * @date 31.07.03
 */
void flipbest(LocalSearch *WalkSat,Clause **UnSatClauses,
  number *sizeOfUnSatClauses)
{
  number *literals, literal;
  Clause *myClause = NULL;
  Formula *formula = WalkSat->formula;  
  Variable *Variables = formula->variables;
  Variable *myVariable;
  number NumberOfVars = formula->number_of_variables;
  number NumberOfClauses = formula->number_of_clauses;
  number *BestVars = (number *) calloc(NumberOfVars,sizeof(number));
  Clause **list;
  number sizeOfList;
  number sizeOfBestVars = 0;
  number Noise = 50;
  bool *assignment = WalkSat->assignment;
  
  number Counter,Number,SizeOfClause;
  number Best = NumberOfClauses + 1, curBest;  
  number current_periods = WalkSat->statistics->periods;
  
  /// find first unsat clause at random
  Number = random()%(*sizeOfUnSatClauses);
  for(Counter=Number;Counter<*sizeOfUnSatClauses;)
  {
    if(UnSatClauses[Counter]->status==UNSATISFIED)
    {
      myClause = UnSatClauses[Counter];
      UnSatClauses[Counter] = UnSatClauses[--(*sizeOfUnSatClauses)];
      break;
    }
    else
      UnSatClauses[Counter] = UnSatClauses[--(*sizeOfUnSatClauses)];
  }
  if(myClause==NULL)
  {
    for(Counter=*sizeOfUnSatClauses-1;Counter>-1;Counter--)
    {
      if(UnSatClauses[Counter]->status==UNSATISFIED)
      {
        myClause = UnSatClauses[Counter];
        UnSatClauses[Counter] = UnSatClauses[--(*sizeOfUnSatClauses)];
        break;
      }
      else
      {
        UnSatClauses[Counter] = UnSatClauses[--(*sizeOfUnSatClauses)];
      }
    }
    if(myClause==NULL)
    {
      if((*sizeOfUnSatClauses)!=0)
        exit(-111);
      free(BestVars);
      return;
    }
  }

  literals = myClause->literals;
  SizeOfClause = myClause->size;
#ifndef NDEBUG
  printf("print unsat clause with size = %d:\n", SizeOfClause);
  printClause(myClause);
#endif
  /// myClause is unsat clause
  /// search for best variable to flip
  for(Counter=0;Counter<SizeOfClause;Counter++)
  {
#ifndef NDEBUG
    printf("calculate best for literal = %d\n", literals[Counter]);
#endif
    curBest = Variables[abs(literals[Counter])-1].number_of_critical_clauses;
    if(curBest<=Best)
    {
      if(curBest<Best)
      {
        sizeOfBestVars = 0;
        Best = curBest;
      }
      BestVars[sizeOfBestVars++] = Counter;
    }
#ifndef NDEBUG
    printf("print curBest vs Best: %d ? %d\n", curBest, Best);
#endif
  }
  if(Best>0 && (random()%100) < Noise)
    Number =abs(literals[random()%SizeOfClause])-1;
  else
  {
    if(sizeOfBestVars==1)
      Number = abs(literals[BestVars[0]])-1;
    else
      Number = abs(literals[BestVars[random()%sizeOfBestVars]])-1;
  }
  /// flip
  assignment[Number] = 1 - assignment[Number];
      
  /// recalculate breakcount
  myVariable = &Variables[Number];
  myVariable->number_of_critical_clauses = 0;
  
  if(assignment[Number])
    literal =   Number+1;
  else
    literal = -(Number+1);
  
  /// 1. set all critical clauses unsat
  if(literal>0)
  {
    list = myVariable->negative_list;
    sizeOfList = myVariable->size_of_negative_list;
    myVariable->size_of_negative_list = 0;
  }
  else
  {
    list = myVariable->positive_list;
    sizeOfList = myVariable->size_of_positive_list;
    myVariable->size_of_positive_list = 0;
  }
  
  for(Counter=0;Counter<sizeOfList;Counter++)
  {
    myClause = list[Counter];
    
    if(myClause->period!=current_periods)
    {
      if(findStatus(WalkSat, myClause, -literal))
        UnSatClauses[(*sizeOfUnSatClauses)++] = myClause;
      
      myClause->period=current_periods;
    }
    else
    {
      if(findNewWL(WalkSat, myClause, -literal))
        UnSatClauses[(*sizeOfUnSatClauses)++] = myClause;
    }
  }
  
  /// 2. decrease number_of_critical_clauses for other literals
  if(literal<0)
  {
    list = myVariable->all_negative_list;
    sizeOfList = myVariable->size_of_all_negative_list;
  }
  else
  {
    list = myVariable->all_positive_list;
    sizeOfList = myVariable->size_of_all_positive_list;
  }
  for(Counter=0;Counter<sizeOfList;Counter++)
  {
    myClause = list[Counter];
    
    if(myClause->period!=current_periods)
    {
      myClause->period = current_periods;
      findStatus(WalkSat, myClause, 0);
    }
    updateNewWL(WalkSat, myClause, literal);
  }
  free(BestVars);
}
/**
 * AddWL  
 */
void addWL(number literal, Variable *Variables,Clause *clause)
{
  Variable *myVariable;
  if(literal>0)
  {
    myVariable = &Variables[literal-1];
    
    if(myVariable->size_of_positive_list ==
        myVariable->real_size_of_positive_list)
    {
      enlargeWLlist(myVariable,1);
    }
    myVariable->positive_list[myVariable->size_of_positive_list++] = clause;      }
  else
  {
    myVariable = &Variables[-literal-1];
    if(myVariable->size_of_negative_list ==
        myVariable->real_size_of_negative_list)
    {
      enlargeWLlist(myVariable,0);
    }
    myVariable->negative_list[myVariable->size_of_negative_list++] = clause;      }
}   
/**
 * WalkSat
 * @date 31.07.03
 */
void modifyByWalkSat(LocalSearch *WalkSat)
{
  number C1=0,Counter;
  Formula *formula = WalkSat->formula;
  number NumberOfClauses = formula->number_of_clauses;
  Variable *Variables = formula->variables;
  Clause *myClauses = formula->clauses;
  Variable *myVariable;
  number NumberOfVariables = formula->number_of_variables;
  bool *assignment = WalkSat->assignment;
  Clause **list;
  Clause *myClause;
  Statistics *statistics = WalkSat->statistics;
  number sizeOfList, myLiteral;
  Clause **UnSatClauses = (Clause **) calloc(NumberOfClauses,sizeof(Clause *));
  number sizeOfUnSatClauses = 0; 
  number *literals;
  number current_periods = ++(WalkSat->statistics->periods);
  number cutoff;

  /// update WLs:
  for(Counter=0;Counter<NumberOfVariables;Counter++)
  {
    myVariable = &Variables[Counter];
    myVariable->number_of_critical_clauses = 0;
    if(assignment[Counter])
    {
      myLiteral = Counter+1;
      list = myVariable->negative_list;
      sizeOfList = myVariable->size_of_negative_list;
      myVariable->size_of_negative_list = 0;
    }
    else
    {
      myLiteral = -Counter-1;
      list = myVariable->positive_list;
      sizeOfList = myVariable->size_of_positive_list;
      myVariable->size_of_positive_list = 0;
    }
      
    for(C1=0;C1<sizeOfList;C1++)
    {
      myClause = list[C1];
      if(myClause->period == current_periods)
      {
//        printClause(myClause);
//        printf(" = %d, %d\n", myClause->status, current_periods);
        continue;
      }
//      printf(" %d = %d?\n",current_periods, myClause->period);
      myClause->period = current_periods;

      myClause->status = SATISFIED;
      if(findStatus(WalkSat, myClause, -myLiteral))
        UnSatClauses[sizeOfUnSatClauses++] = myClause;
    }
  }
#ifndef NDEBUG
  printFormula(formula);
#endif
  cutoff =(NumberOfVariables*NumberOfVariables)>>1;//*NumberOfClauses/5;
  if(!cutoff)
    cutoff = 10*NumberOfVariables;
  cutoff += statistics->flips;
    
  while(sizeOfUnSatClauses!=0)
  {
#ifndef NDEBUG    
    if(!(statistics->flips%100000))
      printf("%d\n",statistics->flips);
#endif
    if(statistics->flips == cutoff)
      break;
    
    flipbest(WalkSat,UnSatClauses,&sizeOfUnSatClauses);
    statistics->flips++;
  }

  // restore WLs. Not very effective...
  for(Counter=0;Counter<NumberOfVariables;Counter++)
  {
    myVariable = &Variables[Counter];
    myVariable->size_of_negative_list = 0;
    myVariable->size_of_positive_list = 0;
  }
                                                    
  for(Counter=0;Counter<NumberOfClauses;Counter++)
  {
    myClause = &myClauses[Counter];
    literals = myClause->literals;
    switch(myClause->size)
    {
      case 0:
        printf("ERROR Size of Clause == 0!\n");
        exit(-30);
        break;    
      case 1:
        addWL(literals[0], Variables, myClause);
        myClause->status = UNIT;
        break;
      case 2:
        addWL(literals[0], Variables, myClause);
        addWL(literals[1], Variables, myClause);
        myClause->status = BIN;
        break;
      default:
        addWL(literals[0], Variables, myClause);
        addWL(literals[1], Variables, myClause);
        myClause->status = NONE;
    }
  }
  
  free(UnSatClauses);
}
