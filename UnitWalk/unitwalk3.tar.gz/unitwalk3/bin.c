#include "base.h"
/**
 * Incremental propUnit
 * @date 29.07.03
 */
void incTempPropUnit(LocalSearch *UnitWalk,number literal)
{
  Variable *myVar;
  Clause **clausesList;
  number sizeOfClausesList;
  Clause *myClause;
  number c, newLiteral;
  number *literals;
  number *tempAssign = UnitWalk->temp_assignment;
  number curTime     = UnitWalk->current_time;
  number *newTempAss = (number *) 
    malloc(UnitWalk->formula->number_of_variables*sizeof(number));
  number sizeOfNewTempAss = 0; 

  /// If we have a conflict in temporarily assigned variables
  /// (we already have -Lit in tempAssign with time of assignment == current):
  if(((tempAssign[abs(literal)-1]==-curTime)&&(literal>0))||
     ((tempAssign[abs(literal)-1]==curTime)&&(literal<0)))
  {
    UnitWalk->unit_clauses[UnitWalk->size_of_unit_clauses++] = literal;
  
    /// process unit clauses
//    processUnitClauses(UnitWalk);
    free(newTempAss);
    return;
  }
  /// No conflict: add Lit to temporary assignment
  tempAssign[abs(literal)-1] = ((literal>0)?curTime:-curTime);
 
  /// Propagate further: for all clauses like (-Lit | y ) in Formula
  /// recursively call incTempPropUnit(y,Formula,PermanentAssignment):
  if(literal>0)
  {
    myVar             = &(UnitWalk->formula->variables[literal - 1]);
    clausesList       = myVar->negative_list;
    sizeOfClausesList = myVar->size_of_negative_list;
  }
  else
  {
    myVar             = &(UnitWalk->formula->variables[-literal - 1]);
    clausesList       = myVar->positive_list;
    sizeOfClausesList = myVar->size_of_positive_list;
  }
/*
  printf("Clauses to bin:\n");
  for(c=0;c<sizeOfClausesList;c++)
    printClause(clausesList[c]);
*/
  for(c=0;c<sizeOfClausesList;c++)
  {
    myClause = clausesList[c];
  
    /**
     * check the clause is BIN?
     */
  
    if((myClause->status == BIN) || 
      (myClause->period==UnitWalk->statistics->periods))
    {
      literals = myClause->literals;
      if(literals[0] == -literal)
        newTempAss[sizeOfNewTempAss++] = literals[1];
      else
        newTempAss[sizeOfNewTempAss++] = literals[0];
    }
  }
  for(c=0;c<sizeOfNewTempAss;c++)
  { 
    newLiteral = newTempAss[c];
    if(newLiteral > 0)
    {
      if((tempAssign[newLiteral - 1] != curTime))
        incTempPropUnit(UnitWalk,newTempAss[c]);
    }
    else
    {
      if((tempAssign[-newLiteral - 1] != -curTime))
        incTempPropUnit(UnitWalk,newTempAss[c]);
    }
  }
  free(newTempAss);
}
/**
 * incremental algorithm for 2SAT: to Formula add new binary clause
 * (Lit1 | Lit2)
 * @date 30.07.03
 */
void incBinSat(LocalSearch *UnitWalk, Clause *clause)
{
  number Lit1 = clause->literals[0];
  number Lit2 = clause->literals[1];
  number currentPeriod = UnitWalk->statistics->periods;
  number *tempAssign = UnitWalk->temp_assignment;

  UnitWalk->current_time++;
  /// If one of literals in new clause is set temporarily to TRUE,
  /// or permanently to anything,
  /// do nothing:
  if(UnitWalk->formula->variables[abs(Lit1)-1].period==currentPeriod)
    return;
  
  if(UnitWalk->formula->variables[abs(Lit2)-1].period==currentPeriod)    
    return;

  if((tempAssign[abs(Lit1)-1]>0)&&(Lit1>0))
    return;
  if((tempAssign[abs(Lit1)-1]<0)&&(Lit1<0))
    return;

  if((tempAssign[abs(Lit2)-1]>0)&&(Lit2>0))
    return;
  if((tempAssign[abs(Lit2)-1]<0)&&(Lit2<0))
    return;
  
  // Otherwise, temporarily set true value to Lit1
  incTempPropUnit(UnitWalk,Lit1);
  processUnitClauses(UnitWalk);
}
