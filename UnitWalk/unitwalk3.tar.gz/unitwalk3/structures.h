#ifndef UNITWALK_DATA_STRUCTRURES
#define UNITWALK_DATA_STRUCTRURES
/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2003.
This is a header file with description of data structures. 
*********************************************************************/
#include <stdio.h>
#include <stdlib.h>
/// basic number type
typedef int number;

#ifndef CLK_TCK
#define CLK_TCK 100
#endif

/**
 * Status of the clause.
 * @date 21.07.03
 */
enum ClauseStatus
{
  SATISFIED,
  UNIT,
  UNSATISFIED,
  BIN,
  NONE
};
typedef enum ClauseStatus ClauseStatus;

/**
 * Data structure for the clause.
 * @date 23.06.03
 */
struct Clause
{
  number *literals;    ///< array of literals
  number size;         ///< size of the clause
  ClauseStatus status; 
  number period;
#ifdef _WALKSAT_
  number flip;
#endif
  number id;
};
typedef struct Clause Clause;

/**
 * Status of variable
 * @date 21.07.03 
 */
enum VariableStatus
{
  SET_TO_ONE,
  SET_TO_ZERO,
  NOT_SET
};
typedef enum VariableStatus VariableStatus;
/**
 * Data structure for the variable.
 * @date 18.07.03 
 */
struct Variable
{
  /// variable for fast conflicts search: determine them at the time of
  /// generation of unit clauses
  /// (e.g., has_unit =
  /// +1 (positive), -1 (negative), 0 (no), 2 (both)).
  number has_unit;

  /// number id;
  number decision_level;

  /// reasons for learning 
  Clause *negaReason; ///< reason for negative literal
  Clause *posiReason; ///< reason for negative literal

  VariableStatus status; 
  number period;

  /// list of WLs
  Clause **positive_list;
  number size_of_positive_list;
  number real_size_of_positive_list;

  Clause **negative_list;
  number size_of_negative_list;
  number real_size_of_negative_list;

#ifdef _WALKSAT_
  /// list of all clauses
  Clause **all_positive_list;
  number size_of_all_positive_list;
  number real_size_of_all_positive_list;

  Clause **all_negative_list;
  number size_of_all_negative_list;
  number real_size_of_all_negative_list;
            
  number number_of_critical_clauses;
#endif
};
typedef struct Variable Variable;

/**
 * Data structure for the formula.
 * @date 18.07.03
 */
struct Formula
{ 
  /// clauses
  Clause   *clauses;
  number number_of_clauses;
  number real_number_of_clauses;
  
  /// variables
  Variable *variables;
  number number_of_variables;

  /// permanent unit clauses
  number *permanent_unit_clauses;
  number size_of_permanent_unit_clauses; 

  /// literals
  number *literals_start;
  number *literals_end;
  number *literals_real_end; 
};
typedef struct Formula Formula;

#ifndef UNITWALKXX
enum BOOLEAN
{
  TRUE=1,
  FALSE=0
};
typedef enum BOOLEAN bool;
#endif
/**
 * Structure for assignment.
 * @date 21.07.03
 */
typedef bool * Assignment;

/**
 * Structure for permutation.
 * @date 21.07.03
 */
typedef number * Permutation;
/**
 * Constraints for the algorithm.
 * @date 18.07.03
 * +\infty can be defined by -1
 */
struct Constraints
{
  number max_runs;
  number max_time;  
  number max_assignments;
  number max_periods;
  number max_tries;
  number max_flips;
  number max_conflicts;
};
typedef struct Constraints Constraints;

/**
 * Statistics of the algorithm
 * @date 21.07.03
 */
struct Statistics
{
  number runs;
  number tries;
  number flips;
  number init_time;
  number final_time;
  number periods;
  number assignments;  
  number conflicts;
};
typedef struct Statistics Statistics;

/**
 * Status of the local search. 
 * @date 18.07.03
 */
enum SearchStatus
{
  SATISFIABLE,
  UNSATISFIABLE,
  UNKNOWN
};
typedef enum SearchStatus SearchStatus;
/**
 * UnitWalk structure.
 * @date 18.07.03
 */
struct LocalSearch
{
  /// initial data
  Constraints  *constraints;
  Formula      *formula;

  /// runtaime data
  Statistics   *statistics;
  SearchStatus status;

  Assignment   assignment;
  Permutation  permutation;
 
  /// learning and backtrack tools 
  number *implication_graph; 
  number conflict_variable; 
  number size_of_implication_graph;
  number current_decision_level;
  
  /// list of all unit clauses (treated as a MULTIset)
  number *unit_clauses;
  number size_of_unit_clauses;

#ifdef _BIN_
  /// data for binary clauses
  /// we also store here the current_time of variable
  number *temp_assignment;
  number current_time;
#endif
};
typedef struct LocalSearch LocalSearch;
#endif /// UNITWALK_DATA_STRUCTRURES
