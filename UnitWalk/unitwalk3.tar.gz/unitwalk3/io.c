/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2001.
This file contains input-output procedures.
*********************************************************************/

#include "base.h"
#include <dirent.h>
#include <string.h>

/// forward declaration
FILE *workWithCNFHead(char *InputFile, Formula *formula);
void readFormulaFromFile(FILE *inFile, Formula *formula);
/**
 * Read formula from file.
 * @date 18.07.03
 */
Formula *readFormula(char *InputFile)
{
  Formula *myFormula = (Formula *) malloc(sizeof(Formula));
  FILE *inFile = workWithCNFHead(InputFile,myFormula);
  
  newFormula(myFormula);
 
  readFormulaFromFile(inFile, myFormula);
  return myFormula;
}

/*
 * Process the head of .cnf-file
 * @date 18.07.03
 */
FILE *workWithCNFHead(char *InputFile, Formula *formula)
{
  char Symbol, cnf[3];
  number NumberOfVars, NumberOfClauses;
  FILE *inFile;

  inFile = fopen(InputFile, "r");
  if(!inFile)
  {
    printf("c Cannot open input file : %s\n", InputFile);
    exit(-1);
  }

  // eat everything before first ^p
  fscanf(inFile, "%c", &Symbol);
  while(Symbol!='p')
  {
    while(Symbol!='\n')
      fscanf(inFile,"%c", &Symbol);
    fscanf(inFile,"%c", &Symbol);
  }

  // read the string "cnf" and number of variables and number of clauses
  fscanf(inFile,"%s%d%d", cnf, &NumberOfVars, &NumberOfClauses);
#ifndef NDEBUG
  printf("c Read formula with %d variables and %d clauses\n",NumberOfVars,
    NumberOfClauses);
#endif
  formula->number_of_clauses   = NumberOfClauses;
  formula->number_of_variables = NumberOfVars;
  return inFile;
}

/**
 * Process body of the file and init cnf formula
 * @date 18.07.03
 */
void readFormulaFromFile(FILE *inFile, Formula *formula)
{
  number Counter1,Counter2,ScanedNumber, NumberOfClauses, NumberOfVars;
  number *myClause;
   
  NumberOfClauses = formula->number_of_clauses;
  NumberOfVars    = formula->number_of_variables;  
  myClause = (number *) malloc(NumberOfVars*sizeof(number));

  for(Counter1=0;Counter1<NumberOfClauses;Counter1++)
  {
    for(Counter2=0;Counter2<NumberOfVars+1;Counter2++)
    {
      fscanf(inFile, "%d", &ScanedNumber);
      if(ScanedNumber!=0)
      { 
        myClause[Counter2] = ScanedNumber;
      }
      else  ///< The end of clause's reading from input
      {
        putClause(formula,myClause,Counter2,Counter1);
        break;
      }
    }
    while(ScanedNumber!=0)
    {
      fscanf(inFile,"%d", &ScanedNumber);
//      printf("%d ", ScanedNumber);
//      fflush(stdout);
    }
  }
  free(myClause);
  fclose(inFile);
}

////////////////////////////////////////////////////////////////////////
int listdir(char *dirname) 
// work with directory of .cnf-files
{
   int i;
   char *NameOfFile, Character, FullNameOffile[512];

   register struct dirent *dirbuf;
   DIR *fddir;
   ino_t dot_ino=0, dotdot_ino=0;

  if((fddir=opendir(dirname))==NULL)
  {
    fprintf(stderr,"Can't read %s\n",dirname);
    return 1;
  }
  
  /* without alphabetical sorting  */
  while ((dirbuf=readdir(fddir))!=NULL ) 
  {
    if (dirbuf->d_ino==0) 
      continue;
    if (strcmp(dirbuf->d_name,".")==0)
    {
      dot_ino=dirbuf->d_ino;
      continue;
    } 
    else if(strcmp(dirbuf->d_name,"..")==0)
    {
      dotdot_ino = dirbuf -> d_ino ;
     continue;
   }
   else 
     NameOfFile =  dirbuf -> d_name;
     for(i=0;(Character=NameOfFile[i])!='\0';i++)
     {
       if(Character=='.')
       if(NameOfFile[i+1]=='c')
       if(NameOfFile[i+2]=='n')
       if(NameOfFile[i+3]=='f')
       {  
//         if (!Quiet) printf("f ");
//         fprintf(outFile,"f ");
         *FullNameOffile='\0';
         strcat(FullNameOffile,dirname);
         strcat(FullNameOffile,"/");
         strcat(FullNameOffile,NameOfFile);
//         if (!Quiet) printf("%s ", FullNameOffile);
//	       fflush(stdout);
//         fprintf(outFile,"%s ", FullNameOffile);
//	       fflush(outFile);
/*
         WorkWithFile(FullNameOffile);
         WorkWithCNF(inFile);
*/
//         fflush(outFile);
       }     
     }
  }
  
  closedir(fddir);

  if(dot_ino==0) 
    printf("Bad directory: no \".\"\n");
  if(dotdot_ino==0) 
    printf("Bad directory: no \"..\"\n");
  if((dot_ino)&&(dot_ino==dotdot_ino)) 
    printf("This is the root directory.\n");

  return 0;
}
