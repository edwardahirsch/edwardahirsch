/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2001.
This is a header file. 
*********************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/time.h> 
#include <sys/times.h> 
#include <dirent.h>
#include <libgen.h>
#include <errno.h>

#define VERSION ("V0.941-bin")

#ifndef __VariablesOFProgram__
#define __VariablesOFProgram__

typedef long number;

/*
 * Data structures :
 */

struct MyList **VariablesInClauses; 
/* 
Array of lists. VariablesInClauses[k-1] is a list of numbers of clauses 
containing variable x_k. Used for quick search for a clause containing x_k.
*/

int Satisfied; 
/* 
1, if we have satisfing assignment; 0 otherwise.  
*/

number *PreUnitClauses; 
number PreNumberOfUnitClauses;
/*
PreUnitClauses is a list of numbers of unit clauses in the input formula.
PreNumberOfUnitClauses is the size of PreUnitClauses.
*/
number PreNumberOfBigClauses;
number NumberOfBigClauses;

struct MyList *PreDualClauses; 
struct MyList **VariablesIn2Clauses;

// list of 2-clauses in the input formula

number *SatAssignment; 
// satisfying assignment, if we know it before the execution

number NumberOfVars; 
// maximal number of a variable in the current formula

number NumberOfClauses; 
// number of clauses in the current formula

number I; 
// runs limit

number T; 
// time limit

number A; 
// assignments limit

number MaxPeriods; 
// max periods per run

number p; 
// MaxPeriods = NumberOfVariables * p / 100 

number Flip; 
// number of flips made so far for one try

number Assign ; 
// number of assignments made so far for one try

number *MedianFlip; 
// total number of flips for for all tries

number *MedianAssign; 
// total number of assignments for for all tries

int Quiet; 
// be quiet

int aGiven; 
// -a given in command line

number MaxTry; 
// tries limit 

number FAILS; 
// number of failures

FILE *outFile; 
// output file

FILE *inFile;  
// input file

struct NumberWithLink{ 
// a clause: its size and array of literals
number Number;
number *link;};

struct MyList{ 
// list of clause numbers
number Number;
struct MyList *link;};

#endif

/* 
 * Functions for work with random strings : 
 */

#ifndef __SetPermutation__
#define __SetPermutation__
void SetPermutation(number *Permutation);
 // fill the trivial permutation 

#endif
void GetRandomPermutation(number *Permutation); 
// random permutation of 1..n

void GetRandomVector(number *Vector); 
// random vector from {0,1}^NumberOfVars 

/*
 * I/O functions :
 */

void OutVariablesInClauses(void); 
// debug info: prints VariablesInClauses[]

void FreeVariablesInClauses(); 
// frees memory from VariablesInClauses[]

// The next three functions read a formula from a file.
number WorkWithCNF(); 
void WorkWithFile(char *InputFile); 

int listdir(char *dirname); 
// runs WorkWithFile for dirname/*.cnf 

/*
 * Main program :
 */

int main(int argc,char *argv[]); 
// main program

number Search(struct NumberWithLink *Gi); 
// algorithm itself
number LookForFork(number headVar, struct NumberWithLink *Formula);