/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2001.
This file contains procedures which are not specific 
for a concrete algorithm.
*********************************************************************/

#include "framework.h"

#define DEF_I (1000*1000*1000)
//max number of algorithm runs
#define DEF_T (30*7*24*60*60)
//max time of algorithm work
#define DEF_A (1000*1000*1000)
//max number of assignments
#define DEF_p -1
//max number of flips, +\infty can be defined by -1 

////////////////////////////////////////////////////////////////////////
char * itoa(number x)
{
	char*s=(char*)malloc(32);
	snprintf(s,31,"%ld",x);
	return s;
}

////////////////////////////////////////////////////////////////////////
number dist(number *Vector,number *Vector1) 
//returns Hamming distance between Vector and Vector1
{
  number Counter, Diff = 0;

#ifndef ___MYVAR_DEBUG___     
  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    if(Vector[Counter]!=Vector1[Counter])
      Diff++;  
  }
#endif

#ifdef ___MYVAR_DEBUG___       
//some debug information 
//that output on screen  
  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    if(Vector[Counter]!=Vector1[Counter])
    {
      Diff++; 
      printf("|%d|",Vector[Counter]); 
    }
    else
      printf("%d",Vector[Counter]); 
    
  }
  
  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    if(Vector[Counter]!=Vector1[Counter])
      printf("|%d|",Vector1[Counter]); 
    else
      printf("%d",Vector1[Counter]); 
   
  }
  
#endif
 return Diff;
 
}

////////////////////////////////////////////////////////////////////////
void FreeVariablesInClauses()
 // free used memory after the execution
{
  number Counter;
  struct LiteralLink *wl;
  struct LiteralLink *nextwl;
 
  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    wl = Vars[Counter].wl;
  
    while(wl!=NULL)
    {
      nextwl = wl->next;
      free(wl);
      wl = nextwl;
    }
  }

  free(LitPool);
  free(Vars);
}


////////////////////////////////////////////////////////////////////////
void newFormulaOut() 
// prints the current formula in dimacs format
{
  int Counter, Counter1,Counter2,SizeOfClause;
  struct Literal *lit = LitPool;
  
  printf("\np cnf %d %d\n",NumberOfVars,NumberOfClauses);
  
  for(Counter=0;Counter<NumberOfClauses;Counter++){
  
    SizeOfClause = lit->clauseSize; 
    for(Counter1=0;Counter1<SizeOfClause;Counter1++){
      if(lit->value & 0x1)
         printf("-%d(%d,%d,%d,%d) ", (lit->value)>>1,lit->clauseSize,lit->position,lit->isWL,lit->isSat);
      else
         printf("%d(%d,%d,%d,%d) ", (lit->value)>>1,lit->clauseSize,lit->position,lit->isWL,lit->isSat);
      lit++;
    }
    printf("0\n");
  }
}

//new
void newOutVars(){
  int Counter;
  struct LiteralLink *wl;
  struct LiteralLink *nextwl;
  
  printf("\n");
  for(Counter=0;Counter<NumberOfVars;Counter++){
    wl = Vars[Counter].wl->next;

    if(wl!=NULL) printf("\n"); 
    
    while(wl!=NULL)
    {
      printf("%d->",wl->lit->value);
      nextwl = wl->next;
      wl = nextwl;
    }
  }
  fflush(stdout); 
}


/*
 * Functions for work with random strings :
 */

////////////////////////////////////////////////////////////////////////
void SetPermutation(number *Permutation) 
// fill a trivial permutation
{
  number Counter;

  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    Permutation[Counter]=Counter+1;
  }
}


////////////////////////////////////////////////////////////////////////
void GetRandomPermutation(number *Permutation) 
// fill a random permutation
{
  number Random,Counter,Number;

  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    Random = random()%NumberOfVars;
    
    Number=Permutation[Counter];
    Permutation[Counter]=Permutation[Random];
    Permutation[Random]=Number;
  }
}


////////////////////////////////////////////////////////////////////////
void GetRandomVector(number *Vector) 
// fill a random vector from {0,1}^n
{
  number Random;
  number Counter;

  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    Random = random()%2;
    Vector[Counter]=Random;
  }
}

////////////////////////////////////////////////////////////////////////
void PutNumbers()
//reads VariablesInClauses and CNFF from file
{
  number NumOfLiterals = 0;// new
  struct NumberWithLink CNFF[NumberOfClauses]; 
  number Counter1,Counter2,Counter3,ScanedNumber, *Clause;
  number SizeOfNumber = sizeof(number);
  struct MyList *ThisClause;
  number sizeOfList = sizeof(struct MyList);
  
  Clause = (number *) malloc(SizeOfNumber*NumberOfVars);

  for(Counter1=0;Counter1<NumberOfClauses;Counter1++)
  {
    for(Counter2=0;Counter2<NumberOfVars+1;Counter2++)
    {
      fscanf(inFile, "%d", &ScanedNumber);
      
      if(ScanedNumber!=0)
      {
        NumOfLiterals++;
// beforehand scan information of one clause from input file
        Clause[Counter2] = ScanedNumber;   
      }
      else 
      //The end of clause's reading from input  
      {
        // if clause is unit then add it to PreUnitClauses
        if(Counter2 == 1)
        {
          PreUnitClauses[PreNumberOfUnitClauses]=Clause[0];
          PreNumberOfUnitClauses++;
        }
        // fill data of clause
        CNFF[Counter1].Number = Counter2; 
        CNFF[Counter1].link = (number *) malloc(SizeOfNumber*Counter2);    
        for(Counter3=0;Counter3<Counter2;Counter3++)
          CNFF[Counter1].link[Counter3] = Clause[Counter3]; 
        break;
      }
    }
    while(ScanedNumber!=0)
      fscanf(inFile,"%d", &ScanedNumber);
  }
  free(Clause);

//new
  Vars    = (struct Var *) malloc(sizeof(struct Var)*NumberOfVars);
  LitPool = (struct Literal *) malloc(sizeof(struct Literal)*NumOfLiterals);
  NumOfLiterals=0;

  for(Counter1=0;Counter1<NumberOfVars;Counter1++){
    Vars[Counter1].wl = (struct LiteralLink *) malloc(sizeof(struct LiteralLink));
    Vars[Counter1].wl->next = NULL;
  }  
  
  //full fields of LitPool
  for(Counter1=0;Counter1<NumberOfClauses;Counter1++)
  {
    Clause = CNFF[Counter1].link;
    Counter3 = CNFF[Counter1].Number;
    
    
    for(Counter2=0;Counter2<Counter3;Counter2++)
    {
      ScanedNumber = Clause[Counter2];
      if(ScanedNumber<0)
        ScanedNumber = -2*ScanedNumber + 1;
      else
        ScanedNumber = 2*ScanedNumber;
	
      LitPool[NumOfLiterals].var = &(Vars[(ScanedNumber>>1)-1]);

      LitPool[NumOfLiterals].clauseSize = Counter3;

      LitPool[NumOfLiterals].position   = Counter2;

      if(Counter2<2){
        struct LiteralLink *wl1 
	         = (struct LiteralLink *) malloc(sizeof(struct LiteralLink));
        wl1->lit  = &(LitPool[NumOfLiterals]);
	      wl1->next = Vars[(ScanedNumber>>1)-1].wl->next;
        wl1->prev = Vars[(ScanedNumber>>1)-1].wl;
        if(wl1->next!=NULL)
          (wl1->next)->prev = wl1;
        Vars[(ScanedNumber>>1)-1].wl->next = wl1;
	
        LitPool[NumOfLiterals].isWL     = 1;
      }
      else
        LitPool[NumOfLiterals].isWL     = 0;

      LitPool[NumOfLiterals].value      = ScanedNumber;
      
      LitPool[NumOfLiterals].isSat      = 0;

      NumOfLiterals++;
    }
  }

//free useless data
for(Counter1=0;Counter1<NumberOfClauses;Counter1++) free(CNFF[Counter1].link);
}

////////////////////////////////////////////////////////////////////////
number WorkWithCNF() 
// process the body of .cnf-file, initialize our data and call Search
{
  number ValueToReturn;
  number zh[2*NumberOfVars];
  
  PreNumberOfUnitClauses = 0;
  PreUnitClauses = zh;
  
  PutNumbers();
  
  fclose(inFile);
  ValueToReturn=Search();
  return ValueToReturn;
}


////////////////////////////////////////////////////////////////////////
void WorkWithSatAssignment(char *InputFile)
// process the body of file with satisfying assignment, 
// initialize our data and call Search
{
  FILE *mainFile = fopen(InputFile, "r");
  char Symbol, NameOfCNFFile[256], v[1];
  int i;

  if(mainFile==NULL)
  {
    printf("Cannot open input file.\n");
    exit(-1);
  }

  fscanf(mainFile, "%c", &Symbol);

  while(1)
  {
  
    while((Symbol!='f')&&(Symbol!=EOF))
    {
      while((Symbol!='\n')&&(Symbol!=EOF))
        fscanf(mainFile,"%c", &Symbol);
      fscanf(mainFile,"%c", &Symbol);
    }
  
    if (Symbol==EOF) break;
    
    fscanf(mainFile,"%s", NameOfCNFFile);

    if (!Quiet) printf("f %s",NameOfCNFFile);   
    fprintf(outFile,"f %s",NameOfCNFFile);  
    fflush(outFile); 

    WorkWithFile(NameOfCNFFile);
   

    SatAssignment = (number *)malloc(sizeof(number)*NumberOfVars);
    
    fscanf(mainFile,"%c", &Symbol);
    while(Symbol=='v'||Symbol==' ')
      fscanf(mainFile,"%c", &Symbol);
  
    i=0;  
    while(Symbol=='0'||Symbol=='1')  
    {
      SatAssignment[i]=Symbol-'0';

      fscanf(mainFile,"%c", &Symbol);
      i++;
    }

    WorkWithCNF();
    
    free(SatAssignment);

    while((Symbol!='\n')&&(Symbol!=EOF))
	  fscanf(mainFile,"%c", &Symbol);
	
	fscanf(mainFile,"%c", &Symbol);
	
	while((Symbol!='\n')&&(Symbol!=EOF))
      fscanf(mainFile,"%c", &Symbol);

    fscanf(mainFile,"%c", &Symbol);
    
    
  }  
  fclose(mainFile);
}


////////////////////////////////////////////////////////////////////////
void WorkWithFile(char *InputFile) 
// process the head of .cnf-file
// and call WorkWithCNF for further
// processing
{
  number Counter1, Counter2, ScanedNumber;
  char Symbol, *cnf[3];
  
  inFile = fopen(InputFile, "r");
  if(!inFile)
  {
    printf("Cannot open input file : %s\n", InputFile);
    exit(-1);
  }
  
  // eat everything before first ^p
  fscanf(inFile, "%c", &Symbol);
  while(Symbol!='p')
  {
    while(Symbol!='\n')
      fscanf(inFile,"%c", &Symbol);
    fscanf(inFile,"%c", &Symbol);
  }
  
  // read the string "cnf" and number of variables and number of clauses
  fscanf(inFile,"%s%d%d", cnf, &NumberOfVars, &NumberOfClauses);
}

////////////////////////////////////////////////////////////////////////
int listdir(char *dirname) 
// work with directory of .cnf-files
{
   int i;
   char *NameOfFile, Character, FullNameOffile[512];

   register struct dirent *dirbuf;
   DIR *fddir;
   ino_t dot_ino=0, dotdot_ino=0;

  if((fddir=opendir(dirname))==NULL)
  {
    fprintf(stderr,"Can't read %s\n",dirname);
    return 1;
  }
  
  /* without alphabetical sorting  */
  while ((dirbuf=readdir(fddir))!=NULL ) 
  {
    if (dirbuf->d_ino==0) 
      continue;
    if (strcmp(dirbuf->d_name,".")==0)
    {
      dot_ino=dirbuf->d_ino;
      continue;
    } 
    else if(strcmp(dirbuf->d_name,"..")==0)
    {
      dotdot_ino = dirbuf -> d_ino ;
     continue;
   }
   else 
     NameOfFile =  dirbuf -> d_name;
     for(i=0;(Character=NameOfFile[i])!='\0';i++)
     {
       if(Character=='.')
       if(NameOfFile[i+1]=='c')
       if(NameOfFile[i+2]=='n')
       if(NameOfFile[i+3]=='f')
       {  
         if (!Quiet) printf("f ");
         fprintf(outFile,"f ");
         *FullNameOffile='\0';
         strcat(FullNameOffile,dirname);
         strcat(FullNameOffile,"/");
         strcat(FullNameOffile,NameOfFile);
         if (!Quiet) printf("%s ", FullNameOffile);
	       fflush(stdout);
         fprintf(outFile,"%s ", FullNameOffile);
	       fflush(outFile);
         WorkWithFile(FullNameOffile);
         WorkWithCNF(inFile);
         fflush(outFile);
       }     
     }
  }
  
  closedir(fddir);

  if(dot_ino==0) 
    printf("Bad directory: no \".\"\n");
  if(dotdot_ino==0) 
    printf("Bad directory: no \"..\"\n");
  if((dot_ino)&&(dot_ino==dotdot_ino)) 
    printf("This is the root directory.\n");

  return 0;
}


////////////////////////////////////////////////////////////////////////
void help() 
// Give help and exit
{
    printf("\n");
    printf("General parameters:\n");
    printf("\n");
    printf("  -f file = name of input file\n");
    printf("  -d dir  = name of input directory\n");
    printf("  -s seed = seed\n");
    printf("  -sr     = random seed\n");
    printf("  -o file = name of output file\n");
    printf("  -a file = name of file with satisfying assignments\n");
    printf("  -I I    = runs limit\n");
    printf("  -T T    = time limit in seconds\n");
    printf("  -A A    = assigns limit\n");
    printf("  -p p    = flips limit\n");
    printf("  -q      = be quiet\n");
    printf("  -h      = this help\n");
    printf("  -r      = number of restarts\n");
    printf("\n");
    printf("For example:\n");
    printf("\n");
    printf("  ./UnitWalk -d cnf/uf800 -T 60\n");
    printf("\n");

    printf("The default values are -I %d, -T %d, -A %d, -p %d, -r 1, -s 28120107.\n",DEF_I,DEF_T,DEF_A,DEF_p);   
    exit(-1); 
}

/* 
 * Main Program :
 */

int main(int argc,char *argv[])
{
  number result, i;  
  char *NameOfFile;
  char *NameOfAssignFile = NULL;
  char *NameOfDir=".";
  int CheckInDir=1; 
  // will check all .cnf-files in a directory?
  
  char NameOfOutputFile[512];

  if (argc==1) help();
  
  result = 28120107;
  srandom(result);

  //default values 
  I = DEF_I;
  T = DEF_T; 
  A = DEF_A;
  p = DEF_p;
  Quiet = 0;
  aGiven = 0;
  MaxTry = 1;
  *NameOfOutputFile = '\0'; 

  for (i=1;i<argc;i++)
  {
    if (strcmp(argv[i],"-o")==0)
    {
      *NameOfOutputFile = '\0';
      strcat(NameOfOutputFile,argv[++i]);
    }
    else if (strcmp(argv[i],"-sr")==0)
    {
      result = time(NULL);
      srandom(result);
    }
    else if (strcmp(argv[i],"-s")==0)
    {
      result = atoi(argv[++i]);
      srandom(result);
    }
    else if (strcmp(argv[i],"-f")==0)
    {
      NameOfFile = argv[++i];
      CheckInDir = 0; 
    }
    else if (strcmp(argv[i],"-d")==0)
      NameOfDir = argv[++i];
    else if (strcmp(argv[i],"-a")==0)
    {
      NameOfAssignFile = argv[++i];
      aGiven=1;
    }
    else if(strcmp(argv[i],"-I")==0)
         I = atoi(argv[++i]);
    else if(strcmp(argv[i],"-r")==0)
         MaxTry = atoi(argv[++i]);
    else if(strcmp(argv[i],"-T")==0)
        T = atoi(argv[++i]);
    else if(strcmp(argv[i],"-A")==0)
        A = atoi(argv[++i]);
    else if(strcmp(argv[i],"-p")==0)
        p = atoi(argv[++i]);
    else if(strcmp(argv[i],"-q")==0)
	Quiet = 1;
    else 
        help();
  }
  
  if (*NameOfOutputFile=='\0')
  {
    if (mkdir("Outputs",0xFFFF)) if (errno != EEXIST)
    {
      printf("Failed to create Outputs directory, and no -o key was given.\n");
      exit(-1);
    }
    strcat(NameOfOutputFile,"Outputs/");
    strcat(NameOfOutputFile,VERSION);
    strcat(NameOfOutputFile,".");
    if (aGiven) 
    {
      strcat(NameOfOutputFile,basename(NameOfAssignFile)); 
      strcat(NameOfOutputFile,".a");
    }
    else if (CheckInDir) 
    { 
      strcat(NameOfOutputFile,basename(NameOfDir)); 
      strcat(NameOfOutputFile,".d"); 
    }
    else 
    {
      strcat(NameOfOutputFile,basename(NameOfFile)); 
      strcat(NameOfOutputFile,".f");
    }

    if (MaxTry>1)
    {
      strcat(NameOfOutputFile,".r");
      strcat(NameOfOutputFile,itoa(MaxTry));
    }
    if (p!=DEF_p)
    {
      strcat(NameOfOutputFile,".p");
      strcat(NameOfOutputFile,itoa(p));
    }
    if (T<DEF_T)
    {
      strcat(NameOfOutputFile,".T");
      strcat(NameOfOutputFile,itoa(T));
    }
    if (I<DEF_I)
    {
      strcat(NameOfOutputFile,".I");
      strcat(NameOfOutputFile,itoa(T));
    }
    if (A<DEF_A)
    {
      strcat(NameOfOutputFile,".A");
      strcat(NameOfOutputFile,itoa(A));
    }
    strcat(NameOfOutputFile,".s");
    strcat(NameOfOutputFile,itoa(result));
  
  
  if (Quiet) 
    strcat(NameOfOutputFile,".q");
  
  strcat(NameOfOutputFile,".pid");
  strcat(NameOfOutputFile,itoa(getpid()));
  
  }
  
  outFile  = fopen(NameOfOutputFile,"w");
  MedianFlip = (number*)malloc(MaxTry*sizeof(number));
  MedianAssign = (number*)malloc(MaxTry*sizeof(number));

  if(NameOfAssignFile!=NULL)
  {
    while(strcmp(NameOfOutputFile,NameOfAssignFile)==0)
      strcat(NameOfOutputFile,"1");
    
    fclose(outFile);
    outFile  = fopen(NameOfOutputFile,"w");
 
    WorkWithSatAssignment(NameOfAssignFile);
  }
  else if(CheckInDir)
    listdir(NameOfDir);
  else
  { 
    if (!Quiet) printf("f %s",NameOfFile);   
    fflush(stdout);
    fprintf(outFile,"f %s",NameOfFile);  
    fflush(outFile); 
    WorkWithFile(NameOfFile);
    WorkWithCNF(inFile);  
  }    
  
  if (!Quiet) printf("end\n");
  fprintf(outFile,"seed = %d\n", result);
  fprintf(outFile,"end\n",NameOfFile);   
  fclose(outFile);
  return FAILS;
}

