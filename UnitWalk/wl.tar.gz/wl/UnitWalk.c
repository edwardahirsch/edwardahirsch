/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2001.
This file contains the implementation of the algorithm itself.
*********************************************************************/

#include "framework.h"

#define MaxRuns (I)
#define MaxAssigns (A)
#define MaxTime (T)

number *UnitClauses;
number NumberOfUnitClauses;
/*
UnitClauses is a list of all unit clauses numbers.
NumberOfUnitClauses is the size of UnitClauses.
*/

////////////////////////////////////////////////////////////////////////
int compare(const void*a,const void*b)
{
	return ((*((number*)a)) < (*((number*)b)));
}


////////////////////////////////////////////////////////////////////////
void clause_sat(struct Literal * lit){ //set current clause sat
  struct Literal * old_lit = lit;	
  int position,i;

  if(lit->clauseSize==1)
    return;
        
  if(lit->isSat){
    lit->isSat = 0;
    return;
  }
    
  position = lit->position;
	
  for(i=0;i<position;i++){
	  lit--;
	  if((lit->isWL)&&(lit->var->value==-1)){ //yes!!
	    lit->isSat = 1;//set sat
      return;	    
	  }
	}	    
    
  lit      = old_lit; 
	position = (lit->clauseSize)-1-position;
  
	for(i=0;i<position;i++){
	  lit++;
    if((lit->isWL)&&(lit->var->value==-1)){ //yes!!
	    lit->isSat = 1;	  
      return;  
	  }
  }
}

//return true if find new wl
char find_new_wl(struct LiteralLink *wl, char value){
  struct Literal * lit     =wl->lit;
  struct Literal * old_lit = lit;	
  int position,i, unit;
//  struct LiteralLink *nextwl;

  if(lit->clauseSize==1){
    if((lit->value & 0x1)!=value) Satisfied = 0; // it's empty now
    return 0;
  }
        
  if(lit->isSat){
    lit->isSat = 0;
    return 0;
  }

  unit = 0; 
	   
  position = lit->position;

	for(i=0;i<position;i++){
    lit--;
	 
	  if((lit->var)->value == -1){//find not set literal
	    if(!lit->isWL){ //it is not watched literal
		    lit->isWL = 1;
		    //unset wl
		    old_lit->isWL = 0;

		    //add new wl to some var
        (wl->prev)->next = wl->next;
        if(wl->next!=NULL)
          (wl->next)->prev = wl->prev;
        
        wl->prev  = (lit->var)->wl;
        wl->next  = ((lit->var)->wl)->next;
        wl->lit   = lit; 
        if(wl->next!=NULL)
          (wl->next)->prev = wl;

        ((lit->var)->wl)->next  = wl;
        return 1;
      }
	    else
	      unit = lit->value;
    }
	  else if((lit->var)->value != (lit->value & 0x1)){
	    //  clause is sat
		  clause_sat(old_lit); 
		  return 0;   
    }
	}	    
    
  lit      = old_lit; 
	position = (lit->clauseSize)-1-position;
	for(i=0;i<position;i++){
    lit++;
	  if((lit->var)->value == -1){//find unset literal
	    if(!lit->isWL){ //it is not watched literal
		    lit->isWL = 1;
		    //unset wl
		    old_lit->isWL = 0;

		    //add new wl to some var
        (wl->prev)->next = wl->next;
        if(wl->next!=NULL)
          (wl->next)->prev = wl->prev;
        
        wl->prev  = (lit->var)->wl;
        wl->next  = ((lit->var)->wl)->next;
        wl->lit   = lit; 
        if(wl->next!=NULL)
          (wl->next)->prev = wl;

        ((lit->var)->wl)->next  = wl;
        return 1;
      }
	    else
	      unit = lit->value;
    }
    else if((lit->var)->value != (lit->value & 0x1)){
	    //  clause is sat
		  clause_sat(old_lit); 
		  return 0;   
    }
  }
  
  if(unit!=0){
    if(unit & 0x1)
      UnitClauses[NumberOfUnitClauses] = -(unit>>1);
    else
      UnitClauses[NumberOfUnitClauses] = (unit>>1);
    NumberOfUnitClauses++;
    return 0;
  }

  Satisfied = 0; // it's empty now
  return 0;
}
////////////////////////////////////////////////////////////////////////
void newSetValue(int var, char value){
/*
 * Assign a value to a variable and update the formula accordingly.
 */
  struct LiteralLink *wl; 
  struct Literal *lit;
  struct LiteralLink *nextwl;
  int variable;

  Assign++;
  
  Vars[var-1].value = value;
  wl = Vars[var-1].wl->next;

//  newOutVars();
    
  while(wl!=NULL){
    lit = wl->lit; 
    //find new wl
    if((lit->value & 0x1) == value){
      nextwl = wl->next;
      find_new_wl(wl,value);
      wl = nextwl;
    }
    // set clause sat
    else{ //size is not zero
      clause_sat(lit);
      wl = wl->next;
    }  
  }
}

////////////////////////////////////////////////////////////////////////////
void Modify(number *pi, number *y)
// one pass of a modified Paturi-Pudlak-Zane algorithm
{
  number Variable;
  number Counter,Number,Counter1,C1;
  number Unit;
  number TimesToReturn = 1;
  number United[NumberOfVars];
  number StartFlip;
  number NextOpposite;
  int Opposite; 
  // do we have the unit clause opposite to the chosen one?
  
  StartFlip=Flip;
  NextOpposite=0;

      
  /*
   * PreUnitClauses is list of unit clauses that is primordialy in formula, 
   * UnitClauses is list of all unit clauses,
   * NumberOfUnitClauses and PreNumberOfUnitClauses - sizes of it 
   */
  NumberOfUnitClauses=PreNumberOfUnitClauses;

  /* United contains all variables that already have values */
  for(Counter=0;Counter<NumberOfVars;Counter++){
    United[Counter]     = 0;
    Vars[Counter].value = -1;
  }
  for(Counter=0;Counter<PreNumberOfUnitClauses;Counter++)
    UnitClauses[Counter] = PreUnitClauses[Counter];

  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    // take variable with number from permutation
    Variable=pi[Counter];
  
    // if we already work with this variable then we skip it 
  if(United[Variable-1]!=1)
  { 
    // if we have unit clause we work with it
    if(NumberOfUnitClauses!=0)
    {
       Opposite=0;
    // take unit clause from list by chance
       Number=random()%NumberOfUnitClauses;
       Unit=UnitClauses[Number];       
    
       NumberOfUnitClauses--;
       UnitClauses[Number]=UnitClauses[NumberOfUnitClauses];       
    
       // if we already work with this unit clause then we skip it
       Counter--;
    
     { 

      for (C1=NumberOfUnitClauses-1; C1>=0; C1--)
       if (UnitClauses[C1]==-Unit)
       { 
         Opposite=1; 
         NumberOfUnitClauses--;
      	 UnitClauses[C1]=UnitClauses[NumberOfUnitClauses];       
         NextOpposite++;
       }
       else if(UnitClauses[C1]==Unit)
       {
         NumberOfUnitClauses--;
         UnitClauses[C1]=UnitClauses[NumberOfUnitClauses];       
       }

       if (Opposite==0)
       {
         if(Unit>0)
         {
           United[Unit-1]=1;
           // set current value in variable and put it into formula
      	   if (y[Unit-1]==0) Flip++;
           y[Unit-1] = 1;
//           SetNewValue(Gi, Unit, 1);
           newSetValue(Unit, 1);
         }
         else //Unit<0
         {
           United[-Unit-1]=1;
           // set current value in variable and put it into formula
      	   if (y[-Unit-1]==1) Flip++;
           y[-Unit-1] = 0;
           newSetValue(-Unit, 0);
  
         }
       }
       // Opposite == 1
       else
       {
         newSetValue(abs(Unit), y[abs(Unit)-1]);

         United[abs(Unit)-1]=1;
       }
     }
    }
    else  
    // work with variable from permutation
    {
      newSetValue(Variable, y[Variable-1]);
      
      United[Variable-1]=1;
    }
#ifdef ___MYVAR_DEBUG___      

if(Flip>100) 
{
  newFormulaOut();
  printf("\nUnit clauses:");
  for(C1=0; C1<NumberOfUnitClauses; C1++) printf("%d,",UnitClauses[C1]);
  printf("\n");
}
#endif

  }

  }
  if (!Satisfied)
  if (StartFlip==Flip) 
  // then flip at random
  {
    number randvar;
 
    if (NextOpposite!=0)
    {
      randvar=random()%NumberOfVars;
      y[randvar]=1-y[randvar];
    }
#ifdef ___MYVAR_DEBUG___      
    else
    {
       printf("\n\nBUG%d\n\n",Flip);
       exit(-1);
    }			  
#endif

  }
}


number Search() 
// search for a satisfying assignment
{
number C, C1, C2, Number, Run, Period;
number pi[NumberOfVars];
number y[NumberOfVars];
number z[NumberOfVars];
number zh[NumberOfClauses];
number SizeOfNumber = sizeof(number);
time_t initime;
number ThisTry = 0;  
number AverageRun=0, AveragePeriod=0, AverageAssign=0, AverageFlip=0;
long microsec;  
struct timeval tv;
struct timezone tz;
//new time
struct tms buf;

//fix initial moment of time
gettimeofday(&tv,&tz);
microsec = tv.tv_usec;
initime=time(NULL);
  
FAILS = 0;

UnitClauses=zh;
SetPermutation(pi);  
GetRandomVector(y);
if((MaxPeriods=(NumberOfVars*p)/100)==0)
  MaxPeriods=NumberOfVars; 
  
if (!Quiet) printf("\n");

//--- Main Cycle ---

for (ThisTry=0; ThisTry<MaxTry; ThisTry++)
{ 
  if (MaxTry>0) if (!Quiet) printf("Try %d/%d...\n",ThisTry+1,MaxTry);
	
  for(Run=0, Assign=0, Flip=0; (Run<MaxRuns) && 
		  (time(NULL)<initime+MaxTime) && 
		  (Assign < MaxAssigns); Run++)
  {
    if (!Quiet) 
    { 
      printf("\x00d[%d:",Run); fflush(stdout); 
    }
    
    if (Run%2==0) 
    // get random vector or the reverse for the previous one
    {
      GetRandomVector(y);
      for(C1=0; C1<NumberOfVars; C1++) z[C1]=y[C1];
    }
    else 
      for(C1=0; C1<NumberOfVars; C1++) y[C1]=1-z[C1];

    for(Period=0; ((Period<MaxPeriods)||(p==-1))&&(time(NULL)<initime+MaxTime); Period++)
    {
    
      if (!Quiet) if (Period%25==0) 
      {
        printf("%c\x008",(Period%50==0)?'/':'\\'); 
        fflush(stdout);
      }

      if (aGiven) 
      { 
        printf("%ld,",dist(SatAssignment,y)); 
        fflush(stdout); 
      }
      
      GetRandomPermutation(pi);
      Satisfied=1;
      //suppose that the current assignment can be made satisfying
      //until we prove the opposite

#ifdef ___MYVAR_DEBUG___      
      printf("\n Current vector transformed to:\n");
    
      for(C1=0; C1<NumberOfVars; C1++)
        printf("%ld, ",y[C1]);
#endif

      Modify(pi,y);
      //one pass of PPSZ

      if(p==-1) if (!Quiet) 
      { 
        printf("\x00d[%d:",Period); 
        fflush(stdout); 
      }

      if (Satisfied==1) 
      //found satisfying assignment
      {
        if (aGiven) 
        { 
          printf("%ld",dist(SatAssignment,y)); 
          fflush(stdout); 
        }
    
        gettimeofday(&tv,&tz);
        times(&buf);
        if (!Quiet) printf(" OK (Run=%ld,Period=%ld,Assigns=%ld,Flips=%ld,Time=%f,UserTime=%f,SysTime=%f)\n",
          Run+1,Period+1,Assign,Flip,
          (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
          ((float)buf.tms_utime+buf.tms_cutime)/100,
          ((float)buf.tms_stime+buf.tms_cstime)/100);
	
	if (MaxTry==1) 
        //then also fprintf the assignment and this data
  	{
          fprintf(outFile," v "); 
	  for(C1=0; C1<NumberOfVars; C1++) fprintf(outFile,"%ld",y[C1]);
	  
          fprintf(outFile,
	    "\n Run=%ld\n Period=%ld\n Assigns=%ld\n Flips=%ld\n Time=%f\n UserTime=%f\n SysTime=%f\n FAILS=%ld\n",
	    Run+1,Period+1,Assign,Flip,
	    (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
      ((float)buf.tms_utime+buf.tms_cutime)/100,
      ((float)buf.tms_stime+buf.tms_cstime)/100,
	    FAILS);
	}

        AverageRun    += (Run+1);
        AveragePeriod += (Period+1);
        AverageAssign += Assign;
        AverageFlip   += Flip;
        MedianAssign[ThisTry] = Assign;
        MedianFlip[ThisTry] = Flip;

        Period=MaxPeriods+1; 
        Run=MaxRuns+1; 
        break; 
        //out of Period, Run cycles
      }

    } //(Period)

    if (aGiven) 
    { 
      printf("%ld\n",dist(SatAssignment,y)); 
      fflush(stdout); 
    }

  } //(Run)
 
  if (!Satisfied)
  {
    FAILS++;
    gettimeofday(&tv,&tz);
    times(&buf);
    if (!Quiet) printf(" FAIL (Run=%ld,Period=%ld,Assigns=%ld,Flips=%ld,Time=%f,UserTime=%f,SysTime=%f)\n",
          Run,Period,Assign,Flip,
          (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
          ((float)buf.tms_utime+buf.tms_cutime)/100,
          ((float)buf.tms_stime+buf.tms_cstime)/100);
    if (MaxTry==1) //then also fprintf the assignment and this data
    {
      fprintf(outFile," v ");
      for(C1=0; C1<NumberOfVars; C1++) fprintf(outFile,"%ld",y[C1]);

      fprintf(outFile,
	    "\n Run=%ld\n Period=%ld\n Assigns=%ld\n Flips=%ld\n Time=%f\n UserTime=%f\n SysTime=%f\n FAILS=%ld\n",
	    Run,Period,Assign,Flip,
	    (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
      ((float)buf.tms_utime+buf.tms_cutime)/100,
      ((float)buf.tms_stime+buf.tms_cstime)/100,
      FAILS);
    }
  }

} //(ThisTry)

//--- End Of Main Cycle ---

if (MaxTry>1) //printf and fprintf average data
{ 
  //fprintf the last satisfying assignment
  fprintf(outFile," v ");
  for(C1=0; C1<NumberOfVars; C1++) fprintf(outFile,"%ld",y[C1]);

  ThisTry -= FAILS;
    
  qsort(MedianAssign,MaxTry,sizeof(number),&compare);
  qsort(MedianFlip,MaxTry,sizeof(number),&compare);
  
  if(ThisTry!=0)
  {
    fprintf(outFile,"\n AverageRun=%f\n AveragePeriod=%f\n AverageAssigns=%ld\n AverageFlips=%ld\n MedianAssigns=%ld\n MedianFlips=%ld\n AverageTime=%f\n UserTime=%f\n SysTime=%f\n FAILS=%ld\n",
       (float)AverageRun/ThisTry, 
       (float)AveragePeriod/ThisTry, 
       AverageAssign/ThisTry, 
       AverageFlip/ThisTry,
       MedianAssign[MaxTry/2],
       MedianFlip[MaxTry/2],
       (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000)/ThisTry,
       ((float)buf.tms_utime+buf.tms_cutime)/(ThisTry*100),
       ((float)buf.tms_stime+buf.tms_cstime)/(ThisTry*100),
       FAILS);
  }
  else
  {
    fprintf(outFile,"\n MedianAssigns=%ld\n MedianFlips=%ld\n AverageTime=%f\n UserTime=%f\n SysTime=%f\n FAILS=%ld\n",
       Assign,
       Flip,
       (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
       ((float)buf.tms_utime+buf.tms_cutime)/100,
       ((float)buf.tms_stime+buf.tms_cstime)/100,
       FAILS);
  }                                                            

  if (!Quiet) 
    if(ThisTry!=0)
    {
      printf("AVERAGES: Run=%.2f,Period=%.2f,Assigns=%ld/%ld,Flips=%ld/%ld,Time=%f,UserTime=%f,SysTime=%f. FAILS=%ld)\n",
       (float)AverageRun/ThisTry, 
       (float)AveragePeriod/ThisTry,
       AverageAssign/ThisTry, 
       MedianAssign[MaxTry/2],
       AverageFlip/ThisTry,
       MedianFlip[MaxTry/2],
       (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000)/ThisTry, 
       ((float)buf.tms_utime+buf.tms_cutime)/(ThisTry*100),
       ((float)buf.tms_stime+buf.tms_cstime)/(ThisTry*100),
       FAILS);
    }
    else
    {
     printf("MEDIAN: Assigns=%ld,Flips=%ld,Time=%f,UserTime=%f,SysTime=%f. FAILS=%ld)\n",
      Assign,
      Flip,
      (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
      ((float)buf.tms_utime+buf.tms_cutime)/100,
      ((float)buf.tms_stime+buf.tms_cstime)/100,
      FAILS);
    }                                          
}
      
FreeVariablesInClauses();
    
return FAILS; 
}

