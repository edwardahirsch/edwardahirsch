#include <stdio.h>
#include "string.h"
#include <iostream>
#include "stdio.h"
#include <vector>
#include "time.h"
#include "stdlib.h"
#include <fstream>
#include <string>
#include <math.h>

using namespace std;


string itos(int number)
{
  /* 10 digits + 1 sign + 1 trailing nul */
  static char buf[12];

  unsigned int unsignedNumber;
  int isNegative = 0;
  char *pos = buf + sizeof(buf) - 1;

  if (number < 0) 
  {
    isNegative = 1;
    unsignedNumber = ((unsigned int)(-(1+number))) + 1;
  } 
  else 
  {
    unsignedNumber = number;
  };

  *pos = 0;

  do 
  {
    *--pos = '0' + (unsignedNumber % 10);
    unsignedNumber /= 10;
  } 
  while (unsignedNumber);

  if (isNegative) 
  {
    *--pos = '-';
  };

  return std::string(pos);
}


class Graph
{
public:
  Graph(int number_of_vertices);
  ~Graph();
  
  void 
  setEdge(int vert1, int vert2);
  
  void 
  clear();
  
  /// the following procedure also changes 
  /// the structure of adjacency matrix
  void 
  setNumberOfVertices(int number_of_vert); 
  
  int 
  getEdge(int vert1, int vert2) const;
  
  int 
  getNumberOfNeighbours(int vert) const;
  
  void 
  print(ostream& os) const;
  
  void 
  generateRandomGraph(int number_of_edges);
  
  void 
  generateQuadraticGraph(int m, int n);
 
  void
  generateBinaryTreeLikeGraph(int number_of_vert);  
  
  void 
  printClausesOfTseitinTautology(std::ostream& os, int format = 0) const;
  
  int 
  getNumberOfClausesOfTseitinTautology() const;  
 
private:
  vector< vector<int> > AdjacencyMatrix;
  int NumberOfVertices;
  int NumberOfEdges;
  int NumberOfClauses;
};

Graph::Graph(int number_of_vertices)
{
  NumberOfVertices = number_of_vertices;
  NumberOfEdges = 0;
  NumberOfClauses = 0;
  if (NumberOfVertices <= 0)
  {
    cout << "\nIllegal number of vertices. Stop.";
    exit(-1);
  };
  AdjacencyMatrix = vector< vector<int> >(NumberOfVertices + 1);
  for (int k = 0; k<= NumberOfVertices; k++)
    AdjacencyMatrix[k] = vector<int>(NumberOfVertices + 1, 0);
  
  for (int i = 0; i <= NumberOfVertices; i++)
    for (int j = 0; j <= NumberOfVertices; j++)
      AdjacencyMatrix[i][j] = 0;
};

Graph::~Graph()
{
  for (int i = 0; i <= NumberOfVertices; i++)
    AdjacencyMatrix[i].clear();
    
  AdjacencyMatrix.clear();
};

void Graph::setNumberOfVertices(int number_of_vertices)
{
  /// deleting last version of adjacency matrix
  for (int z = 0; z <= NumberOfVertices; z++)
    AdjacencyMatrix[z].clear();
    
  AdjacencyMatrix.clear();
  
  /// constructing new version
  NumberOfVertices = number_of_vertices;
  NumberOfEdges = 0;
  NumberOfClauses = 0;
  
  AdjacencyMatrix = vector< vector<int> >(NumberOfVertices + 1);
  for (int k = 0; k<= NumberOfVertices; k++)
    AdjacencyMatrix[k] = vector<int>(NumberOfVertices + 1, 0);
  
  for (int i = 0; i <= NumberOfVertices; i++)
    for (int j = 0; j <= NumberOfVertices; j++)
      AdjacencyMatrix[i][j] = 0;
};

void Graph::setEdge(int vert1, int vert2)
{
  if ((AdjacencyMatrix[vert1][vert2] == 0) && (vert1 != vert2))
  {
    NumberOfEdges++;
    AdjacencyMatrix[vert1][vert2] = NumberOfEdges;
    AdjacencyMatrix[vert2][vert1] = NumberOfEdges;
    //cout << "\nEdge between " << vert1 << " and " << vert2 << " was added.";
  }
  else
    //cout << "\nEdge between " << vert1 << " and " << vert2 << " was not added.";
  //this->print(cout);
  //getchar();
  return;
};

void Graph::clear()
{
  for (int i = 0; i <= NumberOfVertices; i++)
    for (int j = 0; j <= NumberOfVertices; j++)
      AdjacencyMatrix[i][j] = 0;

  NumberOfEdges = 0;      
  return;
};

void Graph::print(ostream& os) const
{
  os << "\n%Graph:";
  os << "\n%Number of vertices: " << NumberOfVertices;
  os << "\n%Number of edges: " << NumberOfEdges;
  os << "\n%Adjacency matrix: ";
  for (int i = 1; i <= NumberOfVertices; i++)
  {
    os << "\n% ";
    for (int j = 1; j <= NumberOfVertices; j++)
      os << AdjacencyMatrix[i][j] << " ";
  };
  return;
};

int Graph::getEdge(int vert1, int vert2) const
{
  return (AdjacencyMatrix[vert1][vert2]);
}; 

void Graph::generateRandomGraph(int number_of_edges)
{
  if ((number_of_edges < 0) || (number_of_edges > NumberOfVertices*(NumberOfVertices - 1)/2))
  {
    cerr << "\nCannot generate graph with " << NumberOfVertices << " vertices and " << number_of_edges << " edges. Stop.";
    exit(-1);
  };    
  
  this->clear();
  
  while (NumberOfEdges != number_of_edges)
  {
    int vert1 = (rand() % NumberOfVertices) + 1;
    int vert2 = (rand() % NumberOfVertices) + 1;    
    this->setEdge(vert1, vert2);
      
    //cout << "\n " << vert1 << " " << vert2 << " " << NumberOfEdges;  
  };
  
  return;
};

int Graph::getNumberOfNeighbours(int vert) const
{
  int result = 0;
  for (int i = 1; i <= NumberOfVertices; i++)
    if (this->getEdge(vert, i))
      result++;
      
  return result;
};

void Graph::printClausesOfTseitinTautology(std::ostream& os, int format) const
{
  //this->print(os);
  if (format == 2)
    os << "p cnf " << NumberOfEdges << " " << this->getNumberOfClausesOfTseitinTautology();
  
  
  for (int i = 1; i <= NumberOfVertices; i++)
  {
    int number_of_literals = this->getNumberOfNeighbours(i);
    if (number_of_literals == 0)
      continue;
    vector<int> ArrayOfLiterals(number_of_literals + 1, 0);
    int id = 0;
    for (int j = 1; j <= NumberOfVertices; j++)
      if (this->getEdge(i,j))
        ArrayOfLiterals[++id] = j;

    if (format == 1)
    {
      os << "\n%Edges incident to vertex " << i << ": ";
      for (int t = 1; t <= number_of_literals; t++)
        os << this->getEdge(ArrayOfLiterals[t], i) << " ";
    };
	
    bool all_permutations_are_considered = false; 
    while (!all_permutations_are_considered)
    {
      /// print permutation if it is "good"
      int number_of_positive_literals = 0;
      for (int k = 1; k <= number_of_literals; k++)
        if (ArrayOfLiterals[k] > 0)
	  number_of_positive_literals++;
	  
      if (number_of_positive_literals % 2 == 0)
      {
	if (format == 1)
	{
	  os << "\ninput_clause(label, axiom, [";
	  for (int h = 1; h <= number_of_literals - 1; h++)
	  {
	    if (ArrayOfLiterals[h] > 0)
	      os << " ++p";
	    else
	      os << " --p";
	      
	    os << this->getEdge(i, abs(ArrayOfLiterals[h])) << ",";
	  }; 
	       

	  if (ArrayOfLiterals[number_of_literals] > 0)
	    os << " ++p";
	  else
	    os << " --p";
	      
	  os << this->getEdge(i, abs(ArrayOfLiterals[number_of_literals]));
	      
	  os << " ]).";  
	};
	
	if (format == 2)
	{
	  os << "\n";
	  for (int h = 1; h <= number_of_literals; h++)
	  {
	    if (ArrayOfLiterals[h] > 0)
	      os << "+";
	    else
	      os << "-";
	    
	    os << this->getEdge(i, abs(ArrayOfLiterals[h])) << " ";
	  };
	      
	  os << " 0";  
	};
      };
      
      /// set to next permutation
      int id = 1;
      while ((ArrayOfLiterals[id] < 0) && (id <= number_of_literals))
      {
        ArrayOfLiterals[id] *= -1;
        id++;
      };
      if (id == number_of_literals + 1)
        all_permutations_are_considered = true;
      else
      {
        ArrayOfLiterals[id] *= -1;
      };
    }; /// considering all permutations
  
  };
};

int Graph::getNumberOfClausesOfTseitinTautology() const
{
  int result = 0;
  for (int i = 1; i <= NumberOfVertices; i++)
  {
    int number_of_literals = this->getNumberOfNeighbours(i);
    if (number_of_literals == 0)
      continue;
    vector<int> ArrayOfLiterals(number_of_literals + 1, 0);
    int id = 0;
    for (int j = 1; j <= NumberOfVertices; j++)
      if (this->getEdge(i,j))
        ArrayOfLiterals[++id] = j;
	
    bool all_permutations_are_considered = false; 
    while (!all_permutations_are_considered)
    {
      int number_of_positive_literals = 0;
      for (int k = 1; k <= number_of_literals; k++)
        if (ArrayOfLiterals[k] > 0)
	  number_of_positive_literals++;
	  
      if (number_of_positive_literals % 2 == 0)
      {
        result++;
      };
      
      /// set to next permutation
      int id = 1;
      while ((ArrayOfLiterals[id] < 0) && (id <= number_of_literals))
      {
        ArrayOfLiterals[id] *= -1;
        id++;
      };
      if (id == number_of_literals + 1)
        all_permutations_are_considered = true;
      else
      {
        ArrayOfLiterals[id] *= -1;
      };
    }; /// considering all permutations
  
  };
  
  return result;
};

void 
Graph::generateQuadraticGraph(int m, int n)
{
  this->setNumberOfVertices(n*m);
  /// vert_num = (i-1)*m + j
  for (int i = 1; i <= n; i++)
    for (int j = 1; j <= m; j++)
    {
      if (i - 1 >= 1)
        this->setEdge((i-1)*m+j, (i-2)*m+j);
      
      if (i + 1 <= n)
        this->setEdge((i-1)*m+j, i*m+j);
      
      if (j - 1 >= 1)
        this->setEdge((i-1)*m+j, (i-1)*m+j-1);
      
      if (j + 1 <= m)
        this->setEdge((i-1)*m+j, (i-1)*m+j+1);
    };
  return;
};

void
Graph::generateBinaryTreeLikeGraph(int number_of_vert)
{
  bool wasFirst = false;
  this->setNumberOfVertices(number_of_vert);
  /// generate heap
  for (int i = 1; i <= number_of_vert; i++)
  {
    if(2*i+1 <= number_of_vert)
    {
      this->setEdge(i, 2*i);
      this->setEdge(i, 2*i+1);
    }
    else if(2*i <= number_of_vert)
      this->setEdge(i, 2*i);
    else if(i+1 <= number_of_vert)
    {
      if(!wasFirst)
      {
        this->setEdge(i,1);
        wasFirst=true;
      }
      this->setEdge(i, i+1);  
    }
  }
}
  

//---------------------------------------------------------------------//
void help()
{
  printf("\nProgram for generation of Tseitin tautologies.");
  printf("\nCurrently it generates tautologies for random graphs.");
  printf("\n\nGeneral parameters: ");
  printf("\n-v\tint\tnumber of vertices");
  printf("\n-e\tint\tnumber of edges");
  printf("\n-rv\tint\trandom number of vertices up to given number");
  printf("\n-re\tint\trandom number of edges up to given number"); 
  printf("\n-f\tint\toutput format: 1--tptp, 2-cnf (default = 1)");
  printf("\n-s\tint\trandom seed (default = time)");
  
  printf("\n\n\n"); 
  return;
};	
//---------------------------------------------------------------------//
void processInitParameters(int argc, char *argv[])
{

  if (argc == 1) 
  {	
    help();
    exit(-1);
  };
  
  int number_of_vertices = 0;
  int number_of_edges = 0;
  int bound_for_vertices = 0;
  int bound_for_edges = 0;
  int format = 1;
  int seed = time(0);

  for (int i = 1; i < argc; i++)
  {
    if ((strcmp(argv[i], "-v") == 0) && (i + 1 < argc))
    {
      number_of_vertices = atoi(argv[++i]);
    }
    else if ((strcmp(argv[i], "-s") == 0) && (i + 1 < argc))
    {
      seed = atoi(argv[++i]);
    }
    else if ((strcmp(argv[i], "-e") == 0) && (i + 1 < argc))
    {
      number_of_edges = atoi(argv[++i]);
    }
    else if ((strcmp(argv[i], "-re") == 0) && (i + 1 < argc))
    {
      bound_for_edges = atoi(argv[++i]);
    }
    else if ((strcmp(argv[i], "-rv") == 0) && (i + 1 < argc))
    {
      bound_for_vertices = atoi(argv[++i]);
    }
    else if ((strcmp(argv[i], "-f") == 0) && (i + 1 < argc))
    {
      format = atoi(argv[++i]);
    }
    else
    {
      help();
      exit(-1);
    };
  };

  srand(seed);

  if (bound_for_vertices)
    number_of_vertices = (rand() % bound_for_vertices) + 1;

  if (bound_for_edges)
    number_of_edges = (rand() % bound_for_edges) + 1;
  
  if ((number_of_vertices <= 0) || (number_of_edges <= 0))
  {
    cerr << "\nCannot proccess init parameters since number of edges or number of vertices has illegal value:";
    cerr << "\nNumber of vertices: " << number_of_vertices;
    cerr << "\nNumber of edges: " << number_of_edges;
    cerr << "\nBound for edges: " << bound_for_edges;
    cerr << "\n\n";
    exit(-1);
  };
  
  Graph* G = new Graph(number_of_vertices);
  G->generateRandomGraph(number_of_edges);
  G->print(cout);
  G->printClausesOfTseitinTautology(cout, format);
  delete G;
  return;
};




int main(int argc, char* argv[])
{
  ///processInitParameters(argc, argv);
  if (argc != 2)
  {
    fprintf(stderr, "\nUsage: %s number-of-variables\n\n", argv[0]);
    exit(1);
  }
  
  Graph* G = new Graph(1);
  int max = 100;
  int j=3, i = atol(argv[1]);;
	{
    string prefix("ts_t_");	  
	  string i_str = itos(i);
	  string j_str = itos(j);
	  
    if (i < 10)
	    prefix.append(string("0"));
    prefix.append(i_str);
//	  prefix.append(string("_"));
    
	  string cnffilename(prefix);
	  cnffilename.append(string(".cnf"));
	  ofstream cnffile(cnffilename.c_str());

    G->generateBinaryTreeLikeGraph(i);
	  G->printClausesOfTseitinTautology(cnffile, 2);
    cnffile.close();
	};
  
  delete G;
  
  return 0;
};
