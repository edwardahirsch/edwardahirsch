/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2001.
This file contains the implementation of the algorithm itself.
*********************************************************************/

#include "framework.h"

#define MaxRuns (I)
#define MaxAssigns (A)
#define MaxTime (T)

number *UnitClauses;
number NumberOfUnitClauses;
/*
UnitClauses is a list of all unit clauses numbers.
NumberOfUnitClauses is the size of UnitClauses.
*/

////////////////////////////////////////////////////////////////////////
int compare(const void*a,const void*b)
{
	return ((*((number*)a)) < (*((number*)b)));
}


////////////////////////////////////////////////////////////////////////
void SetEqual(struct NumberWithLink *A, number *B)
// restores sizes of clauses from array B
{
  number Counter;
  
  for(Counter=0;Counter<NumberOfClauses;Counter++)
  {
    A[Counter].Number = B[Counter]; 
  }
}

////////////////////////////////////////////////////////////////////////
void SetNewValue(struct NumberWithLink *Formula, number Variable, number Value, number *y)
/*
 * Assign a value to a variable and update the formula accordingly.
 */
{
  number Counter, Counter1, Counter2, NumberToChange, C1;
  number NumberOfVarsInClause;
  number *Clause;
  struct MyList *ThisClause;
#ifdef _BIN_
  struct MyList *ThisBinClause;
  struct MyList *NewDualClauses = NULL; 
#endif

  Assign++;

  /* VariablesInClauses[Variable-1] is list of clauses with  
   * Variable 
   */
  
  ThisClause = VariablesInClauses[Variable-1];
  while(ThisClause!=NULL)
  {
    Counter1 = ThisClause->Number;
    
    /* Counter1 - number of current clause, 
     * Clause - current clause it self, 
     * NumberOfVarsInClause - size of current clause */
    
    Clause = Formula[Counter1].link;
    NumberOfVarsInClause = Formula[Counter1].Number;
    for(Counter2=0;Counter2<NumberOfVarsInClause;Counter2++) //search for +-Var
    {
      if(Clause[Counter2]==Variable) // +Variable \in Clause
      {
	      if(Value==1) { Formula[Counter1].Number = 0; break; } // remove Clause
        else
	      {
	  /* Delete only this variable */
          Formula[Counter1].Number--;
          NumberToChange = Clause[Counter2];
          Clause[Counter2] = Clause[Formula[Counter1].Number];      
          Clause[Formula[Counter1].Number] = NumberToChange;
          
          if(NumberOfVarsInClause==1){
	          Satisfied = 0; // now it's empty clause
          }
    	    else if(NumberOfVarsInClause==2) // now it's unit clause
	        {
	          UnitClauses[NumberOfUnitClauses]=Clause[0];
	          NumberOfUnitClauses++;
            tempAss[abs(Clause[0]) - 1] = 0; 
	        }
#ifdef _BIN_
          // now the clause is 2-clause, we put it to the list
          // and after we call incBinSat for all new bin clauses   
          else if(NumberOfVarsInClause==3){
            ThisBinClause         = (struct MyList *) malloc(sizeof(struct MyList));
            ThisBinClause->link   = NewDualClauses;
            ThisBinClause->Number = Counter1;          
            NewDualClauses        = ThisBinClause;
          }
#endif    
          break; // we are hoping there was only one occurrence of Variable
	      }
      }
      else
      {
        if(Clause[Counter2]==-Variable) // -Variable \in Clause
        {
          if(Value==0) { Formula[Counter1].Number=0; break; } // remove Clause
          else
	        {
	    /* Delete only this variable */
            Formula[Counter1].Number--;
            NumberToChange = Clause[Counter2];
            Clause[Counter2] = Clause[Formula[Counter1].Number];      
            Clause[Formula[Counter1].Number] = NumberToChange;
       
            if(NumberOfVarsInClause==1){
	            Satisfied = 0; // it's empty now
            } else if(NumberOfVarsInClause==2) // it's unit now
	          {
	            UnitClauses[NumberOfUnitClauses]=Clause[0];
	            NumberOfUnitClauses++;
              tempAss[abs(Clause[0]) - 1] = 0;
	          }
#ifdef _BIN_
          // now the clause is 2-clause, we put it to the list
          // and after we call incBinSat for all new bin clauses   
            else if(NumberOfVarsInClause==3){
              ThisBinClause         = (struct MyList *) malloc(sizeof(struct MyList));
              ThisBinClause->link   = NewDualClauses;
              ThisBinClause->Number = Counter1;          
              NewDualClauses        = ThisBinClause;
            }
#endif		    
            break; // we are hoping there was only one occurrence of Variable
          }
        }
      }
    }
    
    ThisClause = ThisClause->link;
  }
#ifdef _BIN_
// for all new clauses of size 2 call incBinSat
  ThisClause = NewDualClauses;

  while(ThisClause!=NULL){
    ThisBinClause = ThisClause->link;
    Clause = Formula[ThisClause->Number].link;
    incBinSat(Clause[0], Clause[1],Formula,y);
    free(ThisClause);
    ThisClause = ThisBinClause;
  }
#endif
}

////////////////////////////////////////////////////////////////////////////
// this function implement Unit Propagation - if exist unit clause
// we put value to variable to satisfy this unit clause
char PropUnit(struct NumberWithLink *Gi, number *y){
  number Opposite, Number, Unit,C1;

  if(NumberOfUnitClauses!=0){
    Opposite=0;
  //take unit clause from list by chance
    Number=random()%NumberOfUnitClauses;
    Unit=UnitClauses[Number];       
    
    NumberOfUnitClauses--;
    UnitClauses[Number]=UnitClauses[NumberOfUnitClauses];       
    
    // looking for other occurrence of this variable in unit clauses   
    for(C1=NumberOfUnitClauses-1; C1>=0; C1--)
      if(UnitClauses[C1]==-Unit){ 
        Opposite=1; 
        NumberOfUnitClauses--;
        UnitClauses[C1]=UnitClauses[NumberOfUnitClauses];       
      }
      else if(UnitClauses[C1]==Unit){
        NumberOfUnitClauses--;
        UnitClauses[C1]=UnitClauses[NumberOfUnitClauses];       
      }

      if(Opposite==0){
        if(Unit>0){
          United[Unit-1]=1;
          // set current value in variable and put it into formula
      	  if (y[Unit-1]==0) Flip++;
          y[Unit-1] = 1;
          SetNewValue(Gi, Unit, 1,y);
        }
        else{ //Unit<0
          United[-Unit-1]=1;
          // set current value in variable and put it into formula
      	  if (y[-Unit-1]==1) Flip++;
          y[-Unit-1] = 0;
          SetNewValue(Gi, -Unit, 0,y);  
        }
      }
       // Opposite == 1
      else
      {
        SetNewValue(Gi, abs(Unit), y[abs(Unit)-1],y);
        United[abs(Unit)-1]=1;
      }
    return 1;
  }

  return 0;
}
#ifdef _BIN_
////////////////////////////////////////////////////////////////////////////
// this is temporary Unit Propagation of literal Lit 
void incTempPropUnit(number Lit,struct NumberWithLink *Formula,number *PermanentAssignment){
  number Counter;
  struct MyList *ThisClause;
  number *Clause;
  
  // we have a conflict in temporary assigned variables 
  if(((tempAss[abs(Lit)-1]==-curTime)&&(Lit>0))||
     ((tempAss[abs(Lit)-1]==curTime)&&(Lit<0))){
      // we have a conflict in temporary assigned variables: 
      // there exist -Lit with time of assignment = current 

    UnitClauses[NumberOfUnitClauses] = Lit;
    NumberOfUnitClauses++;
    
    while(NumberOfUnitClauses!=0){
      PropUnit(Formula,PermanentAssignment);
    }
    return;
  }
  
  // add Lit to temporary assignment
  if(Lit>0)
    tempAss[abs(Lit)-1] = curTime;
  else
    tempAss[abs(Lit)-1] = -curTime;
   
  // for all clauses like (-Lit | y ) in Formula
  // call incTempPropUnit(y,Formula,PermanentAssignment);
       
  ThisClause = VariablesInClauses[abs(Lit)-1];

  while(ThisClause!=NULL)
  {
    Counter = ThisClause->Number;
 
    Clause = Formula[Counter].link;
    
    if(Formula[Counter].Number==2){//2clause

      if(Clause[0]==-Lit){
        if(Clause[1]>0){
          if(!(tempAss[Clause[1]-1]>0))
            incTempPropUnit(Clause[1],Formula,PermanentAssignment);
        }
        else{
          if(!(tempAss[-Clause[1]-1]<0))
            incTempPropUnit(Clause[1],Formula,PermanentAssignment);
        }  
      }
      else if(Clause[1]==-Lit){
        if(Clause[0]>0){
          if(!(tempAss[Clause[0]-1]>0))
            incTempPropUnit(Clause[0],Formula,PermanentAssignment);
        }
        else{
          if(!(tempAss[-Clause[0]-1]<0))
            incTempPropUnit(Clause[0],Formula,PermanentAssignment);
        }  
      }
    }
    
    ThisClause = ThisClause->link;
  }
}

////////////////////////////////////////////////////////////////////////////
// incremental algorithm for 2SAT: to Formula add new binary clause (Lit1 | Lit2) 
void incBinSat(number Lit1, number Lit2,struct NumberWithLink *Formula, number *PermanentAssignment){

// increase current time
  curTime++;
  
  while(NumberOfUnitClauses){
    PropUnit(Formula,PermanentAssignment);
  }

// if one of literals in new clause is temporary or permanent assigned
// do nothing
  if((United[abs(Lit1)-1])||(United[abs(Lit2)-1]))
    return;
  
  if((tempAss[abs(Lit1)-1]>0)&&(Lit1>0))
    return;
  if((tempAss[abs(Lit1)-1]<0)&&(Lit1<0))
    return;

  if((tempAss[abs(Lit2)-1]>0)&&(Lit2>0))
    return;
  if((tempAss[abs(Lit2)-1]<0)&&(Lit2<0))
    return;
  
// in other case temporary set true value to Lit1 
  incTempPropUnit(Lit1,Formula,PermanentAssignment);  
}
#endif
////////////////////////////////////////////////////////////////////////////
void Modify(struct NumberWithLink *Gi, number *pi, number *y) 
// one pass of a modified Paturi-Pudlak-Zane algorithm
{
  number Variable;
  number Counter,Number,Counter1,C1;
  number Unit;
  number TimesToReturn = 1;
#ifdef _BIN_
  struct MyList *ThisClause;
  number *Clause;
#endif
  number StartFlip;
  int Opposite; 
  // do we have the unit clause opposite to the chosen one?
  
  StartFlip=Flip;
  
  /*
   * PreUnitClauses is list of unit clauses that is premordialy in formula, 
   * UnitClauses is list of all unit clauses,
   * NumberOfUnitClauses and PreNumberOfUnitClauses - sizes of it 
   */
  NumberOfUnitClauses=PreNumberOfUnitClauses;

  /* United contains all variables that already have values */
  for(Counter=0;Counter<NumberOfVars;Counter++){
    tempAss[Counter] = 0;
      
    United[Counter]=0;
  }
  
  for(Counter=0;Counter<PreNumberOfUnitClauses;Counter++)
    UnitClauses[Counter] = PreUnitClauses[Counter];

#ifdef _BIN_
  // call incBinSat for all binary clauses that is in input formula
  ThisClause = PreDualClauses;

  curTime = 0;

  while(ThisClause!=NULL){
    Counter    = ThisClause->Number;
    Clause     = Gi[Counter].link;
    incBinSat(Clause[0], Clause[1],Gi,y);
    ThisClause = ThisClause->link;
  }

#endif

// main cycle when all variables are assigning
  for(Counter=0;Counter<NumberOfVars;Counter++)
  {
    // take variable with number from permutation
    Variable=pi[Counter];


    while(NumberOfUnitClauses){
      PropUnit(Gi,y);
    }
              
    // if we already work with this variable then we skip it 
  if(United[Variable-1]!=1)
#ifdef _BIN_
  {

  // before set variable some permanent value try to set it temporally
  // in hope to create during this conflict in temporary assignment
    if(y[Variable-1])
      incTempPropUnit(Variable,Gi,y);
    else
      incTempPropUnit(-Variable,Gi,y);
  
    while(NumberOfUnitClauses){
      PropUnit(Gi,y);
    }

    if(United[Variable-1]!=1)
#endif
    {
      SetNewValue(Gi, Variable, y[Variable-1],y);
      United[Variable-1]=1;
    }
#ifdef ___MYVAR_DEBUG___      

if(Flip>100) 
{
  FormulaOut(Gi);
  printf("\nUnit clauses:");
  for(C1=0; C1<NumberOfUnitClauses; C1++) printf("%d,",UnitClauses[C1]);
  printf("\n");
}
#endif
#ifdef _BIN_
  }
#endif
  }
  if (!Satisfied)
  if (StartFlip==Flip) 
  // then flip at random
  {
    number randvar;

    randvar=random()%NumberOfVars;
    y[randvar]=1-y[randvar];

 
#ifdef ___MYVAR_DEBUG___      
    if (NextOpposite!=0)
    {
      randvar=random()%NumberOfVars;
      y[randvar]=1-y[randvar];
    }
    else
    {
       printf("\n\nBUG%d\n\n",Flip);
       exit(-1);
    }			  
#endif

  }
}


number Search(struct NumberWithLink *Gi) 
// search for a satisfying assignment
{
number SizesOfClauses[NumberOfClauses];
number C, C1, C2, Number, Run, Period;
number pi[NumberOfVars];
number y[NumberOfVars];
number z[NumberOfVars];
number zh[NumberOfClauses];
number SizeOfNumber = sizeof(number);
time_t initime;
number ThisTry = 0;  
number AverageRun=0, AveragePeriod=0, AverageAssign=0, AverageFlip=0;
long microsec;  
struct timeval tv;
struct timezone tz;

//new time
struct tms buf;
struct tms bbuf;
times(&bbuf);

//fix initial moment of time
gettimeofday(&tv,&tz);
microsec = tv.tv_usec;
initime=time(NULL);
  
// SizesOfClauses is list of arrays sizes, we need thay to 
// quickly raise after algorithm flip   

UnitClauses=zh;

for(C=0;C<NumberOfClauses;C++) SizesOfClauses[C] = Gi[C].Number;
FAILS = 0;

SetPermutation(pi);  
GetRandomVector(y);
if((MaxPeriods=(NumberOfVars*p)/100)==0)
  MaxPeriods=NumberOfVars; 
  
if (!Quiet) printf("\n");

//--- Main Cycle ---


for (ThisTry=0; ThisTry<MaxTry; ThisTry++)
{ 
  if (MaxTry>0) if (!Quiet) printf("Try %d/%d...\n",ThisTry+1,MaxTry);
	
  for(Run=0, Assign=0, Flip=0; (Run<MaxRuns) && 
		  (time(NULL)<initime+MaxTime) && 
		  (Assign < MaxAssigns); Run++)
  {
    if (!Quiet) 
    { 
      printf("\x00d[%d:",Run); fflush(stdout); 
    }
    
    if (Run%2==0) 
    // get random vector or the reverse for the previous one
    {
      GetRandomVector(y);
      for(C1=0; C1<NumberOfVars; C1++) z[C1]=y[C1];
    }
    else 
      for(C1=0; C1<NumberOfVars; C1++) y[C1]=1-z[C1];


    for(Period=0; ((Period<MaxPeriods)||(p==-1))&&(time(NULL)<initime+MaxTime); Period++)
    {
    
      if (!Quiet) if (Period%25==0) 
      {
        printf("%c\x008",(Period%50==0)?'/':'\\'); 
        fflush(stdout);
      }

      if (aGiven) 
      { 
        printf("%ld,",dist(SatAssignment,y)); 
        fflush(stdout); 
      }
      
      SetEqual(Gi,SizesOfClauses); 
      GetRandomPermutation(pi);
      Satisfied=1;
      //suppose that the current assignment can be made satisfying
      //until we prove the opposite

#ifdef ___MYVAR_DEBUG___      
      printf("\n Current vector transformed to:\n");
    
      for(C1=0; C1<NumberOfVars; C1++)
        printf("%ld, ",y[C1]);
#endif
//      BinSat(Gi,y);
      Modify(Gi,pi,y); 
      //one pass of PPSZ

      if(p==-1) if (!Quiet) 
      { 
        printf("\x00d[%d:",Period); 
        fflush(stdout); 
      }

      if (Satisfied==1) 
      //found satisfying assignment
      {

        gettimeofday(&tv,&tz);
        times(&buf);

        SetEqual(Gi,SizesOfClauses); 
        if(!Satisfy(Gi,y)){
          printf("!!!!!!!!!!!!BUG!!!!!!!!!!!");
          exit(0);
        }
          
        
        if (aGiven) 
        { 
          printf("%ld",dist(SatAssignment,y)); 
          fflush(stdout); 
        }
    
        if (!Quiet) printf(" OK (Run=%ld,Period=%ld,Assigns=%ld,Flips=%ld,Time=%f,UserTime=%f,SysTime=%f)\n",
          Run+1,Period+1,Assign,Flip,
          (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
          ((float)buf.tms_utime+buf.tms_cutime - bbuf.tms_utime - bbuf.tms_cutime)/100,
          ((float)buf.tms_stime+buf.tms_cstime - bbuf.tms_stime - bbuf.tms_cstime)/100);

	
	      if (MaxTry==1) 
        //then also fprintf the assignment and this data
  	    {
          fprintf(outFile," v "); 
	        for(C1=0; C1<NumberOfVars; C1++) fprintf(outFile,"%ld",y[C1]);
	  
          fprintf(outFile,
	          "\n Run=%ld\n Period=%ld\n Assigns=%ld\n Flips=%ld\n Time=%f\n UserTime=%f\n SysTime=%f\n FAILS=%ld\n",
	          Run+1,Period+1,Assign,Flip,
	          (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
            ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/100,
            ((float)buf.tms_stime+buf.tms_cstime - bbuf.tms_stime - bbuf.tms_cstime)/100,
	        FAILS);
	      }

        AverageRun    += (Run+1);
        AveragePeriod += (Period+1);
        AverageAssign += Assign;
        AverageFlip   += Flip;
        MedianAssign[ThisTry] = Assign;
        MedianFlip[ThisTry] = Flip;

        Period=MaxPeriods+1; 
        Run=MaxRuns+1; 
        break; 
        //out of Period, Run cycles
      }

    } //(Period)

    if (aGiven) 
    { 
      printf("%ld\n",dist(SatAssignment,y)); 
      fflush(stdout); 
    }

  } //(Run)
 
  if (!Satisfied)
  {
    FAILS++;
    gettimeofday(&tv,&tz);
    times(&buf);
    if (!Quiet) printf(" FAIL (Run=%ld,Period=%ld,Assigns=%ld,Flips=%ld,Time=%f,UserTime=%f,SysTime=%f)\n",
          Run,Period,Assign,Flip,
          (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
          ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/100,
          ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/100);
    if (MaxTry==1) //then also fprintf the assignment and this data
    {
      fprintf(outFile," v ");
      for(C1=0; C1<NumberOfVars; C1++) fprintf(outFile,"%ld",y[C1]);

      fprintf(outFile,
	    "\n Run=%ld\n Period=%ld\n Assigns=%ld\n Flips=%ld\n Time=%f\n UserTime=%f\n SysTime=%f\n FAILS=%ld\n",
	    Run,Period,Assign,Flip,
	    (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
      ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/100,
      ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/100,
      FAILS);
    }
  }

} //(ThisTry)

//--- End Of Main Cycle ---

if (MaxTry>1) //printf and fprintf average data
{ 
  //fprintf the last satisfying assignment
  fprintf(outFile," v ");
  for(C1=0; C1<NumberOfVars; C1++) fprintf(outFile,"%ld",y[C1]);

  ThisTry -= FAILS;
    
  qsort(MedianAssign,MaxTry,sizeof(number),&compare);
  qsort(MedianFlip,MaxTry,sizeof(number),&compare);
  
  if(ThisTry!=0)
  {
    fprintf(outFile,"\n AverageRun=%f\n AveragePeriod=%f\n AverageAssigns=%ld\n AverageFlips=%ld\n MedianAssigns=%ld\n MedianFlips=%ld\n AverageTime=%f\n UserTime=%f\n SysTime=%f\n FAILS=%ld\n",
       (float)AverageRun/ThisTry, 
       (float)AveragePeriod/ThisTry, 
       AverageAssign/ThisTry, 
       AverageFlip/ThisTry,
       MedianAssign[MaxTry/2],
       MedianFlip[MaxTry/2],
       (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000)/ThisTry,
       ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/(ThisTry*100),
       ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/(ThisTry*100),
       FAILS);
  }
  else
  {
    fprintf(outFile,"\n MedianAssigns=%ld\n MedianFlips=%ld\n AverageTime=%f\n UserTime=%f\n SysTime=%f\n FAILS=%ld\n",
       Assign,
       Flip,
       (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
       ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/100,
       ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/100,
       FAILS);
  }                                                            

  if (!Quiet) 
    if(ThisTry!=0)
    {
      printf("AVERAGES: Run=%.2f,Period=%.2f,Assigns=%ld/%ld,Flips=%ld/%ld,Time=%f,UserTime=%f,SysTime=%f. FAILS=%ld)\n",
       (float)AverageRun/ThisTry, 
       (float)AveragePeriod/ThisTry,
       AverageAssign/ThisTry, 
       MedianAssign[MaxTry/2],
       AverageFlip/ThisTry,
       MedianFlip[MaxTry/2],
       (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000)/ThisTry, 
       ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/(ThisTry*100),
       ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/(ThisTry*100),
       FAILS);
    }
    else
    {
     printf("MEDIAN: Assigns=%ld,Flips=%ld,Time=%f,UserTime=%f,SysTime=%f. FAILS=%ld)\n",
      Assign,
      Flip,
      (time(NULL)-initime + (float)(tv.tv_usec - microsec)/1000000),
      ((float)buf.tms_utime+buf.tms_cutime- bbuf.tms_utime - bbuf.tms_cutime)/100,
      ((float)buf.tms_stime+buf.tms_cstime- bbuf.tms_stime - bbuf.tms_cstime)/100,
      FAILS);
    }                                          
}
      
FreeVariablesInClauses();
for(C=0;C<NumberOfClauses;C++) free(Gi[C].link);
    
return FAILS; 
}

