/********************************************************************
Implementation of algorithm UnitWalk 
by Edward A. Hirsch and Arist Kojevnikov, 2001.
This is a header file. 
*********************************************************************/
#ifdef _MPI_
#include "mpi.h"
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/time.h> 
#include <sys/times.h> 
#include <dirent.h>
#include <libgen.h>
#include <errno.h>

#define VERSION ("V0.944")

#ifndef __VariablesOFProgram__
#define __VariablesOFProgram__

typedef long number;

/*
 * Data structures :
 */

struct MyList **VariablesInClauses; 
/* 
Array of lists. VariablesInClauses[k-1] is a list of numbers of clauses 
containing variable x_k. Used for quick search for a clause containing x_k.
*/

int Satisfied; 
/* 
1, if we have satisfying assignment; 0 otherwise.  
*/

struct MyList *PreDualClauses; 
// list of numbers of 2-clauses in the input formula
number *tempAss;
// array of temporary assignment for variables at time of incBinSat
// size of this array is NumberOfVars and if tempAss[i] is non zero,
// then x_i variable have temporary value ("true" if tempAss[i]>0 or 
// false of tempAss[i]<0). abs(tempAss[i]) is the time when the variable
// was set
number curTime;
// current time, increase by 1 with every call of incBinSat function
number *United;
// array of permanent assigned variables 
  

number *PreUnitClauses; 
number PreNumberOfUnitClauses; 
/*
PreUnitClauses is a list of numbers of unit clauses in the input formula.
PreNumberOfUnitClauses is the size of PreUnitClauses.
*/

number *SatAssignment; 
// satisfying assignment, if we know it before the execution

number NumberOfVars; 
// maximal number of a variable in the current formula

number NumberOfClauses; 
// number of clauses in the current formula

number I; 
// runs limit

number T; 
// time limit

number A; 
// assignments limit

number MaxPeriods; 
// max periods per run

number p; 
// MaxPeriods = NumberOfVariables * p / 100 

number Flip; 
// number of flips made so far for one try

number Assign ; 
// number of assignments made so far for one try

number *MedianFlip; 
// total number of flips for for all tries

number *MedianAssign; 
// total number of assignments for for all tries

int Quiet; 
// be quiet

int aGiven; 
// -a given in command line

number MaxTry; 
// tries limit 

number FAILS; 
// number of failures

FILE *outFile; 
// output file

FILE *inFile;  
// input file

struct NumberWithLink{ 
// a clause: its size and array of literals
number Number;
number *link;};

struct MyList{ 
// list of clause numbers
number Number;
struct MyList *link;};

#endif

/* 
 * Functions for work with random strings : 
 */

#ifndef __SetPermutation__
#define __SetPermutation__
void SetPermutation(number *Permutation);
 // fill the trivial permutation 

#endif
void GetRandomPermutation(number *Permutation); 
// random permutation of 1..n

void GetRandomVector(number *Vector); 
// random vector from {0,1}^NumberOfVars 

/*
 * I/O functions :
 */

void OutVariablesInClauses(void); 
// debug info: prints VariablesInClauses[]

void FreeVariablesInClauses(); 
// frees memory from VariablesInClauses[]

// The next three functions read a formula from a file.
number WorkWithCNF(); 
void WorkWithFile(char *InputFile); 

int listdir(char *dirname); 
// runs WorkWithFile for dirname/*.cnf 

/*
 * Main program :
 */

int main(int argc,char *argv[]); 
// main program

number Search(struct NumberWithLink *Gi); 
// algorithm itself
void incBinSat(number Lit1, number Lit2,struct NumberWithLink *Gi, number *y);
